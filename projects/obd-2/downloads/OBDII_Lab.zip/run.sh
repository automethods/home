#!/bin/sh
# Source-package launcher. The separate Drive download is self-contained.
# Use: bash run.sh [--port 8766] [--no-browser]
set -eu
obdii_lab_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
cd -- "$obdii_lab_dir"
if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' 'Python 3.10 or newer is needed to run the simulator.' >&2
    printf '%s\n' 'Install Python 3, then run: bash run.sh' >&2
    exit 1
fi
if [ ! -f launcher.py ]; then
    printf '%s\n' 'Extract all files from OBDII_Lab.zip before starting this source copy.' >&2
    printf '%s\n' 'For a single-file download, use the standalone run.sh in the Drive OBDII folder.' >&2
    exit 1
fi
export PYTHONDONTWRITEBYTECODE=1
exec python3 -u launcher.py "$@"
