#!/usr/bin/env python3
"""Run the local learning lab, either from source or the bundled launcher."""
import sys

if sys.version_info < (3, 10):
    print("Python 3.10 or newer is required. Found Python " + sys.version.split()[0] + ".", file=sys.stderr)
    print("Install a newer Python 3, then run: bash run.sh", file=sys.stderr)
    raise SystemExit(1)

import argparse
import errno
import os
import signal
import threading
import time
import urllib.error
import urllib.request
import webbrowser


def main():
    parser = argparse.ArgumentParser(prog="run.sh", description="Start the OBD II Lab on this computer.")
    parser.add_argument("--port", type=int, default=8765, help="local port (default: 8765)")
    parser.add_argument("--no-browser", action="store_true", help="start without opening a browser tab")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("choose a port from 1024 to 65535, for example --port 8766")

    try:
        from obdii_lab import __version__
        from obdii_lab.server import create_server
        server = create_server(args.port)
    except OSError as exc:
        if exc.errno == errno.EADDRINUSE:
            print("Port " + str(args.port) + " is already in use.", file=sys.stderr)
            print("Close the previous simulator or choose another port, for example:", file=sys.stderr)
            print("  bash run.sh --port " + str(8766 if args.port != 8766 else 8767), file=sys.stderr)
        else:
            print("Could not start the local simulator: " + str(exc), file=sys.stderr)
        return 1
    except ImportError as exc:
        print("Could not load the simulator: " + str(exc), file=sys.stderr)
        print("Download a fresh standalone run.sh or extract all of OBDII_Lab.zip.", file=sys.stderr)
        return 1

    url = "http://127.0.0.1:" + str(server.server_port)
    print("\nOBD II Lab v" + __version__)
    print("Open " + url + " in your browser.")
    print("Keep this terminal open. Press Ctrl+C here to stop the simulator.\n")

    def open_when_ready():
        # Contact this newly bound server directly, without system HTTP proxies.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            try:
                with opener.open(url + "/api/meta", timeout=0.5) as response:
                    if response.status == 200:
                        break
            except (urllib.error.URLError, OSError):
                time.sleep(0.1)
        else:
            print("Open the vehicle workspace manually at " + url)
            return
        try:
            opened = webbrowser.open(url, new=2)
        except (webbrowser.Error, OSError):
            opened = False
        if not opened:
            print("The browser did not open automatically. Open " + url + " manually.")

    def stop_requested(_signum, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, stop_requested)
    try:
        if not args.no_browser and (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or os.environ.get("BROWSER")):
            threading.Thread(target=open_when_ready, daemon=True).start()
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nLab stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
