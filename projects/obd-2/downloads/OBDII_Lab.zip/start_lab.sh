#!/bin/sh
# Keep the original launcher name working with the Linux Mint launcher.
obdii_lab_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
exec sh "$obdii_lab_dir/run.sh" "$@"
