/* Setup/cycle v0.8 integration: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_setup_cycle_v08.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;const failures=[];
async function test(name,fn){if(process.env.OBD_TEST_FILTER&&!new RegExp(process.env.OBD_TEST_FILTER,'i').test(name))return;try{await fn();passed++;console.log('PASS '+name);}catch(error){failures.push({name,error});console.error('FAIL '+name+'\n'+error.stack);}}
async function main(){
 const server=await startServer();let app;
 try{
  const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
  document.readyState='interactive';await document.dispatchEvent(new CustomEvent('DOMContentLoaded'));
  app=window.VehicleApplication;assert.ok(app);await app.ready;await flush();
  const session=app.session,state=()=>session.result.state;
  const settle=async()=>{await session.command;await waitFor(()=>session.pending===0&&Object.values(app.views).every(v=>!v.inspect?.().pending),'All foreground view commands settle');await flush();};
  const click=async selector=>{const node=$(selector);assert.equal(node.disabled,false,'Control is enabled: '+selector);await node.click();await settle();};
  const change=async(selector,value)=>{const node=$(selector);node.value=String(value);await node.dispatchEvent({type:'change'});await settle();};
  const check=async(selector,value)=>{const node=$(selector);node.checked=value;await node.dispatchEvent({type:'change'});await settle();};
  const input=async(selector,value)=>{const node=$(selector);node.value=String(value);await node.dispatchEvent({type:'input'});await settle();};
  const setup=async(config='petrol_basic',hardware={},settings={mode:'manual',road_mu:.9,grade_pct:0})=>{await session.setup(config,hardware,settings);await settle();};
  const raw=async(url,body)=>{const response=await fetch(baseURL+url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {ok:response.ok,status:response.status,data:await response.json()};};
  const api=async(url,body)=>{const response=await session.api(url,body);session.apply(response);await settle();return response;};
  const close=(a,b,description,tolerance=1e-7)=>assert.ok(Math.abs(a-b)<=tolerance,description+': '+a+' vs '+b);
  const startAutomatic=async()=>{await session.control('ignition',true);await session.control('start');await session.advance(1);await settle();};
  const beginCycle=async()=>{await setup('petrol_basic',{}, {mode:'wltc_class3b',road_mu:.9,grade_pct:0});await click('[data-action="start-cycle"]');};

  await test('boot opens the vehicle stage with two operational workspaces, official preview and a parked model',async()=>{
   assert.deepEqual(Array.from(document.querySelectorAll('[data-workspace]'),n=>n.dataset.workspace),['drive','service']);assert.equal(session.context().workflow.stage,'vehicle');
   assert.equal(session.view,'setup');assert.equal($('#view-setup').hidden,false);assert.equal($('#view-drive').hidden,true);
   assert.equal(state().t,0);assert.equal(state().rpm,0);assert.equal(state().vehicle.ignition,'off');assert.equal(state().vehicle.selector,'P');
   assert.equal(session.testSettings.mode,'wltc_class3b');assert.equal($('[data-setup="driving_mode"]').value,'wltc_class3b');
   const cycle=session.meta.drive_cycles.find(c=>c.id==='wltc_class3b');assert.equal(cycle.preview.length,181);assert.equal(cycle.duration_s,1800);
   assert.equal(cycle.preview[0][0],0);assert.equal(cycle.preview.at(-1)[0],1800);assert.ok($('[data-setup="cycle-preview"]').querySelector('polyline'));
   assert.equal(requests.filter(r=>r.url==='/api/vehicle').length,1);assert.equal([...timers.values()].filter(t=>t.ms===100).length,0);
  });

  await test('Setup stages compatible manual hardware, unfit ABS/ESP and actual road conditions',async()=>{
   session.beginSetup();await settle();await change('[data-setup="configuration"]','petrol_advanced');
   await change('[data-setup="transmission_type"]','manual_6');
   assert.equal($('[data-setup="driving_mode"]').value,'manual');assert.equal($('[data-setup="driving_mode"] option[value="wltc_class3b"]').disabled,true);
   await check('[data-setup="esp_installed"]',true);assert.equal($('[data-setup="abs_installed"]').checked,true);
   await check('[data-setup="abs_installed"]',false);assert.equal($('[data-setup="esp_installed"]').checked,false);
   await change('[data-setup="drivetrain"]','rwd');await change('[data-setup="mass_kg"]',1640);await change('[data-setup="wheel_radius_mm"]',330);
   await change('[data-setup="drag_area_m2"]',.74);await change('[data-setup="rolling_resistance"]',.014);await change('[data-setup="ambient_c"]',5);
   await change('[data-setup="surface"]',.55);await change('[data-setup="grade_pct"]',4);
   assert.equal(state().vehicle.configuration.id,'petrol_basic','Unapplied edits must not change the vehicle');
   await click('[data-setup-action="apply"]');assert.equal(session.context().workflow.stage,'workspace');await click('[data-workspace-choice="service"]');
   const c=state().vehicle.configuration;assert.equal(session.view,'diagnostics');assert.equal(state().t,0);assert.equal(c.id,'petrol_advanced');
   assert.equal(c.transmission_type,'manual_6');assert.equal(c.drivetrain,'rwd');assert.equal(c.mass_kg,1640);close(c.wheel_radius_m,.33,'Wheel radius applied');
   assert.equal(c.drag_area_m2,.74);assert.equal(c.rolling_resistance,.014);assert.equal(c.abs_installed,false);assert.equal(c.esp_installed,false);
   assert.equal(state().vehicle.selector,'N');assert.equal(state().vehicle.ignition,'off');assert.equal(state().inputs.road_mu,.55);assert.equal(state().inputs.grade_pct,4);
   assert.equal(session.inputs.road_mu,.55);assert.equal(session.inputs.grade_pct,4);assert.equal(session.testSettings.mode,'manual');
   assert.equal(session.systems.units.find(u=>u.id==='abs').installed,false);
   await click('[data-action="service-ignition"]');assert.equal(state().vehicle.ignition,'on');assert.equal(state().rpm,0);assert.equal(state().vehicle.start_state,'ignition_on');assert.equal(state().t,0);
   await click('[data-workspace="drive"]');assert.equal(session.view,'drive');assert.equal($('[data-ck="clutch-pedal"]').hidden,false);
   await session.reset();await settle();assert.equal(state().inputs.road_mu,.55);assert.equal(state().inputs.grade_pct,4);assert.equal(state().t,0);
  });

  await test('manual clutch-assisted Start stages a real clutch interlock then restores it while cranking',async()=>{
   await setup('petrol_basic',{transmission_type:'manual_6'});
   await click('[data-ck-action="ignition"]');assert.equal(state().vehicle.selector,'N');assert.equal(session.inputs.clutch,0);
   assert.equal($('[data-ck-action="start"]').disabled,true);assert.equal($('[data-ck-action="start-assist"]').hidden,false);
   const before=state().t,first=requests.length;await click('[data-ck-action="start-assist"]');
   const commands=requests.slice(first).filter(r=>r.url==='/api/control'||r.url==='/api/inputs');
   assert.equal(commands[0].url,'/api/control');assert.equal(commands[0].body.action,'start');assert.equal(commands[0].body.inputs.clutch,1);
   assert.equal(commands.at(-1).url,'/api/inputs');assert.equal(commands.at(-1).body.inputs.clutch,0);
   assert.equal(state().t,before);assert.equal(state().inputs.clutch,0);assert.equal(session.inputs.clutch,0);assert.equal(state().vehicle.start_state,'cranking');
   await session.advance(1);await settle();assert.equal(state().vehicle.start_state,'running');assert.ok(state().rpm>500);assert.equal(state().inputs.clutch,0);
   assert.match($('[data-ck="start-note"]').textContent,/clutch/i);
  });

  await test('BEV Setup restricts transmission, removes unfitted HVAC and protects API compatibility',async()=>{
   session.beginSetup();await settle();await change('[data-setup="configuration"]','bev');
   assert.deepEqual(Array.from($('[data-setup="transmission_type"]').querySelectorAll('option'),n=>n.value),['single_speed']);
   assert.equal($('[data-setup="engine_detail"]').disabled,true);assert.equal($('[data-setup="cylinders"]').disabled,true);assert.equal($('[data-setup="heater_type"]').value,'electric');
   await check('[data-setup="hvac_installed"]',false);assert.equal($('[data-setup="ac_installed"]').checked,false);assert.equal($('[data-setup="ac_installed"]').disabled,true);
   await change('[data-setup="driving_mode"]','wltc_class3b');await click('[data-setup-action="apply"]');
   assert.equal(state().vehicle.configuration.powertrain,'bev');assert.equal(state().vehicle.configuration.hvac_installed,false);assert.equal(state().vehicle.hvac.installed,false);assert.equal($('[data-ck="climate"]').hidden,true);
   const rejected=await raw('/api/vehicle',{configuration:'bev',options:{transmission_type:'manual_6'}});assert.equal(rejected.ok,false);assert.match(rejected.data.error,/transmission/i);
   const actual=await session.api('/api/state');assert.equal(actual.state.vehicle.configuration.powertrain,'bev');assert.equal(actual.state.vehicle.configuration.transmission_type,'single_speed');
  });

  await test('cabin A/C controls change cooling, engine load and accumulated energy in the same model',async()=>{
   await setup('petrol_basic',{ambient_c:35,initial_coolant_c:35,hvac_installed:true,ac_installed:true});await startAutomatic();
   assert.equal($('[data-ck="climate"]').hidden,false);const initial=state().vehicle.hvac.cabin_c;
   await click('[data-ck-action="climate-power"]');await change('[data-ck="climate-target"]',16);await change('[data-ck="climate-fan"]',100);await check('[data-ck="climate-ac"]',true);
   await session.advance(10);await settle();const h=state().vehicle.hvac;
   assert.equal(h.enabled,true);assert.equal(h.setpoint_c,16);assert.equal(h.fan,1);assert.ok(h.cooling_kw>0);assert.ok(h.shaft_load_kw>0);assert.ok(h.energy_kwh>0);assert.ok(h.cabin_c<initial);
   assert.ok(state().engine_shaft_kw>=h.shaft_load_kw);assert.match($('[data-ck="climate-load"]').textContent,/kW engine/);assert.equal($('[data-ck="cabin-temperature"]').textContent,h.cabin_c.toFixed(1)+' °C');
   await click('[data-ck-action="climate-power"]');await session.advance(.2);await settle();assert.equal(state().vehicle.hvac.cooling_kw,0);assert.equal(state().vehicle.hvac.shaft_load_kw,0);
  });

  await test('electric cabin heating consumes traction energy and does not fabricate an engine',async()=>{
   await setup('bev',{ambient_c:0,hvac_installed:true,ac_installed:true});await startAutomatic();
   const initialSOC=state().soc_pct;await click('[data-ck-action="climate-power"]');await change('[data-ck="climate-target"]',30);await change('[data-ck="climate-fan"]',100);
   await session.advance(5);await settle();const h=state().vehicle.hvac;
   assert.equal(state().vehicle.ready,true);assert.equal(state().rpm,0);assert.equal(state().energy.fuel_l,0);assert.ok(h.heat_kw>0);assert.ok(h.electrical_kw>0);assert.equal(h.shaft_load_kw,0);assert.ok(h.energy_kwh>0);assert.ok(h.cabin_c>0);assert.ok(state().soc_pct<initialSOC);
   assert.match($('[data-ck="climate-heater"]').textContent,/Electric/);assert.doesNotMatch($('[data-ck="climate-load"]').textContent,/engine/);
  });

  await test('manual transmission cannot enter the automatic drive cycle through the API',async()=>{
   await setup('diesel',{transmission_type:'manual_6'});const before=state().t;
   assert.equal($('[data-action="start-cycle"]').disabled,true);
   const rejected=await raw('/api/cycle',{action:'start',name:'wltc_class3b'});assert.equal(rejected.ok,false);assert.match(rejected.data.error,/automatic transmission/i);
   const actual=await session.api('/api/state');assert.equal(actual.state.t,before);assert.equal(actual.state.vehicle.ignition,'off');assert.equal(actual.state.vehicle.selector,'N');
  });

  await test('WLTC starts the engine and records distinct target/actual samples on the one simulation clock',async()=>{
   await beginCycle();assert.equal(state().t,0);assert.equal(state().drive_cycle.status,'preparing');assert.equal(state().vehicle.ignition,'on');assert.equal(state().vehicle.start_state,'cranking');assert.equal(session.running,true);
   assert.equal($('[data-ck="throttle"]').disabled,true);assert.equal($('[data-ck-gear="D"]').disabled,true);assert.ok(session.watch.includes('drive_target_kph'));
   const clocks=[...timers.entries()].filter(([,t])=>t.ms===100);assert.equal(clocks.length,1);timers.delete(clocks[0][0]);await clocks[0][1].fn();await settle();close(state().t,.1,'One clock advances one tenth');
   await session.advance(45);await settle();close(state().t,45.1,'Single clock after explicit advance');assert.equal(state().drive_cycle.status,'active');assert.equal(state().vehicle.selector,'D');assert.equal(state().vehicle.parking_brake,false);assert.ok(state().rpm>500);assert.ok(state().speed_kph>5);
   const samples=session.history.filter(s=>s.drive_cycle?.status==='active');assert.ok(samples.length>10);assert.ok(samples.some(s=>s.drive_target_kph>5));assert.ok(samples.some(s=>Math.abs(s.drive_target_kph-s.speed_kph)>.01));
   for(const sample of samples){close(sample.drive_cycle.actual_speed_kph,sample.speed_kph,'Historical actual matches its own sample');close(sample.drive_cycle.tracking_error_kph,sample.drive_target_kph-sample.speed_kph,'Historical tracking error');}
   for(let i=1;i<session.history.length;i++)assert.ok(session.history[i].t>session.history[i-1].t,'History clock is strictly increasing');
   close(Number($('#cycle-actual').textContent),state().speed_kph,'Actual UI readout',.11);close(Number($('#cycle-target').textContent),state().drive_target_kph,'Target UI readout',.11);
   assert.match(session.logCSV(),/drive_target_kph/);assert.ok(session.logHistory.some(s=>s.drive_target_kph>0));assert.equal([...timers.values()].filter(t=>t.ms===100).length,0);
  });

  await test('cycle owns pedals and gears while HVAC stays available; takeover restores manual control without a time jump',async()=>{
   await beginCycle();await session.advance(25);await settle();const before=state().t,gear=state().vehicle.selector;
   const refused=await raw('/api/control',{action:'gear',value:'R',inputs:{throttle:0,brake:1}});assert.equal(refused.ok,false);assert.match(refused.data.error,/Take over/i);
   const oldPedals={throttle:state().inputs.throttle,brake:state().inputs.brake,steer_deg:state().inputs.steer_deg};
   await api('/api/inputs',{inputs:{throttle:1,brake:1,steer_deg:7}});assert.equal(state().t,before);assert.equal(state().vehicle.selector,gear);
   for(const key of Object.keys(oldPedals))close(state().inputs[key],oldPedals[key],'Virtual driver retains '+key);
   await click('[data-ck-action="climate-power"]');assert.equal(state().vehicle.hvac.enabled,true);assert.equal(state().drive_cycle.status,'active');
   await click('[data-action="stop-cycle"]');assert.equal(state().t,before);assert.equal(state().drive_cycle.status,'stopped');assert.equal(session.running,false);assert.equal(state().inputs.throttle,0);assert.equal(state().inputs.brake,0);assert.equal($('[data-ck="throttle"]').disabled,false);
   await input('[data-ck="throttle"]',30);await session.advance(1);await settle();assert.equal(state().inputs.throttle,.3);assert.equal(state().drive_cycle.status,'stopped');assert.equal(state().drive_target_kph,null);assert.equal(state().vehicle.selector,gear);
  });

  await test('legacy ignition input cannot leave the cycle owning a silently disabled vehicle',async()=>{
   for(const endpoint of ['/api/inputs','/api/advance']){
    await beginCycle();await session.advance(2);await settle();const before=state().t;
    const seconds=endpoint==='/api/advance'?.1:0;
    const invalid=await raw(endpoint,{...(seconds?{seconds}:{}),inputs:{ignition:false,throttle:'invalid'}});assert.equal(invalid.ok,false);
    const unchanged=await session.api('/api/state');assert.equal(unchanged.state.vehicle.ignition,'on');assert.equal(unchanged.state.drive_cycle.status,'active');assert.equal(unchanged.state.t,before);
    const response=await raw(endpoint,{...(seconds?{seconds}:{}),inputs:{ignition:false}});
    const actual=await session.api('/api/state');session.apply(actual);await settle();close(actual.state.t,before+(response.ok?seconds:0),'Legacy command time through '+endpoint);
    if(response.ok)assert.ok(actual.state.vehicle.ignition==='on'||!['preparing','active','complete','fault'].includes(actual.state.drive_cycle?.status),'An accepted ignition-off request must hand control back, not leave the virtual driver active with ignition off ('+endpoint+')');
    else assert.match(response.data.error,/cycle|driver|ignition|control|Take over/i);
   }
  });

  await test('recorded OBD capability exchange explains decimal addresses, byte roles and supported parameters',async()=>{
   await setup();await startAutomatic();await session.scannerAction('connect',{protocol:'can11_500',module:'ecu'});const sampledAt=state().t;await session.request('01 00');await settle();
   const d=session.diagnostic;assert.equal(d.request_hex,'01 00');assert.match(d.response_hex,/^41 00 /);assert.equal(state().t,sampledAt);
   const request=session.records.find(r=>r.frame?.id==='7DF'),response=session.records.find(r=>r.frame?.id==='7E8');assert.ok(request&&response);
   assert.equal(window.MessageInspector.address('7DF').number,2015);assert.equal(window.MessageInspector.address('7E8').number,2024);
   await click('[data-workspace="service"]');await click('[data-service-view="diagnostics"]');await click('[data-dock="messages"]');await click('[data-message="'+request.number+'"]');
   const tx=$('#message-detail').textContent;assert.match(tx,/2015 decimal/);assert.match(tx,/Functional OBD request/);assert.match(tx,/Service 1/);assert.match(tx,/PID 0/);assert.match(tx,/application bytes after this header/);assert.match(tx,/not a sensor reading/);
   await click('[data-message="'+response.number+'"]');const rx=$('#message-detail').textContent;assert.match(rx,/2024 decimal/);assert.match(rx,/Engine ECU response/);assert.match(rx,/capability list/);assert.match(rx,/Engine speed/);assert.match(rx,/12 \/ 0x0C/);assert.match(rx,/Engine coolant temperature/);assert.match(rx,/does not say whether a sensor is healthy/);
   assert.equal($('#message-detail').querySelectorAll('.mi-bit-grid span').length,32);assert.equal(window.MessageInspector.outcome(d).label,'Positive reply');
  });

  await test('unplugged DLC produces a real no-reply explanation without inventing data bytes',async()=>{
   await session.connection('dlc',false);await session.request('01 0C');await settle();
   assert.equal(session.diagnostic.response_hex,null);assert.equal(session.diagnostic.frames.length,0);assert.equal(window.MessageInspector.outcome(session.diagnostic).label,'No reply');
   const record=session.records.at(-1);assert.equal(record.frame,null);await click('[data-message="'+record.number+'"]');const panel=$('#message-detail');
   assert.match(panel.textContent,/NO DELIVERED FRAME/);assert.match(panel.textContent,/No reply/i);assert.equal(panel.querySelector('.mi-byte-detail'),null);assert.equal(panel.querySelector('.mi-address'),null);
   await session.connection('dlc',true);await session.request('01 0C');await settle();assert.match(session.diagnostic.response_hex,/^41 0C /);
   assert.deepEqual(errors,[]);assert.equal($('#application-error').hidden,true);assert.ok([...timers.values()].filter(t=>t.ms===100).length<=1);
  });

  console.log(`${passed} v0.8 Setup/cycle contracts passed; ${failures.length} failed. Actual Python HTTP + parsed DOM + CPU Canvas; native event/layout/GPU behavior is not covered.`);
  if(failures.length)process.exitCode=1;
 } finally {if(app){app.dispose();await app.session.command;}server.child.kill('SIGTERM');server.lines.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
