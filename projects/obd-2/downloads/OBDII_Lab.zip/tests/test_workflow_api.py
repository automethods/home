"""A staged vehicle change returns its UI resources or preserves the old run."""
from __future__ import annotations

import json
import threading
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.server import Lab, create_server


class WorkflowApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None):
        request = Request(self.base + path, data=None if body is None else json.dumps(body).encode(),
                          headers={"Content-Type": "application/json"})
        with urlopen(request, timeout=10) as response:
            def invalid_constant(value):
                raise AssertionError("Non-finite JSON: " + value)
            return json.loads(response.read(), parse_constant=invalid_constant)

    def setUp(self):
        self.call("/api/vehicle", {"configuration": "petrol_advanced"})

    def seed_recorded_fault(self):
        """Leave meaningful history, fault memory and a connected diagnostic session."""
        self.call("/api/control", {"action": "ignition", "value": True})
        self.call("/api/control", {"action": "start"})
        self.call("/api/advance", {"seconds": 1.6})
        self.call("/api/scanner", {"action": "connect"})
        self.call("/api/diagnostic", {"payload": "10 03", "can_id": "7E0"})
        self.call("/api/connection", {"id": "maf", "connected": False})
        self.call("/api/advance", {"seconds": .8, "inputs": {"throttle": .3}})
        self.call("/api/diagnostic", {"payload": "03"})
        state = self.call("/api/state")
        exported = self.call("/api/export.json")
        self.assertIn("P0102", state["state"]["dtcs"])
        self.assertGreater(len(exported["history"]), 1)
        self.assertGreater(len(exported["events"]), 0)
        self.assertEqual(len(exported["diagnostics"]), 2)
        self.assertEqual(state["scanner"]["status"], "ready")
        return self.remember_session(state, exported)

    def remember_session(self, state=None, exported=None):
        return {"state": state or self.call("/api/state"),
                "export": exported or self.call("/api/export.json"),
                "objects": {name: getattr(self.server.lab, name)
                            for name in ("lock", "sim", "diag", "scanner", "cycle", "trace")}}

    def assert_session_unchanged(self, before):
        self.assertEqual(self.call("/api/state"), before["state"])
        self.assertEqual(self.call("/api/export.json"), before["export"])
        for name, original in before["objects"].items():
            self.assertIs(getattr(self.server.lab, name), original, name)

    def assert_rejected(self, body):
        with self.assertRaises(HTTPError) as caught:
            self.call("/api/vehicle", body)
        self.assertEqual(caught.exception.code, 400)
        self.assertTrue(json.load(caught.exception)["error"])

    def test_vehicle_response_contains_matching_complete_resources_for_each_powertrain(self):
        before = self.seed_recorded_fault()
        routes = {"meta": "/api/meta", "catalog": "/api/network",
                  "definitions": "/api/diagnostic-definitions", "systems": "/api/systems",
                  "scanner": "/api/scanner"}
        cases = [
            ("petrol_basic", {"transmission_type": "manual_6", "hvac_installed": False}),
            ("petrol_advanced", {"cylinders": 6, "can_bitrate": 250000, "drivetrain": "rwd"}),
            ("diesel", {"abs_installed": False}),
            ("hev", {"drivetrain": "awd", "ac_installed": False}),
            ("phev", {"initial_soc_pct": 45, "ambient_c": -10}),
            ("bev", {"initial_soc_pct": 80}),
        ]
        for configuration, options in cases:
            with self.subTest(configuration=configuration):
                response = self.call("/api/vehicle", {"configuration": configuration, "options": options,
                                                      "initial_inputs": {"road_mu": .6, "grade_pct": 2.5}})
                resources = response["resources"]
                self.assertEqual(set(resources), set(routes))
                for resource, route in routes.items():
                    self.assertEqual(resources[resource], self.call(route), resource)
                self.assertEqual({key: value for key, value in response.items() if key != "resources"},
                                 self.call("/api/state"))
                state = response["state"]
                self.assertEqual(state["configuration_id"], configuration)
                self.assertEqual(state["t"], 0)
                self.assertEqual(state["inputs"]["road_mu"], .6)
                self.assertEqual(state["inputs"]["grade_pct"], 2.5)
                self.assertEqual(state["vehicle"]["start_state"], "off")
                self.assertEqual(state["dtcs"], [])
                self.assertTrue(all(state["connections"].values()))
                self.assertEqual(response["history"], [state])
                self.assertEqual(response["scanner"], resources["scanner"]["state"])
                self.assertEqual(response["scanner"]["status"], "disconnected")
                self.assertEqual(resources["systems"]["configuration"]["id"], configuration)
                self.assertEqual(resources["definitions"]["runtime"]["configuration_id"], configuration)
                self.assertEqual({wire["id"] for wire in resources["catalog"]["wires"]},
                                 set(response["network"]["wires"]))
                signals = {signal["id"]: signal for signal in resources["meta"]["signals"]}
                self.assertEqual(signals["rpm"]["installed"], configuration != "bev")
                self.assertEqual(self.call("/api/export.json")["diagnostics"], [])
                self.assertIs(self.server.lab.lock, before["objects"]["lock"])
                self.assertIsNot(self.server.lab.sim, before["objects"]["sim"])

    def test_invalid_hardware_preserves_previous_state_log_and_fault_memory(self):
        before = self.seed_recorded_fault()
        cases = [
            {"configuration": "missing"},
            {"configuration": "bev", "options": {"transmission_type": "manual_6"}},
            {"options": []},
            {"options": {"abs_installed": False, "esp_installed": True}},
            {"options": {"hvac_installed": False, "ac_installed": True}},
            {"options": {"mass_kg": -1}},
            {"options": {"can_bitrate": 12345}},
            {"options": {"unrecognized_hardware": True}},
        ]
        for body in cases:
            with self.subTest(body=body):
                self.assert_rejected(body)
                self.assert_session_unchanged(before)

    def test_invalid_initial_conditions_preserve_previous_state_log_and_fault_memory(self):
        before = self.seed_recorded_fault()
        cases = [[], {"throttle": .5}, {"grade_pct": 13}, {"road_mu": 0},
                 {"road_mu": "0.5"}, {"road_mu": True}, {"grade_pct": None},
                 {"road_mu": float("nan")}, {"grade_pct": float("inf")}]
        for inputs in cases:
            with self.subTest(inputs=inputs):
                self.assert_rejected({"configuration": "bev", "initial_inputs": inputs})
                self.assert_session_unchanged(before)

    def test_resource_preparation_failure_does_not_commit_the_candidate(self):
        before = self.seed_recorded_fault()
        with patch.object(Lab, "resources", side_effect=ValueError("Vehicle resources unavailable")):
            self.assert_rejected({"configuration": "bev"})
        self.assert_session_unchanged(before)

    def test_non_serializable_response_does_not_commit_the_candidate(self):
        before = self.seed_recorded_fault()
        with patch.object(Lab, "resources", return_value={"meta": {"invalid": float("nan")}}):
            self.assert_rejected({"configuration": "bev"})
        self.assert_session_unchanged(before)

    def test_invalid_vehicle_change_keeps_active_drive_cycle_and_its_history(self):
        self.call("/api/cycle", {"action": "start"})
        self.call("/api/advance", {"seconds": 2})
        before = self.remember_session()
        self.assertEqual(before["state"]["state"]["drive_cycle"]["status"], "active")
        self.assert_rejected({"configuration": "bev", "initial_inputs": {"road_mu": -1}})
        self.assert_session_unchanged(before)


if __name__ == "__main__":
    unittest.main()
