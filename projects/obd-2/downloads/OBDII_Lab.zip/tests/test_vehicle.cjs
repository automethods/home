/* Optional Node built-in checks for the actual GLB reader and wheel bindings.
 * This does not verify browser layout or GPU pixels. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');
let now=0; const frames=[],events={};
const context2d=new Proxy({createLinearGradient:()=>({addColorStop(){}})}, {get:(target,key)=>key in target?target[key]:()=>{}});
class Element {
  constructor(){this.children=[];this.map=new Map();this.events={};this.style={};this.dataset={};this.classList={add(){},remove(){},toggle(){}};this.clientWidth=660;this.clientHeight=330;this.width=660;this.height=330;this.hidden=false;this.textContent='';}
  querySelector(selector){if(!this.map.has(selector))this.map.set(selector,new Element());return this.map.get(selector);}
  set innerHTML(value){this.html=value;}
  setAttribute(){}
  getContext(kind){return kind==='2d'?context2d:null;}
  addEventListener(type,fn){this.events[type]=fn;}
  append(element){this.children.push(element);}
  replaceChildren(){this.children=[];}
  getBoundingClientRect(){return {left:0,top:0,width:660,height:330};}
  get offsetWidth(){return 100;}
}
const window={devicePixelRatio:1,LabUI:{isRunning:()=>true},addEventListener(type,fn){events[type]=fn;}};
const context=vm.createContext({window,document:{createElement:()=>new Element()},ArrayBuffer,Float32Array,Uint32Array,DataView,TextDecoder,Map,Set,AbortController,console,
  performance:{now:()=>now},requestAnimationFrame:fn=>frames.push(fn),
  fetch:async url=>{const buffer=fs.readFileSync(root+url);return {ok:true,arrayBuffer:async()=>buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.byteLength),json:async()=>JSON.parse(buffer)};}});
vm.runInContext(fs.readFileSync(path.join(root,'web/vehicle.js'),'utf8'),context);
const API=window.VehicleView;
function frame(time){now=time;const pending=frames.splice(0);for(const fn of pending)fn(time);}
const state=(t,measurement=36)=>({t,profile:'phev',wheel_speeds_kph:[36,36,36,36],inputs:{ignition:true},connections:{},sensors:{wheel_speeds_kph:[measurement,36,36,36]}});
(async()=>{
  const bytes=fs.readFileSync(path.join(root,'web/models/training_vehicle.glb'));
  const model=API.parseGLB(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
  const bindings=API.validateBindings(JSON.parse(fs.readFileSync(path.join(root,'web/models/vehicle_bindings.json'))));
  assert.ok(model.vertices>1000,'Contoured geometry parses');
  assert.equal(bindings.wheels.length,4);
  for(const binding of bindings.wheels)assert.ok(model.nodes.some(node=>node.name===binding.node),'Named wheel pivot is present');
  for(const name of bindings.body_nodes)assert.ok(model.nodes.some(node=>node.name===name),'Body opacity binding resolves');
  const container=new Element(),view=API.create(container,{compact:true,theme:'dark'});
  await new Promise(resolve=>setImmediate(resolve));
  frame(0);view.update(state(0));frame(0);
  now=200;view.update(state(.2));frame(250);
  const live=view.inspect(),angle=live.wheelAngles.wheel_fl,drawn=live.drawnAngles.wheel_fl;
  assert.ok(Math.abs(angle+10/.31*.2)<1e-9,'Wheel integrates physical speed in metres per second');
  assert.ok(drawn<0&&drawn>angle,'Playback interpolates a completed step without extrapolation');
  events['lab:play']({detail:{running:false}});frame(260);
  const paused=JSON.stringify(view.inspect().drawnAngles);frame(600);view.update(state(.2));frame(620);
  assert.equal(JSON.stringify(view.inspect().drawnAngles),paused,'Pause holds wheel pose');
  view.update(state(.4,null));frame(640);
  assert.ok(view.inspect().wheelAngles.wheel_fl<angle,'A missing measurement leaves physical wheel rotation intact');
  assert.equal(view.inspect().compact,true);assert.equal(view.inspect().theme,'dark');
  container.querySelector('[data-action="cutaway"]').events.click();frame(660);
  assert.equal(view.inspect().opacity,.22,'Cutaway exposes body');
  container.querySelector('[data-action="exterior"]').events.click();frame(680);
  assert.equal(view.inspect().opacity,1,'Exterior closes body');
  view.setTheme('light');assert.equal(view.inspect().theme,'light');
  view.update(state(0));frame(700);assert.equal(Object.keys(view.inspect().wheelAngles).length,0,'A reset clears accumulated rotation');
  view.update({...state(0),vehicle:{direction:-1}});frame(710);
  view.update({...state(.2,null),vehicle:{direction:-1}});frame(720);
  assert.ok(Math.abs(view.inspect().wheelAngles.wheel_fl-10/.31*.2)<1e-9,'Reverse changes physical wheel rotation direction without depending on its sensor');
  view.dispose();
  console.log(JSON.stringify({suite:'Vehicle geometry and animation',status:'passed',model_nodes:model.nodes.length,model_vertices:model.vertices,
    scope:'Actual GLB parser, bindings, physical-wheel integration including reverse, interpolation, pause, reset, missing measurement, view modes and themes; not GPU pixel validation'}));
})().catch(error=>{console.error(error);process.exitCode=1;});
