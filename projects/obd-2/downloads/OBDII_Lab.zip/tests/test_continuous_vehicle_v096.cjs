/* Continuous vehicle / selected diagnostics v0.9.6 acceptance: actual index, controller and all views; actual
 * Python API handlers over stdio. Parsed DOM stands in for native layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_continuous_vehicle_v096.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const createCanvas=()=>{throw Error('This suite does not render Canvas views');};
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
let forbidMetadataReads=false,dropVehicleResponse=false;
const metadataRoutes=new Set(['/api/meta','/api/network','/api/diagnostic-definitions','/api/systems','/api/scanner']);
const heldRequests=[];
function holdNext(url){let release,mark;const gate={url,wait:new Promise(resolve=>release=resolve),entered:new Promise(resolve=>mark=resolve)};gate.release=release;gate.mark=mark;heldRequests.push(gate);return gate;}
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});if(forbidMetadataReads&&options?.method!=='POST'&&metadataRoutes.has(url))throw new Error('Injected metadata GET failure after vehicle commit');const held=heldRequests.findIndex(g=>g.url===url);if(held>=0){const [gate]=heldRequests.splice(held,1);gate.mark();await gate.wait;}const response=await fetch(baseURL+url,options);if(dropVehicleResponse&&url==='/api/vehicle'&&options?.method==='POST'){dropVehicleResponse=false;await response.arrayBuffer();throw new Error('Injected lost vehicle POST response');}return response;},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};

// These views are outside this suite; Setup, Cockpit, Monitor, Scanner and the
// application controller run unchanged, with the real vehicle/scanner handlers.
const unusedView={create:()=>({update(){},setVisible(){},resize(){},dispose(){}})};
for(const name of ['UnitMapView','LiveDataView','DiagnosisView','ConnectionView','LocationsView'])window[name]=unusedView;
const backend=spawn('python3',['-u','tests/http_stdio.py'],{cwd:root,env:{...process.env,PYTHONPATH:root},stdio:['pipe','pipe','inherit']});
const replies=[];
readline.createInterface({input:backend.stdout}).on('line',line=>replies.shift()?.(JSON.parse(line)));
window.fetch=(url,options={})=>new Promise(resolve=>{
 const body=options.body?JSON.parse(options.body):undefined;requests.push({url,body});
 replies.push(r=>resolve({ok:r.status<400,status:r.status,json:async()=>r.data}));backend.stdin.write(JSON.stringify({path:url,body})+'\n');
});
let passed=0,app;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
(async()=>{try{
 const scripts=['session.js','protocols.js','cockpit.js','vehicle-monitor.js','scan-tool.js','setup.js','message-inspector.js','application.js'];
 for(const file of scripts)vm.runInContext(fs.readFileSync(path.join(root,'web',file),'utf8'),sandbox,{filename:file});
 document.readyState='interactive';await document.dispatchEvent(new CustomEvent('DOMContentLoaded'));
 app=window.VehicleApplication;await app.ready;const session=app.session,state=()=>session.result.state;
 const settle=async()=>{await session.command;await flush();};
 const click=async selector=>{const node=$(selector);assert.equal(node.disabled,false,'Enabled '+selector);await node.click();await settle();};
 const change=async(selector,value)=>{const node=$(selector);node.value=String(value);await node.dispatchEvent({type:'change'});await settle();};
 const clocks=()=>[...timers.entries()].filter(([,t])=>t.ms===100);
 const tick=async(count=1)=>{for(let n=0;n<count;n++){const [id,t]=clocks()[0]||[];assert.ok(t,'Vehicle owns an automatic clock');timers.delete(id);await t.fn();await settle();}assert.equal(clocks().length,1);};
 await test('setup is parked; entering a workspace starts one clock with ignition still off',async()=>{
  assert.equal(session.running,false);assert.equal(clocks().length,0);await session.commitSetup('petrol_advanced',{},session.testSettings);
  await click('[data-workspace-choice="service"]');assert.equal(session.running,true);assert.equal(clocks().length,1);assert.equal(state().vehicle.ignition,'off');
  assert.equal(document.querySelector('[data-action="play"]'),null);assert.equal(document.querySelector('[data-action="step"]'),null);
  const t=state().t;await tick(2);assert.ok(state().t>t);assert.equal(state().engine_running,false);
  assert.equal(document.querySelector('[data-vm-action="gauges"]'),null);assert.equal($('#service-dashboard').classList.contains('vm-compact'),false);
 });
 await test('sidebar selects gearbox parameters without silently opening a connection',async()=>{
  await click('[data-select="transmission"]');assert.equal(app.views.scan.inspect().module,'transmission');assert.match($('[data-sc="live-title"]').textContent,/6-speed automatic/);
  assert.match($('[data-sc-action="connect"]').textContent,/Connect to 6-speed automatic/);assert.equal(document.querySelector('[data-sc-parameter="obd.rpm"]'),null);
  assert.equal(session.result.scanner.connected,false);await click('[data-action="service-ignition"]');await tick(2);await click('[data-sc-action="connect"]');
  assert.equal(session.result.scanner.module_id,'transmission');assert.ok(document.querySelector('[data-sc="live-grid"]').textContent.includes('Model sample'));
  await change('[data-sc="module"]','ecu');assert.equal(session.selection,'ecu');assert.equal($('[data-select="ecu"]').classList.contains('active'),true);
  assert.equal(session.result.scanner.module_id,'transmission');await click('[data-sc-action="connect"]');assert.equal(session.result.scanner.module_id,'ecu');
 });
 await test('ECU picker exposes fitted air, lambda, fuel and engine channels with their source',async()=>{
  await click('[data-sc-action="add-parameter"]');const choices=$('[data-sc="parameter-choice"]').textContent+$('[data-sc="live-grid"]').textContent;
  for(const label of ['Manifold absolute pressure','Exhaust lambda','Fuel rail pressure','Fuel flow','Fuel used','Oil pressure','Knock'])assert.ok(choices.includes(label),label);
  assert.match(choices,/Model/);assert.match(choices,/OBD/);
  for(const id of ['cam_sensor','vehicle_sensors.map.signal_voltage_v']){
   await change('[data-sc="parameter-choice"]',id);await click('[data-sc-action="confirm-parameter"]');
   if(id!=='vehicle_sensors.map.signal_voltage_v')await click('[data-sc-action="add-parameter"]');
  }
  await tick(3);assert.ok(session.scanLive.ids.includes('fuel_l_h'));assert.match($('[data-sc-parameter="map"]').textContent,/Model sample/);
  assert.match($('[data-sc-parameter="obd.rpm"]').textContent,/OBD reply/);assert.match($('[data-sc-parameter="lambda_sensor"] .sc-live-value').textContent,/—/);
  assert.equal(requests.some(r=>r.body?.payloads?.includes('fuel_l_h')),false,'Model channels never become invented diagnostic requests');
 });
 await test('automatic D/R buttons and commands require engine running through the full cranking interval',async()=>{
  await click('[data-workspace="drive"]');assert.equal($('[data-ck-shift="D"]').disabled,true);assert.equal($('[data-ck-gear="R"]').disabled,true);
  await assert.rejects(session.shift('D',{assist:true}),/Start the engine/);assert.equal(state().vehicle.selector,'P');
  await click('[data-ck-action="start"]');assert.equal(state().vehicle.start_state,'cranking');assert.equal($('[data-ck-shift="D"]').disabled,true);
  await change('#playback-rate','5');await tick(2);assert.equal(state().vehicle.ready,true);await click('[data-ck-shift="D"]');assert.equal(state().vehicle.selector,'D');
  await click('[data-ck-action="parking"]');assert.equal(state().vehicle.parking_brake,false);
 });
 await test('service pedals change the moving car, OBD RPM, fuel flow and pressure without a Run action',async()=>{
  await click('[data-workspace="service"]');const gas=$('[data-vm-pedal-hold="throttle"]');const initial=state().rpm;
  await gas.dispatchEvent({type:'pointerdown',pointerId:31,button:0});await tick(4);const speed=state().speed_kph;
  assert.ok(speed>1);assert.ok(state().rpm>initial);assert.ok(state().fuel_l_h>0);
  assert.match($('[data-sc-parameter="fuel_l_h"]').textContent,/Model sample/);assert.match($('[data-sc-parameter="lambda_sensor"]').textContent,/Model sample/);
  await click('[data-sc-display="graphs"]');assert.ok($('[data-sc-parameter="map"] svg').querySelector('path.sc-trend-line'));
  await gas.dispatchEvent({type:'pointerup',pointerId:31});assert.equal(session.inputs.throttle,0);
  await click('[data-sc-action="disconnect"]');const disconnectedAt=state().t,reads=requests.filter(r=>r.body?.action==='read').length;await tick();
  assert.ok(state().t>disconnectedAt);assert.equal(session.running,true);assert.equal(requests.filter(r=>r.body?.action==='read').length,reads);await click('[data-sc-action="connect"]');
  assert.equal($('[data-action="start-cycle"]').disabled,true);assert.match($('#drive-task-note').textContent,/Brake to a complete stop/);
  const brake=$('[data-vm-pedal-hold="brake"]');await brake.dispatchEvent({type:'pointerdown',pointerId:32,button:0});await tick(3);assert.ok(state().speed_kph<speed);
  await brake.dispatchEvent({type:'pointerup',pointerId:32});
 });
 await test('missing model measurements clear their number; model-only selections keep advancing',async()=>{
  await session.connection('map',false);await tick();assert.match($('[data-sc-parameter="map"] .sc-live-value').textContent,/—/);
  await session.connection('map',true);await tick();assert.match($('[data-sc-parameter="map"]').textContent,/Model sample/);
  session.setLiveData({ids:['map','fuel_l_h']});await settle();const before=state().t,count=requests.filter(r=>r.body?.action==='read').length;
  await tick(2);assert.ok(state().t>before);assert.equal(requests.filter(r=>r.body?.action==='read').length,count,'Model-only selection sends no OBD batch');
  assert.match($('[data-sc-parameter="fuel_l_h"]').textContent,/Model sample/);
 });
 await test('WLTC starts from parked/off automatically and manual takeover keeps the clock live',async()=>{
  await click('[data-action="restart"]');assert.equal(session.running,true);assert.equal(state().vehicle.ignition,'off');assert.equal(state().vehicle.selector,'P');
  await click('[data-action="start-cycle"]');assert.equal(session.running,true);await tick(3);assert.equal(state().vehicle.ready,true);assert.equal(state().vehicle.selector,'D');
  const before=state().t;await click('[data-workspace="drive"]');await tick();await click('[data-workspace="service"]');assert.ok(state().t>before);
  assert.equal($('[data-action="stop-cycle"]').textContent,'Drive manually');await click('[data-action="stop-cycle"]');assert.equal(state().drive_cycle.status,'stopped');assert.equal(session.running,true);await tick();
 });
 await test('changing vehicle pauses only the editor; cancelling or applying resumes the workspace',async()=>{
  session.setLiveData({ids:['map','rail_pressure','fuel_l_h']});session.beginSetup();assert.equal(session.running,false);assert.equal(clocks().length,0);session.cancelSetup();assert.equal(session.running,true);await tick();
  session.beginSetup();await session.commitSetup('petrol_basic',{}, {mode:'manual',road_mu:.9,grade_pct:0});await settle();assert.equal(session.running,true);
  assert.equal($('[data-action="start-cycle"]').hidden,false,'Manual setup still offers the independent WLTC task');
  const catalog=window.AppModel.liveParameterCatalog(session.context(),'ecu').map(p=>p.id);
  assert.ok(catalog.includes('map'));assert.ok(catalog.includes('lambda_sensor'));assert.ok(catalog.includes('fuel_l_h'));assert.equal(catalog.includes('rail_pressure'),false,'Unfitted extended sensors stay absent');assert.equal(session.scanLive.ids.includes('rail_pressure'),false,'Changing hardware removes unfitted card selections');
 });
 assert.deepEqual(errors,[]);console.log(JSON.stringify({suite:'continuous vehicle, selected unit and ECU coverage v0.9.6',passed,failed:0,scope:'Real API handlers and product controllers; parsed DOM, no native layout claim'}));
 }catch(error){console.error(error.stack);process.exitCode=1;}finally{app?.dispose();backend.kill();}})();
