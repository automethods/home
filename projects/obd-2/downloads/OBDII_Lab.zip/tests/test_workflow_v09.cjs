/* Staged workflow v0.9 acceptance: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_workflow_v09.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
let forbidMetadataReads=false,dropVehicleResponse=false;
const metadataRoutes=new Set(['/api/meta','/api/network','/api/diagnostic-definitions','/api/systems','/api/scanner']);
const heldRequests=[];
function holdNext(url){let release,mark;const gate={url,wait:new Promise(resolve=>release=resolve),entered:new Promise(resolve=>mark=resolve)};gate.release=release;gate.mark=mark;heldRequests.push(gate);return gate;}
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});if(forbidMetadataReads&&options?.method!=='POST'&&metadataRoutes.has(url))throw new Error('Injected metadata GET failure after vehicle commit');const held=heldRequests.findIndex(g=>g.url===url);if(held>=0){const [gate]=heldRequests.splice(held,1);gate.mark();await gate.wait;}const response=await fetch(baseURL+url,options);if(dropVehicleResponse&&url==='/api/vehicle'&&options?.method==='POST'){dropVehicleResponse=false;await response.arrayBuffer();throw new Error('Injected lost vehicle POST response');}return response;},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;const failures=[];
async function test(name,fn){if(process.env.OBD_TEST_FILTER&&!new RegExp(process.env.OBD_TEST_FILTER,'i').test(name))return;try{await fn();passed++;console.log('PASS '+name);}catch(error){failures.push({name,error});console.error('FAIL '+name+'\n'+error.stack);}}
async function main(){
 const server=await startServer();let app;
 try{
  const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
  document.readyState='interactive';await document.dispatchEvent(new CustomEvent('DOMContentLoaded'));
  app=window.VehicleApplication;assert.ok(app);await app.ready;await flush();
  const session=app.session,state=()=>session.result.state;
  const settle=async()=>{await session.command;await waitFor(()=>session.pending===0&&Object.values(app.views).every(v=>!v.inspect?.().pending),'All foreground view commands settle');await flush();};
  const click=async selector=>{const node=$(selector);assert.equal(node.disabled,false,'Control is enabled: '+selector);await node.click();await settle();};
  const change=async(selector,value)=>{const node=$(selector);node.value=String(value);await node.dispatchEvent({type:'change'});await settle();};
  const check=async(selector,value)=>{const node=$(selector);node.checked=value;await node.dispatchEvent({type:'change'});await settle();};
  const input=async(selector,value)=>{const node=$(selector);node.value=String(value);await node.dispatchEvent({type:'input'});await settle();};
  const setup=async(config='petrol_basic',hardware={},settings={mode:'manual',road_mu:.9,grade_pct:0})=>{await session.setup(config,hardware,settings);await settle();};
  const raw=async(url,body)=>{const response=await fetch(baseURL+url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {ok:response.ok,status:response.status,data:await response.json()};};
  const api=async(url,body)=>{const response=await session.api(url,body);session.apply(response);await settle();return response;};
  const close=(a,b,description,tolerance=1e-7)=>assert.ok(Math.abs(a-b)<=tolerance,description+': '+a+' vs '+b);
  const startAutomatic=async()=>{await session.control('ignition',true);await session.control('start');await session.advance(1);await settle();};
  const beginCycle=async()=>{await setup('petrol_basic',{}, {mode:'wltc_class3b',road_mu:.9,grade_pct:0});await click('[data-action="start-cycle"]');};


  const vehiclePosts=()=>requests.filter(r=>r.url==='/api/vehicle').length;
  const mutations=()=>requests.filter(r=>r.body!==null).length;
  const stage=()=>session.context().workflow.stage;
  const hidden=selector=>!!$(selector).closest('[hidden]');
  const key=async(value,target=document.body)=>{await document.dispatchEvent({type:'keydown',key:value,target});await settle();};

  await test('first launch presents vehicle selection without operational controls or a running clock',async()=>{
   assert.equal(stage(),'vehicle');assert.equal(session.context().workflow.complete,false);assert.equal(session.view,'setup');
   assert.equal(hidden('[data-setup-stage="vehicle"]'),false);assert.equal(hidden('[data-setup-stage="workspace"]'),true);
   assert.equal(hidden('.simulation-toolbar'),true);assert.equal(hidden('.app-tabs'),true);assert.equal(hidden('.system-sidebar'),true);assert.equal(hidden('#message-dock'),true);
   assert.deepEqual(Array.from(document.querySelectorAll('[data-workspace]'),n=>n.dataset.workspace),['drive','service']);
   assert.equal(document.querySelector('#tab-setup'),null);assert.equal(document.querySelector('#tab-units'),null);
   assert.equal(state().vehicle.ignition,'off');assert.equal(state().vehicle.selector,'P');assert.equal(state().t,0);assert.equal(session.running,false);
   assert.equal($('[data-setup-action="cancel"]').hidden,true);assert.match($('[data-setup-action="apply"]').textContent,/Continue/i);
  });

  await test('keyboard, hidden navigation and direct operating actions cannot bypass uncommitted setup',async()=>{
   const before=mutations();
   for(const view of ['drive','service','units','diagnostics','wiring','live','locations','diagnosis','configuration'])session.navigate(view);
   session.setUnitView('wiring');session.setDiagnosticView('tests');session.enterWorkspace('drive');session.setRunning(true);
   for(const value of ['1','2','3','4',' ','.'])await key(value);
   await Promise.allSettled([
    ()=>session.advance(.1),()=>session.control('ignition',true),()=>session.connection('ect',false),
    ()=>session.request('01 0C'),()=>session.scannerAction('connect',{protocol:'can11_500',module:'ecu'}),()=>session.cycleAction('start')
   ].map(fn=>Promise.resolve().then(fn)));
   await settle();assert.equal(mutations(),before);assert.equal(stage(),'vehicle');assert.equal(session.view,'setup');assert.equal(session.running,false);assert.equal(state().t,0);
   assert.equal([...timers.values()].filter(t=>t.ms===100).length,0);
  });

  await test('draft edits do not change the parked model, and invalid application stays in the vehicle stage',async()=>{
   const before=vehiclePosts();await change('[data-setup="configuration"]','diesel');await change('[data-setup="driving_mode"]','manual');
   await change('[data-setup="drivetrain"]','awd');await change('[data-setup="mass_kg"]',1700);await change('[data-setup="ambient_c"]',12);
   assert.equal(vehiclePosts(),before);assert.equal(state().vehicle.configuration.id,'petrol_basic');assert.equal(state().t,0);
   await change('[data-setup="mass_kg"]',450);await click('[data-setup-action="apply"]');
   assert.equal(stage(),'vehicle');assert.equal(session.context().workflow.complete,false);assert.equal(state().vehicle.configuration.id,'petrol_basic');
   assert.equal($('[data-setup="configuration"]').value,'diesel');assert.equal($('[data-setup="mass_kg"]').value,'450');
   assert.equal($('[data-setup="error"]').hidden,false);assert.match($('[data-setup="error"]').textContent,/mass|600/i);
   await change('[data-setup="mass_kg"]',1700);
  });

  await test('Continue commits once despite a repeated submission and needs no metadata GET after vehicle replacement',async()=>{
   const before=vehiclePosts(),gate=holdNext('/api/vehicle'),form=$('[data-setup="form"]');
   forbidMetadataReads=true;const submitting=form.dispatchEvent({type:'submit'});
   try{await gate.entered;assert.equal(stage(),'vehicle');assert.equal($('[data-setup-action="apply"]').disabled,true);
    await form.dispatchEvent({type:'submit'});assert.equal(vehiclePosts(),before+1);
   }finally{gate.release();}
   try{await submitting;await settle();}finally{forbidMetadataReads=false;}
   assert.equal(vehiclePosts(),before+1);assert.equal(stage(),'workspace');assert.equal(session.context().workflow.complete,true);
   assert.equal(hidden('[data-setup-stage="vehicle"]'),true);assert.equal(hidden('[data-setup-stage="workspace"]'),false);assert.equal(hidden('.simulation-toolbar'),true);
   assert.equal(state().vehicle.configuration.id,'diesel');assert.equal(state().vehicle.configuration.mass_kg,1700);assert.equal(state().vehicle.configuration.drivetrain,'awd');
   assert.equal(state().t,0);assert.equal(state().vehicle.ignition,'off');assert.equal(session.running,false);
  });

  await test('Back and unchanged Continue keep the committed vehicle without another reset',async()=>{
   const before=vehiclePosts(),history=session.history,result=session.result;
   await click('[data-setup-action="back"]');assert.equal(stage(),'vehicle');assert.equal($('[data-setup="configuration"]').value,'diesel');
   assert.equal($('[data-setup="mass_kg"]').value,'1700');assert.equal(vehiclePosts(),before);
   await click('[data-setup-action="apply"]');assert.equal(stage(),'workspace');assert.equal(vehiclePosts(),before);assert.equal(session.history,history);assert.equal(session.result,result);
  });

  await test('choosing Drive enters the committed parked vehicle without applying it again',async()=>{
   const before=mutations();await click('[data-workspace-choice="drive"]');
   assert.equal(stage(),'active');assert.equal(session.view,'drive');assert.equal(mutations(),before);assert.equal(hidden('.simulation-toolbar'),false);assert.equal(hidden('.app-tabs'),false);
   assert.equal($('#view-setup').hidden,true);assert.equal($('#view-drive').hidden,false);assert.equal(state().t,0);
   assert.equal($('#tab-drive').getAttribute('aria-selected'),'true');assert.equal($('#tab-service').getAttribute('aria-selected'),'false');
   await click('[data-ck-action="ignition"]');await click('[data-ck-action="start"]');await session.advance(1);await settle();
   assert.equal(state().engine_running,true);assert.ok(state().rpm>500);
  });

  await test('Drive and service tools share the same clock, faults, recording and selected component',async()=>{
   await session.scannerAction('connect',{protocol:'can11_500',module:'ecu'});await session.request('01 0C');
   await session.connection('ect',false);await session.advance(.6);session.select('wire:ect_signal');await settle();
   const before={time:state().t,history:session.history,logs:session.logHistory,records:session.records,events:session.events,posts:vehiclePosts(),selection:session.selection};
   session.setRunning(true);const clocks=[...timers.entries()].filter(([,t])=>t.ms===100).map(([id])=>id);
   await click('[data-workspace="service"]');assert.equal($('#tab-service').getAttribute('aria-selected'),'true');
   await click('[data-service-view="units"]');await click('[data-unit-view="wiring"]');assert.equal(session.view,'units');assert.equal(session.unitView,'wiring');
   await click('[data-workspace="drive"]');assert.equal(session.view,'drive');await click('[data-workspace="service"]');assert.equal(session.view,'units');assert.equal(session.unitView,'wiring');
   for(const name of ['history','records','events'])assert.equal(session[name],before[name]);assert.equal(session.logHistory,before.logs);assert.equal(session.selection,before.selection);
   assert.equal(state().t,before.time);assert.equal(vehiclePosts(),before.posts);assert.equal(state().connections.ect,false);assert.equal(session.running,true);
   assert.deepEqual([...timers.entries()].filter(([,t])=>t.ms===100).map(([id])=>id),clocks);
  });

  await test('service includes vehicle configuration and wiring links stay inside the service workspace',async()=>{
   await click('[data-service-view="configuration"]');assert.equal(session.view,'configuration');assert.equal($('#tab-service').getAttribute('aria-selected'),'true');
   assert.equal($('#view-configuration').hidden,false);assert.match($('#view-configuration').textContent,/diesel/i);assert.match($('#view-configuration').textContent,/transmission|automatic/i);
   const before=vehiclePosts();session.navigate('wiring');await settle();assert.equal(session.view,'units');assert.equal(session.unitView,'wiring');assert.equal(vehiclePosts(),before);
   assert.equal($('#tab-service').getAttribute('aria-selected'),'true');
  });

  await test('Change vehicle pauses and releases driving controls; Cancel preserves the complete current run',async()=>{
   await click('[data-workspace="drive"]');document.activeElement=null;
   window.dispatchEvent({type:'keydown',key:'w',code:'KeyW',target:$('#cockpit-content'),preventDefault(){}});assert.equal(session.inputs.throttle,1);
   const before={time:state().t,history:session.history,records:session.records,logs:session.logHistory,posts:vehiclePosts(),configuration:state().vehicle.configuration.id};
   session.setRunning(true);await click('[data-action="configuration"]');
   assert.equal(stage(),'vehicle');assert.equal(session.context().workflow.editing,true);assert.equal(session.running,false);assert.equal(session.inputs.throttle,0);assert.equal(hidden('.simulation-toolbar'),true);
   assert.equal($('[data-setup-action="cancel"]').hidden,false);await change('[data-setup="configuration"]','bev');await change('[data-setup="mass_kg"]',2010);
   assert.equal(vehiclePosts(),before.posts);await click('[data-setup-action="cancel"]');assert.equal(stage(),'active');assert.equal(session.view,'drive');assert.equal(session.running,false);
   assert.equal(state().t,before.time);assert.equal(state().vehicle.configuration.id,before.configuration);assert.equal(state().connections.ect,false);
   assert.equal(session.history,before.history);assert.equal(session.records,before.records);assert.equal(session.logHistory,before.logs);assert.equal(vehiclePosts(),before.posts);
   assert.equal(session.inputs.throttle,0);assert.equal([...timers.values()].filter(t=>t.ms===100).length,0);
  });

  await test('reopening the configuration discards cancelled edits and failed replacement keeps the current run',async()=>{
   await click('[data-action="configuration"]');assert.equal($('[data-setup="configuration"]').value,'diesel');assert.equal($('[data-setup="mass_kg"]').value,'1700');
   const before={time:state().t,records:session.records,history:session.history};await change('[data-setup="mass_kg"]',4000);await click('[data-setup-action="apply"]');
   assert.equal(stage(),'vehicle');assert.equal($('[data-setup="mass_kg"]').value,'4000');assert.equal($('[data-setup="error"]').hidden,false);
   assert.equal(state().t,before.time);assert.equal(session.history,before.history);assert.equal(session.records,before.records);assert.equal(state().vehicle.configuration.id,'diesel');
   await click('[data-setup-action="cancel"]');assert.equal(stage(),'active');assert.equal(state().t,before.time);
  });

  await test('applying a replacement from service starts one new parked run and returns to that workspace',async()=>{
   await click('[data-workspace="service"]');session.navigate('wiring');await settle();await click('[data-action="configuration"]');
   await change('[data-setup="configuration"]','bev');await change('[data-setup="driving_mode"]','manual');await check('[data-setup="hvac_installed"]',false);
   const before=vehiclePosts();await click('[data-setup-action="apply"]');
   assert.equal(vehiclePosts(),before+1);assert.equal(stage(),'active');assert.equal(session.view,'units');assert.equal(session.unitView,'wiring');assert.equal($('#tab-service').getAttribute('aria-selected'),'true');
   assert.equal(state().vehicle.configuration.powertrain,'bev');assert.equal(state().vehicle.hvac.installed,false);assert.equal(state().t,0);assert.equal(state().vehicle.ignition,'off');assert.equal(session.running,false);
   assert.equal(session.records.length,0);assert.equal(session.scanReport,null);assert.equal(session.scanPolling.enabled,false);assert.equal(session.selection,'overview');
   assert.equal(session.systems.units.find(u=>u.id==='ecu').installed,false);assert.ok(session.logHistory.every(s=>s.t===0));
  });

  await test('a lost vehicle response blocks stale-session cancellation until an explicit retry confirms the model',async()=>{
   const originalMass=state().vehicle.configuration.mass_kg;await click('[data-action="configuration"]');
   await change('[data-setup="mass_kg"]',2100);const before=vehiclePosts();dropVehicleResponse=true;
   await click('[data-setup-action="apply"]');assert.equal(vehiclePosts(),before+1);assert.equal(stage(),'vehicle');
   assert.equal(session.context().workflow.recoveryRequired,true);assert.equal(session.context().workflow.canCancel,false);assert.equal($('[data-setup-action="cancel"]').disabled,true);
   assert.match($('[data-setup="error"]').textContent,/could not be confirmed|Apply.*again/i);
   const actual=await (await fetch(baseURL+'/api/state')).json();assert.equal(actual.state.vehicle.configuration.mass_kg,2100);
   assert.equal(state().vehicle.configuration.mass_kg,originalMass,'Unconfirmed new state is not represented as the old session');
   assert.equal(session.cancelSetup(),false);session.navigate('drive');session.enterWorkspace('drive');session.setRunning(true);assert.equal(stage(),'vehicle');assert.equal(session.running,false);
   await change('[data-setup="mass_kg"]',originalMass);await click('[data-setup-action="apply"]');
   assert.equal(vehiclePosts(),before+2,'Even a return to the old identical draft must confirm the unknown backend state');
   assert.equal(stage(),'active');assert.equal(session.context().workflow.recoveryRequired,false);assert.equal(state().vehicle.configuration.mass_kg,originalMass);
   assert.equal(state().vehicle.ignition,'off');assert.equal(state().t,0);assert.equal(session.error,'');
  });

  await test('workspace keyboard shortcuts stay within the committed run and respect focused setup fields',async()=>{
   const before=vehiclePosts();await key('1');assert.equal(session.view,'drive');await key('2');assert.equal(session.view,'units');
   await key('1');const tab=$('#tab-drive');tab.focus();await key('ArrowLeft',tab);assert.equal($('#tab-service').getAttribute('aria-selected'),'true');
   await click('[data-action="configuration"]');await key('2',$('[data-setup="mass_kg"]'));assert.equal(stage(),'vehicle');assert.equal(session.view,'setup');
   await click('[data-setup-action="cancel"]');assert.equal(stage(),'active');assert.equal(vehiclePosts(),before);
   assert.deepEqual(errors,[]);assert.equal($('#application-error').hidden,true);assert.ok([...timers.values()].filter(t=>t.ms===100).length<=1);
  });

  console.log(`${passed} staged workflow v0.9 contracts passed; ${failures.length} failed. Actual Python HTTP + parsed DOM + CPU Canvas; native layout/events/GPU are not covered.`);
  if(failures.length)process.exitCode=1;
 } finally {for(const gate of heldRequests)gate.release();if(app){app.dispose();await app.session.command;}server.child.kill('SIGTERM');server.lines.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
