"""Live parameter batches exercise the actual API handler without sockets."""
import unittest
from http_stdio import HandlerClient


class LiveParametersTests(unittest.TestCase):
    def setUp(self):
        self.client = HandlerClient()
        self.client.request('/api/vehicle', {'configuration': 'petrol_basic'})
        self.client.request('/api/control', {'action': 'ignition', 'value': True})
        self.client.request('/api/advance', {'seconds': .1})
        self.client.request('/api/scanner', {'action': 'connect', 'module': 'ecu'})

    def read(self, payloads):
        return self.client.request('/api/scanner', {'action': 'read', 'payloads': payloads})

    def test_batch_uses_same_timestamp_and_preserves_clock(self):
        before = self.client.lab.snapshot()['t']
        result = self.read(['01 0C', '01 0D', '01 05', '01 04', '01 11'])
        self.assertEqual(result['status'], 200)
        readings = result['data']['readings']
        self.assertEqual(len(readings), 5)
        self.assertEqual({r['sample_t'] for r in readings}, {before})
        self.assertTrue(all(r['response_hex'] for r in readings))
        self.assertEqual(self.client.lab.snapshot()['t'], before)
        self.assertTrue(all(r['target'] == 'ecu' for r in readings))

    def test_batch_cannot_execute_clear_or_session_commands(self):
        before = len(self.client.lab.trace)
        for payloads in ([], ['01 0C', '04'], ['10 03'], '01 0C', [None], ['01 0C'] * 8):
            self.assertEqual(self.read(payloads)['status'], 400)
        self.assertEqual(len(self.client.lab.trace), before)

    def test_missing_sensor_returns_gap_and_does_not_replace_with_plant_value(self):
        self.client.request('/api/connection', {'id': 'maf', 'connected': False})
        self.client.request('/api/advance', {'seconds': .2})
        readings = self.read(['01 10', '01 0C'])['data']['readings']
        self.assertIsNone(readings[0]['response_hex'])
        self.assertIn('sampled', readings[0]['meaning'])
        self.assertTrue(readings[1]['response_hex'])

    def test_disconnected_or_other_unit_does_not_fabricate_ecu_reply(self):
        self.client.request('/api/scanner', {'action': 'disconnect'})
        self.assertIsNone(self.read(['01 0C'])['data']['readings'][0]['response_hex'])
        self.client.request('/api/scanner', {'action': 'connect', 'module': 'transmission'})
        reply = self.read(['01 0C'])['data']['readings'][0]
        self.assertIsNone(reply['response_hex'])
        self.assertEqual(reply['target'], 'transmission')


if __name__ == '__main__':
    unittest.main()
