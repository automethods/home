"""Behavioral/physical checks for the teaching simulator, not OEM validation."""
import json
import math
import unittest

from obdii_lab.core import Sim, SCENARIOS


class CoreTests(unittest.TestCase):
    def test_clock_is_deterministic_and_preserves_fractional_steps(self):
        a = Sim(profile="phev")
        b = Sim(profile="phev")
        a.advance(8.0, {"throttle": 0.4})
        for _ in range(800): b.advance(0.01, {"throttle": 0.4})
        self.assertEqual(a.snapshot(), b.snapshot())
        c = Sim()
        c.advance(0.001)
        self.assertEqual(c.t, 0)
        c.advance(0.001)
        self.assertEqual(c.t, 0.002)

    def test_engine_starts_and_warmup_has_thermal_inertia(self):
        s = Sim(scenario="engine_warmup")
        x = s.advance(2)
        self.assertEqual(x["mode"], "RUNNING")
        self.assertGreater(x["rpm"], 700)
        self.assertLess(x["coolant_c"], 21)
        x = s.advance(118)
        self.assertGreater(x["coolant_c"], 25)
        self.assertLess(x["coolant_c"], 85)  # A 120 s teaching cycle is not full warm-up.
        self.assertEqual(x["speed_kph"], 0)
        self.assertGreater(x["energy"]["fuel_l"], 0)

    def test_ect_voltage_temperature_debounce_and_repair_are_distinct(self):
        s = Sim(scenario="ect_open")
        x = s.advance(3.19)
        self.assertEqual(x["sensors"]["ect_c"], -40)
        self.assertEqual(x["pending_dtcs"], [])
        self.assertGreater(x["coolant_c"], 20)
        x = s.advance(0.02)
        self.assertIn("P0118", x["pending_dtcs"])
        self.assertEqual(x["dtcs"], [])
        self.assertEqual(x["sensors"]["ect_used_c"], 80)
        x = s.advance(0.28)
        self.assertFalse(x["mil"])
        x = s.advance(0.02)
        self.assertTrue(x["mil"])
        self.assertAlmostEqual(s.freeze_frame["t"], 3.5)
        s.clear_emissions_dtcs()
        self.assertFalse(s.snapshot()["mil"])
        self.assertFalse(s.snapshot()["components_monitor_complete"])
        self.assertEqual(s.inputs["fault"], "ect_open")
        self.assertTrue(s.advance(0.52)["mil"])
        self.assertFalse(s.advance(0.1, {"fault": "none"})["pending_dtcs"])
        self.assertTrue(s.snapshot()["mil"])  # Repair does not erase stored memory.

    def test_precharge_blocks_traction_and_battery_flow(self):
        s = Sim(profile="phev")
        x = s.advance(0.2, {"throttle": 0.7})
        self.assertEqual(x["contactor"], "PRECHARGE")
        self.assertEqual(x["motor_power_kw"], 0)
        self.assertEqual(x["battery_current_a"], 0)
        self.assertGreater(x["sensors"]["dc_link_v"], 0)
        x = s.advance(0.22)
        self.assertEqual(x["contactor"], "CLOSED")
        self.assertGreater(x["battery_current_a"], 0)

    def test_low_cell_latches_only_after_persistence_and_inhibits_torque(self):
        s = Sim(scenario="cell_low")
        self.assertEqual(s.advance(8.19)["contactor"], "CLOSED")
        x = s.advance(0.03)
        self.assertEqual(x["contactor"], "FAULT")
        self.assertEqual(x["battery_current_a"], 0)
        self.assertEqual(x["motor_power_kw"], 0)
        self.assertEqual(x["engine_power_kw"], 0)
        self.assertIn("BMU_CELL_UNDERVOLTAGE", x["module_dtc"]["BMU"])
        self.assertFalse(x["mil"])
        self.assertEqual(s.advance(1, {"fault": "none"})["contactor"], "FAULT")

    def test_missing_heartbeat_is_supervised_by_message_age(self):
        s = Sim(scenario="bmu_timeout")
        self.assertEqual(s.advance(8.2)["contactor"], "CLOSED")
        x = s.advance(0.04)
        self.assertEqual(x["mode"], "FAULT")
        self.assertGreater(x["sensors"]["bmu_message_age_ms"], 300)
        self.assertEqual(x["battery_current_a"], 0)
        self.assertFalse(x["dtcs"])

    def test_battery_chemical_terminal_and_heat_energy_balance(self):
        s = Sim(scenario="phev_city")
        x = s.advance(60)
        e = x["energy"]
        self.assertGreater(e["battery_discharge_kwh"], 0)
        self.assertGreater(e["battery_charge_kwh"], 0)
        self.assertAlmostEqual(e["battery_chemical_kwh"], e["battery_terminal_net_kwh"] + e["battery_ohmic_kwh"], places=12)
        self.assertAlmostEqual(e["battery_terminal_net_kwh"], e["battery_discharge_kwh"] - e["battery_charge_kwh"], places=12)
        self.assertEqual(x["speed_kph"], 0)
        self.assertIn("HYBRID", {h["mode"] for h in s.history})
        self.assertIn("EV", {h["mode"] for h in s.history})

    def test_charge_acceptance_limits_generator_output_without_losing_power(self):
        for temperature in (-20, 60):
            s = Sim(scenario="low_soc", config={"initial_battery_temp_c": temperature})
            x = s.advance(10)
            self.assertEqual(x["battery_charge_limit_kw"], 0)
            self.assertAlmostEqual(x["generator_kw"], 0.5 / 0.9, places=8)
            self.assertAlmostEqual(x["battery_power_kw"], 0.5 - 0.9 * x["generator_kw"], places=8)

    def test_large_resistance_cannot_create_negative_discharge_limit(self):
        s = Sim(profile="phev", config={"battery_r_ohm": 2.0})
        x = s.advance(0.6)
        self.assertGreaterEqual(x["battery_discharge_limit_kw"], 0)
        self.assertGreaterEqual(x["battery_power_kw"], 0)
        voc = 300 + x["soc_pct"]
        self.assertLessEqual(x["battery_discharge_limit_kw"], voc ** 2 / (4 * 2.0) / 1000 + 0.01)

    def test_abs_modulates_wheels_and_improves_this_defined_braking_case(self):
        enabled = Sim(scenario="abs_split_mu")
        disabled = Sim(scenario="abs_split_mu")
        a = enabled.advance(12)
        b = disabled.advance(12, {"abs_enabled": False})
        self.assertEqual(a["speed_kph"], 0)
        self.assertEqual(b["speed_kph"], 0)
        self.assertGreater(a["energy"]["abs_active_s"], 1)
        self.assertEqual(b["energy"]["abs_active_s"], 0)
        self.assertLess(a["distance_m"], b["distance_m"])
        self.assertTrue(any(h["speed_kph"] > 20 and max(h["slips"]) > 0.95 for h in disabled.history))
        self.assertTrue(any(min(h["brake_pressure"]) < 0.8 for h in enabled.history))

    def test_high_soc_shifts_braking_energy_to_friction(self):
        high = Sim(scenario="regen_limit")
        normal = Sim(scenario="regen_limit", config={"initial_soc_pct": 75})
        a, b = high.advance(35), normal.advance(35)
        self.assertLess(a["energy"]["battery_charge_kwh"], b["energy"]["battery_charge_kwh"])
        self.assertGreater(a["energy"]["friction_brake_kwh"], b["energy"]["friction_brake_kwh"])
        self.assertAlmostEqual(a["distance_m"], b["distance_m"], delta=3)

    def test_scenario_snapshots_are_finite_json_and_energy_nonnegative(self):
        for case in SCENARIOS[1:]:
            s = Sim(scenario=case["id"])
            x = s.advance(case["duration"])
            json.dumps(x, allow_nan=False)
            self.assertGreaterEqual(x["soc_pct"], 0)
            self.assertLessEqual(x["soc_pct"], 100)
            self.assertGreaterEqual(x["speed_kph"], 0)
            self.assertGreaterEqual(x["energy"]["battery_ohmic_kwh"], 0)

    def test_invalid_inputs_fail_instead_of_creating_nonfinite_states(self):
        for value in (-1, float("inf"), float("nan")):
            with self.assertRaises(ValueError): Sim().advance(value)
        for supplied in ({"throttle": 2}, {"road_mu": 0}, {"fault": "imaginary"}, {"ignition": "yes"}, {"brake": float("nan")}):
            with self.assertRaises(ValueError): Sim().advance(1, supplied)
        for config in ({"mass_kg": 0}, {"initial_soc_pct": 120}, {"battery_r_ohm": -0.1}, {"unknown": 10}):
            with self.assertRaises(ValueError): Sim(config=config)


if __name__ == "__main__":
    unittest.main()
