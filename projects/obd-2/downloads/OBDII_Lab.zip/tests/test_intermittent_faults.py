"""Timed contact faults share the plant clock and existing sensor consequences."""
from copy import deepcopy
import json
import unittest

from obdii_lab.connection_faults import ConnectionFaultSchedule
from obdii_lab.vehicle import VehicleSim
from obdii_lab.vehicle_systems import SensorBank


def configured(configuration="petrol_advanced", *, start=True):
    sim = VehicleSim(configuration)
    sim.sensor_bank = SensorBank(sim.configuration)
    sim.sensor_bank.sample(sim.raw_snapshot())
    if start:
        sim.control("ignition", True)
        sim.control("start")
        sim.advance(1, {"brake": .3})
    return sim


def transitions(sim, connection_id):
    return [event for event in sim.events if "(" + connection_id + "): intermittent " in event["message"]]


class IntermittentConnectionTests(unittest.TestCase):
    def test_new_schedule_starts_connected_without_advancing_time(self):
        sim = configured()
        sim.set_connection("maf", False)
        before = sim.t
        state = sim.set_connection_fault("maf", connected_s=.3, dropout_s=.8)
        fault = state["connection_faults"]["maf"]
        self.assertEqual(sim.t, before)
        self.assertEqual(fault, {
            "mode": "intermittent", "pattern": "regular", "connected_s": .3, "dropout_s": .8,
            "phase": "connected", "effective_connected": True,
            "next_change_s": 1.3, "time_to_change_s": .3,
            "transition_count": 0, "dropout_count": 0, "seed": fault["seed"], "started_at_s": 1,
        })
        self.assertIsInstance(fault["seed"], int)
        self.assertTrue(state["effective_connections"]["maf"])
        json.dumps(state, allow_nan=False)

    def test_boundary_contacts_do_not_force_sensor_samples(self):
        sim = configured(start=False)
        sim.control("ignition", True)
        sim.advance(.1)
        sim.set_connection_fault("maf", connected_s=.03, dropout_s=.04)
        opened = sim.advance(.03)
        self.assertEqual(opened["connection_faults"]["maf"]["phase"], "dropout")
        self.assertFalse(opened["effective_connections"]["maf"])
        self.assertEqual(opened["vehicle_sensors"]["maf"]["validity"], "valid")
        self.assertEqual(opened["vehicle_sensors"]["maf"]["sampled_at"], .1)
        sampled = sim.advance(.022)
        self.assertEqual(sampled["vehicle_sensors"]["maf"]["validity"], "invalid")
        restored = sim.advance(.018)
        self.assertTrue(restored["effective_connections"]["maf"])
        self.assertEqual(restored["connection_faults"]["maf"]["phase"], "connected")
        self.assertEqual(restored["vehicle_sensors"]["maf"]["validity"], "invalid")
        sampled = sim.advance(.032)
        # At 0.20 s another physical dropout has just begun. A 50 ms sample
        # consumes whichever physical contact exists at that scheduled time.
        self.assertEqual(sampled["vehicle_sensors"]["maf"]["sampled_at"], .2)
        self.assertEqual(sampled["vehicle_sensors"]["maf"]["validity"], "invalid")
        self.assertEqual([event["t"] for event in transitions(sim, "maf")], [.13, .17, .2])

    def test_running_maf_dropout_derates_then_recovers_with_stored_memory(self):
        sim = configured()
        sim.control("gear", "D")
        sim.control("parking_brake", False)
        sim.advance(.4, {"throttle": .35, "brake": 0})
        self.assertTrue(sim.snapshot()["engine_running"])
        sim.set_connection_fault("maf", connected_s=.3, dropout_s=.8)
        dropped = sim.advance(.4)
        self.assertEqual(sim.sensor_effects["torque_factor"], .7)
        self.assertIsNone(dropped["vehicle_sensors"]["maf"]["value"])
        self.assertIsNotNone(dropped["vehicle_sensors"]["maf"]["physical_value"])
        self.assertTrue(dropped["engine_running"])
        self.assertNotIn("P0102", dropped["dtcs"])
        stored = sim.advance(.6)
        self.assertIn("P0102", stored["dtcs"])
        restored = sim.advance(.2)
        self.assertEqual(restored["connection_faults"]["maf"]["phase"], "connected")
        self.assertEqual(restored["vehicle_sensors"]["maf"]["validity"], "valid")
        self.assertEqual(sim.sensor_effects["torque_factor"], 1)
        self.assertIn("P0102", restored["dtcs"])
        self.assertNotIn("P0102", restored["pending_dtcs"])
        self.assertEqual(len(transitions(sim, "maf")), 2)

    def test_crank_dropout_uses_existing_inhibit_and_retains_physical_speed(self):
        sim = configured()
        sim.set_connection_fault("crank_sensor", connected_s=.1, dropout_s=1)
        dropped = sim.advance(.18)
        self.assertTrue(sim.sensor_effects["engine_inhibit"])
        self.assertIsNone(dropped["vehicle_sensors"]["crank_sensor"]["value"])
        self.assertIsNone(dropped["vehicle_sensors"]["crank_sensor"]["frequency_hz"])
        self.assertIsNotNone(dropped["vehicle_sensors"]["crank_sensor"]["physical_value"])
        self.assertFalse(dropped["engine_running"])
        self.assertIn("P0335", sim.advance(.6)["dtcs"])

    def test_bmu_pack_input_loss_removes_torque_and_records_a_module_fault(self):
        sim = configured("bev")
        sim.set_connection_fault("pack_voltage", connected_s=.2, dropout_s=.8)
        missing = sim.advance(.85)
        self.assertEqual(sim.sensor_effects["torque_factor"], 0)
        self.assertIsNone(missing["vehicle_sensors"]["pack_voltage"]["value"])
        self.assertGreater(missing["battery_voltage_v"], 0)
        self.assertIn("PACK_VOLTAGE_SIGNAL_MISSING", missing["sensor_dtcs"]["modules"]["bmu"])
        self.assertFalse(missing["dtcs"])
        recovered = sim.advance(.25)
        self.assertEqual(recovered["vehicle_sensors"]["pack_voltage"]["validity"], "valid")
        self.assertEqual(sim.sensor_effects["torque_factor"], 1)
        self.assertIn("PACK_VOLTAGE_SIGNAL_MISSING", recovered["sensor_dtcs"]["modules"]["bmu"])

    def test_short_and_between_sample_dropouts_need_not_set_a_code(self):
        sim = configured()
        sim.set_connection_fault("maf", connected_s=.004, dropout_s=.002)
        state = sim.advance(.008)
        self.assertEqual(state["connection_faults"]["maf"]["transition_count"], 2)
        self.assertEqual(state["vehicle_sensors"]["maf"]["validity"], "valid")
        self.assertEqual(sim.sensor_effects["torque_factor"], 1)
        sim.set_connection_fault("maf", mode="normal")
        # This longer brief dropout is sampled but is shorter than the
        # existing 0.2 s pending / 0.5 s stored persistence requirements.
        sim.set_connection_fault("maf", connected_s=.1, dropout_s=.1)
        state = sim.advance(.27)
        self.assertEqual(state["connection_faults"]["maf"]["dropout_count"], 1)
        self.assertNotIn("P0102", state["pending_dtcs"])
        self.assertNotIn("P0102", state["dtcs"])

    def test_ect_uses_the_existing_solved_open_circuit(self):
        sim = configured()
        sim.set_connection_fault("ect", connected_s=.1, dropout_s=1)
        state = sim.advance(.75)
        self.assertFalse(state["effective_connections"]["ect"])
        self.assertEqual(state["sensors"]["ect_voltage_v"], 5)
        self.assertFalse(state["sensors"]["ect_sensor_valid"])
        self.assertIn("P0118", state["dtcs"])
        self.assertIsNotNone(state["coolant_c"])

    def test_irregular_schedule_is_reproducible_and_advance_partition_invariant(self):
        a, b = configured(), configured()
        for sim in (a, b):
            sim.set_connection_fault("maf", pattern="irregular", connected_s=.3, dropout_s=.6)
        a.advance(3)
        for chunk in (.101, .035, .464, .003, .497, .9, 1):
            b.advance(chunk)
        self.assertEqual(a.snapshot(), b.snapshot())
        self.assertEqual(a.events, b.events)
        self.assertEqual(a.history, b.history)
        times = [event["t"] for event in transitions(a, "maf")]
        self.assertGreater(len(times), 4)
        self.assertNotEqual(times[0], 1.3)
        previous = 1
        for index, time in enumerate(times):
            duration = time - previous
            expected = .3 if index % 2 == 0 else .6
            self.assertGreaterEqual(duration + 1e-9, expected * .75)
            self.assertLessEqual(duration - 1e-9, expected * 1.25)
            previous = time

    def test_independent_connectors_do_not_share_random_sequence_or_controls(self):
        solo, pair = configured(), configured()
        solo.set_connection_fault("maf", pattern="irregular", connected_s=.2, dropout_s=.3)
        pair.set_connection_fault("map", pattern="irregular", connected_s=.2, dropout_s=.3)
        pair.set_connection_fault("maf", pattern="irregular", connected_s=.2, dropout_s=.3)
        solo.advance(2)
        pair.advance(2)
        self.assertEqual(transitions(solo, "maf"), transitions(pair, "maf"))
        faults = pair.snapshot()["connection_faults"]
        self.assertEqual(solo.snapshot()["connection_faults"]["maf"], faults["maf"])
        self.assertNotEqual(faults["maf"]["seed"], faults["map"]["seed"])
        self.assertNotEqual(transitions(pair, "maf")[0]["t"], transitions(pair, "map")[0]["t"])
        pair.set_connection("maf", True)
        self.assertNotIn("maf", pair.snapshot()["connection_faults"])
        self.assertEqual(pair.snapshot()["connection_faults"]["map"], faults["map"])

    def test_pause_state_reads_and_zero_advance_do_not_progress_fault_time(self):
        sim = configured()
        sim.set_connection_fault("maf", pattern="irregular")
        before = sim.snapshot()
        events = deepcopy(sim.events)
        for _ in range(10):
            self.assertEqual(sim.snapshot(), before)
            self.assertEqual(sim.advance(0), before)
        self.assertEqual(sim.events, events)

    def test_clear_does_not_repair_or_cancel_and_repair_does_not_clear(self):
        sim = configured()
        sim.set_connection_fault("maf", connected_s=.1, dropout_s=2)
        self.assertIn("P0102", sim.advance(.8)["dtcs"])
        schedule = deepcopy(sim.snapshot()["connection_faults"])
        sim.clear_emissions_dtcs()
        cleared = sim.snapshot()
        self.assertEqual(cleared["connection_faults"], schedule)
        self.assertFalse(cleared["effective_connections"]["maf"])
        self.assertNotIn("P0102", cleared["dtcs"])
        self.assertIn("P0102", sim.advance(.65)["dtcs"])
        repaired = sim.set_connection("maf", True)
        self.assertEqual(repaired["connection_faults"], {})
        self.assertIn("P0102", repaired["dtcs"])
        final = sim.advance(3)
        self.assertTrue(final["effective_connections"]["maf"])
        self.assertEqual(final["vehicle_sensors"]["maf"]["validity"], "valid")
        self.assertIn("P0102", final["dtcs"])

    def test_normal_open_and_direct_commands_replace_the_schedule(self):
        sim = configured()
        for mode, connected in (("open", False), ("normal", True)):
            sim.set_connection_fault("maf", connected_s=.1, dropout_s=.2)
            state = sim.set_connection_fault("maf", mode=mode)
            self.assertEqual(state["connection_faults"], {})
            self.assertEqual(state["effective_connections"]["maf"], connected)
            self.assertEqual(sim.advance(.6)["effective_connections"]["maf"], connected)
        sim.set_connection_fault("maf", connected_s=.1, dropout_s=.2)
        state = sim.set_connection("maf", False)
        self.assertEqual(state["connection_faults"], {})
        self.assertFalse(sim.advance(.6)["effective_connections"]["maf"])

    def test_invalid_requests_are_atomic_even_when_replacing_an_active_fault(self):
        sim = configured()
        sim.set_connection_fault("maf", connected_s=.1, dropout_s=1)
        sim.advance(.3)
        before = sim.snapshot()
        events = deepcopy(sim.events)
        history = deepcopy(sim.history)
        invalid = [
            ("fuel_level", {}), ("battery_soc", {}), ("pack_voltage", {}),
            ("unit_ecu", {}), ("dlc", {}), ("not_a_sensor", {}), (None, {}),
            ("maf", {"mode": "random"}), ("maf", {"pattern": "random"}),
            ("maf", {"connected_s": True}), ("maf", {"dropout_s": False}),
            ("maf", {"connected_s": float("nan")}), ("maf", {"dropout_s": float("inf")}),
            ("maf", {"connected_s": .001}), ("maf", {"dropout_s": 3600.1}),
            ("maf", {"mode": "normal", "dropout_s": 0}),
            ("maf", {"mode": "open", "pattern": None}),
        ]
        for connection_id, settings in invalid:
            with self.subTest(connection=connection_id, settings=settings), self.assertRaises(ValueError):
                sim.set_connection_fault(connection_id, **settings)
            self.assertEqual(sim.snapshot(), before)
            self.assertEqual(sim.events, events)
            self.assertEqual(sim.history, history)
        with self.assertRaises(ValueError):
            sim.set_connection("maf", "yes")
        self.assertEqual(sim.snapshot(), before)
        with self.assertRaises(ValueError):
            configured("petrol_basic").set_connection_fault("cam_sensor")

    def test_phase_rounding_and_irregular_bounds_are_defined_on_integer_ticks(self):
        sim = configured()
        fault = sim.set_connection_fault("maf", connected_s=.003, dropout_s=.003)["connection_faults"]["maf"]
        self.assertEqual(fault["next_change_s"], 1.004)
        self.assertEqual(sim.advance(.004)["connection_faults"]["maf"]["phase"], "dropout")
        for seconds in (.002, 3600):
            schedule = ConnectionFaultSchedule("maf", "irregular", seconds, seconds, started_tick=0, tick_seconds=.002)
            previous = 0
            for _ in range(10):
                current = schedule.next_change_tick
                duration = (current - previous) * .002
                self.assertGreaterEqual(duration, max(.002, seconds * .75))
                self.assertLessEqual(duration, min(3600, seconds * 1.25))
                schedule.advance_to(current)
                previous = current


if __name__ == "__main__":
    unittest.main()
