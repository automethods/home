#!/usr/bin/env python3
"""Check the delivered downloads, without installed third-party packages.

Build first with tools/build_standalone.py, then run:
python3 tests/check_download.py --downloads ../OBDII_Downloads
This starts temporary loopback servers and uses a recorder instead of a GUI browser.
"""
import argparse
import base64
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def request(url, data=None):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with HTTP.open(req, timeout=2) as response:
        return response.read()


def ready(process, url):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise AssertionError("Launcher exited before readiness: " + process.communicate()[0])
        try:
            return json.loads(request(url + "/api/meta"))
        except (urllib.error.URLError, OSError):
            time.sleep(0.05)
    raise AssertionError("Launcher did not become ready")


def stop(process, signum=signal.SIGINT):
    process.send_signal(signum)
    output = process.communicate(timeout=5)[0]
    assert process.returncode == 0 and "Lab stopped." in output, output


def check_configured_vehicle(url):
    """Exercise the packaged cockpit/API, not an imported source-tree model."""
    def call(path, data=None):
        return json.loads(request(url + path, data))

    metadata = call("/api/meta")
    configurations = {item["id"] for item in metadata["vehicle_configurations"]}
    assert configurations == {"petrol_basic", "petrol_advanced", "diesel", "hev", "phev", "bev"}
    parked = call("/api/vehicle", {"configuration": "petrol_basic"})
    vehicle = parked["state"]["vehicle"]
    assert vehicle["ignition"] == "off" and vehicle["start_state"] == "off"
    assert vehicle["selector"] == "P" and vehicle["parking_brake"] and parked["state"]["rpm"] == 0
    assert parked["state"]["battery_voltage_v"] is None and not vehicle["configuration"]["abs_installed"]
    assert parked["scanner"]["status"] == "disconnected"
    systems = call("/api/systems")
    units = {item["id"]: item for item in systems["units"]}
    assert units["engine"]["installed"] and units["ecu"]["installed"] and units["transmission"]["installed"]
    assert not units["battery"]["installed"] and not units["abs"]["installed"]
    assert len(systems["sensors"]) >= 25 and all(sensor["period_ms"] > 0 for sensor in systems["sensors"])
    assert len(call("/api/network")["wires"]) > 12

    call("/api/control", {"action": "ignition", "value": True})
    on = call("/api/advance", {"seconds": .1})
    assert on["state"]["rpm"] == 0 and on["state"]["vehicle"]["start_state"] == "ignition_on"
    call("/api/scanner", {"action": "connect", "module": "ecu", "protocol": "can11_500"})
    assert call("/api/diagnostic", {"payload": "01 0C"})["diagnostic"]["response_hex"] == "41 0C 00 00"
    starting = call("/api/control", {"action": "start"})
    assert starting["state"]["t"] == on["state"]["t"]
    started = call("/api/advance", {"seconds": 1.5})
    assert started["state"]["engine_running"] and started["state"]["vehicle"]["ready"]
    call("/api/control", {"action": "gear", "value": "D", "inputs": {"brake": .3}})
    call("/api/control", {"action": "parking_brake", "value": False})
    driven = call("/api/advance", {"seconds": 3, "inputs": {"brake": 0, "throttle": .5}})
    assert driven["state"]["speed_kph"] > 5 and driven["state"]["vehicle"]["selector"] == "D"
    assert isinstance(driven["state"]["vehicle"]["gear"], int)
    rpm = call("/api/diagnostic", {"payload": "01 0C"})["diagnostic"]
    assert rpm["response_hex"].startswith("41 0C") and len(rpm["frames"]) == 2
    assert int.from_bytes(bytes.fromhex(rpm["response_hex"])[2:], "big") > 0
    identification = call("/api/diagnostic", {"payload": "22 F1 90"})["diagnostic"]
    assert identification["response_hex"].startswith("62 F1 90") and any(frame["kind"] == "FC" for frame in identification["frames"])
    report = call("/api/scanner", {"action": "scan"})["scan_report"]
    assert len(report["modules"]) >= 7 and next(unit for unit in report["modules"] if unit["id"] == "ecu")["status"] == "healthy"

    call("/api/connection", {"id": "crank_sensor", "connected": False})
    faulty = call("/api/advance", {"seconds": .8})
    assert "P0335" in faulty["state"]["dtcs"] and not faulty["state"]["engine_running"]
    assert faulty["state"]["speed_kph"] > 0  # Removing a signal does not teleport the vehicle to rest.
    missing = call("/api/diagnostic", {"payload": "01 0C"})["diagnostic"]
    assert missing["status"] == "sample_unavailable" and missing["response_hex"] is None and missing["frames"] == []
    exported = call("/api/export.json")
    assert exported["vehicle_configuration"]["id"] == "petrol_basic" and exported["summary"]["final_soc_pct"] is None
    assert exported["final_state"]["vehicle_sensors"]["crank_sensor"]["value"] is None
    rows = list(csv.DictReader(io.StringIO(request(url + "/api/export.csv").decode())))
    assert rows[-1]["selector"] == "D" and rows[-1]["sensor_crank_sensor_value"] == ""
    assert rows[-1]["sensor_crank_sensor_validity"] == "invalid"

    electric = call("/api/vehicle", {"configuration": "bev"})
    assert electric["state"]["coolant_c"] is None and electric["state"]["vehicle"]["fuel_pct"] is None
    electric_units = {item["id"]: item for item in call("/api/systems")["units"]}
    assert not electric_units["engine"]["installed"] and not electric_units["ecu"]["installed"]
    assert electric_units["battery"]["installed"] and electric_units["inverter"]["installed"]
    assert not any(service["available_now"] for service in call("/api/diagnostic-definitions")["services"])
    call("/api/control", {"action": "ignition", "value": True})
    call("/api/control", {"action": "start"})
    ready_state = call("/api/advance", {"seconds": 1})
    assert ready_state["state"]["vehicle"]["ready"] and ready_state["state"]["rpm"] == 0
    call("/api/control", {"action": "gear", "value": "D", "inputs": {"brake": .3}})
    call("/api/control", {"action": "parking_brake", "value": False})
    ev_drive = call("/api/advance", {"seconds": 1, "inputs": {"brake": 0, "throttle": .5}})
    assert ev_drive["state"]["speed_kph"] > 0 and ev_drive["state"]["energy"]["fuel_l"] == 0
    assert ev_drive["state"]["energy"]["battery_discharge_kwh"] > 0 and ev_drive["state"]["vehicle"]["gear"] == 1
    call("/api/scanner", {"action": "connect", "module": "inverter", "protocol": "can11_500"})
    assert call("/api/diagnostic", {"payload": "01 0C"})["diagnostic"]["status"] == "state_only"
    ev_export = call("/api/export.json")
    assert ev_export["vehicle_configuration"]["id"] == "bev" and ev_export["summary"]["final_coolant_c"] is None
    return {"configurations": len(configurations), "units": len(units), "sensor_channels": len(systems["sensors"]),
            "scanner_modules": len(report["modules"])}



def check_sensor_characteristics_and_intermittent_faults(url):
    def call(path, data=None):
        return json.loads(request(url + path, data))
    call("/api/vehicle", {"configuration": "petrol_advanced"})
    systems = call("/api/systems")
    assert {s["id"] for s in systems["signal_types"]} == {"analog", "digital", "pulse", "discrete", "derived"}
    assert [g["sample_period_ms"] for g in systems["sample_groups"]] == [10, 20, 50, 100, 500, 1000]
    crank = next(s for s in systems["sensors"] if s["id"] == "crank_sensor")
    assert crank["characteristics"]["timing"]["sample_rate_hz"] == 50
    assert crank["characteristics"]["pulse"]["pulses_per_revolution"] == 60
    call("/api/control", {"action": "ignition", "value": True})
    call("/api/control", {"action": "start"})
    call("/api/advance", {"seconds": 1})
    call("/api/connection-fault", {"id": "maf", "pattern": "regular", "connected_s": 1, "dropout_s": 1})
    dropped = call("/api/advance", {"seconds": 1.7})["state"]
    assert dropped["connection_faults"]["maf"]["phase"] == "dropout"
    assert dropped["vehicle_sensors"]["maf"]["validity"] == "invalid" and "P0102" in dropped["dtcs"]
    recovered = call("/api/advance", {"seconds": .5})["state"]
    assert recovered["vehicle_sensors"]["maf"]["validity"] == "valid" and "P0102" in recovered["dtcs"]
    assert call("/api/export.json")["final_state"]["connection_faults"]["maf"]["dropout_count"] == 1
    call("/api/connection", {"id": "maf", "connected": True})
    stopped = call("/api/advance", {"seconds": 2})["state"]
    assert not stopped["connection_faults"] and stopped["effective_connections"]["maf"]
    assert b"data-um-group-heading" in request(url + "/web/unit-map.js")
    assert b"data-cv-arrangement" in request(url + "/web/connection-view.js")


def check_setup_and_cycle(url):
    def call(path, data=None):
        return json.loads(request(url + path, data))
    manual = call("/api/vehicle", {"configuration": "petrol_basic", "options": {
        "transmission_type": "manual_6", "drivetrain": "rwd", "mass_kg": 1420,
        "wheel_radius_m": .32, "ambient_c": 5, "initial_coolant_c": 5}})
    assert manual["state"]["vehicle"]["selector"] == "N"
    assert manual["state"]["vehicle"]["chassis"]["driven_wheels"] == ["rl", "rr"]
    call("/api/control", {"action": "ignition", "value": True})
    call("/api/control", {"action": "start", "inputs": {"clutch": 1, "brake": .35}})
    restored = call("/api/inputs", {"inputs": {"clutch": 0, "brake": 0}})
    assert restored["state"]["t"] == 0 and restored["state"]["inputs"]["clutch"] == 0
    started = call("/api/advance", {"seconds": 1.5})
    assert started["state"]["rpm"] > 500
    call("/api/control", {"action": "hvac", "value": {"enabled": True, "setpoint_c": 24, "fan": 1, "ac_enabled": False}})
    cold = call("/api/advance", {"seconds": 1})
    assert cold["state"]["vehicle"]["hvac"]["heat_kw"] == 0
    systems = call("/api/systems")
    assert len(systems["functional_groups"]) == 6
    assert next(s for s in systems["sensors"] if s["id"] == "crank_sensor")["start_required"]
    fuel = next(s for s in systems["sensors"] if s["id"] == "fuel_level")
    assert fuel["functional_group"] == "monitoring" and not fuel["disconnectable"]
    call("/api/vehicle", {"configuration": "bev", "options": {"ambient_c": 0}})
    cycles = call("/api/cycles")
    assert len(cycles["trace"]) == 1801 and max(v for _, v in cycles["trace"]) == 131.3
    call("/api/control", {"action": "hvac", "value": {"enabled": True, "setpoint_c": 24, "fan": 1, "ac_enabled": False}})
    call("/api/cycle", {"action": "start", "name": "wltc_class3b"})
    for _ in range(8):
        running = call("/api/advance", {"seconds": 5, "inputs": {"throttle": 0, "brake": 0}})
    snapshot = running["state"]
    assert snapshot["drive_cycle"]["status"] == "active" and snapshot["drive_target_kph"] is not None
    assert snapshot["vehicle"]["hvac"]["electric_heater_kw"] > 0 and snapshot["vehicle"]["hvac"]["energy_kwh"] > 0
    assert abs(snapshot["drive_cycle"]["tracking_error_kph"]) < 5
    report = call("/api/export.json")
    assert report["drive_cycle"]["status"] == "active" and report["final_state"]["drive_target_kph"] is not None
    assert any(p.get("drive_target_kph", 0) for p in report["history"])
    stopped = call("/api/cycle", {"action": "stop"})["state"]
    assert stopped["t"] == snapshot["t"] and stopped["inputs"]["brake"] == stopped["inputs"]["throttle"] == 0
    assert stopped["drive_cycle"]["status"] == "stopped" and stopped["drive_target_kph"] is None


def check_dashboard_controls(url):
    def call(path, body=None):
        return json.loads(request(url + path, body))
    html = request(url + "/").decode()
    assert 'id="service-dashboard"' in html and '/web/vehicle-monitor.js' in html
    assert html.index('id="service-dashboard"') < html.index('class="app-view-stack"')
    script = request(url + "/web/vehicle-monitor.js").decode()
    assert 'VehicleMonitor' in script and 'data-vm-redzone' in script
    assert 'vm-redzone' in request(url + "/web/vehicle-monitor.css").decode()
    for configuration in ("petrol_basic", "diesel", "bev"):
        call("/api/vehicle", {"configuration": configuration})
        call("/api/control", {"action": "ignition", "value": True})
        before = call("/api/state")["state"]["t"]
        call("/api/control", {"action": "seatbelt", "value": False})
        warning = call("/api/control", {"action": "driver_door", "value": True})["state"]
        assert warning["t"] == before
        assert all(warning["vehicle"]["warning_lamps"][key] for key in ("seatbelt", "door_open", "parking_brake"))
        call("/api/control", {"action": "start"})
        call("/api/advance", {"seconds": 1.2})
        call("/api/control", {"action": "gear", "value": "D", "inputs": {"brake": .35}})
        stopped = call("/api/advance", {"seconds": .5, "inputs": {"throttle": .6, "brake": 0}})["state"]
        assert stopped["speed_kph"] == 0 and stopped["vehicle"]["parking_brake"]
        call("/api/control", {"action": "parking_brake", "value": False})
        moving = call("/api/advance", {"seconds": 1})["state"]
        assert moving["speed_kph"] > 0 and moving["vehicle"]["selector"] == "D"
        assert not moving["vehicle"]["warning_lamps"]["parking_brake"]
        assert moving["vehicle"]["warning_lamps"]["seatbelt"] and moving["vehicle"]["warning_lamps"]["door_open"]
        exported = call("/api/export.json")
        assert exported["final_state"]["vehicle"]["driver_door_open"]
        assert not exported["final_state"]["vehicle"]["driver_seatbelt_fastened"]


def check_odometer_and_console(url):
    def call(path, body=None):
        return json.loads(request(url + path, body))
    monitor = request(url + "/web/vehicle-monitor.js").decode()
    assert all(marker in monitor for marker in ("data-vm-pedal-hold", "data-vm-pedal-range", "reset-trip", "take-control"))
    scanner = request(url + "/web/scan-tool.js").decode()
    assert all(marker in scanner for marker in ('data-sc-tab="faults"', 'data-sc-tab="data"', 'data-sc-tab="connector"'))
    assert b"DIESEL_SENSORS.html" in request(url + "/web/index.html")
    assert b"13" in request(url + "/docs/DIESEL_SENSORS.html")
    state = call("/api/vehicle", {"configuration": "petrol_basic", "options": {"initial_odometer_km": 68240.5}})["state"]
    assert state["vehicle"]["odometer_km"] == 68240.5 and state["vehicle"]["trip_distance_km"] == 0
    call("/api/control", {"action": "ignition", "value": True})
    call("/api/control", {"action": "start"})
    call("/api/advance", {"seconds": 1.2})
    call("/api/control", {"action": "gear", "value": "D", "inputs": {"brake": .35}})
    call("/api/control", {"action": "parking_brake", "value": False})
    moving = call("/api/advance", {"seconds": 3, "inputs": {"throttle": .5, "brake": 0}})["state"]
    assert moving["vehicle"]["odometer_km"] > 68240.5 and moving["vehicle"]["trip_distance_km"] > 0
    reset = call("/api/control", {"action": "reset_trip"})["state"]
    assert reset["t"] == moving["t"] and reset["vehicle"]["odometer_km"] == moving["vehicle"]["odometer_km"]
    assert reset["vehicle"]["trip_distance_km"] == 0 and reset["vehicle"]["selector"] == "D"
    exported = call("/api/export.json")
    assert exported["vehicle_configuration"]["powertrain"] == "petrol"
    assert exported["final_state"]["vehicle"]["odometer_km"] == reset["vehicle"]["odometer_km"]
    assert b"odometer_km" in request(url + "/api/export.csv")


def main(downloads, report_path):
    standalone = downloads / "run.sh"
    source_zip = downloads / "OBDII_Lab.zip"
    release = json.loads((ROOT / "RELEASE.json").read_text())
    expected_version = release["version"]
    assert expected_version == "0.9.5", "This acceptance check targets the 0.9.5 continuous-diagnostics release"
    checks = []
    for shell in ("sh", "bash"):
        subprocess.run([shell, "-n", str(standalone)], check=True, capture_output=True)
    checks.append("Standalone file passes sh and bash syntax checks")
    content = standalone.read_bytes()
    encoded = content.split(b"\n: <<'OBDII_PAYLOAD'\n", 1)[1].rsplit(b"\nOBDII_PAYLOAD", 1)[0]
    assert base64.b64decode(b"".join(encoded.split()), validate=True) == source_zip.read_bytes()
    with zipfile.ZipFile(source_zip) as archive:
        names = set(archive.namelist())
        assert {"run.sh", "launcher.py", "run.py", "web/index.html", "SHA256SUMS.txt",
                "obdii_lab/vehicle.py", "obdii_lab/vehicle_systems.py", "obdii_lab/scanner.py",
                "web/cockpit.js", "web/vehicle-monitor.js", "web/vehicle-monitor.css", "web/unit-map.js", "web/scan-tool.js", "web/setup.js", "web/message-inspector.js",
                "obdii_lab/drive_cycles.py", "data/wltc_class3b.json"}.issubset(names)
        assert not any(name.startswith("OBDII_Lab/") or "__pycache__" in name or name == "CHANGELOG.md" for name in names)
        sums = dict(line.split("  ", 1)[::-1] for line in archive.read("SHA256SUMS.txt").decode().splitlines())
        assert set(sums) == names - {"SHA256SUMS.txt"}
        assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in sums.items())
    checks.append("Flat source ZIP, complete file checksums and identical embedded payload")

    with tempfile.TemporaryDirectory(prefix="OBDII download check ", dir=ROOT.parent) as temporary:
        task = Path(temporary)
        work = task / "Shared disk" / "Work" / "OBDII"
        work.mkdir(parents=True)
        script = work / "run.sh"
        shutil.copyfile(standalone, script)
        script.chmod(0o444)
        work.chmod(0o555)
        runtime = task / "temporary-runtime"
        runtime.mkdir()
        minimal_bin = task / "python-only-path"
        minimal_bin.mkdir()
        (minimal_bin / "python3").symlink_to(sys.executable)
        env = os.environ.copy()
        for name in ("DISPLAY", "WAYLAND_DISPLAY", "BROWSER"):
            env.pop(name, None)
        env["TMPDIR"] = str(runtime)
        env["PATH"] = str(minimal_bin)
        bash = shutil.which("bash")
        assert bash

        def start(file, extra=None, environment=None, direct=False):
            port = free_port()
            command = ([str(file)] if direct else [bash, str(file)]) + ["--port", str(port)] + (extra or [])
            process = subprocess.Popen(command, cwd=task, env=environment or env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, start_new_session=True)
            return process, "http://127.0.0.1:" + str(port), port

        process, url, port = start(script, ["--no-browser"])
        try:
            assert ready(process, url)["version"] == expected_version
            assert list(work.iterdir()) == [script] and len(list(runtime.iterdir())) == 1
            index = request(url)
            assert b"vehicle-application" in index
            assert b'class="application mode-setup"' in index and b'class="app-version">0.9.5<' in index
            assert all(marker in index for marker in (b'aria-controls="view-drive"', b'aria-controls="view-service"'))
            assert b'id="tab-setup"' not in index and b'id="tab-units"' not in index
            assert all(marker in index for marker in (b'data-service-view="diagnostics"', b'data-service-view="units"', b'data-service-view="configuration"'))
            assert all(label in index for label in (b">Drive</button>", b">Diagnostics &amp; service</button>", b">Vehicle units</button>", b">Diagnostics</button>"))
            assert all(marker in index for marker in (b"view-live", b"view-diagnosis", b"view-wiring", b"view-locations"))
            assert all(marker not in index for marker in (b"learning-reader", b"instrument-workspace", b"/web/app.js", b"/web/workbench.js", b"/web/dashboard.js"))
            assert len(json.loads(request(url + "/api/book"))["documents"]) == 12
            assert request(url + "/OBDII_Beginner_Handbook.pdf").startswith(b"%PDF-")
            assert request(url + "/OBDII_Learning_Guide.pdf").startswith(b"%PDF-")
            assert request(url + "/OBDII_Visual_Workbench.pdf").startswith(b"%PDF-")
            for module, marker in (("session.js", b"AppSession"), ("application.js", b"VehicleApplication"),
                                   ("live-data.js", b"LiveDataView"), ("diagnosis.js", b"DiagnosisView"),
                                   ("connection-view.js", b"LocationsView"), ("cockpit.js", b"CockpitView"),
                                   ("unit-map.js", b"UnitMapView"), ("scan-tool.js", b"ScannerView"),
                                   ("setup.js", b"SetupView"), ("message-inspector.js", b"MessageInspector")):
                assert marker in request(url + "/web/" + module)
            for stylesheet in ("application.css", "live-data.css", "diagnosis.css", "connection-view.css", "cockpit.css", "unit-map.css", "scan-tool.css", "setup.css"):
                assert len(request(url + "/web/" + stylesheet)) > 500
            assert b"0.9.5" in request(url + "/docs/WORKSPACE.html")
            setup_source = request(url + "/web/setup.js")
            assert b'data-setup-stage="vehicle"' in setup_source and b'data-setup-stage="workspace"' in setup_source
            assert b'data-workspace-choice="service"' in setup_source and b'data-workspace-choice="drive"' in setup_source
            definitions = json.loads(request(url + "/api/diagnostic-definitions"))
            assert len(definitions["modules"]) == release["diagnostic_definition_modules"]
            assert len(definitions["services"]) == release["diagnostic_definition_services"]
            assert {module["id"] for module in definitions["modules"]} == {"ecu", "bmu", "phev_ecu", "abs_esp"}
            assert all(service["availability"] == "implemented" for service in definitions["services"])
            request(url + "/api/reset", {"profile": "phev", "scenario": "city_drive", "config": {}})
            drive = json.loads(request(url + "/api/advance", {"seconds": 1, "inputs": {}}))["state"]
            assert drive["distance_m"] > 0 and drive["drive_phase"] and drive["speed_kph"] > 0
            scan = json.loads(request(url + "/api/diagnostic", {"payload": "01 0D", "can_id": "7DF"}))["diagnostic"]
            assert scan["response_hex"].startswith("41 0D") and len(scan["frames"]) == 2
            assert len(json.loads(request(url + "/api/network"))["wires"]) == 12
            assert request(url + "/web/models/training_vehicle.glb").startswith(b"glTF")
            assert b"bind" in request(url + "/web/three-adapter.js")
            assert b"WORKSPACE.html" in request(url + "/START_HERE.html")
            request(url + "/api/reset", {"profile": "engine", "scenario": "manual", "config": {}})
            result = json.loads(request(url + "/api/advance", {"seconds": 0.5, "inputs": {"ignition": True, "fault": "ect_open"}}))
            assert result["state"]["t"] > 0 and not result["state"]["sensors"]["ect_sensor_valid"]
            assert result["explanation"]
            configured_counts = check_configured_vehicle(url)
            check_sensor_characteristics_and_intermittent_faults(url)
            check_dashboard_controls(url)
            check_odometer_and_console(url)
            check_setup_and_cycle(url)
            stop(process)
            assert not list(runtime.iterdir())
            with socket.socket() as sock:
                assert sock.connect_ex(("127.0.0.1", port)) != 0
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
        checks.extend([
            "Only run.sh in an otherwise empty folder; launched from a different directory and path with spaces",
            "No executable permission needed; read-only file/directory modes; PATH contains only Python",
            "Staged Vehicle / Workspace flow, Drive and Diagnostics & service, linked service tools, decimal message explanations, current 0.9.3 guide and bundled reference PDFs",
            "Legacy reset, scripted drive, OBD response and electrical fault APIs remain available",
            "Packaged petrol cockpit: ignition alone leaves RPM zero, START cranks/runs, PRND and parking brake govern actual driving, scan-tool OBD/UDS requests return generated frames",
            "Packaged crank-sensor interruption stalls the engine while the car coasts; DTC, unavailable scan sample and blank measured CSV channel agree",
            "Packaged sensor characteristics expose five signal types and six sample rates; intermittent MAF dropout changes measured validity, stores P0102, recovers without clearing memory, exports its schedule and cancels on direct reconnection",
            "Packaged dashboard and persistent service instruments: parking brake holds the car with accelerator applied; manual release moves petrol, diesel and BEV; seat-belt/door indicators reflect shared state and exported BODY events",
            "Packaged compact scanner and shared service pedal assets are present; configured odometer follows real movement and Trip A reset preserves total distance, clock, gear and export identity",
            "Packaged BEV has no engine/ECU or fuel reading, reaches READY, drives electrically and exports nullable engine fields; inverter inspection is explicitly state-only",
            "Packaged manual transmission starts in Neutral with clutch interlock; temporary inputs restore without advancing time; cold coolant cannot immediately heat the cabin",
            "Packaged official WLTC trace has 1801 samples; virtual driving preserves target/actual history, electric cabin heat consumes power, takeover releases pedals without advancing time",
            f"Packaged metadata exposes {configured_counts['configurations']} vehicle configurations, {configured_counts['units']} unit roles, {configured_counts['sensor_channels']} sampled sensor definitions and {configured_counts['scanner_modules']} scan-tool module roles",
            "Bundled simulator advances and injected temperature-sensor fault changes the live state",
            "Custom port, no-browser option, Ctrl+C exit, socket close and temporary-folder cleanup",
        ])

        process, url, _ = start(script, ["--no-browser"])
        try:
            ready(process, url)
            stop(process, signal.SIGTERM)
            assert not list(runtime.iterdir())
            assert list(work.iterdir()) == [script] and script.read_bytes() == content
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
        checks.append("Repeated launch and SIGTERM cleanup leave downloaded folder and file unchanged")

        with socket.socket() as occupied:
            occupied.bind(("127.0.0.1", 0))
            occupied.listen()
            result = subprocess.run([bash, str(script), "--port", str(occupied.getsockname()[1]), "--no-browser"],
                                    cwd=task, env=env, capture_output=True, text=True, timeout=8)
            assert result.returncode == 1 and "already in use" in result.stderr
            assert "bash run.sh --port" in result.stderr and not list(runtime.iterdir())
        checks.append("Occupied port produces an actionable error and cleans its temporary files")

        for damaged_content in (content[:-150], content.replace(b"UEsDB", b"QEsDB", 1)):
            assert damaged_content != content
            broken = task / "damaged.sh"
            broken.write_bytes(damaged_content)
            result = subprocess.run([bash, str(broken), "--no-browser"], cwd=task, env=env, capture_output=True, text=True, timeout=8)
            assert result.returncode == 1 and "Download run.sh again" in result.stderr, result.stderr
            assert "Traceback" not in result.stderr and not list(runtime.iterdir())
        checks.append("Truncated or corrupted downloads fail clearly before starting the simulator")

        for options, code, message in ((["--help"], 0, "--no-browser"), (["--port", "0"], 2, "1024")):
            result = subprocess.run([bash, str(script), *options], cwd=task, env=env, capture_output=True, text=True, timeout=8)
            assert result.returncode == code and message in result.stdout + result.stderr
            assert not list(runtime.iterdir())
        checks.append("Help and invalid-port exits clean up bundled files")

        marker = task / "browser-call.json"
        recorder = task / "browser_recorder.py"
        recorder.write_text('import json,sys,urllib.request\nfrom pathlib import Path\nurl=sys.argv[2]\nwith urllib.request.build_opener(urllib.request.ProxyHandler({})).open(url+"/api/meta",timeout=1) as response: ready=response.status==200\nPath(sys.argv[1]).write_text(json.dumps({"url":url,"ready_at_browser_handoff":ready}))\n')
        browser_env = env.copy()
        browser_env["BROWSER"] = " ".join(shlex.quote(value) for value in (sys.executable, str(recorder), str(marker))) + " %s"
        process, url, _ = start(script, environment=browser_env)
        try:
            ready(process, url)
            deadline = time.monotonic() + 5
            while not marker.exists() and time.monotonic() < deadline:
                time.sleep(0.05)
            assert json.loads(marker.read_text()) == {"url": url, "ready_at_browser_handoff": True}
            stop(process)
            assert not list(runtime.iterdir())
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
        checks.append("Browser handoff occurs once and only after the bundled server is ready")

        direct_script = task / "executable-run.sh"
        shutil.copyfile(standalone, direct_script)
        direct_script.chmod(0o755)
        process, url, _ = start(direct_script, ["--no-browser"], direct=True)
        try:
            ready(process, url)
            stop(process)
            assert not list(runtime.iterdir())
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
        checks.append("Direct executable launcher also works when executable permission is available")

        extracted = task / "Extracted source"
        with zipfile.ZipFile(source_zip) as archive:
            archive.extractall(extracted)
        source_env = env.copy()
        source_env["PATH"] = os.environ["PATH"]
        process, url, _ = start(extracted / "run.sh", ["--no-browser"], environment=source_env)
        try:
            assert ready(process, url)["version"] == expected_version
            assert len(json.loads(request(url + "/api/book"))["documents"]) == 12
            stop(process)
            assert not list(extracted.rglob("__pycache__"))
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
        checks.append("Flat source ZIP launches after extraction, without creating bytecode/history folders")
        work.chmod(0o755)

    report = {"status": "PASS", "checks": checks,
              "browser_check": "A recorder executable verified browser handoff; the actual Mint desktop and browser were not available.",
              "permission_check": "Read-only file and directory mode bits were used; a physical noexec shared-drive mount was not available."}
    if report_path:
        report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--downloads", type=Path, default=ROOT.parent / "OBDII_Downloads")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    main(args.downloads.resolve(), args.report)
