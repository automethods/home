/* Vehicle identity selection contracts: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_vehicle_identity_v093.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}

let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){const server=await startServer();let app;try{
 for(const m of fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)){if(m[1]==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,m[1]),'utf8'),sandbox,{filename:m[1]});}
 app=window.VehicleApplication;await app.ready;await flush();
 const state=()=>app.session.result.state,configuration=()=>state().vehicle.configuration;
 const settle=async()=>{await app.session.command;await waitFor(()=>app.session.pending===0,'Vehicle selection settles');await flush();};
 const draft=async id=>{if(app.session.workflowStage!=='vehicle')app.session.beginSetup();await settle();$('[data-setup="configuration"]').value=id;await $('[data-setup="configuration"]').dispatchEvent({type:'change'});$('[data-setup="driving_mode"]').value='manual';await $('[data-setup="driving_mode"]').dispatchEvent({type:'change'});await settle();};
 const apply=async()=>{await $('[data-setup-action="apply"]').click();await settle();};
 const enter=async(mode='drive')=>{if(app.session.workflowStage==='workspace')await $(`[data-workspace-choice="${mode}"]`).click();else app.session.navigate(mode);await settle();};
 const identity=(id,label,powertrain)=>{assert.equal(configuration().id,id);assert.equal(configuration().powertrain,powertrain);assert.equal($('#configuration-label').textContent,label);assert.equal($('#vehicle-profile').textContent,powertrain.toUpperCase());assert.equal($('[data-ck="vehicle-name"]').textContent,label);assert.equal($('[data-setup="committed-name"]').textContent,label);};
 const unit=id=>app.session.systems.units.find(item=>item.id===id);
 const component=id=>app.session.catalog.components.find(item=>item.id===id);
 await test('Applying basic petrol shows one committed ICE identity in both workspaces',async()=>{await draft('petrol_basic');await apply();await enter();identity('petrol_basic','Petrol · basic','petrol');assert.equal(state().profile,'phev','Legacy solver profile stays compatible and is not used as vehicle identity');assert.equal(unit('battery').installed,false);assert.equal(unit('bmu').installed,false);assert.equal(unit('inverter').installed,false);assert.equal(unit('charging').installed,false);app.session.navigate('service');await settle();identity('petrol_basic','Petrol · basic','petrol');assert.equal($('[data-vm="energy-label"]').textContent,'Fuel');});
 await test('Basic ICE unit selection, wiring and renderer catalog agree on Vehicle controller',async()=>{assert.equal(unit('supervisor').label,'Vehicle controller');assert.equal(component('supervisor').label,unit('supervisor').label);assert.equal(component('supervisor').description,unit('supervisor').description);app.session.select('supervisor');app.session.navigate('wiring');await settle();assert.match($('[data-cv-title]').textContent,/Vehicle controller/);assert.doesNotMatch($('#selection-breadcrumb').textContent,/hybrid|phev/i);assert.equal($('#inspector-content').querySelector('.inspector-title').textContent,'Vehicle controller');app.session.navigate('locations');await settle();assert.equal(renderers.at(-1).catalog.components.find(c=>c.id==='supervisor').label,'Vehicle controller');assert.equal(renderers.at(-1).catalog.components.find(c=>c.id==='bmu').installed,false);});
 await test('Basic ICE wiring offers fitted circuits and live data uses a neutral engine-control label',async()=>{app.session.select('overview');app.session.navigate('wiring');await settle();assert.ok(document.querySelector('[data-cv-select="coolant_sensor"]'));assert.equal(document.querySelector('[data-cv-select="bmu"]'),null);assert.equal(document.querySelector('[data-cv-select="abs"]'),null);app.session.navigate('live');await settle();const signal=app.session.signals.find(item=>item.id==='engine_requested');assert.equal(signal.source,'Engine control');app.session.navigate('units');await settle();assert.equal(document.querySelector('[data-um-unit="battery"]'),null);assert.equal(document.querySelector('[data-um-unit="bmu"]'),null);});
 await test('Choosing PHEV is a draft until Apply and then updates hardware and every vehicle label',async()=>{await draft('phev');assert.equal($('[data-setup="configuration"]').value,'phev');assert.match($('[data-setup="summary"]').textContent,/Plug-in hybrid/);identity('petrol_basic','Petrol · basic','petrol');await apply();await enter();identity('phev','Plug-in hybrid · PHEV','phev');assert.equal(unit('battery').installed,true);assert.equal(unit('bmu').installed,true);assert.equal(unit('inverter').installed,true);assert.equal(unit('charging').installed,true);app.session.select('overview');app.session.navigate('wiring');await settle();assert.ok(document.querySelector('[data-cv-select="bmu"]'));assert.match($('[data-cv-select="bmu"]').textContent,/BMU → Vehicle controller/);});
 await test('Returning from PHEV to basic ICE removes HV hardware, sources and stale identity after Apply',async()=>{await draft('petrol_basic');assert.equal($('[data-setup="configuration"]').value,'petrol_basic');identity('phev','Plug-in hybrid · PHEV','phev');await apply();await enter();identity('petrol_basic','Petrol · basic','petrol');assert.equal(unit('battery').installed,false);assert.equal(component('battery').installed,false);assert.equal(component('bmu').installed,false);assert.equal(state().soc_pct,null);assert.deepEqual(Object.keys(state().bmu_report),[]);assert.equal($('[data-ck="energy-label"]').textContent,'Fuel remaining');app.session.select('overview');for(const route of ['scan','units','wiring','live','locations','configuration']){app.session.navigate(route);await settle();identity('petrol_basic','Petrol · basic','petrol');}app.session.navigate('wiring');await settle();assert.equal(document.querySelector('[data-cv-select="bmu"]'),null);});
 await test('HEV retains electric hardware but omits a plug-in charge interface',async()=>{await draft('hev');await apply();await enter('service');identity('hev','Hybrid · HEV','hev');assert.equal(unit('battery').installed,true);assert.equal(unit('bmu').installed,true);assert.equal(unit('inverter').installed,true);assert.equal(unit('charging').installed,false);assert.equal(component('supervisor').label,'Vehicle controller');app.session.select('overview');app.session.navigate('wiring');await settle();assert.ok(document.querySelector('[data-cv-select="bmu"]'));});
 assert.equal(errors.length,0,errors.join('\n'));const result={suite:'Vehicle identity and configuration selection v0.9.3',passed,failed:0,requests:requests.length,scope:'Actual setup form, shared Session, Python HTTP and parsed UI. Vehicle renderer receives the actual catalog; native layout/GPU are not exercised.'};if(process.argv[2])fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2));console.log(JSON.stringify(result));
}finally{if(app)app.dispose();server.lines.close();server.child.kill('SIGTERM');}}
main().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
