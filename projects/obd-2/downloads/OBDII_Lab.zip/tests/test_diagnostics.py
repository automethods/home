"""Protocol examples, framing failures, and consistency checks (no hardware)."""

import unittest

from obdii_lab.diagnostics import (
    DiagnosticServer, IsoTpReceiver, SYNTHETIC_VIN,
    decode_dtc, encode_dtc, segment_payload,
)


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.snapshot = {
            "rpm": 2000, "coolant_c": 90, "speed_kph": 50,
            "load_pct": 40, "maf_g_s": 12.5, "throttle_pct": 20,
            "ambient_c": 20, "dtcs": [], "pending_dtcs": [], "mil": False,
            "components_monitor_complete": False,
        }
        self.server = DiagnosticServer(lambda: self.snapshot)

    def test_rpm_known_answer_and_can_format(self):
        result = self.server.request("01 0C")
        self.assertEqual(result["response_hex"], "41 0C 1F 40")
        self.assertEqual(result["frames"][0]["data"], "02 01 0C 00 00 00 00 00")
        self.assertEqual(result["frames"][0]["id"], "7DF")
        self.assertEqual(result["frames"][1]["data"], "04 41 0C 1F 40 00 00 00")
        self.assertEqual(result["frames"][1]["id"], "7E8")

    def test_coolant_encoding_and_sensor_truth_distinction(self):
        self.assertEqual(self.server.request("0105")["response_hex"], "41 05 82")
        self.snapshot["sensors"] = {"ect_c": -40, "ect_used_c": 80}
        self.assertEqual(self.server.request("0105")["response_hex"], "41 05 00")
        self.assertEqual(self.snapshot["coolant_c"], 90)

    def test_airflow_and_percentage_known_answers(self):
        self.assertEqual(self.server.request("01 10")["response_hex"], "41 10 04 E2")
        self.assertEqual(self.server.request("01 04")["response_hex"], "41 04 66")
        self.assertEqual(self.server.request("01 11")["response_hex"], "41 11 33")
        self.assertEqual(self.server.request("01 0F")["response_hex"], "41 0F 3C")
        self.assertEqual(self.server.request("01 0D")["response_hex"], "41 0D 32")

    def test_supported_mask_matches_services(self):
        result = bytes.fromhex(self.server.request("01 00")["response_hex"])
        mask = int.from_bytes(result[2:], "big")
        for pid in range(1, 33):
            advertised = bool(mask & (1 << (32 - pid)))
            returned = self.server.request(f"01 {pid:02X}")["response_hex"] is not None
            self.assertEqual(advertised, returned, hex(pid))
        self.assertEqual(self.server.request("09 00")["response_hex"], "49 00 40 00 00 00")

    def test_dtc_count_is_included_for_can(self):
        self.snapshot.update(dtcs=["P0118"], pending_dtcs=["P0118"], mil=True)
        self.assertEqual(self.server.request("03")["response_hex"], "43 01 01 18")
        self.assertEqual(self.server.request("07")["response_hex"], "47 01 01 18")
        self.assertEqual(self.server.request("01 01")["response_hex"], "41 01 81 44 00 00")
        self.snapshot["components_monitor_complete"] = True
        self.assertEqual(self.server.request("01 01")["response_hex"], "41 01 81 04 00 00")

    def test_empty_dtc_memory(self):
        self.assertEqual(self.server.request("03")["response_hex"], "43 00")
        self.assertEqual(self.server.request("07")["response_hex"], "47 00")

    def test_clear_is_real_callback_not_cosmetic(self):
        self.snapshot.update(dtcs=["P0118"], pending_dtcs=["P0118"], mil=True)
        self.assertIsNone(self.server.request("04")["response_hex"])
        self.assertEqual(self.snapshot["dtcs"], ["P0118"])
        def clear():
            self.snapshot.update(dtcs=[], pending_dtcs=[], mil=False,
                                 components_monitor_complete=False)
        server = DiagnosticServer(lambda: self.snapshot, clear)
        self.assertEqual(server.request("04")["response_hex"], "44")
        self.assertEqual(server.request("03")["response_hex"], "43 00")

    def test_vin_transport_contains_physical_flow_control(self):
        result = self.server.request("09 02")
        self.assertEqual(len(SYNTHETIC_VIN), 17)
        self.assertEqual([f["kind"] for f in result["frames"]], ["SF", "FF", "FC", "CF", "CF"])
        self.assertEqual(result["frames"][1]["data"].split()[:2], ["10", "14"])
        self.assertEqual(result["frames"][2]["id"], "7E0")
        receiver = IsoTpReceiver(padding_byte=0)
        assembled = None
        for index, frame in enumerate(result["frames"]):
            if frame["id"] == "7E8":
                assembled = receiver.feed(frame["data"], index * .001)
        self.assertEqual(assembled, b"\x49\x02\x01" + SYNTHETIC_VIN.encode())

    def test_silent_unsupported_and_strict_shapes(self):
        for request in ["01 FF", "01 0C 0D", "02 0C", "22 F1 90", "03 00", "09 04", "0A"]:
            result = self.server.request(request)
            self.assertIsNone(result["response_hex"], request)
            self.assertEqual(len(result["frames"]), 1)
        self.assertIsNone(self.server.request("01 0C", 0x700)["response_hex"])
        self.assertEqual(self.server.request("01 0C", 0x7E0)["response_hex"], "41 0C 1F 40")

    def test_invalid_input_and_encoding_bounds(self):
        for request in ["", "ATZ", "0", "gg", "01 " * 8]:
            self.assertIn("error", self.server.request(request))
        self.assertIn("error", self.server.request("01 0C", 0x800))
        self.snapshot["rpm"] = 90000
        self.assertEqual(self.server.request("01 0C")["response_hex"], "41 0C FF FF")
        self.snapshot["rpm"] = float("nan")
        self.assertIn("error", self.server.request("01 0C"))


class DtcTests(unittest.TestCase):
    def test_known_binary_mapping(self):
        for text, raw in [("P0118", "01 18"), ("P0300", "03 00"),
                          ("U0100", "C1 00"), ("C1234", "52 34"), ("B2ABC", "AA BC")]:
            self.assertEqual(encode_dtc(text), bytes.fromhex(raw))
            self.assertEqual(decode_dtc(raw), text)

    def test_all_bit_patterns_roundtrip(self):
        # Covers every family, leading digit, and low nibble, including boundaries.
        for number in range(65536):
            raw = number.to_bytes(2, "big")
            self.assertEqual(encode_dtc(decode_dtc(raw)), raw)

    def test_invalid_codes(self):
        for code in ["P4000", "X1234", "P011", "P01G8", "P12345"]:
            with self.assertRaises(ValueError):
                encode_dtc(code)


class IsoTpTests(unittest.TestCase):
    def test_roundtrip_at_boundaries_and_sequence_wrap(self):
        for size in [1, 7, 8, 13, 14, 20, 111, 112, 120, 255, 4095]:
            payload = bytes(i % 256 for i in range(size))
            frames = segment_payload(payload)
            self.assertTrue(all(len(f) == 8 for f in frames))
            receiver = IsoTpReceiver()
            for index, frame in enumerate(frames):
                result = receiver.feed(frame, index * .001)
            self.assertEqual(result, payload, size)
            self.assertFalse(receiver.active)

    def test_wrong_sequence_aborts(self):
        frames = segment_payload(bytes(range(20)))
        receiver = IsoTpReceiver()
        receiver.feed(frames[0], 0)
        with self.assertRaisesRegex(ValueError, "sequence"):
            receiver.feed(frames[2], .001)
        self.assertFalse(receiver.active)

    def test_timeout_is_simulated_not_wall_clock(self):
        frames = segment_payload(bytes(range(20)))
        receiver = IsoTpReceiver(timeout_s=.05)
        receiver.feed(frames[0], 1)
        with self.assertRaises(TimeoutError):
            receiver.feed(frames[1], 1.06)
        self.assertFalse(receiver.active)

    def test_bad_padding_and_malformed_length(self):
        with self.assertRaises(ValueError):
            IsoTpReceiver(padding_byte=0).feed("02 01 0C FF FF FF FF FF")
        for bad in ["", "00", "07 01", "10 06 01 02 03 04 05 06", "10 14", "21 01 02", "30 00 00"]:
            with self.assertRaises(ValueError):
                IsoTpReceiver().feed(bad)
        receiver = IsoTpReceiver()
        receiver.feed(segment_payload(bytes(range(20)))[0])
        with self.assertRaisesRegex(ValueError, "Truncated"):
            receiver.feed("21 07 08")

    def test_single_frame_replaces_previous_transfer(self):
        receiver = IsoTpReceiver()
        receiver.feed(segment_payload(bytes(range(20)))[0])
        self.assertEqual(receiver.feed("02 41 00", .01), b"\x41\x00")
        self.assertFalse(receiver.active)


if __name__ == "__main__":
    unittest.main()
