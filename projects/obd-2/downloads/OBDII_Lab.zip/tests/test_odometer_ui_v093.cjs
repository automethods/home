/* Odometer and Trip A dashboard contracts: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_odometer_ui_v093.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){const server=await startServer();let app;try{
 const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
 for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
 app=window.VehicleApplication;await app.ready;await flush();
 const state=()=>app.session.result.state,vehicle=()=>state().vehicle;
 const settled=()=>app.session.pending===0&&!app.monitor.inspect().pending&&!app.views.drive.inspect().pending;
 const settle=async()=>{await app.session.command;await waitFor(settled,'Distance controls settle');await flush();};
 const click=async selector=>{await $(selector).click();await settle();};
 const format=value=>new Intl.NumberFormat('en-GB',{minimumFractionDigits:1,maximumFractionDigits:1}).format(value);
 const assertCounters=()=>{const v=vehicle();assert.equal($('[data-ck="odometer"]').textContent,format(v.odometer_km));assert.equal($('[data-ck="trip"]').textContent,format(v.trip_distance_km));assert.equal($('[data-vm="odometer"]').textContent,format(v.odometer_km));assert.equal($('[data-vm="trip"]').textContent,format(v.trip_distance_km));};
 const next=async(id='petrol_basic',options={},mode='manual')=>{const settings={mode,road_mu:.9,grade_pct:0};if(app.session.setupComplete)await app.session.setup(id,options,settings,{enterDrive:false});else await app.session.commitSetup(id,options,settings);app.session.enterWorkspace('drive');app.session.setRunning(false);await settle();};
 await test('Initial distance counters are zero without invented vehicle history',async()=>{await next();assert.equal(vehicle().odometer_km,0);assert.equal(vehicle().trip_distance_km,0);assertCounters();assert.equal($('[data-ck="odometer"]').textContent,'0.0');});
 await test('Configured odometer is grouped with one decimal and Trip A starts independently',async()=>{await next('petrol_basic',{initial_odometer_km:123456.7});assert.equal($('[data-ck="odometer"]').textContent,'123,456.7');assert.equal($('[data-ck="trip"]').textContent,'0.0');assertCounters();assert.match($('[data-ck="distance-display"]').getAttribute('aria-label'),/Odometer 123,456.7 kilometres; Trip A 0.0 kilometres/);});
 await test('Engine idle does not manufacture distance while time advances',async()=>{await app.session.control('ignition',true);await app.session.control('start');app.session.setRunning(false);await app.session.advance(3);await settle();assert.equal(state().engine_running,true);assert.equal(state().speed_kph,0);assert.equal(vehicle().odometer_km,123456.7);assert.equal(vehicle().trip_distance_km,0);assertCounters();});
 await test('Forward driving increases both counters from actual model distance',async()=>{await app.session.shift('D',{assist:true});await app.session.control('parking_brake',false);await app.session.setInputs({throttle:.6,brake:0});await app.session.advance(12);await settle();assert.ok(state().distance_m>20);assert.ok(vehicle().odometer_km>123456.7);assert.ok(Math.abs(vehicle().odometer_km-123456.7-state().distance_m/1000)<1e-8);assert.ok(Math.abs(vehicle().trip_distance_km-state().distance_m/1000)<1e-8);assertCounters();});
 await test('Full dashboard Reset Trip A preserves total distance, time, gear and running engine',async()=>{const before={t:state().t,odo:vehicle().odometer_km,distance:state().distance_m,gear:vehicle().selector,speed:state().speed_kph},count=requests.filter(r=>r.url==='/api/control'&&r.body.action==='reset_trip').length;await click('[data-ck-action="reset-trip"]');assert.equal(vehicle().trip_distance_km,0);assert.equal(vehicle().odometer_km,before.odo);assert.equal(state().distance_m,before.distance);assert.equal(state().t,before.t);assert.equal(vehicle().selector,before.gear);assert.equal(state().speed_kph,before.speed);assert.equal(state().engine_running,true);assert.equal(requests.filter(r=>r.url==='/api/control'&&r.body.action==='reset_trip').length,count+1);assertCounters();});
 await test('Service dashboard shows the same growing trip and resets only Trip A while tools stay open',async()=>{await app.session.advance(3);assert.ok(vehicle().trip_distance_km>0);app.session.navigate('service');app.session.navigate('wiring');await settle();assert.equal($('#service-dashboard').hidden,false);assertCounters();const before={t:state().t,odo:vehicle().odometer_km,selection:app.session.selection,view:app.session.view};await click('[data-vm-action="reset-trip"]');assert.equal(vehicle().trip_distance_km,0);assert.equal(vehicle().odometer_km,before.odo);assert.equal(state().t,before.t);assert.equal(app.session.selection,before.selection);assert.equal(app.session.view,before.view);assertCounters();});
 await test('Repeated reset clicks wait for one confirmed shared command',async()=>{await app.session.advance(.2);const originalFetch=app.session.fetch;let release,held=0;const gate=new Promise(resolve=>{release=resolve;});app.session.fetch=async(url,options)=>{if(url==='/api/control'&&JSON.parse(options.body).action==='reset_trip'){held++;await gate;}return originalFetch(url,options);};let first;try{first=$('[data-vm-action="reset-trip"]').click();await waitFor(()=>held===1,'Reset request held');assert.equal($('[data-vm-action="reset-trip"]').disabled,true);assert.equal($('[data-ck-action="reset-trip"]').disabled,true);await $('[data-vm-action="reset-trip"]').click();assert.equal(held,1);release();await first;await settle();assert.equal(vehicle().trip_distance_km,0);assertCounters();}finally{release();await first;app.session.fetch=originalFetch;}});
 await test('Reset remains available to inspect distance during WLTC without stopping its driver',async()=>{await next('petrol_basic',{initial_odometer_km:2000},'wltc_class3b');app.session.navigate('service');await app.session.cycleAction('start');app.session.setRunning(false);await app.session.advance(14);await settle();assert.ok(['preparing','active'].includes(state().drive_cycle.status));assert.equal($('[data-vm-action="reset-trip"]').disabled,false);const before={t:state().t,odo:vehicle().odometer_km,cycle:state().drive_cycle.status};await click('[data-vm-action="reset-trip"]');assert.equal(state().t,before.t);assert.equal(vehicle().odometer_km,before.odo);assert.equal(state().drive_cycle.status,before.cycle);assert.equal(vehicle().trip_distance_km,0);assertCounters();});
 await test('BEV uses the same truthful counters and changing the vehicle starts its chosen baseline',async()=>{await next('bev',{initial_odometer_km:98765.4});assert.equal(state().t,0);assert.equal(vehicle().odometer_km,98765.4);assert.equal(vehicle().trip_distance_km,0);assertCounters();assert.equal($('[data-ck="odometer"]').textContent,'98,765.4');assert.equal($('[data-vm-redzone="left"]').style.display,'none');});
 await test('Starting mileage entered in the real setup form seeds both dashboards and adds actual driving distance',async()=>{
  await click('[data-action="configuration"]');assert.equal(app.session.workflowStage,'vehicle');
  $('[data-setup="configuration"]').value='petrol_basic';await $('[data-setup="configuration"]').dispatchEvent({type:'change'});
  $('[data-setup="driving_mode"]').value='manual';await $('[data-setup="driving_mode"]').dispatchEvent({type:'change'});
  $('[data-setup="initial_odometer_km"]').value='65432.1';await $('[data-setup="initial_odometer_km"]').dispatchEvent({type:'change'});
  assert.equal(vehicle().odometer_km,98765.4,'Typing a seed is a draft, not a live odometer edit');
  await click('[data-setup-action="apply"]');assert.equal(vehicle().configuration.id,'petrol_basic');assert.equal(vehicle().configuration.initial_odometer_km,65432.1);assert.equal(vehicle().odometer_km,65432.1);assert.equal(vehicle().trip_distance_km,0);assertCounters();
  assert.equal(requests.filter(r=>r.url==='/api/vehicle').at(-1).body.options.initial_odometer_km,65432.1,'The submitted seed is numeric');
  app.session.navigate('drive');await settle();await click('[data-ck-action="ignition"]');app.session.setRunning(false);await click('[data-ck-action="start"]');app.session.setRunning(false);await app.session.advance(1);
  await app.session.shift('D',{assist:true});await app.session.control('parking_brake',false);await app.session.setInputs({throttle:.6,brake:0});await app.session.advance(15);await settle();
  assert.ok(state().distance_m>50);assert.ok(Math.abs(vehicle().odometer_km-65432.1-state().distance_m/1000)<1e-8);assert.ok(Math.abs(vehicle().trip_distance_km-state().distance_m/1000)<1e-8);assertCounters();assert.notEqual($('[data-ck="odometer"]').textContent,'65,432.1');
  await click('[data-workspace="service"]');assert.equal($('#service-dashboard').hidden,false);assertCounters();
 });
 await test('Odometer edits stay a draft on Cancel and replace the vehicle only on explicit Apply',async()=>{
  const before={t:state().t,odo:vehicle().odometer_km,trip:vehicle().trip_distance_km,distance:state().distance_m,seed:vehicle().configuration.initial_odometer_km},count=requests.filter(r=>r.url==='/api/vehicle').length;
  await click('[data-action="configuration"]');assert.equal(Number($('[data-setup="initial_odometer_km"]').value),before.seed);
  $('[data-setup="initial_odometer_km"]').value='100000.5';await $('[data-setup="initial_odometer_km"]').dispatchEvent({type:'change'});
  assert.equal(vehicle().odometer_km,before.odo);assert.equal(vehicle().trip_distance_km,before.trip);await click('[data-setup-action="cancel"]');
  assert.equal(app.session.workflowStage,'active');assert.equal(state().t,before.t);assert.equal(state().distance_m,before.distance);assert.equal(vehicle().odometer_km,before.odo);assert.equal(vehicle().trip_distance_km,before.trip);assert.equal(vehicle().configuration.initial_odometer_km,before.seed);assert.equal(requests.filter(r=>r.url==='/api/vehicle').length,count);assertCounters();
  await click('[data-action="configuration"]');assert.equal(Number($('[data-setup="initial_odometer_km"]').value),before.seed,'Cancelled mileage does not survive reopening Setup');
  $('[data-setup="initial_odometer_km"]').value='222222.2';await $('[data-setup="initial_odometer_km"]').dispatchEvent({type:'change'});assert.equal(vehicle().odometer_km,before.odo);assert.equal(vehicle().trip_distance_km,before.trip);assert.equal(requests.filter(r=>r.url==='/api/vehicle').length,count);
  await click('[data-setup-action="apply"]');assert.equal(requests.filter(r=>r.url==='/api/vehicle').length,count+1);assert.equal(vehicle().configuration.initial_odometer_km,222222.2);assert.equal(vehicle().odometer_km,222222.2);assert.equal(vehicle().trip_distance_km,0);assert.equal(state().distance_m,0);assert.equal(state().t,0);assertCounters();
 });
 assert.equal(errors.length,0,errors.join('\n'));const result={suite:'Odometer and Trip A UI v0.9.3',passed,failed:0,requests:requests.length,scope:'Actual shared Session + Python HTTP + parsed UI. No native browser layout or GPU claim.'};if(process.argv[2])fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }finally{if(app)app.dispose();server.lines.close();server.child.kill('SIGTERM');}}
main().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
