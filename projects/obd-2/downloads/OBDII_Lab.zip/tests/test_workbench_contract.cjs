/* Optional contract checks. Run via python3 tests/run_workbench_contract.py.
 * Uses Node built-ins only. Evaluates the actual product helpers with an inert
 * document and real Python Sim/network fixtures. No DOM layout, browser events,
 * Canvas rendering or WebGL pixels are verified by this suite.
 */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
if (!process.argv[2]) {
  process.stderr.write('Run python3 tests/run_workbench_contract.py to supply real simulator fixtures.\n');
  process.exit(2);
}
const fixture = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const productPath = path.join(__dirname, '..', 'web', 'workbench.js');
const original = fs.readFileSync(productPath, 'utf8');
const anchor = '  window.Workbench={';
assert.equal(original.split(anchor).length, 2, 'Expose helpers at the single product export; review if the module structure changes.');
// Only add a test export in memory. Product files and function bodies are unmodified.
const instrumented = original.replace(anchor, `
  window.__workbenchContract = {
    configure(data, objectId, experimentId) {
      catalog=data.catalog; snapshot=data.scene.state; network=data.scene.network;
      selected=objectId; experiment=experimentId||'ect'; points=[];
    },
    currentConnection, findObject, sampleValue, addSamples, renderInspector, observe,
    getPoints:()=>points.map(point=>({t:point.t,v:point.v}))
  };
${anchor}`);
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    innerHTML: '', textContent: '', hidden: false, disabled: false,
    addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; },
    classList: {add() {}, remove() {}, toggle() {}}, setAttribute() {},
  });
  return elements.get(id);
}
const window = {addEventListener() {}};
const context = vm.createContext({window, document:{getElementById:element}, console});
vm.runInContext(instrumented, context, {filename:productPath, timeout:5000});
const api = window.__workbenchContract;
assert.ok(api, 'Actual module helper export available');
const scene = name => fixture.scenes[name];
function use(name, objectId='ect_signal', experimentId='ect') {
  elements.clear();
  api.configure({catalog:fixture.catalog, scene:scene(name)}, objectId, experimentId);
}
function inspector() { api.renderInspector(); return element('wb-inspector').innerHTML; }
function observation() { api.observe(); return element('wb-observation').innerHTML; }
function history(name) { api.addSamples({history:scene(name).history,state:scene(name).state}); return api.getPoints(); }
let passed=0, failed=0;
function test(name, fn) {
  try { fn(); passed++; console.log('PASS '+name); }
  catch(error) { failed++; console.error('FAIL '+name+'\n'+error.stack); }
}

test('DLC supply remains a 12.6 V reference through CAN disconnection', () => {
  use('dlc_open','dlc_power');
  assert.equal(api.currentConnection('dlc_power'), null);
  assert.equal(api.sampleValue(scene('dlc_open').state), 12.6);
  assert.ok(history('dlc_open').every(point=>point.v===12.6));
  assert.equal(scene('dlc_open').network.wires.dlc_power.available, true);
});

test('DLC ground remains a 0 V reference with complete history', () => {
  use('dlc_open','dlc_ground');
  assert.equal(api.currentConnection('dlc_ground'), null);
  assert.equal(api.sampleValue(scene('dlc_open').state), 0);
  assert.ok(history('dlc_open').every(point=>point.v===0));
  assert.equal(scene('dlc_open').network.wires.dlc_ground.available, true);
});

test('Disconnected ECT retains its observable receiver-side voltage', () => {
  use('ect_checking');
  assert.equal(scene('ect_checking').network.wires.ect_signal.connected, false);
  assert.equal(scene('ect_checking').network.wires.ect_signal.available, true);
  assert.equal(api.sampleValue(scene('ect_checking').state), 5);
  assert.equal(api.sampleValue(scene('ect_fallback').state), 5);
});

test('ECT history preserves healthy, open and repaired samples without false gaps', () => {
  use('ect_repaired');
  const points=history('ect_repaired');
  assert.ok(points.length>3);
  assert.ok(points.every(point=>point.v!==null));
  assert.ok(points.some(point=>point.v===5));
  assert.ok(points[0].v<4.9 && points.at(-1).v<4.9);
});

test('Disconnected BMU retains receiver message age and its history', () => {
  use('bmu_open','bmu_can_h','bmu');
  const live=scene('bmu_open').network.wires.bmu_can_h;
  assert.equal(live.connected,false);
  assert.equal(live.available,true);
  assert.ok(live.value>300);
  assert.equal(api.sampleValue(scene('bmu_open').state),live.value);
  const points=history('bmu_open');
  assert.ok(points.every(point=>point.v!==null));
  assert.ok(points.at(-1).v>300);
});

test('Missing FL measurement makes a gap while the physical wheel still turns', () => {
  use('wheel_missing','wheel_fl_signal','wheel_fl');
  const current=scene('wheel_missing');
  assert.ok(current.state.wheel_speeds_kph[0]>20);
  assert.equal(current.state.sensors.wheel_speeds_kph[0],null);
  assert.equal(api.sampleValue(current.state),null);
  assert.equal(current.network.wires.wheel_fl_signal.available,false);
  const points=history('wheel_missing');
  assert.ok(points.some(point=>point.v!==null));
  assert.ok(points.some(point=>point.v===null));
  assert.equal(points.at(-1).v,null);
});

test('Disconnected diagnostic CAN produces application-probe gaps', () => {
  use('dlc_open','dlc_can_h','dlc');
  assert.equal(api.currentConnection('dlc_can_h'),'dlc');
  assert.equal(api.sampleValue(scene('dlc_open').state),null);
  const points=history('dlc_open');
  assert.ok(points.some(point=>point.v!==null));
  assert.ok(points.some(point=>point.v===null));
});

test('Ignition-off observation says unpowered rather than fallback', () => {
  use('unpowered');
  const html=observation();
  assert.match(html,/Unpowered/);
  assert.doesNotMatch(html,/Fallback|Checking input/);
});

test('Invalid ECT before debounce says checking and identifies the marker', () => {
  use('ect_checking');
  assert.equal(scene('ect_checking').state.ect_derate_factor,1);
  const html=observation();
  assert.match(html,/Checking input/);
  assert.match(html,/−40 °C marker/);
  assert.doesNotMatch(html,/Fallback/);
});

test('Debounced ECT observation names the actual fallback state', () => {
  use('ect_fallback');
  assert.ok(scene('ect_fallback').state.ect_derate_factor<1);
  assert.equal(scene('ect_fallback').state.sensors.ect_used_c,80);
  assert.match(observation(),/Fallback/);
});

test('Legacy ECT fault separates effective continuity from physical switch', () => {
  use('legacy_ect');
  assert.equal(scene('legacy_ect').state.connections.ect,true);
  assert.equal(scene('legacy_ect').state.effective_connections.ect,false);
  const html=inspector();
  assert.match(html,/<th>Continuity<\/th><td>Open circuit<\/td>/);
  assert.match(html,/Switch connected/);
  assert.match(html,/injected fault active/);
});

test('Legacy wheel dropout also preserves unavailable scope samples', () => {
  use('legacy_wheel','wheel_fl_signal','wheel_fl');
  assert.equal(scene('legacy_wheel').state.connections.wheel_fl,true);
  assert.equal(scene('legacy_wheel').state.effective_connections.wheel_fl,false);
  assert.equal(api.sampleValue(scene('legacy_wheel').state),null);
  assert.equal(history('legacy_wheel').at(-1).v,null);
});

test('Unassigned DLC pins are not styled as assigned functions', () => {
  use('healthy','dlc_socket');
  const html=inspector();
  const classes=new Map([...html.matchAll(/class="([^"]*)" data-pin="pin:dlc_socket:(\d+)"/g)].map(match=>[Number(match[2]),match[1].trim().split(/\s+/)]));
  assert.equal(classes.size,16);
  for (const pin of [1,3,8,9,11,12,13]) assert.ok(!classes.get(pin).includes('assigned'),'Unassigned DLC pin '+pin);
  for (const pin of [4,5,6,14,16]) assert.ok(classes.get(pin).includes('assigned'),'Assigned DLC pin '+pin);
});

test('Pin selection resolves the real socket and pin properties', () => {
  use('healthy','pin:dlc_socket:6');
  const found=api.findObject('pin:dlc_socket:6');
  assert.equal(found.type,'Pin');
  assert.equal(found.object.number,6);
  assert.equal(found.object.label,'CAN-H');
  assert.equal(found.socket.id,'dlc_socket');
  assert.match(inspector(),/Pin 6 · CAN-H/);
  assert.equal(api.sampleValue(scene('healthy').state),null);
});

test('Static supply and ground inspector readings say reference value', () => {
  for (const wire of ['dlc_power','dlc_ground']) {
    use('dlc_open',wire);
    const html=inspector();
    assert.match(html,/<br>reference value<\/small>/);
    assert.doesNotMatch(html,/wb-connection-control/);
    assert.doesNotMatch(html,/<br>live sample<\/small>/);
  }
});

test('Engine-only profile does not fabricate wheel or BMU history', () => {
  for (const wire of ['wheel_fl_signal','bmu_can_h']) {
    use('healthy',wire);
    assert.equal(api.sampleValue(scene('healthy').state),null);
    assert.ok(history('healthy').every(point=>point.v===null));
  }
});

console.log(JSON.stringify({suite:'workbench helper contracts',passed,failed,
  runtime:process.version,fixtures:'Python Sim + observe_network',
  scope:'Actual helper logic and generated HTML text; no browser, DOM-layout, Canvas or WebGL pixel verification'}));
process.exitCode=failed?1:0;
