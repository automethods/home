"""Prepare frozen real-handler fixtures for native Chrome layout/language checks.

Run: python3 tests/prepare_browser_language.py --output /tmp/obd-language-browser
Open the printed index.html with ?view=setup|drive|service|units|diagnosis|wiring|help
and &lang=en|uk. #qa-report contains native viewport and switch checks.
This fixture transport is for UI/layout checks; live dynamics are covered by the
stdio-backed interaction suites, not by these frozen snapshots.
"""
from pathlib import Path
import sys,json,re
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from http_stdio import HandlerClient
import argparse
parser=argparse.ArgumentParser(description='Prepare native-browser layout fixtures from real API handlers; model dynamics are frozen.')
parser.add_argument('--output',type=Path,default=Path('/tmp/obd-language-browser'))
out=parser.parse_args().output;out.mkdir(parents=True,exist_ok=True)
c=HandlerClient();off=c.request('/api/vehicle',{'configuration':'petrol_advanced'})['data']
c.request('/api/cycle',{'action':'start'});c.lab.advance(40)
running=c.lab.state([])
c.request('/api/cycle',{'action':'stop'});c.request('/api/scanner',{'action':'connect','module':'ecu'});connected=c.lab.state([])
read=c.request('/api/scanner',{'action':'read','payloads':['01 0C','01 0D','01 05','01 04','01 11','01 10','01 0F']})['data']
scan=c.request('/api/scanner',{'action':'scan'})['data']
c.request('/api/scanner',{'action':'connect','module':'transmission'});transmission=c.lab.state([])
fixtures={'off':off,'running':running,'connected':connected,'read':read,'scan':scan,'transmission':transmission}
js='''
const fixtures=FIXTURES;
window.fetch=async(url,init={})=>{const body=init.body?JSON.parse(init.body):{};let data;if(url==='/api/vehicle')data=fixtures.off;else if(url==='/api/scanner')data=body.action==='read'?fixtures.read:body.action==='scan'?fixtures.scan:body.module==='transmission'?fixtures.transmission:fixtures.connected;else if(url==='/api/advance')data=fixtures.connected;else if(String(url).startsWith('/api/'))data=fixtures.connected;else return originalFetch(String(url).startsWith('/')?ROOT+String(url).slice(1):url,init);return new Response(JSON.stringify(data),{status:200,headers:{'Content-Type':'application/json'}});};
'''.replace('FIXTURES',json.dumps(fixtures,ensure_ascii=False)).replace('ROOT',json.dumps(ROOT.as_uri()+'/'))
s=(ROOT/'web/index.html').read_text();s=re.sub(r'(href|src)="/(web/[^"]+)"',lambda m:f'{m[1]}="{(ROOT/m[2]).resolve().as_uri()}"',s)
s=s.replace('<script src=', '<script>const originalFetch=window.fetch.bind(window);'+js+'</script><script src=',1)
end='''<script>
(async()=>{await VehicleApplication.ready;const s=VehicleApplication.session,view=new URLSearchParams(location.search).get('view')||'setup';if(view!=='setup'){await s.commitSetup('petrol_advanced',{},s.testSettings);s.enterWorkspace(view==='drive'?'drive':'service');s.setRunning(false);s.apply(fixtures.connected);if(view==='units')s.navigate('units');if(view==='wiring'){s.select('ecu');s.navigate('wiring');}if(view==='diagnosis')s.navigate('diagnosis');if(view==='signals')s.navigate('live');if(view==='help')document.querySelector('[data-action=help]').click();if(view==='service'){s.navigate('scan');await s.scannerAction('connect',{module:'ecu'});}if(view==='gearbox'){s.select('transmission');s.navigate('scan');await s.scannerAction('connect',{module:'transmission'});}}
setTimeout(()=>{const session=VehicleApplication.session,before=session.result,records=session.records.length;document.querySelector('[data-language-choice=en]').click();const english=document.querySelector('[data-workspace=service]').textContent.trim();document.querySelector('[data-language-choice=uk]').click();window.AppI18n.render();const ukrainian=document.querySelector('[data-workspace=service]').textContent.trim();const roundtrip={english,ukrainian,sameState:before===session.result,sameRecords:records===session.records.length};const boxes=Object.fromEntries(['.setup-flow','.app-main','#drive-task-bar','#service-dashboard','.vm-instruments','.vm-driver-controls','.service-workspace','#view-scan'].map(q=>{const e=document.querySelector(q),r=e.getBoundingClientRect();return[q,{x:r.x,y:r.y,w:r.width,h:r.height}];}));const texts=[],walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=walker.nextNode()){if(n.parentElement.closest('script,style,code,pre,[hidden],textarea'))continue;if(!n.parentElement.getClientRects().length)continue;const text=n.nodeValue.trim();if(/[A-Za-z]{3}/.test(text))texts.push(text);}const checks={english:english==='Diagnostics & service',ukrainian:ukrainian==='Діагностика й обслуговування',sameState:roundtrip.sameState,sameRecords:roundtrip.sameRecords,noHorizontalOverflow:document.documentElement.scrollWidth===document.documentElement.clientWidth};const report={checks,roundtrip,lang:document.documentElement.lang,viewport:[innerWidth,innerHeight],page:[document.documentElement.scrollWidth,document.documentElement.clientWidth],boxes,texts:[...new Set(texts)]};const el=document.createElement('script');el.id='qa-report';el.type='application/json';el.textContent=JSON.stringify(report);document.body.append(el);document.querySelectorAll('script:not(#qa-report)').forEach(n=>n.remove());},200);
})().catch(e=>{document.body.dataset.qaError=e.stack;});
</script>'''
s=s.replace('</body>',end+'</body>');(out/'index.html').write_text(s)
print(out/'index.html')
