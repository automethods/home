"""Signal-type and sampling metadata must describe the actual teaching channels."""
from copy import deepcopy
import json
import math
import unittest

from obdii_lab.core import Parameters, ect_circuit
from obdii_lab.network import network_catalog
from obdii_lab.vehicle_systems import (
    SENSOR_DEFINITIONS, SensorBank, build_network_catalog,
    signal_catalog_for_vehicle, vehicle_system_catalog,
)


CONFIG = {"powertrain": "phev", "engine_detail": "extended", "abs_installed": True,
          "esp_installed": True, "hvac_installed": True, "ac_installed": True,
          "transmission_type": "manual_6"}


def snapshot(t=0, change=0):
    coolant = 80 + change * 10
    return {
        "t": t, "inputs": {"ignition": True, "throttle": .3, "brake": 0, "steer_deg": 0},
        "rpm": 1800 + change * 600, "speed_kph": 36 + change * 10,
        "coolant_c": coolant, "ambient_c": 20 + change * 5, "load_pct": 40,
        "maf_g_s": 12 + change * 8, "engine_running": True, "motor_power_kw": 10,
        "wheel_radius_m": .3, "wheel_speeds_kph": [36] * 4,
        "battery_voltage_v": 350 + change * 10, "battery_current_a": 20,
        "battery_temp_c": 25 + change * 5, "soc_pct": 60 + change * 10,
        "sensors": ect_circuit(coolant, Parameters()),
        "connections": {"ect": True, "wheel_fl": True, "dlc": True, "bmu": True},
        "vehicle": {"selector": "N", "low_voltage_v": 14.2, "fuel_pct": 78,
                    "hvac": {"cabin_c": 22, "fan": .3, "enabled": True, "powered": True,
                             "electrical_kw": 1, "shaft_load_kw": 0, "heat_kw": 2, "cooling_kw": 0}},
        "energy": {"fuel_l": 0},
    }


class SensorCharacteristicsTests(unittest.TestCase):
    def test_every_definition_has_a_serializable_signal_type_and_exact_rate(self):
        catalog = vehicle_system_catalog(CONFIG)
        self.assertEqual(len(SENSOR_DEFINITIONS), 42)
        types = {item["id"] for item in catalog["signal_types"]}
        self.assertEqual(types, {"analog", "digital", "pulse", "discrete", "derived"})
        groups = {item["id"]: item for item in catalog["sample_groups"]}
        self.assertEqual({item["sample_period_ms"] for item in groups.values()}, {10, 20, 50, 100, 500, 1000})
        for original, sensor in zip(SENSOR_DEFINITIONS, catalog["sensors"]):
            with self.subTest(sensor=sensor["id"]):
                detail = sensor["characteristics"]
                self.assertEqual(detail, original["characteristics"])
                self.assertIn(detail["signal_type"], types)
                self.assertEqual(detail["unit"], sensor["unit"])
                self.assertEqual(detail["range"], sensor["range"])
                self.assertTrue(detail["description"])
                self.assertTrue(detail["scope"])
                timing = detail["timing"]
                self.assertEqual(timing["sample_period_ms"], sensor["period_ms"])
                self.assertEqual(timing["sample_rate_hz"], 1000 / sensor["period_ms"])
                self.assertEqual(timing["group_label"], groups[timing["group_id"]]["label"])
        json.dumps(catalog, allow_nan=False)

    def test_all_rate_groups_agree_with_actual_held_sampling(self):
        # One representative of every rate. Logging and rendering are absent;
        # advancing simulation time alone determines the next held sample.
        ids = ("ect", "crank_sensor", "maf", "pack_voltage", "intake_temp", "battery_soc")
        for sensor_id in ids:
            with self.subTest(sensor=sensor_id):
                bank = SensorBank(CONFIG)
                period = bank.specs[sensor_id]["characteristics"]["timing"]["sample_period_ms"] / 1000
                bank.sample(snapshot())
                first = deepcopy(bank.readings[sensor_id])
                bank.sample(snapshot(period - .001, change=1))
                self.assertEqual(bank.readings[sensor_id]["value"], first["value"])
                self.assertEqual(bank.readings[sensor_id]["sampled_at"], 0)
                bank.sample(snapshot(period, change=1))
                self.assertNotEqual(bank.readings[sensor_id]["value"], first["value"])
                self.assertAlmostEqual(bank.readings[sensor_id]["sampled_at"], period)

    def test_derived_channels_do_not_claim_connectors_or_wire_signals(self):
        catalog = vehicle_system_catalog(CONFIG)
        signals = signal_catalog_for_vehicle(CONFIG)
        bank = SensorBank(CONFIG)
        bank.sample(snapshot())
        derived = [s for s in catalog["sensors"] if s["connection_id"] is None]
        self.assertIn("battery_soc", {s["id"] for s in derived})
        self.assertIn("fuel_level", {s["id"] for s in derived})
        for sensor in derived:
            with self.subTest(sensor=sensor["id"]):
                detail = sensor["characteristics"]
                self.assertEqual(detail["signal_type"], "derived")
                self.assertIsNone(detail["electrical"])
                self.assertIsNone(detail["pulse"])
                self.assertIsNone(sensor["socket_id"])
                self.assertFalse(sensor["disconnectable"])
                self.assertIsNone(bank.readings[sensor["id"]]["signal_voltage_v"])
                self.assertIsNone(bank.readings[sensor["id"]]["frequency_hz"])
                owned = [s for s in signals if s["sensor_id"] == sensor["id"]]
                self.assertEqual([s["id"] for s in owned], [sensor["signal_id"]])

    def test_digital_levels_match_the_two_brake_switch_states(self):
        bank = SensorBank(CONFIG)
        detail = bank.specs["brake_switch"]["characteristics"]
        self.assertEqual(detail["signal_type"], "digital")
        self.assertIsNone(detail["pulse"])
        levels = {item["value"]: item["voltage_v"] for item in detail["electrical"]["levels"]}
        self.assertEqual(levels, {0: 0, 1: 5})
        for step, (pedal, state) in enumerate(((0, False), (.02, False), (.03, True), (1, True))):
            sample = snapshot(step * .02)
            sample["inputs"]["brake"] = pedal
            bank.sample(sample)
            reading = bank.readings["brake_switch"]
            self.assertIs(reading["value"], state)
            self.assertEqual(reading["signal_voltage_v"], levels[int(state)])

    def test_discrete_selector_has_no_claimed_physical_encoding(self):
        bank = SensorBank(CONFIG)
        spec = bank.specs["transmission_range"]
        self.assertEqual(spec["kind"], "state")
        self.assertEqual(spec["characteristics"]["signal_type"], "discrete")
        self.assertIsNone(spec["characteristics"]["electrical"])
        self.assertIsNone(spec["characteristics"]["pulse"])
        bank.sample(snapshot())
        self.assertEqual(bank.readings["transmission_range"]["value"], "N")
        self.assertIsNone(bank.readings["transmission_range"]["signal_voltage_v"])
        self.assertIsNone(bank.readings["transmission_range"]["frequency_hz"])

    def test_pulse_counts_match_runtime_frequency_not_sample_frequency(self):
        bank = SensorBank(CONFIG)
        sample = snapshot()
        bank.sample(sample)
        for sensor_id in ("crank_sensor", "cam_sensor", "rotor_sensor", "wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"):
            with self.subTest(sensor=sensor_id):
                detail = bank.specs[sensor_id]["characteristics"]
                reading = bank.readings[sensor_id]
                self.assertEqual(detail["signal_type"], "pulse")
                self.assertIsNone(detail["electrical"])
                if sensor_id.startswith("wheel_"):
                    revolutions_per_second = reading["value"] / 3.6 / (2 * math.pi * sample["wheel_radius_m"])
                else:
                    revolutions_per_second = reading["value"] / 60
                expected = revolutions_per_second * detail["pulse"]["pulses_per_revolution"]
                self.assertAlmostEqual(reading["frequency_hz"], expected)
                self.assertEqual(detail["timing"]["sample_rate_hz"], 50)
                self.assertNotAlmostEqual(reading["frequency_hz"], 50)
        self.assertEqual(bank.readings["crank_sensor"]["frequency_hz"], 1800)
        self.assertEqual(bank.readings["cam_sensor"]["frequency_hz"], 15)
        stopped = snapshot(.02)
        stopped.update(rpm=0, speed_kph=0, wheel_speeds_kph=[0] * 4)
        bank.sample(stopped)
        self.assertEqual(bank.readings["crank_sensor"]["frequency_hz"], 0)
        self.assertEqual(bank.readings["rotor_sensor"]["frequency_hz"], 0)
        bank.set_connection("crank_sensor", False)
        bank.sample(snapshot(.04))
        self.assertIsNone(bank.readings["crank_sensor"]["frequency_hz"])

    def test_solved_ect_and_illustrative_analogue_voltage_are_distinct(self):
        bank = SensorBank(CONFIG)
        ect = bank.specs["ect"]["characteristics"]["electrical"]
        linear = bank.specs["throttle_sensor"]["characteristics"]["electrical"]
        self.assertEqual(ect["model"], "solved_ntc_divider")
        self.assertEqual(ect["range_v"], [0, 5])
        self.assertEqual(linear["model"], "illustrative_linear_transfer")
        self.assertEqual(linear["range_v"], [.5, 4.5])
        for step, (pedal, expected_voltage) in enumerate(((0, .5), (.5, 2.5), (1, 4.5))):
            sample = snapshot(step * .02)
            sample["inputs"]["throttle"] = pedal
            bank.sample(sample)
            self.assertEqual(bank.readings["throttle_sensor"]["signal_voltage_v"], expected_voltage)
        sample = snapshot(.06)
        sample["connections"]["ect"] = False
        sample["sensors"] = ect_circuit(80, Parameters(), open_circuit=True)
        bank.sample(sample)
        self.assertEqual(bank.readings["ect"]["validity"], "invalid")
        # The solved ECU input is measurable even when temperature is invalid.
        self.assertEqual(bank.readings["ect"]["signal_voltage_v"], 5)

    def test_signal_and_component_metadata_keep_source_characteristics(self):
        catalog = vehicle_system_catalog(CONFIG)
        network = build_network_catalog(CONFIG, network_catalog())
        components = {component["id"]: component for component in network["components"]}
        signals = signal_catalog_for_vehicle(CONFIG)
        for sensor in catalog["sensors"]:
            with self.subTest(sensor=sensor["id"]):
                self.assertEqual(components[sensor["component_id"]]["properties"]["characteristics"], sensor["characteristics"])
                for signal in (s for s in signals if s["sensor_id"] == sensor["id"]):
                    self.assertEqual(signal["characteristics"], sensor["characteristics"])
        # A plotted pulse-frequency number uses the existing numeric signal
        # kind, but still identifies its source as a frequency-encoded sensor.
        pulse_channel = next(s for s in signals if s["id"] == "vehicle_sensors.crank_sensor.frequency_hz")
        self.assertEqual(pulse_channel["kind"], "analog")
        self.assertEqual(pulse_channel["characteristics"]["signal_type"], "pulse")
        catalog["sensors"][0]["characteristics"]["timing"]["sample_period_ms"] = -1
        self.assertEqual(vehicle_system_catalog(CONFIG)["sensors"][0]["characteristics"]["timing"]["sample_period_ms"], 10)


if __name__ == "__main__":
    unittest.main()
