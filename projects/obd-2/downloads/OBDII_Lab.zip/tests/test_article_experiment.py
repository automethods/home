"""Independent timing oracle, recovery and isolation checks for the article."""
import math
import unittest

from obdii_lab.article_experiment import run_matrix
from http_stdio import HandlerClient


class ArticleExperimentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = run_matrix()

    def test_matrix_covers_all_twenty_cells_and_both_controls(self):
        cases = self.report["cases"]
        self.assertEqual(len(cases), 22)
        self.assertEqual({(c["summary"]["duration_ms"], c["summary"]["phase_ms"])
                          for c in cases[1:-1]},
                         {(d, p) for d in (10, 20, 50, 100, 600) for p in (2, 10, 24, 48)})
        self.assertIsNone(cases[0]["summary"]["first_invalid_sample_s"])
        self.assertEqual(cases[-1]["summary"]["final_torque_factor"], .7)
        self.assertTrue(cases[-1]["summary"]["final_stored_P0102"])

    def test_analytic_sampling_oracle_predicts_each_pulse(self):
        # Independent half-open pulse / periodic-sampling calculation.
        for case in self.report["cases"][1:-1]:
            s = case["summary"]
            opening = 2000 + s["phase_ms"]
            closing = opening + s["duration_ms"]
            first = math.ceil(opening / 50) * 50
            recovery = math.ceil(closing / 50) * 50
            detected = first < closing
            with self.subTest(case=s["id"]):
                self.assertEqual(s["first_invalid_sample_s"], first / 1000 if detected else None)
                self.assertEqual(s["first_control_effect_s"], first / 1000 if detected else None)
                self.assertEqual(s["recovery_sample_s"], recovery / 1000 if detected else None)
                self.assertEqual(s["first_pending_s"] is not None, detected and recovery - first > 200)
                self.assertEqual(s["first_stored_s"] is not None, detected and recovery - first > 500)
                self.assertEqual(s["final_stored_P0102"], s["duration_ms"] == 600)
                self.assertEqual(s["final_validity"], "valid")
                self.assertEqual(s["final_torque_factor"], 1.)
                self.assertFalse(s["final_pending_P0102"])
                self.assertEqual(s["contact_events"], [dict(t=opening/1000, connected=False),
                                                        dict(t=closing/1000, connected=True)])

    def test_task_and_observation_times_are_distinct_and_full_resolution(self):
        for case in self.report["cases"]:
            trace = case["trace"]
            self.assertEqual(len(trace), 900)
            self.assertAlmostEqual(trace[-1]["observed_at_s"], 3.8)
            for row in trace:
                if row["controller_at_s"] is not None:
                    self.assertAlmostEqual(row["observed_at_s"] - row["controller_at_s"], .002)
        long = self.report["cases"][-1]["summary"]
        self.assertAlmostEqual(long["first_pending_s"] - long["first_invalid_sample_s"], .2)
        self.assertAlmostEqual(long["first_stored_s"] - long["first_invalid_sample_s"], .5)

    def test_api_preserves_the_existing_vehicle_and_rejects_parameter_overrides(self):
        from unittest.mock import patch
        client = HandlerClient()
        client.lab.set_vehicle("bev")
        client.lab.advance(.2)
        before = client.lab.state()
        # The matrix itself is exercised above; check HTTP dispatch and isolation here.
        with patch("obdii_lab.server.run_matrix", return_value=self.report):
            reply = client.request("/api/article-experiment", {})
        self.assertEqual(reply["status"], 200)
        self.assertEqual(len(reply["data"]["cases"]), 22)
        self.assertEqual(client.lab.state(), before)
        invalid = client.request("/api/article-experiment", {"throttle": 1})
        self.assertEqual(invalid["status"], 400)
        self.assertEqual(client.lab.state(), before)


if __name__ == "__main__":
    unittest.main()
