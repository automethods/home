"""Discovery and selected-unit connection have different, observable scopes."""
import unittest
from http_stdio import HandlerClient


class ScannerScopeTests(unittest.TestCase):
    def setUp(self):
        self.client = HandlerClient()
        self.client.request('/api/vehicle', {'configuration': 'petrol_advanced'})
        self.client.request('/api/control', {'action': 'ignition', 'value': True})
        self.client.request('/api/advance', {'seconds': .1})

    def action(self, action, **settings):
        result = self.client.request('/api/scanner', {'action': action, **settings})
        self.assertEqual(result['status'], 200, result)
        return result['data']

    def test_connect_reads_only_the_named_unit(self):
        result = self.action('connect', module='ecu')
        self.assertEqual(result['scanner']['module_id'], 'ecu')
        self.assertIsNone(result['scan_report'])
        self.assertEqual(result['unit_report']['module_id'], 'ecu')
        self.assertEqual([m['id'] for m in result['unit_report']['modules']], ['ecu'])
        self.assertEqual({d['target'] for d in result['unit_report']['diagnostics']}, {'ecu'})

    def test_gearbox_fault_read_does_not_query_engine(self):
        self.action('connect', module='transmission')
        result = self.action('faults')
        self.assertIsNone(result['scan_report'])
        self.assertEqual([m['id'] for m in result['unit_report']['modules']], ['transmission'])
        self.assertEqual(result['unit_report']['diagnostics'], [])

    def test_discovery_works_before_connecting_a_unit(self):
        before = self.client.lab.scanner.state()
        t = self.client.lab.snapshot()['t']
        result = self.action('scan', protocol='can11_500')
        units = [m for m in result['scan_report']['modules'] if m['installed']]
        self.assertGreater(len(units), 1)
        self.assertTrue(all(m['status'] == 'healthy' for m in units))
        self.assertEqual(result['scanner'], before)
        self.assertFalse(result['scanner']['connected'])
        self.assertEqual(self.client.lab.snapshot()['t'], t)

    def test_discovery_preserves_open_gearbox_session(self):
        self.action('connect', module='transmission')
        before = self.client.lab.scanner.state()
        report = self.action('scan', protocol='can11_500')['scan_report']
        self.assertIn('ecu', [m['id'] for m in report['modules']])
        self.assertEqual(self.client.lab.scanner.state(), before)

    def test_failed_discovery_preserves_connection(self):
        self.action('connect', module='ecu')
        before = self.client.lab.scanner.state()
        result = self.client.request('/api/scanner', {'action': 'scan', 'protocol': 'iso9141'})
        self.assertEqual(result['status'], 400)
        self.assertEqual(self.client.lab.scanner.state(), before)
        result = self.action('scan', protocol='can11_250')
        self.assertTrue(all(m['status'] == 'bitrate_mismatch' for m in result['scan_report']['modules'] if m['installed']))
        self.assertEqual(self.client.lab.scanner.state(), before)


if __name__ == '__main__':
    unittest.main()
