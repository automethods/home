/* Actual Python sensor schedules and samples, parsed-node UI contracts.
 * This suite checks source meaning and shared-state interactions, not native
 * browser layout. Run: node tests/test_sensor_map_v091.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const project=path.resolve(__dirname,'..'),runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const fixtureRun=spawnSync('python3',['-c',`
import json
from obdii_lab.server import Lab
from obdii_lab.vehicle_systems import vehicle_system_catalog
lab=Lab();lab.set_vehicle('petrol_advanced');sim=lab.sim
states={'off':sim.snapshot()};sim.control('ignition',True);sim.advance(.1);states['stopped']=sim.snapshot()
sim.control('start');sim.advance(1.5);states['running']=sim.snapshot()
sim.advance(.1,{'brake':.25});states['braking']=sim.snapshot();sim.control('gear','D');sim.control('parking_brake',False)
sim.advance(2,{'throttle':.5,'brake':0});states['driving']=sim.snapshot();sim.advance(.004);states['held_sample']=sim.snapshot()
sim.set_connection('crank_sensor',False);states['open_before_sample']=sim.snapshot();sim.advance(.04);states['crank_open']=sim.snapshot()
sim.set_connection('ect',False);sim.advance(.04);states['ect_open']=sim.snapshot()
data={'states':states,'systems':vehicle_system_catalog(sim.configuration),'signals':lab.signal_catalog(),'catalog':lab.catalog()}
lab.set_vehicle('bev');sim=lab.sim;sim.control('ignition',True);sim.control('start');sim.advance(1.5)
data['bev']={'state':sim.snapshot(),'systems':vehicle_system_catalog(sim.configuration),'signals':lab.signal_catalog(),'catalog':lab.catalog()}
lab.set_vehicle('diesel');sim=lab.sim
data['diesel']={'state':sim.snapshot(),'systems':vehicle_system_catalog(sim.configuration),'signals':lab.signal_catalog(),'catalog':lab.catalog()}
print(json.dumps(data))
`],{cwd:project,encoding:'utf8',maxBuffer:16*1024*1024});
assert.equal(fixtureRun.status,0,fixtureRun.stderr);const fixture=JSON.parse(fixtureRun.stdout);
const harness=fs.readFileSync(path.join(project,'tests/test_dashboard_contract.cjs'),'utf8'),begin=harness.indexOf('const decodeEntities='),end=harness.indexOf('const elements=new Node(');assert.ok(begin>=0&&end>begin);
const w={},sandbox={window:w,document:{},console,assert,createCanvas,setInterval(){throw Error('Sensor maps must not create simulation time');},requestAnimationFrame(){throw Error('Sensor maps must use shared samples');}};vm.createContext(sandbox);
vm.runInContext(harness.slice(begin,end)+'\nglobalThis.TestNode=Node;',sandbox);
const Node=sandbox.TestNode,originalMatches=Node.prototype.matches;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{const attrs=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];return originalMatches.call(this,part.replace(/\[[^\]]+\]/g,'')||'*')&&attrs.every(match=>this.hasAttribute(match[1])&&(match[2]===undefined||this.getAttribute(match[1])===match[2]));});};
vm.runInContext(fs.readFileSync(path.join(project,'web/unit-map.js'),'utf8'),sandbox);
const container=new Node('main'),calls={select:[],navigate:[],watch:[],connection:[]};container._width=960;
let current={state:fixture.states.running,systems:fixture.systems,signals:fixture.signals,catalog:fixture.catalog,selection:'ecu',logInterval:60},view;
let connectionGate=null,connectionFailure='';
view=w.UnitMapView.create(container,{onSelect:id=>{calls.select.push(id);current={...current,selection:id};view.update(current);},onNavigate:id=>calls.navigate.push(id),onWatch:(id,on)=>calls.watch.push({id,on}),onConnection:async(id,connected)=>{calls.connection.push({id,connected});if(connectionGate)await connectionGate;if(connectionFailure)throw Error(connectionFailure);current={...current,state:connected?fixture.states.held_sample:fixture.states.open_before_sample};view.update(current);}});view.update(current);
const $=selector=>{const node=container.querySelector(selector);assert.ok(node,'Markup '+selector);return node;};
const click=async selector=>container.dispatchEvent({type:'click',target:$(selector)});
const change=async(name,value)=>{const node=$(`[data-um="${name}"]`);node.value=value;await node.dispatchEvent({type:'change'});};
const update=(state,extras={})=>{current={...current,state,...extras};view.update(current);};
const sensor=id=>current.systems.sensors.find(item=>item.id===id);
const row=id=>$(`[data-um-sensor="${id}"]`);
const groups=()=>{const result={};let currentGroup;for(const item of $('[data-um="sensor-rows"]').children){if(item.dataset.umGroupHeading){currentGroup=item.dataset.umGroupHeading;result[currentGroup]=[];}else if(item.dataset.umSensor)result[currentGroup].push(item.dataset.umSensor);}return result;};
const nformat=value=>value.toLocaleString('en-GB',{maximumFractionDigits:Math.abs(value)>=100?0:2});
const reset=()=>update(fixture.states.running,{systems:fixture.systems,signals:fixture.signals,catalog:fixture.catalog,selection:'ecu'});
let passed=0,failed=0;async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name+'\n'+error.stack);}}
(async()=>{
 await test('Purpose remains the default and every fitted ECU input has a characteristics badge',()=>{
  assert.equal(view.inspect().groupBy,'purpose');assert.equal($('[data-um="group-by"]').querySelectorAll('option').length,4);
  const expected=current.systems.sensors.filter(item=>item.unit_id==='ecu'&&item.installed);assert.equal(container.querySelectorAll('[data-um-sensor]').length,expected.length);
  assert.equal(container.querySelectorAll('[data-um-purpose-heading]')[0].dataset.umPurposeHeading,'start_critical');
  for(const item of expected){assert.equal($(`[data-um-signal-type="${item.id}"]`).dataset.signalType,item.characteristics.signal_type);assert.ok($(`[data-um-characteristics="${item.id}"]`));}
 });
 await test('timing guidance separates sample rate, pulse rate and the recording interval',()=>{
  const help=$('[data-um="timing-help"]');assert.equal(help.hidden,false);assert.match(help.textContent,/20 ms = 50 samples\/s \(50 Hz\)/);assert.match(help.textContent,/Pulse frequency/);assert.match(help.textContent,/recording interval only controls saved log rows/);
  assert.match(row('crank_sensor').querySelector('[data-um-sample]').textContent,/20 ms · 50 samples\/s/);assert.equal(current.logInterval,60);
 });
 await test('Signal type groups use connector characteristics and retain every row exactly once',async()=>{
  await change('group-by','signal-type');const actual=groups(),expected={};for(const item of current.systems.sensors.filter(item=>item.unit_id==='ecu'&&item.installed)){(expected[item.characteristics.signal_type]??=[]).push(item.id);}
  assert.deepEqual(actual,expected);assert.deepEqual(actual.pulse,['crank_sensor','cam_sensor']);assert.equal(container.querySelector('[data-um-purpose-heading]'),null);
 });
 await test('sampling groups are exact configured cadences ordered from faster to slower',async()=>{
  await change('group-by','sample-rate');const actual=groups();assert.deepEqual(Object.keys(actual),['period_10ms','period_20ms','period_50ms','period_100ms','period_500ms']);
  for(const [id,members] of Object.entries(actual)){const ms=sensor(members[0]).period_ms,heading=$(`[data-um-group-heading="${id}"]`);assert.ok(heading.textContent.includes(ms+' ms · '+1000/ms+' Hz'));assert.ok(heading.textContent.includes(members.length+' input'));assert.ok(members.every(name=>sensor(name).period_ms===ms));}
 });
 await test('the one-second diesel sensor is grouped as 1000 ms and 1 Hz, not log cadence',()=>{
  update(fixture.diesel.state,{systems:fixture.diesel.systems,signals:fixture.diesel.signals,catalog:fixture.diesel.catalog,selection:'ecu'});
  assert.match($('[data-um-group-heading="period_1000ms"]').textContent,/1,000 ms · 1 Hz/);assert.ok(groups().period_1000ms.includes('nox_sensor'));reset();
 });
 await test('Sensor system grouping retains physical groups and their exact membership',async()=>{
  await change('group-by','system');const actual=groups();for(const [id,members] of Object.entries(actual))assert.ok(members.every(name=>sensor(name).group===id));assert.ok(actual.air.includes('maf'));assert.ok(actual.position.includes('crank_sensor'));assert.ok(actual.cooling.includes('ect'));
 });
 await test('grouping is view-only and preserves filters, shared selection, clock and watched signals',async()=>{
  await change('purpose','running_control');await change('group','air');const before=JSON.stringify(current),callbacks=JSON.stringify(calls);
  for(const grouping of ['purpose','signal-type','sample-rate','system']){await change('group-by',grouping);assert.equal(view.inspect().selectedUnit,'ecu');assert.equal(view.inspect().purpose,'running_control');assert.equal(view.inspect().group,'air');assert.equal(JSON.stringify(current),before);assert.equal(JSON.stringify(calls),callbacks);assert.ok(row('maf'));assert.equal(container.querySelector('[data-um-sensor="crank_sensor"]'),null);}
 });
 await test('empty filter combinations reset both filters while keeping the chosen grouping',async()=>{
  await change('purpose','start_critical');assert.equal($('[data-um="empty-sensors"]').hidden,false);assert.equal($('[data-um="sensor-table-wrap"]').hidden,true);
  await click('[data-um-action="clear-filters"]');assert.equal(view.inspect().purpose,'all');assert.equal(view.inspect().group,'all');assert.equal(view.inspect().groupBy,'system');assert.equal($('[data-um="empty-sensors"]').hidden,true);assert.ok(row('crank_sensor'));
 });
 await test('pulse characteristics expose the chosen count and distinguish speed from pulse frequency',()=>{
  const detail=$('[data-um-characteristics="crank_sensor"]');assert.match(detail.textContent,/0 rpm to 7,000 rpm/);assert.match(detail.textContent,/Pulses per revolution60/);assert.match(detail.textContent,/crankshaft revolution/);assert.match(detail.textContent,/held speed sample/);assert.match(detail.textContent,/individual pulse edges are not simulated/);
  assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: '+nformat(fixture.states.running.vehicle_sensors.crank_sensor.frequency_hz)+' Hz');assert.match($('[data-um-sample="crank_sensor"]').textContent,/50 samples\/s/);
 });
 await test('analogue rows show the sampled transfer voltage and declared range without pulse labels',()=>{
  const detail=$('[data-um-characteristics="maf"]');assert.match(detail.textContent,/0 g\/s to 250 g\/s/);assert.match(detail.textContent,/0.5 V to 4.5 V/);assert.match(detail.textContent,/Transfer/);assert.match(detail.textContent,/illustrat/i);
  assert.equal($('[data-um-live-signal="maf"]').textContent,'Signal voltage: '+nformat(fixture.states.running.vehicle_sensors.maf.signal_voltage_v)+' V');assert.doesNotMatch($('[data-um-live-signal="maf"]').textContent,/Hz/);
 });
 await test('ordinary live samples keep row, open detail and grouping nodes stable',async()=>{
  await change('group-by','sample-rate');const crank=row('crank_sensor'),detail=$('[data-um-characteristics="crank_sensor"]'),heading=$('[data-um-group-heading="period_20ms"]'),before=JSON.stringify(groups());detail.open=true;
  update(fixture.states.driving);assert.equal(row('crank_sensor'),crank);assert.equal($('[data-um-characteristics="crank_sensor"]'),detail);assert.equal(detail.open,true);assert.equal($('[data-um-group-heading="period_20ms"]'),heading);assert.equal(JSON.stringify(groups()),before);
  assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: '+nformat(fixture.states.driving.vehicle_sensors.crank_sensor.frequency_hz)+' Hz');
 });
 await test('age comes from the sampled input rather than fabricating a sample on each render',()=>{
  update(fixture.states.held_sample);const reading=current.state.vehicle_sensors.crank_sensor;assert.match($('[data-um-age="crank_sensor"]').textContent,new RegExp(nformat(reading.age_ms)+' ms'));assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: '+nformat(reading.frequency_hz)+' Hz');const node=row('crank_sensor');view.update(current);assert.equal(row('crank_sensor'),node);
 });
 await test('unplug hides a stale pulse immediately before the next sample, not as a zero-Hz reading',()=>{
  assert.equal(fixture.states.open_before_sample.vehicle_sensors.crank_sensor.validity,'valid','This fixture exercises a held pre-fault sample');update(fixture.states.open_before_sample);
  assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: unavailable');assert.equal($('[data-um-reading="crank_sensor"]').textContent,'—');assert.equal($('[data-um-quality="crank_sensor"]').textContent,'Connector open');assert.match($('[data-um-quality="crank_sensor"]').title,/next scheduled sample/);
 });
 await test('sampled missing pulse stays unavailable while physical coasting is separately labelled',()=>{
  update(fixture.states.crank_open);const reading=current.state.vehicle_sensors.crank_sensor;assert.equal(reading.validity,'invalid');assert.ok(reading.physical_value>0);assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: unavailable');assert.match($('[data-um-physical="crank_sensor"]').textContent,/Physical: .*rpm \(model\)/);assert.equal($('[data-um-reading="crank_sensor"]').textContent,'—');
 });
 await test('an open solved NTC can show its ECU pull-up voltage without a valid temperature',()=>{
  update(fixture.states.ect_open);const reading=current.state.vehicle_sensors.ect;assert.equal($('[data-um-reading="ect"]').textContent,'—');assert.equal($('[data-um-quality="ect"]').textContent,'Connector open');assert.equal($('[data-um-live-signal="ect"]').textContent,'ECU input: '+nformat(reading.signal_voltage_v)+' V · open circuit');assert.match($('[data-um-characteristics="ect"]').textContent,/NTC divider/);
 });
 await test('healthy zero speed is 0 Hz and ignition-off pulse is unavailable',()=>{
  update(fixture.states.stopped);assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: 0 Hz');update(fixture.states.off);assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: unavailable');assert.equal($('[data-um-quality="crank_sensor"]').textContent,'Unpowered');reset();
 });
 await test('digital switch shows separate low and high levels, not a frequency',async()=>{
  await click('[data-um-unit="body"]');await change('group-by','signal-type');assert.ok(groups().digital.includes('brake_switch'));assert.equal($('[data-um-signal-type="brake_switch"]').dataset.signalType,'digital');assert.equal($('[data-um-live-signal="brake_switch"]').textContent,'Signal voltage: 0 V');assert.match($('[data-um-characteristics="brake_switch"]').textContent,/Released: 0 V; Applied: 5 V/);update(fixture.states.braking);assert.equal($('[data-um-live-signal="brake_switch"]').textContent,'Signal voltage: 5 V');
 });
 await test('selector states have no invented analogue voltage or pulse stream',async()=>{
  await click('[data-um-unit="transmission"]');assert.ok(groups().discrete.includes('transmission_range'));assert.equal($('[data-um-signal-type="transmission_range"]').dataset.signalType,'discrete');assert.equal($('[data-um-live-signal="transmission_range"]').textContent,'');assert.match($('[data-um-characteristics="transmission_range"]').textContent,/physical encoding and wire voltage are unspecified/);
 });
 await test('fuel level and state of charge are calculated channels without unplug controls or voltage',async()=>{
  await click('[data-um-unit="cluster"]');assert.ok(groups().derived.includes('fuel_level'));assert.equal($('[data-um-signal-type="fuel_level"]').dataset.signalType,'derived');assert.equal($('[data-um-live-signal="fuel_level"]').textContent,'');assert.equal(container.querySelector('[data-um-pins="fuel_level"]'),null);assert.equal(container.querySelector('[data-um-connection="fuel_level"]'),null);assert.match($('[data-um-characteristics="fuel_level"]').textContent,/no independent sensor connector/);
  update(fixture.bev.state,{systems:fixture.bev.systems,signals:fixture.bev.signals,catalog:fixture.bev.catalog,selection:'bmu'});assert.ok(groups().derived.includes('battery_soc'));assert.equal($('[data-um-live-signal="battery_soc"]').textContent,'');assert.equal(container.querySelector('[data-um-pins="battery_soc"]'),null);assert.equal(container.querySelector('[data-um-connection="battery_soc"]'),null);assert.ok(groups().analog.includes('pack_current'));assert.match($('[data-um-characteristics="pack_current"]').textContent,/-250 A to 400 A/);
 });
 await test('BMU sampling groups distinguish pack readings, temperature and charge estimate',async()=>{
  await change('group-by','sample-rate');assert.deepEqual(groups(),{period_100ms:['pack_voltage','pack_current'],period_500ms:['pack_temperature'],period_1000ms:['battery_soc']});assert.match($('[data-um-sample="battery_soc"]').textContent,/1,000 ms · 1 sample\/s/);
 });
 await test('Plot, Pins and full schematic continue to select the same unit without changing the clock',async()=>{
  reset();await change('purpose','start_critical');await change('group-by','sample-rate');const t=current.state.t;await click('[data-um-plot="crank_sensor"]');assert.equal(calls.select.at(-1),'signal:vehicle_sensors.crank_sensor.value');assert.equal(calls.watch.at(-1).id,'vehicle_sensors.crank_sensor.value');assert.equal(calls.navigate.at(-1),'signals');await click('[data-um-pins="crank_sensor"]');assert.equal(calls.select.at(-1),'socket:crank_sensor_socket');assert.equal(calls.navigate.at(-1),'wiring');assert.equal(view.inspect().purpose,'start_critical');assert.equal(view.inspect().groupBy,'sample-rate');await click('[data-um-action="full-wiring"]');assert.equal(calls.select.at(-1),'ecu');assert.equal(current.state.t,t);
 });
 await test('direct unplug waits for the confirmed snapshot, blocks duplicate requests and retains the unit',async()=>{
  update(fixture.states.held_sample,{selection:'ecu'});const t=current.state.t,button=$('[data-um-connection="crank_sensor"]'),oldReading=$('[data-um-reading="crank_sensor"]').textContent;assert.equal(button.textContent,'Disconnect');let release;connectionGate=new Promise(done=>{release=done;});const pending=click('[data-um-connection="crank_sensor"]');await Promise.resolve();
  assert.equal(button.disabled,true);assert.match($('[data-um-connection-message="crank_sensor"]').textContent,/Updating connector/);assert.equal($('[data-um-reading="crank_sensor"]').textContent,oldReading);const count=calls.connection.length;await click('[data-um-connection="crank_sensor"]');assert.equal(calls.connection.length,count);release();await pending;connectionGate=null;
  assert.deepEqual(calls.connection.at(-1),{id:'crank_sensor',connected:false});assert.equal(button.textContent,'Reconnect');assert.equal(button.disabled,false);assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: unavailable');assert.equal(view.inspect().selectedUnit,'ecu');assert.equal(current.state.t,t);await click('[data-um-connection="crank_sensor"]');assert.deepEqual(calls.connection.at(-1),{id:'crank_sensor',connected:true});assert.equal(button.textContent,'Disconnect');assert.equal(current.state.t,t);
 });
 await test('connector errors remain visible and do not invent a disconnection',async()=>{
  const before=current.state;connectionFailure='Connector change rejected by simulator';await click('[data-um-connection="crank_sensor"]');assert.equal(current.state,before);assert.equal($('[data-um-connection="crank_sensor"]').disabled,false);assert.equal($('[data-um-connection="crank_sensor"]').textContent,'Disconnect');assert.match($('[data-um-connection-message="crank_sensor"]').textContent,/rejected by simulator/);assert.doesNotMatch($('[data-um-live-signal="crank_sensor"]').textContent,/unavailable/);connectionFailure='';
 });
 await test('intermittent status follows snapshot phases without regrouping or creating its own timer',()=>{
  const base=current.state,node=row('crank_sensor'),heading=$('[data-um-group-heading="period_20ms"]'),before=JSON.stringify(groups()),pattern={mode:'intermittent',pattern:'regular',phase:'connected',effective_connected:true,connected_s:2,dropout_s:.4,next_change_s:base.t+1.2,time_to_change_s:1.2,dropout_count:0,transition_count:0,seed:1};
  update({...base,connection_faults:{crank_sensor:pattern}});assert.match($('[data-um-connection-status="crank_sensor"]').textContent,/Intermittent · connected · next in 1.2 s/);assert.equal($('[data-um-connection="crank_sensor"]').textContent,'Stop test & reconnect');
  update({...fixture.states.open_before_sample,connection_faults:{crank_sensor:{...pattern,phase:'dropout',effective_connected:false,time_to_change_s:.25}}});assert.match($('[data-um-connection-status="crank_sensor"]').textContent,/Intermittent · dropout · next in 0.25 s/);assert.equal($('[data-um-live-signal="crank_sensor"]').textContent,'Pulse frequency: unavailable');assert.equal(row('crank_sensor'),node);assert.equal($('[data-um-group-heading="period_20ms"]'),heading);assert.equal(JSON.stringify(groups()),before);
  const status=$('[data-um-connection-status="crank_sensor"]').textContent;view.update(current);assert.equal($('[data-um-connection-status="crank_sensor"]').textContent,status,'A repeated snapshot does not advance the fault clock');
 });
 await test('stopping an intermittent test requests a reconnect and clears the live schedule label',async()=>{
  await click('[data-um-connection="crank_sensor"]');assert.deepEqual(calls.connection.at(-1),{id:'crank_sensor',connected:true});assert.equal($('[data-um-connection-status="crank_sensor"]').textContent,'');assert.equal($('[data-um-connection="crank_sensor"]').textContent,'Disconnect');assert.equal($('[data-um-connection-message="crank_sensor"]').textContent,'');assert.doesNotMatch($('[data-um-live-signal="crank_sensor"]').textContent,/unavailable/);
 });
 await test('disposal removes grouping listeners and all view nodes',()=>{
  const control=$('[data-um="group-by"]');assert.equal((control.listeners.get('change')||[]).length,1);view.dispose();assert.equal((control.listeners.get('change')||[]).length,0);assert.equal(container.children.length,0);
 });
 console.log(JSON.stringify({suite:'sensor map characteristics v0.9.1',passed,failed,scope:'Actual Python VehicleSim/SensorBank fixtures and parsed-node UI contracts; no native browser layout verification'}));process.exitCode=failed?1:0;
})();
