"""Reference-book extraction checks: keep theory, remove page controls.

The input files are explicitly allowlisted locally authored documents. These
checks are not a claim that the parser is a general untrusted-HTML sanitizer.
"""
from html.parser import HTMLParser
from pathlib import Path
import tempfile
import unittest

from obdii_lab.book import BookHTML, DOCUMENTS, read_book


ROOT = Path(__file__).resolve().parents[1]


class Elements(HTMLParser):
    """Inspect retained content without comparing serializer whitespace."""
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.text = []
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))

    def handle_data(self, data):
        self.text.append(data)


def extract(source, name="LEARNING_GUIDE"):
    parser = BookHTML(name)
    parser.feed(source)
    parser.close()
    return parser, "".join(parser.html)


class BookExtractionTests(unittest.TestCase):
    def test_page_chrome_is_excluded_but_chapter_words_and_entities_survive(self):
        source = """<html><head><title>Window title</title></head><body>
        <header>Outer navigation</header><main>
        <header id="title-block-header"><h1>Repeated page title</h1></header>
        <nav id="TOC"><ul><li><a href="#sensor">Repeated contents</a></li></ul></nav>
        <h1 id="sensor">Sensors &amp; <em>signals</em></h1>
        <p>Keep the real explanation: 2 &lt; 5 and A &amp; B.</p>
        <h2>Try <code>one change</code></h2><p>See what happens.</p>
        </main><aside>After the document</aside></body></html>"""
        parser, result = extract(source)
        text = " ".join(" ".join(Elements(result).text).split())
        self.assertIn("Keep the real explanation: 2 < 5 and A & B.", text)
        for omitted in ("Window title", "Outer navigation", "Repeated page title", "Repeated contents", "After the document"):
            self.assertNotIn(omitted, text)
        self.assertEqual([h["title"] for h in parser.headings], ["Sensors & signals", "Try one change"])
        self.assertEqual([h["level"] for h in parser.headings], [1, 2])

    def test_nested_page_controls_are_removed_without_losing_following_theory(self):
        source = """<main><h1 id="a">A lesson</h1>
        <script>window.unwanted = true;</script>
        <style>.unwanted {display:none}</style>
        <form action="/send"><div>Submit this<input value="x"/><br><button>Send</button></div></form>
        <iframe src="https://example.invalid/">Embedded page</iframe>
        <footer><div>Footer links<br/></div></footer>
        <h2 id="b">The next lesson</h2><p>Important retained explanation.</p></main>"""
        parser, result = extract(source)
        self.assertNotIn("unwanted", result)
        self.assertNotIn("Submit this", result)
        self.assertNotIn("Embedded page", result)
        self.assertNotIn("Footer links", result)
        self.assertIn("Important retained explanation.", result)
        self.assertEqual([h["title"] for h in parser.headings], ["A lesson", "The next lesson"])
        self.assertFalse({"script", "style", "form", "iframe", "input", "button"} & {tag for tag, _ in Elements(result).tags})

    def test_navigation_is_removed_even_when_not_named_pandoc_toc(self):
        _, result = extract('<main><nav aria-label="Document navigation"><a href="other.html">Site navigation</a></nav><h1>Actual chapter</h1><p>Theory.</p></main>')
        self.assertNotIn("Site navigation", result)
        self.assertNotIn("<nav", result)
        self.assertIn("Actual chapter", result)

    def test_mathml_images_figures_lists_and_tables_remain_readable(self):
        source = """<main><h2 id="voltage">Temperature and voltage</h2>
        <p><math display="block" xmlns="http://www.w3.org/1998/Math/MathML"><semantics>
        <mrow><mi>V</mi><mo>=</mo><mfrac><mn>5</mn><mn>2</mn></mfrac></mrow>
        <annotation encoding="application/x-tex">V=\\frac{5}{2}</annotation>
        </semantics></math></p>
        <figure><img src="figures/control_loop.png" alt="Sensor &amp; computer" width="800"/><figcaption>Keep this caption.</figcaption></figure>
        <ol><li>Change one input.</li><li>Observe the response.</li></ol>
        <table><thead><tr><th>Input</th><th>Meaning</th></tr></thead><tbody><tr><td>Temperature</td><td>How warm it is.</td></tr></tbody></table>
        <p>End of the explanation.</p></main>"""
        _, result = extract(source)
        elements = Elements(result)
        tags = [tag for tag, _ in elements.tags]
        for retained in ("math", "semantics", "mrow", "mfrac", "annotation", "figure", "img", "figcaption", "ol", "table", "thead", "tbody"):
            self.assertIn(retained, tags)
        img = next(attrs for tag, attrs in elements.tags if tag == "img")
        self.assertEqual(img["src"], "/docs/figures/control_loop.png")
        self.assertEqual(img["alt"], "Sensor & computer")
        self.assertEqual(img["width"], "800")
        math = next(attrs for tag, attrs in elements.tags if tag == "math")
        self.assertEqual(math["display"], "block")
        self.assertEqual(math["xmlns"], "http://www.w3.org/1998/Math/MathML")
        self.assertIn("V=\\frac{5}{2}", result)
        self.assertIn("End of the explanation.", result)

    def test_ids_and_internal_links_share_a_document_namespace(self):
        source = '<main><h1 id="intro">Introduction</h1><h2 id="energy">Energy</h2><p><a href="#energy">Go to energy</a><a href="PROTOCOL.html#requests">Other guide</a><a href="https://example.com/ref">External</a></p></main>'
        first, first_html = extract(source, "LEARNING_GUIDE")
        second, second_html = extract(source, "PROTOCOL")
        self.assertTrue(set(h["id"] for h in first.headings).isdisjoint(h["id"] for h in second.headings))
        attrs = Elements(first_html).tags
        ids = {a["id"] for _, a in attrs if "id" in a}
        local_hrefs = [a["href"][1:] for tag, a in attrs if tag == "a" and a.get("href", "").startswith("#")]
        self.assertTrue(set(local_hrefs) <= ids)
        self.assertIn('href="/docs/PROTOCOL.html#requests"', first_html)
        self.assertIn('href="https://example.com/ref"', first_html)
        self.assertIn('href="#protocol--energy"', second_html)

    def test_generated_heading_identifiers_do_not_collide_with_explicit_identifiers(self):
        fixtures = [
            '<main><h1 id="heading-2">A named section</h1><h2>A section without an ID</h2><h3>Its subsection</h3></main>',
            '<main><h1>A section without an ID</h1><h2 id="heading-1">A later named section</h2><p><a href="#heading-1">Find the later section</a></p></main>',
        ]
        for source in fixtures:
            with self.subTest(source=source):
                parser, result = extract(source)
                ids = [h["id"] for h in parser.headings]
                self.assertEqual(len(ids), len(set(ids)))
                emitted_ids = [attrs["id"] for _, attrs in Elements(result).tags if "id" in attrs]
                self.assertEqual(len(emitted_ids), len(set(emitted_ids)))
                if "later named" in source:
                    named = next(h for h in parser.headings if h["title"] == "A later named section")
                    self.assertEqual(named["id"], "learning_guide--heading-1")
                    self.assertIn('href="#learning_guide--heading-1"', result)

    def test_event_attributes_inline_style_and_unsafe_link_schemes_are_removed(self):
        _, result = extract('''<main><h1 onclick="bad()" style="color:red">Title</h1>
        <p><a href="javascript:bad()" onmouseover="bad()">Unsafe link</a>
        <a href="mailto:author@example.com">Email</a></p>
        <img src="data:text/html,example" onerror="bad()" alt="Unavailable image"/>
        <p>Retained ordinary content.</p></main>''')
        elements = Elements(result)
        self.assertFalse(any(key.startswith("on") or key in {"style", "srcdoc"} for _, attrs in elements.tags for key in attrs))
        self.assertNotIn("javascript:", result)
        self.assertNotIn("data:text", result)
        self.assertIn('href="mailto:author@example.com"', result)
        self.assertIn("Retained ordinary content.", result)

    def test_self_closing_skipped_blocks_do_not_hide_the_following_chapter(self):
        parser, result = extract('<main><iframe src="unused"/><form/><style/><h2 id="after">After the controls</h2><p>Still here.</p></main>')
        self.assertEqual(parser.headings, [{"id": "learning_guide--after", "title": "After the controls", "level": 2}])
        self.assertIn("Still here.", result)
        self.assertNotIn("<iframe", result)


class BookLoadingTests(unittest.TestCase):
    def test_only_allowlisted_html_files_are_loaded_in_document_order(self):
        with tempfile.TemporaryDirectory(prefix="obdii-book-") as temporary:
            docs = Path(temporary)
            (docs / "LEARNING_GUIDE.html").write_text('<main><h1 id="one">Model theory</h1><p>Trusted local theory.</p></main>')
            (docs / "PROTOCOL.html").write_text('<main><h1 id="two">Messages</h1></main>')
            (docs / "UNLISTED.html").write_text('<main><h1>Not part of the book</h1></main>')
            (docs / "BEGINNER_HANDBOOK.md").write_text('# This is not the generated reading HTML')
            book = read_book(docs)
        self.assertEqual([d["id"] for d in book["documents"]], ["learning_guide", "protocol"])
        expected_titles = dict(DOCUMENTS)
        self.assertEqual(book["documents"][0]["title"], expected_titles["LEARNING_GUIDE"])
        self.assertEqual(book["documents"][0]["url"], "/docs/LEARNING_GUIDE.html")
        self.assertEqual(book["reading_copy"], "/OBDII_Learning_Guide.pdf")
        self.assertNotIn("Not part of the book", str(book))

    def test_delivered_guides_retain_equations_images_and_usable_heading_tree(self):
        docs = ROOT / "docs"
        book = read_book(docs)
        documents = {document["id"]: document for document in book["documents"]}
        self.assertIn("learning_guide", documents)
        self.assertIn("protocol", documents)
        theory = documents["learning_guide"]
        self.assertTrue(theory["headings"])
        source = (docs / "LEARNING_GUIDE.html").read_text()
        source_elements, theory_elements = Elements(source), Elements(theory["html"])
        self.assertGreater(sum(tag == "math" for tag, _ in theory_elements.tags), 5)
        self.assertEqual(sum(tag == "math" for tag, _ in source_elements.tags), sum(tag == "math" for tag, _ in theory_elements.tags))
        self.assertEqual(sum(tag == "img" for tag, _ in source_elements.tags), sum(tag == "img" for tag, _ in theory_elements.tags))
        all_ids = set()
        for doc in book["documents"]:
            with self.subTest(document=doc["id"]):
                emitted_ids = {attrs["id"] for _, attrs in Elements(doc["html"]).tags if "id" in attrs}
                self.assertTrue(doc["title"])
                self.assertTrue(doc["headings"])
                self.assertTrue(all(h["title"] and h["id"] in emitted_ids and 1 <= h["level"] <= 4 for h in doc["headings"]))
                self.assertTrue(all(h["id"].startswith(doc["id"] + "--") for h in doc["headings"]))
                self.assertTrue(all_ids.isdisjoint(emitted_ids))
                all_ids.update(emitted_ids)
                self.assertNotIn('<nav id="', doc["html"])


if __name__ == "__main__":
    unittest.main()
