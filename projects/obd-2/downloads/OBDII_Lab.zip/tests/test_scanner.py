"""Virtual adapter gating, byte replies and explicit module-state inspection."""
import json
import unittest

from obdii_lab.scanner import ScannerSession
from obdii_lab.core import Sim
from obdii_lab.diagnostics import DiagnosticServer, IsoTpReceiver
from obdii_lab.runner import diagnostic_server
from obdii_lab.vehicle import VehicleSim
from obdii_lab.vehicle_systems import SensorBank


def configured(id="petrol_advanced", options=None):
    sim = VehicleSim(id, options)
    sim.sensor_bank = SensorBank(sim.configuration)
    sim.sensor_bank.sample(sim.raw_snapshot())
    return sim


class ScannerSessionTests(unittest.TestCase):
    def setUp(self):
        self.sim = configured()
        self.scanner = ScannerSession(self.sim)

    def ready(self):
        self.sim.control("ignition", True)
        self.sim.advance(.1)
        self.scanner.connect()

    def test_disconnected_request_has_no_frames_or_reply(self):
        response = self.scanner.request("01 0C")
        self.assertEqual(self.scanner.state()["status"], "disconnected")
        self.assertEqual(response["frames"], [])
        self.assertIsNone(response["response_hex"])
        self.assertTrue(response["timeout"])

    def test_ignition_on_is_sufficient_engine_need_not_run(self):
        self.scanner.connect()
        off = self.scanner.request("01 0C")
        self.assertEqual(off["connection"]["status"], "vehicle_off")
        self.assertEqual(off["frames"], [])
        self.ready()
        response = self.scanner.request("01 0C")
        self.assertFalse(self.sim.snapshot()["engine_running"])
        self.assertEqual(response["response_hex"], "41 0C 00 00")
        self.assertEqual(response["frames"][0]["id"], "7DF")
        self.assertEqual(response["frames"][1]["id"], "7E8")
        self.assertEqual(response["sample_t"], self.sim.t)

    def test_wrong_bitrate_is_silent_and_matching_250_is_supported(self):
        self.ready()
        self.scanner.connect("can11_250")
        response = self.scanner.request("03")
        self.assertEqual(response["connection"]["status"], "bitrate_mismatch")
        self.assertEqual(response["frames"], [])
        vehicle = configured(options={"can_bitrate": 250000})
        vehicle.control("ignition", True)
        vehicle.advance(.1)
        scanner = ScannerSession(vehicle)
        scanner.connect("can11_250")
        response = scanner.request("03")
        self.assertEqual(response["response_hex"], "43 00")
        self.assertEqual(response["bitrate"], 250000)

    def test_monitor_ignition_bit_follows_configuration_without_extra_readiness_claims(self):
        for preset, ignition_bit in (("petrol_advanced", 0), ("diesel", 0x08)):
            with self.subTest(preset=preset):
                sim = configured(preset)
                sim.control("ignition", True)
                sim.advance(.1)
                scanner = ScannerSession(sim)
                scanner.connect()
                result = scanner.request("01 01")
                payload = bytes.fromhex(result["response_hex"])
                self.assertEqual(payload[:2], b"\x41\x01")
                self.assertEqual(payload[3] & 0x08, ignition_bit)
                self.assertEqual(payload[3] & 0x07, 0x04, "Only the common component monitor is supported")
                self.assertEqual(payload[3] & 0xB0, 0, "No unsupported common-monitor or reserved bits")
                self.assertEqual(payload[4:], b"\x00\x00", "No specialized monitor support or completion is claimed")
                receiver = IsoTpReceiver()
                assembled = None
                for frame in result["frames"]:
                    if frame["id"] == "7E8":
                        assembled = receiver.feed(frame["data"], sim.t)
                self.assertEqual(assembled, payload, "Wire trace and application bytes agree")

    def test_diesel_component_completion_changes_only_its_own_incomplete_flag(self):
        snapshot = configured("diesel").snapshot()
        server = DiagnosticServer(lambda: snapshot)
        snapshot["components_monitor_complete"] = False
        incomplete = bytes.fromhex(server.request("01 01")["response_hex"])
        snapshot["components_monitor_complete"] = True
        complete = bytes.fromhex(server.request("01 01")["response_hex"])
        self.assertEqual(incomplete[3], 0x4C)
        self.assertEqual(complete[3], 0x0C)
        self.assertEqual(incomplete[:3], complete[:3])
        self.assertEqual(incomplete[4:], b"\x00\x00")
        self.assertEqual(complete[4:], b"\x00\x00")

    def test_legacy_sim_monitor_retains_spark_ignition_format(self):
        sim = Sim("engine", "manual")
        server = diagnostic_server(sim)
        payload = bytes.fromhex(server.request("01 01")["response_hex"])
        self.assertEqual(payload[3] & 0x08, 0)
        self.assertEqual(payload[3] & 0x07, 0x04)
        self.assertEqual(payload[4:], b"\x00\x00")

    def test_reference_transport_cannot_silently_connect(self):
        for protocol in ("iso9141", "iso14230", "j1850_pwm", "j1850_vpw", "can29_500", "doip"):
            with self.subTest(protocol=protocol):
                with self.assertRaisesRegex(ValueError, "reference-only"):
                    self.scanner.connect(protocol)
                self.assertFalse(self.scanner.connected)
        with self.assertRaises(ValueError):
            self.scanner.connect("unknown")

    def test_dlc_and_ecu_connectors_gate_requests(self):
        self.ready()
        self.sim.set_connection("dlc", False)
        response = self.scanner.request("09 02")
        self.assertEqual(response["connection"]["status"], "dlc_open")
        self.assertEqual(response["frames"], [])
        self.sim.set_connection("dlc", True)
        self.sim.set_connection("unit_ecu", False)
        response = self.scanner.request("03")
        self.assertEqual(response["connection"]["status"], "unit_open")
        self.assertEqual(response["frames"], [])
        self.sim.set_connection("unit_ecu", True)
        self.assertEqual(self.scanner.request("03")["response_hex"], "43 00")

    def test_uds_uses_explicit_physical_address_and_existing_session(self):
        self.ready()
        response = self.scanner.request("10 03")
        self.assertTrue(response["response_hex"].startswith("50 03"))
        self.assertEqual(response["frames"][0]["id"], "7E0")
        self.assertEqual(response["session"]["id"], 3)
        vin = self.scanner.request("22 F1 90")
        self.assertTrue(vin["response_hex"].startswith("62 F1 90"))
        self.assertIsNone(self.scanner.request("22 F1 90", 0x7DF)["response_hex"])

    def test_missing_sample_does_not_return_hidden_plant_value(self):
        self.ready()
        self.sim.control("start")
        self.sim.advance(1)
        self.assertIsNotNone(self.scanner.request("01 10")["response_hex"])
        self.sim.set_connection("maf", False)
        self.sim.advance(.8)
        self.assertIsNotNone(self.sim.snapshot()["maf_g_s"])
        response = self.scanner.request("01 10")
        self.assertEqual(response["status"], "sample_unavailable")
        self.assertIsNone(response["response_hex"])
        self.assertEqual(response["frames"], [])
        self.assertIn("01 02", self.scanner.request("03")["response_hex"])

    def test_sampled_pid_is_held_until_its_sensor_updates(self):
        self.ready()
        bank = self.sim.sensor_bank
        bank.readings["maf"].update(value=17.5, validity="valid")
        # The plant and measured channel intentionally differ at this instant.
        self.assertNotEqual(self.sim.snapshot()["maf_g_s"], 17.5)
        self.assertEqual(self.scanner.request("01 10")["response_hex"], "41 10 06 D6")

    def test_clear_response_clears_memory_and_active_fault_reappears(self):
        self.ready()
        self.sim.set_connection("map", False)
        self.sim.advance(.8)
        self.assertIn("P0107", self.sim.snapshot()["dtcs"])
        self.assertEqual(self.scanner.request("04")["response_hex"], "44")
        self.assertFalse(self.sim.sensor_bank.connections["map"])
        self.assertEqual(self.scanner.request("03")["response_hex"], "43 00")
        self.sim.advance(.8)
        self.assertIn("P0107", self.sim.snapshot()["dtcs"])

    def test_non_ecu_units_have_no_invented_wire_protocol(self):
        self.ready()
        self.scanner.connect(module_id="abs")
        self.assertEqual(self.scanner.state()["status"], "state_only")
        response = self.scanner.request("22 F1 90")
        self.assertEqual(response["status"], "state_only")
        self.assertEqual(response["frames"], [])
        self.assertIsNone(response["response_hex"])
        report = self.scanner.scan()
        self.assertEqual(self.scanner.module_id, "abs")
        module = next(m for m in report["modules"] if m["id"] == "abs")
        self.assertEqual(module["source"], "simulation module state")
        self.assertEqual(module["diagnostic_capability"], "state_only")
        self.assertTrue(module["signals"])
        self.assertTrue(all(r["response_hex"] for r in report["diagnostics"]))

    def test_scan_when_disconnected_does_not_leak_live_values(self):
        self.sim.control("ignition", True)
        self.sim.advance(.1)
        self.sim.set_connection("maf", False)
        self.sim.advance(.8)
        report = self.scanner.scan()
        for module in report["modules"]:
            self.assertFalse(module["codes"])
            self.assertTrue(all(s["value"] is None for s in module["signals"]))
        self.assertTrue(all(not r["frames"] for r in report["diagnostics"]))

    def test_bev_has_no_combustion_ecu_but_can_inspect_electric_units(self):
        sim = configured("bev")
        scanner = ScannerSession(sim)
        with self.assertRaisesRegex(ValueError, "not installed"):
            scanner.connect(module_id="ecu")
        sim.control("ignition", True)
        sim.advance(.1)
        scanner.connect(module_id="bmu")
        report = scanner.scan()
        self.assertEqual(report["diagnostics"], [])
        bmu = next(m for m in report["modules"] if m["id"] == "bmu")
        self.assertTrue(bmu["installed"])
        self.assertTrue(any(s["id"] == "pack_voltage" and s["value"] is not None for s in bmu["signals"]))
        self.assertEqual(next(m for m in report["modules"] if m["id"] == "ecu")["status"], "not_installed")

    def test_catalog_maps_all_pins_and_active_transport_roles(self):
        catalog = self.scanner.catalog()
        self.assertEqual([p["number"] for p in catalog["socket"]["pins"]], list(range(1, 17)))
        self.assertEqual(catalog["socket"]["pins"][5]["label"], "CAN-H")
        self.assertEqual(catalog["socket"]["pins"][13]["label"], "CAN-L")
        self.assertEqual(next(p for p in catalog["protocols"] if p["id"] == "j1850_vpw")["pins"], [2, 4, 5, 16])
        json.dumps(catalog, allow_nan=False)

    def test_invalid_request_does_not_generate_frames(self):
        self.ready()
        for payload, address in (("", None), ("GG", None), ("ATZ", None), ("01 0C", 0x800), ("03", True), (None, None)):
            with self.subTest(payload=payload, address=address):
                result = self.scanner.request(payload, address)
                self.assertIn("error", result)
                self.assertFalse(result["frames"])

    def test_logged_requests_share_simulation_timestamp_and_disconnect_is_real(self):
        self.ready()
        first = self.scanner.request("03")
        self.sim.advance(.2)
        second = self.scanner.request("01 0C")
        self.assertLess(first["sample_t"], second["sample_t"])
        self.assertEqual(len(self.scanner.log), 2)
        self.assertEqual(self.scanner.state()["last_request_t"], second["sample_t"])
        self.scanner.disconnect()
        self.assertTrue(self.scanner.request("03")["timeout"])


if __name__ == "__main__":
    unittest.main()
