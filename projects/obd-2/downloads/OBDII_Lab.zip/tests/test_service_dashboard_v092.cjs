/* Persistent service dashboard contracts: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_service_dashboard_v092.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){const server=await startServer();try{
 const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
 for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
 const app=window.VehicleApplication;await app.ready;await flush();
 const settle=async()=>{await app.session.command;await waitFor(()=>app.session.pending===0&&!app.monitor.inspect().pending,'Monitor controls settle');await flush();};
 const click=async selector=>{await $(selector).click();await settle();};
 const state=()=>app.session.result.state;
 const next=async(id='petrol_basic',options={})=>{const settings={mode:'manual',road_mu:.9,grade_pct:0};if(app.session.setupComplete)await app.session.setup(id,options,settings,{enterDrive:false});else await app.session.commitSetup(id,options,settings);app.session.enterWorkspace('service');app.session.setRunning(false);await settle();};
 await test('Initial vehicle setup hides the service monitor and creates no independent clock',async()=>{assert.equal($('#service-dashboard').hidden,true);assert.equal(app.monitor.inspect().visible,false);assert.equal(app.session.workflowStage,'vehicle');});
 await next();
 await test('Service dashboard and scan tool are visible together outside tool scrolling',async()=>{assert.equal($('#service-dashboard').hidden,false);assert.equal($('#view-service').hidden,false);assert.equal($('#view-scan').hidden,false);assert.equal($('#service-dashboard').closest('.app-view-stack'),null);assert.equal($('#service-dashboard').parentElement.id,'app-main');assert.equal($('[data-vm="gear"]').textContent,'P');assert.equal($('[data-vm="energy"]').textContent,'100.0%');assert.equal($('[data-vm="supply"]').textContent,'12.6 V');});
 await test('Service ignition is routed once to the shared vehicle',async()=>{const count=requests.filter(r=>r.url==='/api/control'&&r.body.action==='ignition').length;await click('[data-vm-action="ignition"]');app.session.setRunning(false);assert.equal(state().vehicle.ignition,'on');assert.equal(requests.filter(r=>r.url==='/api/control'&&r.body.action==='ignition').length,count+1);assert.equal($('[data-vm-lamp="parking"]').classList.contains('lit'),true);assert.equal($('[data-vm="supply"]').textContent,'12.4 V');assert.equal($('[data-vm-lamp="oil"]').classList.contains('lit'),true);});
 await test('Start engine in service drives the same RPM gauge and preserves diagnostics',async()=>{await click('[data-vm-action="start"]');app.session.setRunning(false);await app.session.advance(1);await settle();assert.equal(state().engine_running,true);assert.equal(Number($('[data-vm="left-value"]').textContent),Math.round(state().rpm));assert.ok(Number($('[data-vm="left-value"]').textContent)>500);assert.equal($('#view-scan').hidden,false);assert.equal($('[data-vm="supply"]').textContent,'14.2 V');assert.equal($('[data-vm="power-state"]').textContent,'Engine running');});
 await test('Every service tool preserves monitor state and clock without separate requests',async()=>{const time=state().t,count=requests.length;for(const route of ['units','wiring','live','locations','diagnosis','configuration','scan']){app.session.navigate(route);await flush();assert.equal($('#service-dashboard').hidden,false);assert.equal(app.monitor.inspect().time,time);assert.equal(state().vehicle.configuration.id,'petrol_basic');}assert.equal(requests.length,count);});
 await test('Seat belt and door controls update actual body state and paused tell-tales',async()=>{const time=state().t;await click('[data-vm-action="seatbelt"]');await click('[data-vm-action="door"]');assert.equal(state().t,time);assert.equal(state().vehicle.driver_seatbelt_fastened,false);assert.equal(state().vehicle.driver_door_open,true);assert.equal($('[data-vm-lamp="seatbelt"]').classList.contains('lit'),true);assert.equal($('[data-vm-lamp="door"]').classList.contains('lit'),true);await click('[data-vm-action="seatbelt"]');await click('[data-vm-action="door"]');assert.equal($('[data-vm-lamp="seatbelt"]').classList.contains('lit'),false);assert.equal($('[data-vm-lamp="door"]').classList.contains('lit'),false);});
 await test('Service parking warning release controls the same drive without changing gear',async()=>{await app.session.shift('D',{assist:true});await app.session.setInputs({throttle:.6});await app.session.advance(.5);assert.equal(state().speed_kph,0);assert.equal($('#service-dashboard').classList.contains('vm-parking-blocked'),true);assert.match($('[data-vm="notice"]').textContent,/release/i);await click('[data-vm-action="release-parking"]');assert.equal(state().vehicle.selector,'D');await app.session.advance(1);assert.ok(state().speed_kph>0);assert.equal($('[data-vm-lamp="parking"]').classList.contains('lit'),false);assert.equal(Number($('[data-vm="speed-value"]').textContent),Math.round(state().speed_kph));await app.session.setInputs({throttle:0});});
 await test('Live sensor fault is visible on dashboard while scanner remains available',async()=>{app.session.navigate('scan');await app.session.connection('crank_sensor',false);await app.session.advance(.8);assert.equal(state().engine_running,false);assert.equal($('[data-vm-lamp="mil"]').classList.contains('lit'),true);assert.match($('[data-vm="power-state"]').textContent,/inhibited/i);assert.equal($('[data-vm-action="start"]').disabled,true);assert.match($('[data-vm="notice"]').textContent,/Inspect the sensor connections/);assert.equal($('#view-scan').hidden,false);assert.equal(app.monitor.inspect().time,state().t);assert.equal(Number($('[data-vm="left-value"]').textContent),Math.round(state().rpm));});
 await test('Full driver controls returns to the same vehicle and service restores the monitor',async()=>{const time=state().t;await click('[data-vm-action="drive"]');assert.equal(app.session.view,'drive');assert.equal($('#service-dashboard').hidden,true);assert.equal($('#view-drive').hidden,false);assert.equal(state().t,time);app.session.navigate('service');assert.equal($('#service-dashboard').hidden,false);assert.equal(state().connections.crank_sensor,false);assert.equal(state().t,time);});
 await test('Diesel red zone and idle readings use the configured diesel scale',async()=>{await next('diesel');const zone=$('[data-vm-redzone="left"]');assert.notEqual(zone.style.display,'none');assert.equal(zone.hasAttribute('hidden'),false);assert.equal(Number(zone.getAttribute('data-redline-rpm')),4500);const scale=window.CockpitView.rpmScale(state());assert.equal(scale.max,5000);await click('[data-vm-action="ignition"]');app.session.setRunning(false);await click('[data-vm-action="start"]');app.session.setRunning(false);await app.session.advance(1);assert.ok(state().rpm>500);assert.equal(Number($('[data-vm="left-value"]').textContent),Math.round(state().rpm));});
 await test('BEV service panel shows power and charge, hides engine red zone and engine lamps',async()=>{await next('bev');assert.equal($('[data-vm-redzone="left"]').style.display,'none');assert.equal($('[data-vm="left-unit"]').textContent,'kW');assert.equal($('[data-vm="energy-label"]').textContent,'Charge');assert.equal($('[data-vm-lamp="mil"]').hidden,true);assert.equal($('[data-vm-lamp="oil"]').hidden,true);await click('[data-vm-action="ignition"]');app.session.setRunning(false);await click('[data-vm-action="start"]');app.session.setRunning(false);await app.session.advance(1);assert.equal(state().vehicle.ready,true);assert.equal($('[data-vm="power-state"]').textContent,'READY');});
 await test('Manual start assistance works in service and restores momentary clutch input',async()=>{await next('petrol_basic',{transmission_type:'manual_6'});await click('[data-vm-action="ignition"]');app.session.setRunning(false);assert.match($('[data-vm-action="start"]').textContent,/Clutch/);await click('[data-vm-action="start"]');app.session.setRunning(false);await app.session.advance(1);assert.equal(state().engine_running,true);assert.equal(state().inputs.clutch,0);assert.equal($('#view-scan').hidden,false);});
 await test('Vehicle edit hides operational instruments and cancel restores them without resetting',async()=>{const time=state().t;app.session.beginSetup();assert.equal($('#service-dashboard').hidden,true);app.session.cancelSetup();await settle();assert.equal($('#service-dashboard').hidden,false);assert.equal(state().t,time);});
 assert.equal(errors.length,0,errors.join('\n'));const result={passed,errors,requests:requests.length,native_browser:false};const report=process.argv[2];if(report)fs.writeFileSync(report,JSON.stringify(result,null,2));console.log(JSON.stringify(result));app.dispose();
 }finally{server.lines.close();server.child.kill('SIGTERM');}}
main().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
