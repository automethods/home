/* Actual ScannerView and AppSession callbacks over API-shaped fixtures generated
 * by VehicleSim/ScannerSession. Generic parsed nodes exercise interaction logic;
 * this is not browser layout, native event, GPU, or physical-adapter validation.
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const project=path.resolve(__dirname,'..');
const fixturesRun=spawnSync('python3',['-c',`
import json
from obdii_lab.server import Lab
lab=Lab();lab.set_vehicle('petrol_advanced');s=lab.sim
states={'off':s.snapshot()};catalog=lab.scanner.catalog()
s.control('ignition',True);s.advance(.1);lab.scanner.connect();states['on']=s.snapshot()
s.control('start');s.advance(1);states['running']=s.snapshot()
requests={p:lab.scanner.request(p) for p in ['01 0C','01 0D','01 05','01 0F','01 10','01 11','03','07','04','22 F1 90','10 03']}
healthy=lab.scanner.scan();definitions=lab.definitions()
s.set_connection('maf',False);s.advance(.8);states['fault']=s.snapshot();fault=lab.scanner.scan();requests['missing_maf']=lab.scanner.request('01 10')
s.set_connection('dlc',False);requests['timeout']=lab.scanner.request('01 0C')
lab.set_vehicle('bev');s=lab.sim;s.control('ignition',True);s.advance(.1);states['bev']=s.snapshot();bev_catalog=lab.scanner.catalog();lab.scanner.connect(module_id='bmu');bev_report=lab.scanner.scan()
print(json.dumps({'states':states,'catalog':catalog,'bev_catalog':bev_catalog,'definitions':definitions,'requests':requests,'healthy':healthy,'fault':fault,'bev_report':bev_report},allow_nan=False))
`],{cwd:project,encoding:'utf8',maxBuffer:4*1024*1024});
assert.equal(fixturesRun.status,0,fixturesRun.stderr);const fixture=JSON.parse(fixturesRun.stdout),copy=value=>JSON.parse(JSON.stringify(value));
const harness=fs.readFileSync(path.join(project,'tests/test_dashboard_contract.cjs'),'utf8'),begin=harness.indexOf('const decodeEntities='),end=harness.indexOf('const elements=new Node(');
assert.ok(begin>=0&&end>begin);
const timers=new Map(),requests=[],calls={select:[],navigate:[],scanner:[],poll:[]};let timerId=0;
class CustomEvent{constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const window={dispatchEvent(){},fetch(){throw Error('Test must provide its explicit fixture API');}};
const sandbox={window,document:{activeElement:null},console,assert,CustomEvent,
 setTimeout(fn,ms){const id=++timerId;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
 setInterval(){throw Error('Scanner must not create a separate polling clock');},requestAnimationFrame(){throw Error('Scanner does not need its own rendering loop');}};
vm.createContext(sandbox);vm.runInContext(harness.slice(begin,end)+'\nglobalThis.TestNode=Node;',sandbox);
const Node=sandbox.TestNode,originalMatches=Node.prototype.matches;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{const attrs=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];return originalMatches.call(this,part.replace(/\[[^\]]+\]/g,'')||'*')&&attrs.every(match=>this.hasAttribute(match[1])&&(match[2]===undefined||this.getAttribute(match[1])===match[2]));});};
// A native select loses the old option/value when its option nodes are replaced.
const html=Object.getOwnPropertyDescriptor(Node.prototype,'innerHTML');
Object.defineProperty(Node.prototype,'innerHTML',{get:html.get,set(value){if(this.tagName==='SELECT')this._value=undefined;html.set.call(this,value);}});
for(const file of ['session.js','protocols.js','scan-tool.js'])vm.runInContext(fs.readFileSync(path.join(project,'web',file),'utf8'),sandbox,{filename:file});
let vehicle=copy(fixture.states.off),connected=false,protocol='can11_500',targetModule='ecu',activeCatalog=fixture.catalog,report=fixture.healthy;
let failConnect=false,holdConnect=null;
const connection=()=>({connected,protocol,module_id:targetModule,vehicle_bitrate:500000,bitrate:protocol==='can11_250'?250000:500000,
 status:!connected?'disconnected':!vehicle.inputs.ignition?'vehicle_off':protocol==='can11_250'?'bitrate_mismatch':targetModule==='ecu'?'ready':'state_only',
 reason:!connected?'Connect the virtual scan tool.':!vehicle.inputs.ignition?'Switch ignition on.':protocol==='can11_250'?'Adapter and vehicle CAN bitrates do not match.':targetModule==='ecu'?'Virtual engine ECU is available.':'Model state only; no OEM endpoint.'});
const result=extra=>({state:copy(vehicle),scanner:connection(),history:[],events:[],network:{},signals:{},...extra});
const fakeAPI=async(url,options={})=>{
 const body=options.body?JSON.parse(options.body):null;requests.push({url,body});
 let data;
 if(url==='/api/scanner'){
  if(body.action==='connect'){
   if(holdConnect)await holdConnect;if(failConnect)throw Error('Adapter connection rejected by simulator.');
   const target=body.module||'ecu',transport=activeCatalog.protocols.find(p=>p.id===body.protocol);
   if(!transport||transport.availability!=='implemented')throw Error('Reference-only transport');
   if(!activeCatalog.modules.some(m=>m.id===target&&m.installed))throw Error('Unit is not fitted');
   connected=true;protocol=body.protocol;targetModule=target;data=result();
  }else if(body.action==='disconnect'){connected=false;data=result();}
  else if(body.action==='scan'){const scanned=copy(report);scanned.t=vehicle.t;scanned.connection=connection();data=result({scan_report:scanned});}
 }else if(url==='/api/diagnostic'){
  let diagnostic=copy(!connected||!vehicle.inputs.ignition||protocol==='can11_250'?fixture.requests.timeout:fixture.requests[body.payload]||fixture.requests['03']);
  if(protocol==='can11_250')diagnostic.meaning='Adapter and vehicle CAN bitrates do not match. No simulated reply.';
  if(targetModule!=='ecu')diagnostic={request_hex:body.payload,response_hex:null,frames:[],status:'state_only',meaning:'No byte endpoint.'};
  diagnostic.sample_t=vehicle.t;data=result({diagnostic});
 }else if(url==='/api/advance'){
  vehicle.t+=Number(body.seconds);data=result();
 }else throw Error('Unexpected API route '+url);
 return {ok:true,json:async()=>data};
};
const session=window.AppSession.create({fetch:fakeAPI});session.definitions=copy(fixture.definitions);session.scannerCatalog=activeCatalog;session.ready=true;session.apply(result());
// These fixtures describe an already chosen vehicle at the workspace-choice step.
// Enter service through the real gate; scanner tests do not model vehicle setup.
session.setupComplete=true;session.workflowStage='workspace';session.enterWorkspace('service');
// Freeze this API-shaped fixture: the scanner itself must create no clock.
session.setRunning(false);
const container=new Node('main');
const view=window.ScannerView.create(container,{
 onScanner:(action,settings)=>{calls.scanner.push({action,settings});return session.scannerAction(action,settings);},
 onRequest:(payload,canId)=>session.request(payload,canId),
 onPoll:settings=>{calls.poll.push(settings);session.setScannerPolling(settings);},
 onSelect:id=>calls.select.push(id),onNavigate:id=>calls.navigate.push(id)
});
const unsubscribe=session.subscribe(ctx=>view.update(ctx));view.update(session.context());
const $=selector=>{const node=container.querySelector(selector);assert.ok(node,'Actual scanner markup '+selector);return node;};
const flush=async()=>{for(let i=0;i<6;i++)await new Promise(resolve=>setImmediate(resolve));};
const settle=async()=>{await session.command;await flush();};
const click=async(selector)=>{const target=$(selector);if(!target.disabled)await container.dispatchEvent({type:'click',target});await settle();};
const change=async(selector,value)=>{const target=$(selector);target.value=value;await target.dispatchEvent({type:'change'});await settle();};
const submit=async()=>{await $('[data-sc="request-form"]').dispatchEvent({type:'submit'});await settle();};
const sync=name=>{vehicle=copy(fixture.states[name]);session.apply(result());};
const same=(a,b)=>assert.deepEqual(copy(a),b);
let passed=0,failed=0;async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name+'\n'+error.stack);}}
(async()=>{
 await test('initial view is disconnected and requests need an explicit connection',()=>{
  assert.match($('[data-sc="connection-status"]').textContent,/disconnected/);
  assert.equal($('[data-sc-action="send"]').disabled,true);assert.equal($('[data-sc-action="scan"]').disabled,false,'Discovery is independent of a unit connection');
  assert.equal(container.querySelectorAll('[data-sc-pin]').length,16);assert.equal(timers.size,0);
 });
 await test('CAN pins 6 and 14 are interactive and navigate to the exact wiring pin',async()=>{
  assert.equal($('[data-sc-pin="6"]').classList.contains('active'),true);assert.equal($('[data-sc-pin="14"]').classList.contains('active'),true);
  assert.equal($('[data-sc-pin="7"]').classList.contains('active'),false);
  const originalPin=$('[data-sc-pin="6"]');
  await click('[data-sc-pin="14"]');assert.equal($('[data-sc-pin="6"]'),originalPin,'Pin selection preserves the focusable connector nodes');assert.equal(view.inspect().pin,14);assert.match($('[data-sc="pin-title"]').textContent,/CAN-L/);
  await click('[data-sc-action="pin"]');assert.equal(calls.select.at(-1),'pin:dlc_socket:14');assert.equal(calls.navigate.at(-1),'wiring');
  await container.dispatchEvent({type:'keydown',key:'Enter',target:$('[data-sc-pin="6"]')});assert.equal(view.inspect().pin,6);
  assert.match($('[data-sc="waveform"]').innerHTML,/recessive/i);assert.match($('[data-sc="signal-example"]').textContent,/not a circuit simulation/);
  assert.match($('[data-sc="pin-description"]').textContent,/differential data pair/);
  assert.match($('[data-sc="pin-facts"]').textContent,/Pin 14/);assert.match($('[data-sc="pin-facts"]').textContent,/vehicle control continues/);
  assert.match($('[data-sc="pin-scope"]').textContent,/not a captured waveform/);
  assert.match($('[data-sc="bitrate-note"]').textContent,/500,000/);assert.match($('[data-sc="bitrate-note"]').textContent,/2 µs/);
  assert.match($('[data-sc="waveform"]').getAttribute('aria-label'),/dominant bit 0/i);
  assert.ok(container.querySelector('[data-sc="sources"] a[href="https://www.ti.com/document-viewer/lit/html/SSZTCN3"]'));
 });
 await test('supply and unused pins explain their distinct role without inventing electrical faults',async()=>{
  await click('[data-sc-pin="16"]');assert.match($('[data-sc="pin-description"]').textContent,/separate from.*traction battery/);
  assert.match($('[data-sc="pin-facts"]').textContent,/remains present/);
  await click('[data-sc-pin="1"]');assert.match($('[data-sc="pin-use"]').textContent,/Not used/);
  assert.match($('[data-sc="pin-description"]').textContent,/Vehicle-specific/);
  await click('[data-sc-pin="6"]');
 });
 await test('selecting a reference transport shows its own pins and cannot run it',async()=>{
  await change('[data-sc="protocol"]','iso9141');assert.equal($('[data-sc-action="connect"]').disabled,true);
  assert.equal($('[data-sc="protocol-scope"]').textContent,'Reference only');assert.equal($('[data-sc-pin="7"]').classList.contains('active'),true);
  await click('[data-sc-pin="7"]');assert.match($('[data-sc="pin-facts"]').textContent,/not a differential pair/);assert.match($('[data-sc="pin-facts"]').textContent,/not implemented/);
  assert.equal($('[data-sc-pin="6"]').classList.contains('active'),false);const count=calls.scanner.length;await click('[data-sc-action="connect"]');assert.equal(calls.scanner.length,count);
  await change('[data-sc="protocol"]','can11_500');
 });
 await test('Connect callback uses the server module field and engine-off connection is explicit',async()=>{
  await click('[data-sc-action="connect"]');same(calls.scanner.at(-1),{action:'connect',settings:{protocol:'can11_500',module:'ecu'}});
  assert.equal(targetModule,'ecu');assert.equal($('[data-sc="connection-status"]').textContent,'vehicle off');
  await submit();assert.equal($('[data-sc="response-bytes"]').textContent,'No reply');
  sync('running');assert.equal($('[data-sc="connection-status"]').textContent,'ready');
 });
 await test('background clock traffic does not disable scan controls but a control command does',()=>{
  view.update({...session.context(),busy:true,controlsBusy:false});
  assert.equal($('[data-sc-action="send"]').disabled,false);assert.equal($('[data-sc-action="scan"]').disabled,false);
  view.update({...session.context(),busy:true,controlsBusy:true});assert.equal($('[data-sc-action="send"]').disabled,true);
  view.update(session.context());
 });
 await test('actual request bytes decode without substituting live dashboard values',async()=>{
  await submit();const reply=fixture.requests['01 0C'],bytes=reply.response_hex.split(' ').map(x=>parseInt(x,16)),rpm=(256*bytes[2]+bytes[3])/4;
  assert.equal($('[data-sc="request-bytes"]').textContent,'01 0C');assert.equal($('[data-sc="response-bytes"]').textContent,reply.response_hex);
  assert.equal($('[data-sc="response-value"]').textContent,rpm.toLocaleString('en-GB',{maximumFractionDigits:2})+' rpm');
  assert.match($('[data-sc="response-formula"]').textContent,/256 ×/);assert.ok(session.records.length>=2);
 });
 await test('an applied wrong bitrate is visibly different from an unapplied selection and produces no value',async()=>{
  await change('[data-sc="protocol"]','can11_250');assert.equal($('[data-sc="connection-status"]').textContent,'Selection not applied');
  assert.equal($('[data-sc-action="send"]').disabled,true);await click('[data-sc-action="connect"]');
  assert.equal($('[data-sc="connection-status"]').textContent,'bitrate mismatch');assert.match($('[data-sc="connection-reason"]').textContent,/bitrates do not match/);
  assert.equal($('[data-sc="connection-status"]').classList.contains('ready'),false);await submit();
  assert.equal($('[data-sc="response-value"]').textContent,'—');assert.equal($('[data-sc="response-bytes"]').textContent,'No reply');
  await change('[data-sc="protocol"]','can11_500');await click('[data-sc-action="connect"]');
  assert.equal($('[data-sc="connection-status"]').textContent,'ready');
 });
 await test('metadata decodes IAT and MAF services as values, not generic success text',async()=>{
  for(const request of ['01 0F','01 10']){
   const descriptor=fixture.definitions.services.find(s=>s.request_hex===request);await change('[data-sc="service"]',descriptor.id);await submit();
   const b=fixture.requests[request].response_hex.split(' ').map(x=>parseInt(x,16)),d=descriptor.decode,raw=b.slice(d.data_offset,d.data_offset+d.data_length).reduce((n,v)=>256*n+v,0),value=raw*d.factor+d.offset;
   assert.equal($('[data-sc="response-value"]').textContent,value.toLocaleString('en-GB',{maximumFractionDigits:2})+' '+descriptor.unit);
   assert.match($('[data-sc="response-formula"]').textContent,/=/);
  }
 });
 await test('UDS service selection chooses physical addressing and decodes returned identity',async()=>{
  const service=fixture.definitions.services.find(s=>s.request_hex==='22 F1 90');await change('[data-sc="service"]',service.id);
  assert.equal($('[data-sc="address"]').value,'7E0');await submit();
  same(requests.at(-1).body,{payload:'22 F1 90',can_id:'7E0'});assert.match($('[data-sc="response-value"]').textContent,/LAB000/);
 });
 await test('changed target remains unapplied, stops polling and cannot read the old ECU',async()=>{
  session.setScannerPolling({enabled:true});await change('[data-sc="module"]','abs');
  assert.equal(targetModule,'ecu');assert.equal($('[data-sc-action="connect"]').textContent,'Connect to ABS / stability controller');
  assert.equal($('[data-sc="connection-status"]').textContent,'Selection not applied');assert.equal($('[data-sc-action="send"]').disabled,true);
  assert.equal($('[data-sc-action="scan"]').disabled,false);assert.equal(session.scanPolling.enabled,false);
  await click('[data-sc-action="connect"]');assert.equal(targetModule,'abs');assert.equal($('[data-sc="connection-status"]').textContent,'state only');
  assert.equal($('[data-sc-action="send"]').disabled,true);assert.equal($('[data-sc-action="clear"]').disabled,true);
 });
 await test('scan report distinguishes byte replies from model-state inspection and follows selection',async()=>{
  await click('[data-sc-action="scan"]');const rows=$('[data-sc="module-rows"]');
  assert.match(rows.textContent,/OBD replies \+ sampled inputs/);assert.match(rows.textContent,/Simulation state/);
  await click('[data-sc-unit="abs"]');assert.equal(calls.select.at(-1),'abs');assert.equal(calls.navigate.at(-1),'signals');
  report=fixture.fault;sync('fault');await click('[data-sc-action="scan"]');assert.match(rows.textContent,/P0102/);
 });
 await test('a legacy draft cannot pretend that the existing CAN connection was applied',async()=>{
  await change('[data-sc="protocol"]','iso14230');assert.equal(connected,true);assert.equal(protocol,'can11_500');
  assert.equal($('[data-sc-action="connect"]').disabled,true);assert.equal($('[data-sc-action="scan"]').disabled,true);
  assert.equal($('[data-sc-action="send"]').disabled,true);assert.match($('[data-sc="connection-reason"]').textContent,/reference-only/);
  await change('[data-sc="protocol"]','can11_500');await change('[data-sc="module"]','ecu');await click('[data-sc-action="connect"]');
 });
 await test('read continuously uses the shared simulation clock at 1 minute cadence',async()=>{
  sync('running');const rpm=fixture.definitions.services.find(s=>s.request_hex==='01 0C');await change('[data-sc="service"]',rpm.id);
  await change('[data-sc="poll-interval"]','60');const enabled=$('[data-sc="poll-enabled"]');enabled.checked=true;await enabled.dispatchEvent({type:'change'});await settle();
  assert.equal(session.scanPolling.interval,60);assert.equal(session.scanPolling.enabled,true);same(calls.poll.at(-1),{enabled:true,payload:'01 0C',canId:'7DF',interval:60});
  const before=requests.filter(r=>r.url==='/api/diagnostic').length;await session.pollScanner();await settle();
  assert.equal(requests.filter(r=>r.url==='/api/diagnostic').length,before,'The first continuous sample waits for its configured interval');
  await session.pollScanner();await flush();assert.equal(requests.filter(r=>r.url==='/api/diagnostic').length,before,'Paused simulation time causes no extra read');
  vehicle.t+=59;session.apply(result());await session.pollScanner();assert.equal(requests.filter(r=>r.url==='/api/diagnostic').length,before);
  vehicle.t+=1;session.apply(result());await session.pollScanner();await settle();assert.equal(requests.filter(r=>r.url==='/api/diagnostic').length,before+1);
  await session.pollScanner();assert.equal(requests.filter(r=>r.url==='/api/diagnostic').length,before+1);
  vehicle.t+=60;session.apply(result());await session.pollScanner();await settle();assert.equal(requests.filter(r=>r.url==='/api/diagnostic').length,before+2);
  assert.equal(timers.size,0,'No independent scanner timer');
 });
 await test('missing measurement clears the response value instead of retaining the last number',()=>{
  session.diagnostic=copy(fixture.requests.missing_maf);session.emit();assert.equal($('[data-sc="response-value"]').textContent,'—');
  assert.equal($('[data-sc="response-bytes"]').textContent,'No reply');assert.match($('[data-sc="response-meaning"]').textContent,/valid sampled/);
 });
 await test('disconnect stops continuous reads and a rejected reconnect is visible',async()=>{
  await click('[data-sc-action="disconnect"]');assert.equal(connected,false);assert.equal(session.scanPolling.enabled,false);
  assert.equal($('[data-sc-action="send"]').disabled,true);failConnect=true;await click('[data-sc-action="connect"]');
  assert.equal(connected,false);assert.equal($('[data-sc="notice"]').hidden,false);assert.match($('[data-sc="notice"]').textContent,/rejected/);failConnect=false;
 });
 await test('a new BEV configuration removes ECU choices and clears prior reply and scan views',()=>{
  vehicle=copy(fixture.states.bev);activeCatalog=fixture.bev_catalog;session.scannerCatalog=activeCatalog;session.diagnostic=null;session.scanReport=null;session.apply(result());
  assert.equal(container.querySelector('[data-sc="module"] option[value="ecu"]'),null);
  assert.equal($('[data-sc="response-title"]').textContent,'No request yet');assert.equal($('[data-sc="response-bytes"]').textContent,'—');
  assert.match($('[data-sc="module-rows"]').textContent,/No scan results/);assert.equal(view.inspect().pin,6);
  assert.equal($('[data-sc-pin="6"]').getAttribute('aria-pressed'),'true');
 });
 await test('BEV BMU connection carries the selected module through the request queue',async()=>{
  await change('[data-sc="module"]','bmu');await click('[data-sc-action="connect"]');assert.equal(targetModule,'bmu');
  assert.equal($('[data-sc-action="send"]').disabled,true);report=fixture.bev_report;await click('[data-sc-action="scan"]');
  assert.equal(container.querySelector('[data-sc-unit="ecu"]'),null);assert.ok(container.querySelector('[data-sc-unit="bmu"]'));
 });
 await test('pending connection disables duplicate actions and disposal removes callbacks',async()=>{
  assert.equal($('[data-sc-action="connect"]').disabled,true,'The named unit is already connected');await click('[data-sc-action="disconnect"]');
  let resolve;holdConnect=new Promise(done=>{resolve=done;});const target=$('[data-sc-action="connect"]');await container.dispatchEvent({type:'click',target});await flush();
  assert.equal(view.inspect().pending,true);assert.equal(target.disabled,true);const before=calls.scanner.length;await container.dispatchEvent({type:'click',target});assert.equal(calls.scanner.length,before);
  resolve();await settle();holdConnect=null;assert.equal(view.inspect().pending,false);
  unsubscribe();view.dispose();session.dispose();assert.equal(container.children.length,0);assert.equal([...container.listeners.values()].flat().length,0);assert.equal(timers.size,0);
 });
 console.log(JSON.stringify({suite:'scan tool v0.7',passed,failed,fixtures:'Actual VehicleSim/ScannerSession data; API-shaped adapter with real AppSession queue',scope:'Actual JS callbacks, SVG nodes and state contracts; no native browser layout, native events, GPU or hardware adapter claim'}));process.exitCode=failed?1:0;
})();
