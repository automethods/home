"""Causal checks for configurable driveline and cabin climate behavior.

These are checks of declared generic teaching assumptions, not production-car
calibration, refrigerant-system validation or WLTP certification.
"""
import json
import unittest

from obdii_lab.vehicle import VehicleSim, VEHICLE_CONFIGURATIONS
from obdii_lab.vehicle_systems import SensorBank, vehicle_system_catalog, signal_catalog_for_vehicle, build_network_catalog
from obdii_lab.network import network_catalog


def configured(name="petrol_basic", **options):
    sim = VehicleSim(name, options)
    sim.sensor_bank = SensorBank(sim.configuration)
    sim.sensor_bank.sample(sim.raw_snapshot())
    return sim


def started(name="petrol_basic", **options):
    sim = configured(name, **options)
    sim.control("ignition", True)
    sim.advance(0, {"clutch": 1 if sim.manual_transmission else 0, "brake": .35})
    sim.control("start")
    sim.advance(1.6)
    return sim


def driving(name="petrol_basic", seconds=5, **options):
    sim = started(name, **options)
    sim.control("gear", "1" if sim.manual_transmission else "D")
    sim.control("parking_brake", False)
    sim.advance(seconds, {"throttle": .5, "brake": 0, "clutch": .3 if sim.manual_transmission else 0})
    return sim


class ChassisTests(unittest.TestCase):
    def test_compatible_transmissions_and_defaults_are_explicit(self):
        for preset in VEHICLE_CONFIGURATIONS:
            sim = configured(preset["id"])
            expected = "automatic_6" if sim.is_ice else "single_speed" if not sim.has_engine else "hybrid_power_split"
            self.assertEqual(sim.configuration["transmission_type"], expected)
            self.assertEqual(sim.selector, "P")
            self.assertEqual(sim.snapshot()["vehicle"]["chassis"]["driven_wheels"], ["fl", "fr"])
        for name, transmission in (("bev", "manual_6"), ("diesel", "single_speed"), ("hev", "automatic_6")):
            with self.subTest(name=name), self.assertRaises(ValueError):
                configured(name, transmission_type=transmission)

    def test_chassis_values_validate_and_do_not_mutate_presets(self):
        original = VEHICLE_CONFIGURATIONS[0]["mass_kg"]
        sim = configured(mass_kg=2100, wheel_radius_m=.35, drag_area_m2=.8, rolling_resistance=.02, drivetrain="rwd")
        self.assertEqual(sim.p.mass_kg, 2100)
        self.assertEqual(sim.p.wheel_radius_m, .35)
        self.assertEqual(sim.p.drag_area_m2, .8)
        self.assertEqual(sim.p.rolling_coefficient, .02)
        self.assertEqual(VEHICLE_CONFIGURATIONS[0]["mass_kg"], original)
        for values in ({"mass_kg": True}, {"wheel_radius_m": 0}, {"mass_kg": float("nan")}, {"drag_area_m2": 2}, {"rolling_resistance": .1}, {"drivetrain": "rear"}, {"ambient_c": 99}):
            with self.subTest(values=values), self.assertRaises(ValueError):
                configured(**values)

    def test_mass_radius_and_road_load_change_motion(self):
        light = driving(mass_kg=800)
        heavy = driving(mass_kg=2500)
        self.assertGreater(light.v, heavy.v * 1.3)
        small = driving(wheel_radius_m=.22)
        large = driving(wheel_radius_m=.45)
        self.assertGreater(small.v, large.v)
        self.assertGreater(small.rpm, large.rpm)
        coast = []
        for drag, rolling in ((.3, .004), (1.5, .035)):
            sim = started(drag_area_m2=drag, rolling_resistance=rolling)
            sim.control("gear", "N"); sim.control("parking_brake", False)
            sim.v = 25; sim.wheels = [25 / sim.p.wheel_radius_m] * 4
            sim.advance(4, {"brake": 0, "throttle": 0})
            coast.append(sim.v)
        self.assertGreater(coast[0], coast[1] + .5)

    def test_drivetrain_sends_torque_to_selected_wheels(self):
        for layout, driven in (("fwd", (0, 1)), ("rwd", (2, 3)), ("awd", (0, 1, 2, 3))):
            with self.subTest(layout=layout):
                sim = started("petrol_advanced", drivetrain=layout)
                sim.control("gear", "D"); sim.control("parking_brake", False)
                sim.advance(.8, {"throttle": 1, "brake": 0, "road_mu": .15})
                speeds = sim.snapshot()["wheel_speeds_kph"]
                for index in driven:
                    self.assertGreater(speeds[index], sim.v * 3.6 + 5)
                for index in set(range(4)) - set(driven):
                    self.assertLess(abs(speeds[index] - sim.v * 3.6), 1)

    def test_manual_start_requires_clutch_and_neutral_without_advancing_time(self):
        sim = configured(transmission_type="manual_6")
        self.assertEqual(sim.selector, "N")
        sim.control("ignition", True)
        with self.assertRaisesRegex(ValueError, "clutch"):
            sim.control("start")
        sim.advance(0, {"clutch": 1})
        sim.control("start")
        self.assertEqual(sim.t, 0)
        # Accepted start stays latched in neutral after assisted input restoration.
        sim.advance(1.6, {"clutch": 0})
        self.assertGreater(sim.rpm, 750)
        self.assertEqual(sim.snapshot()["vehicle"]["start_state"], "running")

    def test_manual_shifts_use_clutch_selected_ratio_and_no_automatic_shift(self):
        sim = started(transmission_type="manual_6")
        sim.advance(0, {"clutch": 0})
        with self.assertRaisesRegex(ValueError, "clutch"):
            sim.control("gear", "1")
        for invalid in ("P", "D", "7"):
            with self.assertRaises(ValueError): sim.control("gear", invalid)
        sim.advance(0, {"clutch": 1}); sim.control("gear", "1"); sim.control("parking_brake", False)
        sim.advance(5, {"clutch": .4, "throttle": .4, "brake": 0})
        self.assertGreater(sim.v * 3.6, 15)
        self.assertEqual(sim.selector, "1")
        sim.advance(0, {"clutch": 1}); sim.control("gear", "2")
        sim.advance(4, {"clutch": 0, "throttle": .4})
        snapshot = sim.snapshot()
        self.assertEqual(snapshot["vehicle"]["gear"], 2)
        self.assertEqual(snapshot["vehicle"]["gear_ratio"], sim.RATIOS[1])
        self.assertGreater(snapshot["speed_kph"], 20)
        with self.assertRaises(ValueError): sim.advance(0, {"clutch": 1.1})
        sim.advance(0, {"clutch": 1})
        with self.assertRaisesRegex(ValueError, "Stop"): sim.control("gear", "R")

    def test_manual_clutch_load_can_stall_and_restart(self):
        sim = started(transmission_type="manual_6")
        sim.control("gear", "1")
        sim.advance(1, {"clutch": 0, "throttle": 0, "brake": 1})
        self.assertEqual(sim.snapshot()["vehicle"]["start_state"], "stalled")
        self.assertFalse(sim.snapshot()["engine_running"])
        sim.advance(0, {"clutch": 1}); sim.control("gear", "N"); sim.control("start"); sim.advance(1.6)
        self.assertGreater(sim.rpm, 750)
        self.assertEqual(sim.snapshot()["vehicle"]["start_state"], "running")

    def test_manual_clutch_sensor_open_blocks_new_start_not_physical_pedal(self):
        sim = configured(transmission_type="manual_6")
        sim.control("ignition", True); sim.advance(0, {"clutch": 1})
        sim.set_connection("clutch_position", False)
        with self.assertRaisesRegex(ValueError, "disconnected"): sim.control("start")
        self.assertEqual(sim.inputs["clutch"], 1)
        self.assertFalse(sim.snapshot()["vehicle"]["can_start"])
        sim.set_connection("clutch_position", True); sim.control("start"); sim.advance(1.6)
        self.assertTrue(sim.snapshot()["engine_running"])


class ClimateTests(unittest.TestCase):
    def test_cold_ice_heater_waits_for_warm_coolant(self):
        cold = started(ambient_c=0)
        cold.control("hvac", {"enabled": True, "setpoint_c": 24, "fan": 1})
        cold.advance(5)
        state = cold.snapshot()["vehicle"]["hvac"]
        self.assertEqual(state["heat_kw"], 0)
        self.assertEqual(state["cabin_c"], 0)
        self.assertEqual(state["status"], "waiting for warm coolant")
        hot = started(ambient_c=0, initial_coolant_c=90)
        hot.control("hvac", {"enabled": True, "setpoint_c": 24, "fan": 1})
        initial = hot.cabin_c
        hot.advance(30)
        self.assertGreater(hot.cabin_c, initial + 1)
        self.assertLess(hot.cabin_c, 24)
        self.assertGreater(hot.snapshot()["vehicle"]["hvac"]["heat_kw"], 1)

    def test_ac_cools_gradually_and_increases_ice_fuel_use(self):
        base = started(ambient_c=35)
        cooled = started(ambient_c=35)
        cooled.control("hvac", {"enabled": True, "setpoint_c": 18, "fan": 1, "ac_enabled": True})
        base.advance(30); cooled.advance(30)
        state = cooled.snapshot()["vehicle"]["hvac"]
        self.assertLess(cooled.cabin_c, base.cabin_c - 1)
        self.assertGreater(cooled.cabin_c, 18)
        self.assertGreater(state["compressor_kw"], 1)
        self.assertGreater(state["shaft_load_kw"], state["compressor_kw"])
        self.assertGreater(cooled.energy["fuel_l"], base.energy["fuel_l"])

    def test_electric_heater_draws_traction_energy_without_fuel(self):
        base = started("bev", ambient_c=0)
        heated = started("bev", ambient_c=0)
        heated.control("hvac", {"enabled": True, "setpoint_c": 24, "fan": 1})
        base.advance(30); heated.advance(30)
        state = heated.snapshot()["vehicle"]["hvac"]
        self.assertGreater(heated.cabin_c, base.cabin_c + 1)
        self.assertGreater(state["electric_heater_kw"], 4)
        self.assertGreater(state["energy_kwh"], .03)
        self.assertLess(heated.soc, base.soc)
        self.assertEqual(heated.energy["fuel_l"], 0)
        self.assertEqual(heated.rpm, 0)

    def test_hvac_connector_removes_load_and_samples_but_cabin_remains_physical(self):
        sim = started("bev", ambient_c=0)
        sim.control("hvac", {"enabled": True, "fan": 1}); sim.advance(10)
        temperature = sim.cabin_c
        sim.set_connection("unit_hvac", False); sim.advance(.6)
        state = sim.snapshot()
        self.assertEqual(state["vehicle"]["hvac"]["electrical_kw"], 0)
        self.assertEqual(state["vehicle"]["hvac"]["status"], "disconnected")
        self.assertIsNone(state["vehicle_sensors"]["cabin_temperature"]["value"])
        self.assertGreater(sim.cabin_c, temperature - .1)
        self.assertIn("HVAC_DISCONNECTED", state["sensor_dtcs"]["modules"]["hvac"])
        sim.set_connection("unit_hvac", True); sim.advance(.6)
        self.assertGreater(sim.snapshot()["vehicle"]["hvac"]["electrical_kw"], 4)
        self.assertEqual(sim.snapshot()["vehicle_sensors"]["cabin_temperature"]["validity"], "valid")

    def test_cabin_sensor_loss_gives_ventilation_without_temperature_control(self):
        sim = started("bev", ambient_c=0)
        sim.control("hvac", {"enabled": True, "fan": 1}); sim.advance(1)
        sim.set_connection("cabin_temperature", False); sim.advance(.6)
        state = sim.snapshot()["vehicle"]["hvac"]
        self.assertEqual(state["heat_kw"], 0)
        self.assertEqual(state["cooling_kw"], 0)
        self.assertGreater(state["blower_kw"], 0)
        self.assertIn("sensor fault", state["status"])

    def test_unfitted_climate_options_and_atomic_controls(self):
        sim = configured(hvac_installed=False)
        self.assertFalse(sim.configuration["ac_installed"])
        with self.assertRaises(ValueError): sim.control("hvac", {"enabled": True})
        with self.assertRaises(ValueError): configured(hvac_installed=False, ac_installed=True)
        with self.assertRaises(ValueError): configured("bev", heater_type="coolant")
        with self.assertRaises(ValueError): configured(heater_type="electric")
        sim = configured(ac_installed=False)
        before = dict(sim.hvac)
        for settings in ({"enabled": True, "fan": 2}, {"setpoint_c": float("nan")}, {"enabled": 1}, {"ac_enabled": True}):
            with self.subTest(settings=settings), self.assertRaises(ValueError): sim.control("hvac", settings)
            self.assertEqual(sim.hvac, before)

    def test_catalog_exposes_functional_importance_and_hvac_units(self):
        sim = configured(transmission_type="manual_6")
        catalog = vehicle_system_catalog(sim.configuration)
        sensors = {s["id"]: s for s in catalog["sensors"]}
        self.assertEqual(sensors["crank_sensor"]["functional_group"], "start_critical")
        self.assertTrue(sensors["crank_sensor"]["start_required"])
        self.assertEqual(sensors["fuel_level"]["functional_group"], "monitoring")
        self.assertFalse(sensors["fuel_level"]["disconnectable"])
        self.assertEqual(sensors["maf"]["functional_group"], "running_control")
        self.assertIn("70%", sensors["maf"]["failure_effect"])
        self.assertEqual(sensors["cabin_temperature"]["functional_group"], "comfort_control")
        self.assertTrue(any(u["id"] == "hvac" and u["installed"] for u in catalog["units"]))
        network = build_network_catalog(sim.configuration, network_catalog())
        self.assertTrue(any(c["id"] == "unit_hvac" for c in network["connections"]))
        self.assertTrue(any(s["id"] == "vehicle_sensors.cabin_temperature.value" for s in signal_catalog_for_vehicle(sim.configuration)))
        for preset in VEHICLE_CONFIGURATIONS:
            other = configured(preset["id"])
            json.dumps(other.snapshot(), allow_nan=False)
            json.dumps(vehicle_system_catalog(other.configuration), allow_nan=False)


if __name__ == "__main__":
    unittest.main()
