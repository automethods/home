"""Dashboard warning actions cross HTTP and remain visible in run exports."""
import json
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.server import create_server


class DashboardWarningApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None):
        req = Request(self.base + path, data=None if body is None else json.dumps(body).encode(),
                      headers={"Content-Type": "application/json"})
        with urlopen(req, timeout=10) as response:
            return json.load(response)

    def control(self, action, value=None, inputs=None):
        return self.call("/api/control", {"action": action, "value": value, "inputs": inputs or {}})

    def setUp(self):
        self.call("/api/vehicle", {"configuration": "petrol_basic"})

    def test_body_actions_change_shared_state_at_the_same_time_and_export_actual_states(self):
        self.control("ignition", True)
        first = self.control("seatbelt", False)
        second = self.control("driver_door", True)
        self.assertEqual(first["state"]["t"], 0)
        self.assertEqual(second["state"]["t"], 0)
        vehicle = second["state"]["vehicle"]
        self.assertFalse(vehicle["driver_seatbelt_fastened"])
        self.assertTrue(vehicle["driver_door_open"])
        self.assertTrue(vehicle["warning_lamps"]["seatbelt"])
        self.assertTrue(vehicle["warning_lamps"]["door_open"])
        exported = self.call("/api/export.json")
        self.assertEqual(exported["final_state"]["vehicle"], vehicle)
        self.assertEqual(len([e for e in exported["events"] if e["source"] == "BODY"]), 2)
        self.call("/api/advance", {"seconds": .2})
        exported = self.call("/api/export.json")
        self.assertFalse(exported["history"][-1]["vehicle"]["driver_seatbelt_fastened"])
        self.assertTrue(exported["history"][-1]["vehicle"]["driver_door_open"])
        self.assertTrue(exported["history"][0]["vehicle"]["driver_seatbelt_fastened"])

    def test_invalid_body_action_restores_staged_controls_and_does_not_log_an_event(self):
        self.control("ignition", True)
        before = self.call("/api/state")
        for action in ("seatbelt", "driver_door"):
            for value in (0, 1, "false", None):
                with self.subTest(action=action, value=value):
                    with self.assertRaises(HTTPError) as caught:
                        self.control(action, value, {"throttle": .8, "brake": .7})
                    self.assertEqual(caught.exception.code, 400)
                    self.assertIn("boolean", json.load(caught.exception)["error"])
                    self.assertEqual(self.call("/api/state"), before)

    def test_new_vehicle_resets_driver_body_states(self):
        self.control("seatbelt", False)
        self.control("driver_door", True)
        for configuration in ("diesel", "bev", "petrol_basic"):
            reset = self.call("/api/vehicle", {"configuration": configuration})
            vehicle = reset["state"]["vehicle"]
            self.assertTrue(vehicle["driver_seatbelt_fastened"])
            self.assertFalse(vehicle["driver_door_open"])
            self.assertTrue(vehicle["parking_brake"])
            self.assertFalse(vehicle["warning_lamps"]["parking_brake"])
            self.assertFalse(any(e["source"] == "BODY" for e in reset["events"]))

    def test_body_actions_during_wltc_preserve_virtual_driver_control(self):
        self.call("/api/cycle", {"action": "start", "name": "wltc_class3b"})
        before = self.call("/api/state")["state"]
        for action, value in (("seatbelt", False), ("driver_door", True)):
            result = self.control(action, value, {"throttle": 1, "brake": 0, "steer_deg": 10})
            after = result["state"]
            self.assertEqual(after["t"], before["t"])
            self.assertEqual(after["drive_cycle"], before["drive_cycle"])
            for pedal in ("throttle", "brake", "steer_deg"):
                self.assertEqual(after["inputs"][pedal], before["inputs"][pedal])
        self.assertFalse(after["vehicle"]["driver_seatbelt_fastened"])
        self.assertTrue(after["vehicle"]["driver_door_open"])


if __name__ == "__main__":
    unittest.main()
