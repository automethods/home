"""Verify that beginner explanations follow actual state, not selected buttons."""
from copy import deepcopy
import json
import unittest

from obdii_lab.core import Sim
from obdii_lab.diagnostics import DiagnosticServer
from obdii_lab.explanations import explain, explain_diagnostic, fault_catalog


class ExplanationTests(unittest.TestCase):
    def test_explanations_are_read_only_and_cover_profiles_with_finite_json(self):
        for profile in Sim.PROFILES:
            s = Sim(profile).advance(1)
            before = deepcopy(s)
            description = explain(s)
            self.assertEqual(s, before)
            for key in ("heading", "summary", "what_changed", "computer_action", "why", "next_step"):
                self.assertTrue(description[key])
            self.assertTrue(description["observations"])
            json.dumps(description, allow_nan=False)
            if profile == "engine":
                self.assertFalse(any(o["signal_id"].startswith("battery_") for o in description["observations"]))

    def test_coolant_fault_separates_detection_fallback_repair_and_memory(self):
        sim = Sim(scenario="ect_open")
        checking = explain(sim.advance(3.1))
        self.assertEqual(checking["fault"]["state"], "checking")
        self.assertFalse(checking["fault"]["detected"])
        self.assertIn("invalid", [o["status"] for o in checking["observations"]])
        fallback = explain(sim.advance(.2))
        self.assertEqual(fallback["fault"]["state"], "pending")
        self.assertIn("substituted", [o["status"] for o in fallback["observations"]])
        confirmed = explain(sim.advance(.3))
        self.assertEqual(confirmed["fault"]["state"], "confirmed")
        repaired = explain(sim.advance(.02, {"fault": "none"}))
        self.assertFalse(repaired["fault"]["present"])
        self.assertEqual(repaired["fault"]["name"], "none")
        self.assertEqual(repaired["fault"]["state"], "remembered")
        self.assertNotIn("substituted", [o["status"] for o in repaired["observations"]])
        sim.clear_emissions_dtcs()
        self.assertEqual(explain(sim.advance(.1))["fault"]["state"], "normal")

    def test_actual_high_input_is_explained_even_without_fault_button(self):
        s = Sim(config={"initial_coolant_c": -90, "ambient_c": -90}).advance(.6)
        result = explain(s)
        self.assertEqual(s["inputs"]["fault"], "none")
        self.assertEqual(result["fault"]["cause_name"], "coolant_high_input")
        self.assertTrue(result["fault"]["present"])
        self.assertNotIn("disconnected", result["what_changed"])

    def test_power_off_never_calls_zero_voltage_a_zero_temperature(self):
        s = Sim().advance(.2, {"ignition": False, "fault": "ect_open"})
        result = explain(s)
        self.assertEqual(result["fault"]["state"], "unpowered")
        sensed = next(o for o in result["observations"] if o["signal_id"] == "sensors.ect_c")
        self.assertEqual(sensed["status"], "unavailable")
        self.assertIn("not a zero coolant temperature", sensed["meaning"])

    def test_missing_wheel_disables_all_assistance_without_erasing_wheel_motion(self):
        sim = Sim(profile="braking", scenario="abs_split_mu")
        sim.advance(2)
        state = sim.advance(.02, {"fault": "wheel_fl_dropout"})
        result = explain(state)
        self.assertFalse(state["abs_active"])
        self.assertFalse(state["esp_active"])
        self.assertGreater(state["wheel_speeds_kph"][0], 0)
        self.assertIn("all anti-lock", result["computer_action"])
        reports = {o["signal_id"]: o for o in result["observations"]}
        self.assertEqual(reports["wheel_speeds_kph.0"]["status"], "normal")
        self.assertEqual(reports["sensors.wheel_speeds_kph.0"]["status"], "missing")
        repaired = explain(sim.advance(.05, {"fault": "none"}))
        self.assertFalse(repaired["fault"]["present"])
        self.assertEqual(repaired["fault"]["state"], "remembered")

    def test_missing_battery_messages_separate_stale_report_and_latched_shutdown(self):
        sim = Sim(scenario="bmu_timeout")
        waiting = explain(sim.advance(8.05))
        self.assertEqual(waiting["fault"]["state"], "checking")
        stopped = explain(sim.advance(.25))
        self.assertEqual(stopped["fault"]["state"], "latched")
        report = next(o for o in stopped["observations"] if o["signal_id"] == "bmu_report.pack_current_a")
        self.assertEqual(report["status"], "stale")
        restored = explain(sim.advance(.2, {"fault": "none"}))
        self.assertFalse(restored["fault"]["present"])
        self.assertEqual(restored["fault"]["state"], "latched")
        self.assertIn("off", restored["fault"]["repair_instruction"])
        sim.advance(.2, {"ignition": False})
        restarted = explain(sim.advance(.8, {"ignition": True}))
        self.assertEqual(restarted["fault"]["state"], "remembered")
        self.assertEqual(sim.snapshot()["contactor"], "CLOSED")

    def test_low_cell_is_a_test_measurement_and_remains_latched_after_repair(self):
        sim = Sim(scenario="cell_low")
        result = explain(sim.advance(8.4))
        self.assertEqual(result["fault"]["state"], "latched")
        measurement = next(o for o in result["observations"] if o["signal_id"] == "sensors.cell_min_v")
        self.assertIn("not a simulated damaged cell", measurement["meaning"])
        repaired = explain(sim.advance(.2, {"fault": "none"}))
        self.assertFalse(repaired["fault"]["present"])
        self.assertEqual(repaired["fault"]["state"], "latched")

    def test_low_charge_is_explained_as_control_strategy_not_battery_failure(self):
        state = Sim(scenario="low_soc").advance(4)
        result = explain(state)
        self.assertEqual(state["mode"], "CHARGE SUSTAIN")
        self.assertFalse(result["fault"]["present"])
        self.assertIn("preserve", result["computer_action"])
        self.assertIn("does not mean the battery is faulty", result["why"])

    def test_old_coolant_memory_does_not_hide_a_new_battery_fault(self):
        sim = Sim(profile="phev")
        sim.advance(1, {"fault": "ect_open", "throttle": .2})
        self.assertTrue(sim.snapshot()["dtcs"])
        state = sim.advance(.5, {"fault": "bmu_timeout"})
        result = explain(state)
        self.assertEqual(result["fault"]["cause_name"], "bmu_timeout")
        self.assertEqual(result["fault"]["state"], "latched")

    def test_catalog_restricts_profiles_and_is_independent(self):
        catalog = fault_catalog()
        self.assertEqual({item["id"] for item in catalog}, set(Sim.FAULTS))
        wheel = next(item for item in catalog if item["id"] == "wheel_fl_dropout")
        self.assertNotIn("engine", wheel["profiles"])
        wheel["title"] = "caller edit"
        self.assertNotEqual(next(item for item in fault_catalog() if item["id"] == "wheel_fl_dropout")["title"], "caller edit")


class DiagnosticExplanationTests(unittest.TestCase):
    def test_named_temperature_reply_explains_invalid_marker_without_bytes(self):
        sim = Sim(scenario="ect_open")
        sim.advance(4)
        server = DiagnosticServer(sim.snapshot, sim.clear_emissions_dtcs)
        raw = server.request("01 05")
        result = explain_diagnostic(raw, sim.snapshot())
        self.assertIn("cannot be trusted", result["answer"])
        self.assertNotIn("41 05 00", result["answer"] + result["explanation"])
        self.assertEqual(result["technical"]["response_hex"], "41 05 00")

    def test_clear_reply_does_not_promise_repair_or_clear_other_modules(self):
        sim = Sim(scenario="ect_open")
        sim.advance(4)
        server = DiagnosticServer(sim.snapshot, sim.clear_emissions_dtcs)
        result = explain_diagnostic(server.request("04"), sim.snapshot())
        self.assertIn("does not repair", result["explanation"])
        self.assertIn("does not clear battery or brake", result["explanation"])
        sim.advance(.6)
        self.assertTrue(sim.snapshot()["dtcs"])

    def test_empty_engine_list_does_not_hide_battery_warning_scope(self):
        sim = Sim(scenario="cell_low")
        sim.advance(9)
        server = DiagnosticServer(sim.snapshot, sim.clear_emissions_dtcs)
        result = explain_diagnostic(server.request("03"), sim.snapshot())
        self.assertEqual(result["answer"], "No engine warnings in this list")
        self.assertIn("separate battery or brake", result["explanation"])

    def test_an_untranslated_warning_is_not_mistaken_for_an_empty_list(self):
        sim = Sim()
        sim.dtcs.add("P0300")  # A future monitor can supply another supported DTC encoding.
        server = DiagnosticServer(sim.snapshot, sim.clear_emissions_dtcs)
        result = explain_diagnostic(server.request("03"), sim.snapshot())
        self.assertNotEqual(result["answer"], "No engine warnings in this list")
        self.assertEqual(result["technical"]["stored_codes"], ["P0300"])


if __name__ == "__main__":
    unittest.main()
