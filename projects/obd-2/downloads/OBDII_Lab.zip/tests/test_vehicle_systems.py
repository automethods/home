"""Configured sensors: timing, physical/measurement separation and interruption effects."""
import json
import math
import unittest

from obdii_lab.network import network_catalog, observe_network
from obdii_lab.vehicle import VehicleSim, VEHICLE_CONFIGURATIONS
from obdii_lab.vehicle_systems import (
    SensorBank, vehicle_system_catalog, signal_catalog_for_vehicle,
    read_vehicle_signals, build_network_catalog, observe_vehicle_network,
)


CONFIG = {"powertrain": "petrol", "engine_detail": "extended", "abs_installed": True, "esp_installed": True}


def sample(t=0, **values):
    result = {"t": t, "inputs": {"ignition": True, "throttle": .3, "brake": 0, "steer_deg": 0},
              "rpm": 1800., "speed_kph": 36., "coolant_c": 80., "ambient_c": 20., "load_pct": 40.,
              "maf_g_s": 12., "engine_running": True, "motor_power_kw": 10., "wheel_radius_m": .3,
              "wheel_speeds_kph": [36.] * 4, "battery_voltage_v": 350., "battery_current_a": 20.,
              "battery_temp_c": 25., "soc_pct": 60., "sensors": {"ect_c": 80., "ect_voltage_v": 1.2, "ect_sensor_valid": True},
              "connections": {"ect": True, "wheel_fl": True, "dlc": True, "bmu": True},
              "vehicle": {"selector": "D", "low_voltage_v": 14.2, "fuel_pct": 78.}, "energy": {"fuel_l": 0}}
    result.update(values)
    return result


def configured(id="petrol_advanced", options=None):
    sim = VehicleSim(id, options)
    sim.sensor_bank = SensorBank(sim.configuration)
    sim.sensor_bank.sample(sim.raw_snapshot())
    return sim


class ConfiguredSensorTests(unittest.TestCase):
    def test_all_configurations_initialise_without_fabricating_absent_signals(self):
        for configuration in VEHICLE_CONFIGURATIONS:
            with self.subTest(configuration=configuration["id"]):
                sim = configured(configuration["id"])
                s = sim.snapshot()
                json.dumps(s, allow_nan=False)
                for reading in s["vehicle_sensors"].values():
                    if not reading["installed"]:
                        self.assertIsNone(reading["value"])
                        self.assertEqual(reading["validity"], "unavailable")
                self.assertIsNone(s["vehicle_sensors"]["crank_sensor"]["value"])
        bev = configured("bev").snapshot()
        self.assertFalse(bev["vehicle_sensors"]["ect"]["installed"])
        self.assertTrue(bev["vehicle_sensors"]["rotor_sensor"]["installed"])
        self.assertFalse(configured("petrol_basic").snapshot()["vehicle_sensors"]["wheel_fl"]["installed"])

    def test_extended_and_diesel_inventories_differ(self):
        def installed_ids(config):
            return {s["id"] for s in vehicle_system_catalog(config)["sensors"] if s["installed"]}
        basic = installed_ids({**CONFIG, "engine_detail": "basic"})
        extended = installed_ids(CONFIG)
        diesel = installed_ids({**CONFIG, "powertrain": "diesel"})
        self.assertTrue({"cam_sensor", "rail_pressure", "boost_sensor"}.issubset(extended - basic))
        self.assertTrue({"nox_sensor", "dpf_pressure"}.issubset(diesel - extended))
        self.assertNotIn("knock_sensor", diesel)
        self.assertFalse(any(s["installed"] for s in vehicle_system_catalog({**CONFIG, "abs_installed": False})["sensors"] if s["id"] in ("yaw_sensor", "steering_sensor")))

    def test_fast_and_slow_samples_hold_distinct_ages(self):
        bank = SensorBank(CONFIG)
        bank.sample(sample())
        bank.sample(sample(.02, rpm=2400, maf_g_s=20, ambient_c=30))
        self.assertEqual(bank.readings["crank_sensor"]["value"], 2400)
        self.assertEqual(bank.readings["maf"]["value"], 12)
        self.assertEqual(bank.readings["maf"]["age_ms"], 20)
        self.assertEqual(bank.readings["intake_temp"]["value"], 26)
        bank.sample(sample(.05, rpm=2400, maf_g_s=20, ambient_c=30))
        self.assertEqual(bank.readings["maf"]["value"], 20)
        self.assertEqual(bank.readings["intake_temp"]["age_ms"], 50)
        bank.sample(sample(.5, ambient_c=30))
        self.assertEqual(bank.readings["intake_temp"]["value"], 35)
        # Sampling does not depend on the wall clock or the dt argument.
        bank.sample(sample(.5, maf_g_s=99), dt=60)
        self.assertNotEqual(bank.readings["maf"]["value"], 99)

    def test_eight_auxiliary_connectors_produce_sampled_faults(self):
        cases = {"maf": "P0102", "map": "P0107", "throttle_sensor": "P0122", "accelerator_sensor": "P2122",
                 "crank_sensor": "P0335", "cam_sensor": "P0340", "rail_pressure": "P0190", "boost_sensor": "P0237"}
        for id, code in cases.items():
            with self.subTest(sensor=id):
                bank = SensorBank(CONFIG)
                bank.sample(sample())
                bank.set_connection(id, False)
                bank.sample(sample(.1))
                self.assertIsNone(bank.readings[id]["value"])
                self.assertIsNotNone(bank.readings[id]["physical_value"])
                self.assertEqual(bank.readings[id]["validity"], "invalid")
                self.assertNotIn(code, bank.pending_dtcs)
                bank.sample(sample(.3))
                self.assertIn(code, bank.pending_dtcs)
                self.assertNotIn(code, bank.stored_dtcs)
                bank.sample(sample(.6))
                self.assertIn(code, bank.stored_dtcs)
                bank.set_connection(id, True)
                bank.sample(sample(.8))
                self.assertEqual(bank.readings[id]["validity"], "valid")
                self.assertNotIn(code, bank.pending_dtcs)
                self.assertIn(code, bank.stored_dtcs)
                bank.clear_codes()
                self.assertNotIn(code, bank.stored_dtcs)

    def test_clear_does_not_repair_active_connector(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("maf", False)
        bank.sample(sample())
        bank.sample(sample(.6))
        bank.clear_codes()
        self.assertFalse(bank.connections["maf"])
        bank.sample(sample(.7))
        self.assertFalse(bank.stored_dtcs)
        bank.sample(sample(1.3))
        self.assertIn("P0102", bank.stored_dtcs)

    def test_crank_loss_prevents_start_even_at_zero_rpm(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("crank_sensor", False)
        bank.sample(sample(rpm=0, engine_running=False))
        self.assertTrue(bank.effects["engine_inhibit"])
        self.assertIsNone(bank.readings["crank_sensor"]["value"])
        self.assertEqual(bank.readings["crank_sensor"]["physical_value"], 0)

    def test_propulsion_derate_and_inhibit_are_different(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("maf", False)
        bank.sample(sample())
        self.assertEqual(bank.effects["torque_factor"], .7)
        bank.set_connection("accelerator_sensor", False)
        bank.sample(sample(.05))
        self.assertEqual(bank.effects["torque_factor"], 0)
        bank.set_connection("accelerator_sensor", True)
        bank.sample(sample(.1))
        self.assertEqual(bank.effects["torque_factor"], .7)

    def test_repair_waits_for_the_next_measured_sample(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("maf", False)
        bank.sample(sample())
        self.assertEqual(bank.effects["torque_factor"], .7)
        bank.set_connection("maf", True)
        bank.sample(sample(.01))
        self.assertEqual(bank.readings["maf"]["validity"], "invalid")
        self.assertEqual(bank.effects["torque_factor"], .7)
        bank.sample(sample(.05))
        self.assertEqual(bank.readings["maf"]["validity"], "valid")
        self.assertEqual(bank.effects["torque_factor"], 1)

    def test_off_or_uninstalled_channels_do_not_generate_codes(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("maf", False)
        bank.sample(sample(inputs={"ignition": False}))
        bank.sample(sample(3, inputs={"ignition": False}))
        self.assertFalse(bank.stored_dtcs)
        self.assertEqual(bank.readings["maf"]["validity"], "unavailable")
        with self.assertRaises(ValueError):
            bank.set_connection("pack_current", False)
        with self.assertRaises(ValueError):
            bank.set_connection("maf", "false")
        with self.assertRaises(ValueError):
            bank.set_connection("not_a_connector", False)

    def test_whole_ecu_disconnect_inhibits_without_fabricating_own_sensor_dtcs(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("unit_ecu", False)
        bank.sample(sample())
        bank.sample(sample(1))
        self.assertTrue(bank.effects["engine_inhibit"])
        self.assertFalse(bank.stored_dtcs)
        self.assertIsNone(bank.readings["ect"]["value"])
        self.assertIn("ECU_DISCONNECTED", bank.module_faults["ecu"])

    def test_wheel_and_yaw_effects_preserve_physical_rotation(self):
        bank = SensorBank(CONFIG)
        bank.set_connection("wheel_fr", False)
        bank.sample(sample())
        self.assertTrue(bank.effects["abs_inhibit"])
        self.assertTrue(bank.effects["esp_inhibit"])
        self.assertIsNone(bank.readings["wheel_fr"]["value"])
        self.assertEqual(bank.readings["wheel_fr"]["physical_value"], 36)
        bank.set_connection("wheel_fr", True)
        bank.set_connection("yaw_sensor", False)
        bank.sample(sample(.1))
        self.assertFalse(bank.effects["abs_inhibit"])
        self.assertTrue(bank.effects["esp_inhibit"])

    def test_electric_faults_are_module_events_not_fake_emissions_codes(self):
        bank = SensorBank({**CONFIG, "powertrain": "bev"})
        bank.set_connection("pack_current", False)
        bank.sample(sample(coolant_c=None))
        bank.sample(sample(.6, coolant_c=None))
        self.assertEqual(bank.effects["torque_factor"], 0)
        self.assertFalse(bank.stored_dtcs)
        self.assertIn("PACK_CURRENT_SIGNAL_MISSING", bank.module_faults["bmu"])

    def test_cluster_values_share_the_configured_vehicle_state(self):
        bank = SensorBank(CONFIG)
        bank.sample(sample(vehicle={"selector": "N", "fuel_pct": 33.5, "low_voltage_v": 10.6}))
        self.assertEqual(bank.readings["fuel_level"]["value"], 33.5)
        self.assertEqual(bank.readings["body_supply"]["value"], 10.6)
        self.assertEqual(bank.readings["transmission_range"]["value"], "N")

    def test_signal_frequencies_are_derived_and_zero_speed_is_valid(self):
        bank = SensorBank(CONFIG)
        bank.sample(sample())
        self.assertEqual(bank.readings["crank_sensor"]["frequency_hz"], 1800)
        self.assertEqual(bank.readings["cam_sensor"]["frequency_hz"], 15)
        self.assertAlmostEqual(bank.readings["wheel_fr"]["frequency_hz"], 10/(2*math.pi*.3)*48)
        bank.sample(sample(.1, rpm=0, wheel_speeds_kph=[0]*4))
        self.assertEqual(bank.readings["crank_sensor"]["validity"], "valid")
        self.assertEqual(bank.readings["crank_sensor"]["frequency_hz"], 0)

    def test_time_validation_and_ect_voltage_fault_are_explicit(self):
        bank = SensorBank(CONFIG)
        bank.sample(sample(1, sensors={"ect_c": -40, "ect_voltage_v": 5, "ect_sensor_valid": False},
                           connections={"ect": False}))
        snap = sample(1, vehicle_sensors=bank.readings)
        records = read_vehicle_signals(snap, CONFIG)
        self.assertEqual(records["vehicle_sensors.ect.value"]["validity"], "invalid")
        self.assertEqual(records["vehicle_sensors.ect.signal_voltage_v"]["validity"], "valid")
        self.assertEqual(records["vehicle_sensors.ect.signal_voltage_v"]["value"], 5)
        self.assertFalse(bank.module_faults)
        with self.assertRaises(ValueError):
            bank.sample(sample(.5))
        with self.assertRaises(ValueError):
            bank.sample(sample(float("nan")))


class ConfiguredNetworkTests(unittest.TestCase):
    def test_graph_endpoints_are_valid_unique_and_base_is_not_mutated(self):
        base = network_catalog()
        before = json.dumps(base, sort_keys=True)
        graph = build_network_catalog(CONFIG, base)
        self.assertEqual(json.dumps(base, sort_keys=True), before)
        components = {c["id"]: c for c in graph["components"]}
        sockets = {s["id"]: s for s in graph["sockets"]}
        self.assertEqual(len(components), len(graph["components"]))
        self.assertEqual(len(sockets), len(graph["sockets"]))
        self.assertEqual(len({w["id"] for w in graph["wires"]}), len(graph["wires"]))
        for wire in graph["wires"]:
            for endpoint in (wire["from"], wire["to"]):
                self.assertIn(endpoint["pin"], [p["number"] for p in sockets[endpoint["socket_id"]]["pins"]])
        for component in components.values():
            for socket_id in component["socket_ids"]:
                self.assertEqual(sockets[socket_id]["component_id"], component["id"])

    def test_abs_absent_preserves_mechanical_wheels_but_not_sensor_wires(self):
        sim = configured("petrol_basic")
        graph = build_network_catalog(sim.configuration, network_catalog())
        obs = observe_vehicle_network(sim.snapshot(), graph, observe_network(sim.snapshot()))
        self.assertTrue(obs["components"]["wheel_fl"]["installed"])
        self.assertFalse(obs["components"]["abs"]["installed"])
        self.assertFalse(obs["wires"]["wheel_fl_signal"]["available"])
        self.assertEqual(obs["wires"]["wheel_fl_signal"]["status"], "not installed")

    def test_bev_graph_masks_engine_probe_and_keeps_low_voltage_supply(self):
        sim = configured("bev")
        graph = build_network_catalog(sim.configuration, network_catalog())
        obs = observe_vehicle_network(sim.snapshot(), graph, observe_network(sim.snapshot()))
        self.assertFalse(obs["components"]["ecu"]["installed"])
        self.assertIsNone(obs["wires"]["dlc_can_h"]["value"])
        self.assertEqual(obs["wires"]["dlc_power"]["value"], 12.6)
        self.assertTrue(obs["components"]["inverter"]["installed"])

    def test_signal_metadata_has_owner_and_group_for_unit_filtering(self):
        metas = signal_catalog_for_vehicle(CONFIG)
        for meta in metas:
            self.assertIn("unit_id", meta)
            self.assertIn("group_id", meta)
            self.assertIn("component_id", meta)
        self.assertEqual(next(m for m in metas if m["id"] == "vehicle_sensors.maf.value")["unit_id"], "ecu")

    def test_connected_voltage_and_unplugged_wire_are_live(self):
        sim = configured()
        sim.control("ignition", True)
        sim.advance(.1)
        graph = build_network_catalog(sim.configuration, network_catalog())
        before = observe_vehicle_network(sim.snapshot(), graph, observe_network(sim.snapshot()))
        self.assertTrue(before["wires"]["maf_signal"]["available"])
        self.assertTrue(before["wires"]["maf_signal"]["activity"])
        sim.set_connection("maf", False)
        sim.advance(.1)
        after = observe_vehicle_network(sim.snapshot(), graph, observe_network(sim.snapshot()))
        self.assertFalse(after["wires"]["maf_signal"]["available"])
        self.assertIsNone(after["wires"]["maf_signal"]["value"])
        self.assertEqual(after["components"]["maf"]["status"], "sensor disconnected")


if __name__ == "__main__":
    unittest.main()
