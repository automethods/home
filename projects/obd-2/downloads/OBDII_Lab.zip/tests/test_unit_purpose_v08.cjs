/* Purpose groups use actual configured sensor metadata. Parsed-node UI contracts;
 * no browser layout or native event claim. Run: node tests/test_unit_purpose_v08.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const project=path.resolve(__dirname,'..'),runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const run=spawnSync('python3',['-c',`
import json
from obdii_lab.vehicle import VehicleSim
from obdii_lab.vehicle_systems import SensorBank,vehicle_system_catalog,signal_catalog_for_vehicle,build_network_catalog
from obdii_lab.network import network_catalog
sim=VehicleSim('petrol_advanced');sim.sensor_bank=SensorBank(sim.configuration);sim.sensor_bank.sample(sim.raw_snapshot())
sim.control('ignition',True);sim.control('start');sim.advance(1.5)
healthy=sim.snapshot();sim.set_connection('maf',False);sim.advance(.6)
print(json.dumps({'healthy':healthy,'open':sim.snapshot(),'systems':vehicle_system_catalog(sim.configuration),'signals':signal_catalog_for_vehicle(sim.configuration),'catalog':build_network_catalog(sim.configuration,network_catalog())}))
`],{cwd:project,encoding:'utf8',maxBuffer:10*1024*1024});assert.equal(run.status,0,run.stderr);const fixture=JSON.parse(run.stdout);
const source=fs.readFileSync(path.join(project,'tests/test_dashboard_contract.cjs'),'utf8'),begin=source.indexOf('const decodeEntities='),end=source.indexOf('const elements=new Node(');assert.ok(begin>=0&&end>begin);
const w={},sandbox={window:w,document:{},console,assert,createCanvas,setInterval(){throw Error('Unit view must not create time');},requestAnimationFrame(){throw Error('Unit view must not create time');}};vm.createContext(sandbox);vm.runInContext(source.slice(begin,end)+'\nglobalThis.TestNode=Node;',sandbox);
const Node=sandbox.TestNode,originalMatches=Node.prototype.matches;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{const attrs=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];return originalMatches.call(this,part.replace(/\[[^\]]+\]/g,'')||'*')&&attrs.every(match=>this.hasAttribute(match[1])&&(match[2]===undefined||this.getAttribute(match[1])===match[2]));});};
vm.runInContext(fs.readFileSync(path.join(project,'web/unit-map.js'),'utf8'),sandbox);
const container=new Node('main'),calls={select:[],navigate:[],watch:[]};let view;
let current={state:fixture.healthy,systems:fixture.systems,signals:fixture.signals,catalog:fixture.catalog,selection:'ecu'};
view=w.UnitMapView.create(container,{onSelect:id=>{calls.select.push(id);current={...current,selection:id};view.update(current);},onNavigate:id=>calls.navigate.push(id),onWatch:(id,on)=>calls.watch.push({id,on})});view.update(current);
const $=selector=>{const node=container.querySelector(selector);assert.ok(node,'Markup '+selector);return node;};
const click=async selector=>container.dispatchEvent({type:'click',target:$(selector)});
const change=async(name,value)=>{const node=$(`[data-um="${name}"]`);node.value=value;await node.dispatchEvent({type:'change'});};
let passed=0,failed=0;async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name+'\n'+error.stack);}}
(async()=>{
 await test('all ECU inputs remain visible, grouped with starting first and truthful counts',()=>{
  assert.equal(view.inspect().purpose,'all');const headings=container.querySelectorAll('[data-um-purpose-heading]');assert.equal(headings[0].dataset.umPurposeHeading,'start_critical');
  const expected=fixture.systems.sensors.filter(s=>s.unit_id==='ecu'&&s.installed);assert.equal(container.querySelectorAll('[data-um-sensor]').length,expected.length);
  assert.match($('[data-um-purpose-heading="start_critical"]').textContent,/1 input/);
  assert.match($('[data-um-importance="crank_sensor"]').textContent,/Required for engine start/);
 });
 await test('Purpose filtering preserves clock and selection without issuing controls',async()=>{
  const t=current.state.t;await change('purpose','start_critical');assert.ok($('[data-um-sensor="crank_sensor"]'));assert.equal(container.querySelector('[data-um-sensor="maf"]'),null);assert.equal(current.state.t,t);assert.equal(current.selection,'ecu');assert.equal(calls.navigate.length,0);
 });
 await test('purpose and sensor group compose, and empty matches have a working reset',async()=>{
  await change('group','air');assert.equal($('[data-um="empty-sensors"]').hidden,false);assert.equal($('[data-um="sensor-table-wrap"]').hidden,true);
  await click('[data-um-action="clear-filters"]');assert.equal(view.inspect().purpose,'all');assert.equal(view.inspect().group,'all');assert.equal($('[data-um="empty-sensors"]').hidden,true);
  await change('purpose','running_control');await change('group','air');assert.ok($('[data-um-sensor="maf"]'));assert.ok($('[data-um-sensor="map"]'));assert.equal(container.querySelector('[data-um-sensor="crank_sensor"]'),null);
 });
 await test('implemented fallback explanation is available and remains open through live samples',()=>{
  const row=$('[data-um-sensor="maf"]'),detail=row.querySelector('details');assert.ok(detail);detail.open=true;assert.match(detail.textContent,/70%/);assert.match(detail.textContent,/production strategies differ/i);
  current={...current,state:fixture.open};view.update(current);assert.equal($('[data-um-sensor="maf"]').querySelector('details'),detail);assert.equal(detail.open,true);assert.equal(row.querySelector('[data-um-reading]').textContent,'—');assert.equal(row.querySelector('[data-um-quality]').textContent,'Connector open');assert.match(row.querySelector('[data-um-physical]').textContent,/Physical:/);assert.equal(view.inspect().purpose,'running_control');
 });
 await test('fuel level is information with no invented unplug action',async()=>{
  await click('[data-um-unit="cluster"]');assert.equal(view.inspect().purpose,'all');assert.equal(view.inspect().group,'all');const row=$('[data-um-sensor="fuel_level"]');assert.equal(row.dataset.umPurpose,'monitoring');assert.match(row.textContent,/Derived channel/);assert.match(row.textContent,/not a start prerequisite/i);assert.equal(container.querySelector('[data-um-pins="fuel_level"]'),null);assert.ok($('[data-um-plot="fuel_level"]'));
 });
 await test('HVAC unit has its own icon and comfort channels',async()=>{
  assert.ok($('[data-um-unit="hvac"]'));await click('[data-um-unit="hvac"]');assert.ok($('[data-um-purpose-heading="comfort_control"]'));assert.ok($('[data-um-sensor="cabin_temperature"]'));assert.ok($('[data-um-pins="cabin_temperature"]'));assert.equal($('[data-um="purpose"]').querySelectorAll('option').length,2);
 });
 await test('full schematic button uses the selected unit and retains time',async()=>{
  const time=current.state.t;await click('[data-um-action="full-wiring"]');assert.equal(calls.select.at(-1),'hvac');assert.equal(calls.navigate.at(-1),'wiring');assert.equal(current.state.t,time);
 });
 await test('sensor Plot and Pins remain linked after purpose filtering',async()=>{
  await click('[data-um-unit="ecu"]');await change('purpose','start_critical');await click('[data-um-plot="crank_sensor"]');assert.equal(calls.select.at(-1),'signal:vehicle_sensors.crank_sensor.value');assert.equal(calls.navigate.at(-1),'signals');assert.equal(calls.watch.at(-1).id,'vehicle_sensors.crank_sensor.value');
  await click('[data-um-pins="crank_sensor"]');assert.equal(calls.select.at(-1),'socket:crank_sensor_socket');assert.equal(calls.navigate.at(-1),'wiring');assert.equal(view.inspect().purpose,'start_critical');
 });
 await test('disposing the purpose view removes handlers and DOM',()=>{view.dispose();assert.equal(container.children.length,0);assert.equal([...container.listeners.values()].flat().length,0);});
 console.log(JSON.stringify({suite:'unit functional purpose v0.8',passed,failed,scope:'Actual model metadata and parsed-node interactions; no browser layout verification'}));process.exitCode=failed?1:0;
})();
