"""Behavioral contracts for the configured driver-seat plant.

These test causality, interlocks and measurement truth. They do not assert that
the generic calibration reproduces a particular production vehicle.
"""
import json
import math
import unittest

from obdii_lab.vehicle import VEHICLE_CONFIGURATIONS, VehicleSim


class ConfiguredVehicleTests(unittest.TestCase):
    def started(self, configuration="petrol_basic", options=None):
        sim = VehicleSim(configuration, options)
        sim.control("ignition", True)
        sim.control("start")
        sim.advance(1.6, {"brake": .3})
        return sim

    def driving(self, configuration="petrol_basic", seconds=10, options=None):
        sim = self.started(configuration, options)
        sim.control("gear", "D")
        sim.control("parking_brake", False)
        sim.advance(seconds, {"throttle": .5, "brake": 0})
        return sim

    def test_all_presets_begin_parked_off_without_starting_from_pedals(self):
        self.assertEqual({c["id"] for c in VEHICLE_CONFIGURATIONS},
                         {"petrol_basic", "petrol_advanced", "diesel", "hev", "phev", "bev"})
        for config in VEHICLE_CONFIGURATIONS:
            with self.subTest(configuration=config["id"]):
                sim = VehicleSim(config["id"])
                first = sim.snapshot()
                self.assertEqual(first["vehicle"]["start_state"], "off")
                self.assertEqual(first["vehicle"]["selector"], "P")
                self.assertTrue(first["vehicle"]["parking_brake"])
                sim.advance(1, {"throttle": 1})
                snapshot = sim.snapshot()
                self.assertEqual(snapshot["speed_kph"], 0)
                self.assertEqual(snapshot["rpm"], 0)
                self.assertEqual(snapshot["energy"]["fuel_l"], 0)
                self.assertFalse(snapshot["vehicle"]["ready"])
                json.dumps(snapshot, allow_nan=False)

    def test_ignition_on_supplies_diagnostics_but_does_not_start_propulsion(self):
        for config in ("petrol_basic", "diesel", "hev", "bev"):
            with self.subTest(configuration=config):
                sim = VehicleSim(config)
                sim.control("ignition", True)
                sim.advance(2, {"throttle": 1})
                snapshot = sim.snapshot()
                self.assertTrue(snapshot["inputs"]["ignition"])
                self.assertEqual(snapshot["vehicle"]["start_state"], "ignition_on")
                self.assertEqual(snapshot["rpm"], 0)
                self.assertEqual(snapshot["speed_kph"], 0)
                self.assertFalse(snapshot["vehicle"]["ready"])
                if sim.has_hv:
                    self.assertEqual(snapshot["contactor"], "OFF")
                else:
                    self.assertTrue(snapshot["sensors"]["ect_sensor_valid"])

    def test_engine_start_has_a_cranking_interval_and_controls_do_not_tick(self):
        sim = VehicleSim()
        with self.assertRaises(ValueError):
            sim.control("start")
        sim.control("ignition", True)
        sim.control("start")
        self.assertEqual(sim.t, 0)
        self.assertEqual(sim.snapshot()["vehicle"]["start_state"], "cranking")
        sim.advance(.15)
        self.assertGreater(sim.rpm, 100)
        self.assertFalse(sim.snapshot()["engine_running"])
        sim.advance(.95)
        self.assertGreater(sim.rpm, 700)
        self.assertTrue(sim.snapshot()["engine_running"])
        self.assertTrue(sim.snapshot()["vehicle"]["ready"])

    def test_electric_ready_requires_precharge_but_never_starts_an_engine(self):
        sim = VehicleSim("bev")
        sim.control("ignition", True)
        sim.control("start")
        sim.advance(.2)
        self.assertEqual(sim.contactor, "PRECHARGE")
        self.assertFalse(sim.snapshot()["vehicle"]["ready"])
        sim.advance(.8)
        self.assertEqual(sim.contactor, "CLOSED")
        self.assertTrue(sim.snapshot()["vehicle"]["ready"])
        self.assertEqual(sim.rpm, 0)
        self.assertFalse(sim.snapshot()["engine_running"])

    def test_neutral_disconnects_engine_torque_and_drive_uses_actual_ratios(self):
        sim = self.started()
        sim.control("gear", "N")
        sim.control("parking_brake", False)
        sim.advance(5, {"throttle": .75, "brake": 0})
        self.assertLess(sim.v, .01)
        self.assertGreater(sim.rpm, 3000)
        self.assertEqual(sim.engine_power_kw, 0)
        self.assertGreater(sim.energy["fuel_l"], 0)
        sim.control("gear", "D")
        sim.advance(12, {"throttle": .5})
        snapshot = sim.snapshot()
        self.assertGreater(snapshot["speed_kph"], 40)
        self.assertGreaterEqual(snapshot["vehicle"]["gear"], 3)
        self.assertEqual(snapshot["vehicle"]["gear_ratio"], sim.RATIOS[sim.actual_gear - 1])
        # With little converter slip, engine speed follows wheel speed × ratios.
        wheels_rpm = (sim.wheels[0] + sim.wheels[1]) / 2 * 30 / math.pi
        coupled = wheels_rpm * snapshot["vehicle"]["gear_ratio"] * sim.FINAL_DRIVE
        self.assertLess(abs(sim.rpm - coupled), 450)
        self.assertTrue(any(e["source"] == "TRANSMISSION" and "Automatic gear" in e["message"]
                            for e in sim.events))

    def test_park_and_parking_brake_hold_the_stationary_vehicle(self):
        sim = self.started()
        sim.advance(2, {"throttle": 1, "brake": 0})
        self.assertEqual(sim.v, 0)
        sim.advance(0, {"brake": .3})
        sim.control("gear", "D")
        sim.advance(2, {"throttle": 1, "brake": 0})
        self.assertTrue(sim.parking_brake)
        self.assertEqual(sim.v, 0)
        sim.control("parking_brake", False)
        sim.advance(2)
        self.assertGreater(sim.v, 1)

    def test_reverse_has_signed_motion_and_direction_changes_are_interlocked(self):
        for config in ("petrol_basic", "bev"):
            with self.subTest(configuration=config):
                sim = self.started(config)
                sim.control("gear", "R")
                sim.control("parking_brake", False)
                sim.advance(4, {"brake": 0, "throttle": .4})
                snapshot = sim.snapshot()
                self.assertGreater(snapshot["speed_kph"], 5)
                self.assertLess(snapshot["signed_speed_kph"], -5)
                self.assertLess(snapshot["signed_distance_m"], 0)
                self.assertEqual(snapshot["vehicle"]["gear"], "R")
                for gear in ("D", "P"):
                    with self.assertRaises(ValueError):
                        sim.control("gear", gear)
                self.assertEqual(sim.selector, "R")

    def test_drive_and_reverse_require_running_engine_as_well_as_brake(self):
        sim = VehicleSim()
        sim.advance(0, {"brake": .3})
        with self.assertRaises(ValueError):
            sim.control("gear", "D")
        sim.control("ignition", True)
        sim.advance(0, {"brake": 0})
        with self.assertRaises(ValueError):
            sim.control("gear", "D")
        sim.advance(0, {"brake": .3})
        for gear in ("D", "R"):
            with self.assertRaisesRegex(ValueError, "Start the engine"):
                sim.control("gear", gear)
        sim.control("start")
        for gear in ("D", "R"):
            with self.assertRaisesRegex(ValueError, "Start the engine"):
                sim.control("gear", gear)
        self.assertEqual(sim.t, 0)
        self.assertEqual(sim.selector, "P")
        sim.advance(1)
        self.assertTrue(sim.snapshot()["vehicle"]["ready"])
        sim.control("gear", "D")
        self.assertEqual(sim.selector, "D")

    def test_electric_and_hybrid_shift_requires_ready_without_requiring_combustion(self):
        for configuration in ("bev", "hev", "phev"):
            with self.subTest(configuration=configuration):
                sim = VehicleSim(configuration)
                sim.control("ignition", True)
                sim.advance(0, {"brake": .3})
                for gear in ("D", "R"):
                    with self.assertRaisesRegex(ValueError, "READY"):
                        sim.control("gear", gear)
                sim.control("start")
                with self.assertRaisesRegex(ValueError, "READY"):
                    sim.control("gear", "D")
                sim.advance(1)
                self.assertTrue(sim.snapshot()["vehicle"]["ready"])
                self.assertFalse(sim.snapshot()["engine_running"])
                sim.control("gear", "D")
                self.assertEqual(sim.selector, "D")

    def test_stopping_propulsion_coasts_without_teleporting_or_turning_ignition_off(self):
        sim = self.driving()
        speed, distance = sim.v, sim.distance_m
        sim.control("stop")
        self.assertEqual(sim.v, speed)
        self.assertTrue(sim.ignition_on)
        sim.advance(1.5, {"throttle": 0, "brake": 0})
        self.assertGreater(sim.v, speed * .8)
        self.assertLess(sim.v, speed)
        self.assertGreater(sim.distance_m, distance)
        self.assertLess(sim.rpm, 2)
        self.assertFalse(sim.snapshot()["engine_running"])
        with self.assertRaises(ValueError):
            sim.control("ignition", False)
        with self.assertRaises(ValueError):
            sim.control("gear", "P")

    def test_battery_and_engine_installation_are_truthful_in_exports(self):
        ice, bev = self.driving(), self.driving("bev")
        ice_snapshot, ev_snapshot = ice.snapshot(), bev.snapshot()
        self.assertIsNone(ice_snapshot["soc_pct"])
        self.assertIsNone(ice_snapshot["battery_current_a"])
        self.assertEqual(ice_snapshot["module_status"]["BMU"], "NOT INSTALLED")
        self.assertEqual(ice_snapshot["energy"]["battery_discharge_kwh"], 0)
        self.assertGreater(ice_snapshot["energy"]["fuel_l"], 0)
        self.assertIsNone(ev_snapshot["coolant_c"])
        self.assertIsNone(ev_snapshot["vehicle"]["fuel_pct"])
        self.assertEqual(ev_snapshot["module_status"]["ECU"], "NOT INSTALLED")
        self.assertEqual(ev_snapshot["energy"]["fuel_l"], 0)
        self.assertEqual(ev_snapshot["rpm"], 0)
        self.assertEqual(ev_snapshot["fuel_l_h"], 0)
        self.assertGreater(ev_snapshot["energy"]["battery_discharge_kwh"], 0)
        self.assertLess(ev_snapshot["soc_pct"], 80)
        self.assertEqual(ev_snapshot["vehicle"]["gear"], 1)
        for sim, connector in ((ice, "bmu"), (bev, "ect"), (ice, "wheel_fl")):
            with self.assertRaises(ValueError):
                sim.set_connection(connector, False)

    def test_hybrid_battery_sizes_and_diesel_engine_calibration_are_distinct(self):
        hev, phev = self.driving("hev"), self.driving("phev")
        self.assertEqual(phev.p.capacity_ah / hev.p.capacity_ah, 12.5)
        self.assertGreater(60 - hev.snapshot()["soc_pct"], 60 - phev.snapshot()["soc_pct"])
        petrol, diesel = self.started(), self.started("diesel")
        for sim in (petrol, diesel):
            sim.control("gear", "N")
            sim.advance(2, {"throttle": 1, "brake": 0})
        self.assertLess(diesel.rpm, petrol.rpm)
        self.assertLessEqual(diesel.rpm, diesel.configuration["redline_rpm"])
        self.assertNotEqual(diesel.p.fuel_density_kg_l, petrol.p.fuel_density_kg_l)
        self.assertGreater(diesel.fuel_l_h, 0)

    def test_optional_abs_esp_installation_differs_from_enabled_state(self):
        basic = VehicleSim()
        self.assertFalse(basic.snapshot()["vehicle"]["configuration"]["abs_installed"])
        for feature in ("abs_enabled", "esp_enabled"):
            with self.assertRaises(ValueError):
                basic.control(feature, True)
        sim = VehicleSim("petrol_basic", {"abs_installed": True, "esp_installed": True})
        sim.control("abs_enabled", False)
        self.assertFalse(sim.abs_enabled)
        self.assertFalse(sim.esp_enabled)
        self.assertTrue(sim.configuration["abs_installed"])
        sim.control("esp_enabled", True)
        self.assertTrue(sim.abs_enabled)
        sim.control("esp_enabled", False)
        self.assertTrue(sim.abs_enabled)
        self.assertFalse(sim.esp_enabled)
        no_abs = VehicleSim("diesel", {"abs_installed": False})
        self.assertFalse(no_abs.configuration["esp_installed"])
        with self.assertRaises(ValueError):
            VehicleSim("diesel", {"abs_installed": False, "esp_installed": True})

    def test_ect_repair_restores_signal_and_derate_but_retains_dtc_memory(self):
        sim = self.started()
        sim.set_connection("ect", False)
        sim.advance(.8)
        fault = sim.snapshot()
        self.assertIn("P0118", fault["dtcs"])
        self.assertFalse(fault["sensors"]["ect_sensor_valid"])
        self.assertLess(fault["ect_derate_factor"], 1)
        sim.set_connection("ect", True)
        sim.advance(.1)
        repaired = sim.snapshot()
        self.assertTrue(repaired["sensors"]["ect_sensor_valid"])
        self.assertEqual(repaired["ect_derate_factor"], 1)
        self.assertIn("P0118", repaired["dtcs"])
        sim.clear_emissions_dtcs()
        self.assertEqual(sim.snapshot()["dtcs"], [])

    def test_bmu_reconnect_restores_messages_but_requires_ignition_cycle_and_ready(self):
        sim = self.driving("bev", seconds=3)
        sim.set_connection("bmu", False)
        sim.advance(.6)
        self.assertEqual(sim.contactor, "FAULT")
        self.assertFalse(sim.snapshot()["vehicle"]["ready"])
        sim.set_connection("bmu", True)
        sim.advance(.5)
        self.assertEqual(sim.contactor, "FAULT")
        sim.advance(8, {"brake": 1, "throttle": 0})
        self.assertEqual(sim.v, 0)
        sim.control("gear", "P")
        sim.control("ignition", False)
        sim.advance(.1)
        sim.control("ignition", True)
        sim.advance(.5)
        self.assertFalse(sim.snapshot()["vehicle"]["ready"])
        sim.control("start")
        sim.advance(1)
        self.assertEqual(sim.contactor, "CLOSED")
        self.assertTrue(sim.snapshot()["vehicle"]["ready"])

    def test_input_validation_is_atomic_and_options_preserve_shared_presets(self):
        sim = VehicleSim()
        before = sim.snapshot()
        for seconds, inputs in ((-1, {"ignition": True}), (0, {"ignition": True, "throttle": float("nan")}),
                                (0, {"ignition": 0}), (0, []), (0, {"abs_enabled": True})):
            with self.assertRaises(ValueError):
                sim.advance(seconds, inputs)
            self.assertEqual(sim.snapshot(), before)
        custom = VehicleSim("petrol_basic", {"cylinders": 8, "engine_detail": "extended", "can_bitrate": 250000})
        self.assertEqual(custom.configuration["cylinders"], 8)
        self.assertEqual(custom.configuration["can_bitrate"], 250000)
        self.assertEqual(VehicleSim().configuration["cylinders"], 4)
        self.assertEqual(VehicleSim().configuration["can_bitrate"], 500000)
        with self.assertRaises(ValueError):
            VehicleSim("bev", {"cylinders": 4})
        with self.assertRaises(ValueError):
            VehicleSim("petrol_basic", {"can_bitrate": 125000})

    def test_chunking_and_snapshot_reads_do_not_change_plant_trajectory(self):
        whole, chunks = self.started(), self.started()
        for sim in (whole, chunks):
            sim.control("gear", "D")
            sim.control("parking_brake", False)
        whole.advance(3.007, {"throttle": .6, "brake": 0})
        for dt in (1, .333, .001, .7, .973):
            chunks.advance(dt, {"throttle": .6, "brake": 0})
            chunks.snapshot()
            chunks.raw_snapshot()
        self.assertEqual(whole.snapshot(), chunks.snapshot())

    def test_sensor_hook_keeps_raw_state_separate_and_honors_controller_inhibits(self):
        class Bank:
            readings = {"probe": {"value": 5}}
            connections = {"probe": False}
            stored_dtcs = {"P0102"}
            pending_dtcs = {"P0102"}
            module_faults = {"abs": ["WHEEL_FR_SIGNAL_MISSING"]}
            effects = {"engine_inhibit": False, "torque_factor": 0, "abs_inhibit": True, "esp_inhibit": True}
            calls = 0

            def sample(self, snapshot, dt):
                assert "vehicle" in snapshot and "vehicle_sensors" not in snapshot
                assert dt == .01
                self.calls += 1

            def fault_details(self):
                return [{"sensor_id": "probe", "code": "P0102"}]

            def clear_codes(self):
                self.stored_dtcs = set()
                self.pending_dtcs = set()

            def set_connection(self, connection_id, connected):
                self.connections[connection_id] = connected

        sim = self.started("petrol_advanced")
        bank = Bank()
        sim.sensor_bank = bank
        sim.control("gear", "D")
        sim.control("parking_brake", False)
        sim.advance(1, {"throttle": 1, "brake": 0})
        self.assertEqual(bank.calls, 100)
        self.assertEqual(sim.v, 0)
        snapshot = sim.snapshot()
        self.assertIn("P0102", snapshot["dtcs"])
        self.assertFalse(snapshot["connections"]["probe"])
        self.assertTrue(snapshot["vehicle"]["abs_inhibited"])
        self.assertFalse(snapshot["abs_active"])
        self.assertEqual(snapshot["module_status"]["ABS_ESP"], "SIGNAL FAULT")
        self.assertEqual(snapshot["sensor_dtcs"]["modules"], bank.module_faults)
        self.assertEqual(bank.calls, 100)
        sim.clear_emissions_dtcs()
        self.assertEqual(sim.snapshot()["dtcs"], [])
        bank.effects = {"engine_inhibit": True, "torque_factor": 0}
        sim.advance(.1)
        self.assertFalse(sim.snapshot()["engine_running"])


if __name__ == "__main__":
    unittest.main()
