/* Exercise the actual application shell while its first vehicle request is pending. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const nodes=new Map();
function node(selector){if(!nodes.has(selector))nodes.set(selector,{value:'',classList:{toggle(){}},setAttribute(){},addEventListener(){}});return nodes.get(selector);}
let languageChanged,setupUpdates=0;
const loading={error:'',workflow:{stage:'vehicle',complete:false},view:'setup',state:undefined,systems:{units:[],sensors:[]},catalog:{},signals:[],selection:'overview'};
const session={subscribe(fn){this.listener=fn;},initialize(){this.listener(loading);return new Promise(()=>{});}};
const view={create:()=>({update(){setupUpdates++;},setVisible(){},setServiceInputEnabled(){},resize(){}})};
const window={AppModel:{escape:String,resolveSelection:()=>({componentId:'overview'})},AppSession:{create:()=>session},
 AppI18n:{subscribe(fn){languageChanged=fn;}},addEventListener(){},VehicleMonitor:{create:()=>({setVisible(){}})}};
for(const name of ['SetupView','CockpitView','UnitMapView','LiveDataView','DiagnosisView','ScannerView','ConnectionView','LocationsView'])window[name]=view;
const document={querySelector:node,querySelectorAll:()=>[],addEventListener(){}};
const context={window,document,console,Promise};vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'web/application.js'),'utf8'),context,{filename:'application.js'});
assert.equal(setupUpdates,1);
assert.doesNotThrow(()=>languageChanged(),'Initial language notification must wait for the first vehicle state.');
assert.equal(setupUpdates,1,'Language change does not initialize a second vehicle or rerender setup.');
loading.state={vehicle:{configuration:{id:'petrol_basic'}}};
loading.systems.units=[{id:'ecu',label:'Engine ECU',group:'Engine',description:'Engine control unit'}];
assert.doesNotThrow(()=>languageChanged());
assert.match(node('#system-tree').innerHTML,/Engine ECU/,'Language changes render the component tree once state exists.');
console.log('PASS: startup language notification tolerates the pending vehicle request and renders normally after state arrives.');
