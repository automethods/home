/* Configured vehicle geometry uses actual model/network fixtures and the GLB renderer.
 * This does not verify browser layout or GPU pixels. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
let now=0; const frames=[],events={};
const context2d=new Proxy({createLinearGradient:()=>({addColorStop(){}})}, {get:(target,key)=>key in target?target[key]:()=>{}});
class Element {
  constructor(){this.children=[];this.map=new Map();this.events={};this.style={};this.dataset={};this.classList={add(){},remove(){},toggle(){}};this.clientWidth=660;this.clientHeight=330;this.width=660;this.height=330;this.hidden=false;this.textContent='';}
  querySelector(selector){if(!this.map.has(selector))this.map.set(selector,new Element());return this.map.get(selector);}
  set innerHTML(value){this.html=value;}
  setAttribute(){}
  getContext(kind){return kind==='2d'?context2d:null;}
  addEventListener(type,fn){this.events[type]=fn;}
  append(element){this.children.push(element);}
  replaceChildren(){this.children=[];}
  getBoundingClientRect(){return {left:0,top:0,width:660,height:330};}
  get offsetWidth(){return 100;}
}
const window={devicePixelRatio:1,LabUI:{isRunning:()=>true},addEventListener(type,fn){events[type]=fn;}};
const context=vm.createContext({window,document:{createElement:()=>new Element()},ArrayBuffer,Float32Array,Uint32Array,DataView,TextDecoder,Map,Set,AbortController,console,
  performance:{now:()=>now},requestAnimationFrame:fn=>frames.push(fn),
  fetch:async url=>{const buffer=fs.readFileSync(root+url);return {ok:true,arrayBuffer:async()=>buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.byteLength),json:async()=>JSON.parse(buffer)};}});
vm.runInContext(fs.readFileSync(path.join(root,'web/vehicle.js'),'utf8'),context);
const API=window.VehicleView;
function frame(time){now=time;const pending=frames.splice(0);for(const fn of pending)fn(time);}
const state=(t,measurement=36)=>({t,profile:'phev',wheel_speeds_kph:[36,36,36,36],inputs:{ignition:true},connections:{},sensors:{wheel_speeds_kph:[measurement,36,36,36]}});

const fixtureRun=spawnSync('python3',['-c',`
import json
from obdii_lab.server import Lab
fixtures={}
for name,configuration,connection in [('petrol','petrol_basic',None),('phev','phev',None),('bev','bev',None),('ecu_open','phev','unit_ecu'),('bmu_open','phev','bmu')]:
 lab=Lab();lab.set_vehicle(configuration)
 if connection:lab.sim.set_connection(connection,False)
 result=lab.state();fixtures[name]={'state':result['state'],'network':result['network'],'catalog':lab.catalog()}
print(json.dumps(fixtures,allow_nan=False))
`],{cwd:root,encoding:'utf8',maxBuffer:20*1024*1024});
assert.equal(fixtureRun.status,0,fixtureRun.stderr);const fixtures=JSON.parse(fixtureRun.stdout);
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
(async()=>{
 const container=new Element(),view=API.create(container,{locator:true,theme:'dark'});
 await new Promise(resolve=>setImmediate(resolve));frame(0);
 const update=key=>{const f=fixtures[key];view.update(f.state,f.network,f.catalog);frame(now+20);return view.inspect();};
 const cutaway=()=>{container.querySelector('[data-action="cutaway"]').events.click();frame(now+20);};
 const present=(inspection,id)=>inspection.renderedComponents.includes(id);
 const retainedBodyAndWheels=inspection=>{assert.ok(inspection.bodyMeshes>0,'Body shell remains in the draw list');for(const id of ['wheel_fl','wheel_fr','wheel_rl','wheel_rr'])assert.ok(present(inspection,id),'Physical wheel remains: '+id);};
 await test('Basic petrol cutaway omits unfitted traction hardware, labels and harnesses',()=>{update('petrol');cutaway();const inspected=view.inspect();retainedBodyAndWheels(inspected);for(const id of ['battery','bmu','abs']){assert.equal(present(inspected,id),false,id+' geometry is omitted');assert.equal(inspected.shownParts.includes(id),false,id+' part chip is hidden');assert.equal(inspected.shownLabels.includes(id),false,id+' location label is hidden');}assert.ok(present(inspected,'engine'));assert.ok(present(inspected,'ecu'));assert.equal(inspected.shownWires.some(id=>id.startsWith('bmu_')),false);});
 await test('Selecting PHEV restores its fitted traction hardware in the same imported geometry',()=>{const inspected=update('phev');retainedBodyAndWheels(inspected);for(const id of ['battery','bmu','abs']){assert.ok(present(inspected,id),id+' geometry is present');assert.ok(inspected.shownParts.includes(id),id+' part chip is available');}assert.ok(inspected.shownWires.includes('bmu_can_h'));});
 await test('A disconnected but fitted ECU remains visible and is fault-marked',()=>{const inspected=update('ecu_open');assert.equal(fixtures.ecu_open.network.components.ecu.available,false);assert.ok(present(inspected,'ecu'));assert.ok(inspected.shownParts.includes('ecu'));assert.ok(inspected.inactiveComponents.includes('ecu'));view.select('ecu');assert.match(container.querySelector('.vv-selection').querySelector('span').textContent,/Unit disconnected/);assert.doesNotMatch(container.querySelector('.vv-selection').querySelector('span').textContent,/Not fitted/);});
 await test('An unplugged fitted BMU stays in the cutaway with its interrupted CAN branch',()=>{const inspected=update('bmu_open');assert.equal(fixtures.bmu_open.network.wires.bmu_can_h.connected,false);assert.ok(present(inspected,'bmu'));assert.ok(inspected.shownParts.includes('bmu'));assert.ok(inspected.shownWires.includes('bmu_can_h'));view.select('bmu');assert.match(container.querySelector('.vv-selection').querySelector('span').textContent,/connector open/);});
 await test('BEV removes combustion hardware while retaining battery, body and physical wheels',()=>{const inspected=update('bev');retainedBodyAndWheels(inspected);for(const id of ['engine','ecu','coolant_sensor']){assert.equal(present(inspected,id),false);assert.equal(inspected.shownParts.includes(id),false);assert.equal(inspected.shownLabels.includes(id),false);}assert.ok(present(inspected,'battery'));assert.ok(present(inspected,'bmu'));});
 await test('Local model and binding imports preserve configuration visibility without hiding body or wheels',async()=>{update('petrol');const bytes=fs.readFileSync(path.join(root,'web/models/training_vehicle.glb'));await view.loadModel(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'Imported training model.glb',false);view.loadBindings(JSON.parse(fs.readFileSync(path.join(root,'web/models/vehicle_bindings.json'))));cutaway();let inspected=view.inspect();retainedBodyAndWheels(inspected);assert.equal(present(inspected,'battery'),false);assert.equal(present(inspected,'bmu'),false);inspected=update('phev');assert.ok(present(inspected,'battery'));assert.ok(present(inspected,'bmu'));inspected=update('petrol');assert.equal(present(inspected,'battery'),false);assert.equal(present(inspected,'bmu'),false);retainedBodyAndWheels(inspected);});
 view.dispose();const result={suite:'Configured 3D component visibility v0.9.3',passed,failed:0,scope:'Actual Python configuration/network fixtures, GLB parsing, shared geometry draw list and CPU Canvas fallback. WebGL uses the same filtered draw list; GPU pixels/native layout are not exercised.'};if(process.argv[2])fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2));console.log(JSON.stringify(result));
})().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
