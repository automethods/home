#!/usr/bin/env python3
"""Optional Node-built-in checks of workbench helpers against real model data.

Run: python3 tests/run_workbench_contract.py
No Node package installation is needed. Node is optional and is not required to
launch or use the simulator. These checks are not browser/DOM or pixel tests.
"""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from obdii_lab.core import Sim
from obdii_lab.network import network_catalog, observe_network


def capture(sim: Sim) -> dict:
    state = sim.snapshot()
    return {"state": state, "network": observe_network(state), "history": list(sim.history)}


def fixtures() -> dict:
    scenes = {}
    ect = Sim(config={"initial_coolant_c": 25, "ambient_c": 25})
    ect.advance(.4, {"throttle": .2})
    scenes["healthy"] = capture(ect)
    ect.set_connection("ect", False)
    ect.advance(.1)
    scenes["ect_checking"] = capture(ect)
    ect.advance(.22)
    scenes["ect_fallback"] = capture(ect)
    ect.advance(.3)
    ect.set_connection("ect", True)
    ect.advance(.1)
    scenes["ect_repaired"] = capture(ect)

    off = Sim()
    off.advance(.1, {"ignition": False})
    scenes["unpowered"] = capture(off)

    legacy_ect = Sim()
    legacy_ect.advance(.1, {"fault": "ect_open"})
    scenes["legacy_ect"] = capture(legacy_ect)

    dlc = Sim()
    dlc.advance(.4, {"throttle": .2})
    dlc.set_connection("dlc", False)
    dlc.advance(.3)
    scenes["dlc_open"] = capture(dlc)

    bmu = Sim(profile="phev")
    bmu.advance(1, {"throttle": .2})
    bmu.set_connection("bmu", False)
    bmu.advance(.5)
    scenes["bmu_open"] = capture(bmu)

    wheel = Sim(profile="braking", config={"initial_speed_kph": 70})
    wheel.advance(.4)
    wheel.set_connection("wheel_fl", False)
    wheel.advance(.2, {"brake": .2})
    scenes["wheel_missing"] = capture(wheel)

    legacy_wheel = Sim(profile="braking", config={"initial_speed_kph": 60})
    legacy_wheel.advance(.2, {"fault": "wheel_fl_dropout"})
    scenes["legacy_wheel"] = capture(legacy_wheel)
    return {"catalog": network_catalog(), "scenes": scenes}


def main() -> int:
    node = shutil.which("node")
    if node is None:
        print("SKIP: optional workbench helper checks need Node.js. The simulator itself requires only Python.")
        return 0
    # A scoped temporary fixture avoids nonblocking stdin differences between
    # Node and managed terminals. It is removed when this context exits.
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", suffix=".json", prefix="workbench-contract-", dir=ROOT.parent) as fixture_file:
        json.dump(fixtures(), fixture_file, allow_nan=False)
        fixture_file.flush()
        completed = subprocess.run(
            [node, str(ROOT / "tests" / "test_workbench_contract.cjs"), fixture_file.name],
            text=True, cwd=ROOT, check=False,
        )
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
