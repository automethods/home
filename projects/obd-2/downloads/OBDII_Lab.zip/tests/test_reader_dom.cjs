/* Optional learning-book DOM/API checks against a disposable Python model.
 * Uses jsdom for events and content; Canvas drawing is mocked, not pixel-tested.
 */
const assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require('jsdom');
const base=process.argv[2];
if(!base)throw new Error('Supply the disposable local server URL.');
const errors=[],requests=[];
const vc=new VirtualConsole();
vc.on('jsdomError',e=>{if(!e.message.includes('navigation (except hash changes)'))errors.push(e.message);});
vc.on('error',e=>errors.push(String(e)));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function main(){
 const dom=await JSDOM.fromURL(base,{resources:'usable',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.fetch=async(path,options)=>{requests.push({path,body:options?.body});return fetch(new URL(path,base),options);};
  w.HTMLElement.prototype.scrollIntoView=function(){};
  w.HTMLCanvasElement.prototype.getBoundingClientRect=()=>({width:640,height:120,left:0,top:0,right:640,bottom:120});
  const context={scale(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fill(){},closePath(){},fillText(){},setLineDash(){},arc(){},createLinearGradient(){return {addColorStop(){}};}};
  w.HTMLCanvasElement.prototype.getContext=type=>type==='webgl2'?null:new Proxy(context,{get:(target,key)=>target[key]||(()=>{})});
  w.URL.createObjectURL=()=> 'blob:reader-test';w.URL.revokeObjectURL=()=>{};
 }});
 const w=dom.window,d=w.document,$=s=>d.querySelector(s);
 async function until(test,why){const started=Date.now();while(!test()){if(Date.now()-started>9000)throw new Error('Timed out '+why+' '+errors.join('|'));await sleep(10);}}
 async function action(name){const b=$('[data-reader-action="'+name+'"]');assert.ok(b,'button '+name);assert.equal(b.disabled,false,name+' enabled');b.click();await until(()=>!b.disabled&&!w.LabUI.isBusy(),name);await sleep(15);}
 async function fault(name){const b=$('[data-reader-fault="'+name+'"]');assert.equal(b.disabled,false);b.click();await until(()=>!b.disabled&&!w.LabUI.isBusy(),'fault '+name);await sleep(15);}
 function chapter(id){$('[data-reader-chapter="'+id+'"]').click();}
 const state=()=>w.LabUI.state();
 try{
  await until(()=>w.LabUI?.state()&&d.querySelectorAll('[data-reader-chapter]').length===10&&d.querySelectorAll('.lr-document').length===12&&w.Workbench?.ready(),'reader ready with complete theory');
  $('#show-learning').click();assert.equal($('#learning-reader').hidden,false);assert.equal($('#instrument-workspace').hidden,true);
  assert.equal($('.lr-technical').open,false,'electronics start closed');assert.equal($('.lr-bytes').open,false);
  assert.ok($('.lr-story-heading').textContent.length>8);assert.ok($('.lr-narrative').textContent.includes('Why this happens'));
  assert.equal(d.querySelectorAll('.lr-story-node').length,4);
  const unchanged=state().t;chapter('sensor_fault');assert.equal(state().t,unchanged,'reading does not reset model');
  await action('start');assert.equal(state().profile,'engine');assert.equal(state().scenario,'manual');assert.equal(state().t,1.1);
  assert.equal(state().sensors.ect_sensor_valid,true);
  await fault('ect_open');assert.equal(state().sensors.ect_sensor_valid,false);assert.equal(state().dtcs.length,0,'debounce before warning');
  assert.match($('.lr-story').textContent,/check|observ|unusable|signal/i);
  await action('step');await action('step');assert.equal(state().sensors.ect_used_c,80,'fallback after detection');
  await action('step');await action('step');await action('step');await action('step');
  assert.deepEqual([...state().dtcs],['P0118']);assert.match($('.lr-story').textContent,/substitute|warning|remember|confirmed/i);
  await action('read-warnings');const plain=$('.lr-diagnostic-text').textContent;
  assert.match(plain,/coolant|temperature/i);assert.doesNotMatch(plain,/43 01|0x|7DF/,'primary diagnostic answer has no hex');
  assert.match($('.lr-bytes').textContent,/43 01 01 18/,'optional exact message remains available');
  await action('repair');assert.equal(state().sensors.ect_sensor_valid,true);assert.deepEqual([...state().dtcs],['P0118']);assert.match($('.lr-story').textContent,/remember|stored/i);
  await action('clear-warnings');assert.equal(state().dtcs.length,0);
  chapter('engine');await action('start');const t=state().t;const pedal=$('#lr-accelerator');assert.ok(pedal);pedal.value='35';pedal.dispatchEvent(new w.Event('input',{bubbles:true}));await until(()=>state().t>t&&!w.LabUI.isBusy(),'pedal update');assert.equal(state().inputs.throttle,.35);
  await action('play');await until(()=>state().t>t+.2,'playback');$('#show-instruments').click();await until(()=>!w.LabUI.isBusy(),'view pause');const paused=state().t;await sleep(450);assert.equal(state().t,paused,'switching views pauses reader');$('#show-learning').click();
  chapter('wheel_fault');await action('start');await fault('wheel_fl_dropout');
  assert.equal(state().sensors.wheel_speeds_kph[0],null);assert.ok(state().wheel_speeds_kph[0]>0);assert.equal(state().abs_active,false);assert.equal(state().esp_active,false);assert.match($('.lr-story').textContent,/friction|ordinary braking/i);
  await action('repair');assert.ok(state().sensors.wheel_speeds_kph[0]>=0);
  chapter('battery');await action('start');await fault('bmu_timeout');await action('advance-five');assert.equal(state().contactor,'FAULT');assert.match($('.lr-story').textContent,/old|fresh|stale|stopped/i);
  await action('repair');assert.match($('.lr-repair-note').textContent,/restart|off|reset/i);await action('restart');assert.notEqual(state().contactor,'FAULT');
  const beforeReference=state().t;$('.lr-reference-link').click();assert.ok($('.lr-article').classList.contains('lr-reference-content'));assert.ok($('.lr-article').textContent.length>3000);assert.equal(state().t,beforeReference);
  $('[data-reader-nav="glossary"]').click();assert.equal(d.querySelectorAll('.lr-glossary-entry').length,30);assert.equal(state().t,beforeReference);
  assert.equal(errors.length,0,errors.join('\n'));
  console.log(JSON.stringify({status:'PASS',checks:['default learning book','10 chapters and 10 full theory documents','reading preserves state','plain-language live explanation','ECT disconnect/debounce/substitution/confirmation','human-readable diagnostic answer with optional bytes','repair versus stored memory','manual pedal affects live model','playback and view-change pause','wheel sensor loss versus physical wheel motion','BMU timeout and restart after repair','full reference and 30-word glossary'],requests:requests.length,console_errors:errors.length},null,2));
 }finally{w.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
