"""Configured vehicle identity must not inherit labels from the hybrid core."""
import unittest

from obdii_lab.network import network_catalog
from obdii_lab.server import Lab


class VehicleIdentityTests(unittest.TestCase):
    def test_configured_unit_identity_replaces_legacy_component_labels(self):
        lab = Lab()
        for configuration in ("petrol_basic", "petrol_advanced", "diesel", "hev", "phev", "bev"):
            with self.subTest(configuration=configuration):
                lab.set_vehicle(configuration)
                components = {item["id"]: item for item in lab.catalog()["components"]}
                for unit in lab.systems()["units"]:
                    component = components[unit["id"]]
                    self.assertEqual(component["label"], unit["label"])
                    self.assertEqual(component["description"], unit["description"])
                    self.assertEqual(component["installed"], unit["installed"])
                self.assertEqual(components["supervisor"]["label"], "Vehicle controller")

    def test_identity_update_keeps_existing_geometry_and_signal_bindings(self):
        original = network_catalog()
        lab = Lab()
        lab.set_vehicle("petrol_basic")
        configured = {item["id"]: item for item in lab.catalog()["components"]}
        for component in original["components"]:
            with self.subTest(component=component["id"]):
                resolved = configured[component["id"]]
                for field in ("position", "bindings", "kind"):
                    self.assertEqual(resolved[field], component[field])
        self.assertEqual(next(c for c in original["components"] if c["id"] == "supervisor")["label"], "Hybrid supervisor")

    def test_ice_has_no_hv_hardware_while_hev_and_phev_remain_distinct(self):
        lab = Lab()
        for configuration, electric, plug in (("petrol_basic", False, False), ("hev", True, False), ("phev", True, True)):
            with self.subTest(configuration=configuration):
                lab.set_vehicle(configuration)
                components = {item["id"]: item for item in lab.catalog()["components"]}
                for identifier in ("battery", "bmu", "inverter"):
                    self.assertEqual(components[identifier]["installed"], electric)
                self.assertEqual(components["charging"]["installed"], plug)
                snapshot = lab.snapshot()
                self.assertEqual(snapshot["vehicle"]["configuration"]["id"], configuration)
                self.assertEqual(snapshot["profile"], "phev")  # Core compatibility, not vehicle identity.
                self.assertEqual(next(s for s in lab.signal_catalog() if s["id"] == "engine_requested")["source"], "Engine control")


if __name__ == "__main__":
    unittest.main()
