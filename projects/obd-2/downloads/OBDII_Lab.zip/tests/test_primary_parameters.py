"""Primary ECU/gearbox probes use existing plant values and explicit units."""
import json
import unittest
from obdii_lab.server import Lab


class PrimaryParameterTests(unittest.TestCase):
    def vehicle(self, configuration='petrol_basic', options=None):
        lab=Lab();lab.set_vehicle(configuration,options or {})
        return lab

    def start(self,lab,manual=False):
        sim=lab.sim
        sim.control('ignition',True)
        if manual:sim.advance(0,{'clutch':1})
        sim.control('start');sim.advance(1,{'brake':.3})
        return sim

    def test_idle_keeps_hourly_consumption_and_has_no_distance_consumption(self):
        lab=self.vehicle();sim=self.start(lab);s=sim.snapshot()
        self.assertGreater(s['fuel_l_h'],0)
        self.assertIsNone(s['fuel_l_100km'])
        values=lab.signals(s)
        self.assertEqual(values['fuel_l_100km']['validity'],'unavailable')
        self.assertEqual(values['fuel_l_h']['value'],s['fuel_l_h'])
        json.dumps(s,allow_nan=False)

    def test_moving_consumption_uses_same_flow_and_speed_in_both_directions(self):
        for selector in ['D','R']:
            with self.subTest(selector=selector):
                lab=self.vehicle();sim=self.start(lab);sim.control('gear',selector);sim.control('parking_brake',False)
                s=sim.advance(3,{'throttle':.4,'brake':0})
                self.assertGreater(s['speed_kph'],1)
                self.assertAlmostEqual(s['fuel_l_100km'],s['fuel_l_h']*100/s['speed_kph'])
                self.assertEqual(lab.signals(s)['fuel_l_100km']['value'],s['fuel_l_100km'])
                if selector=='R':self.assertLess(s['signed_speed_kph'],0)

    def test_fuel_free_coasting_is_zero_not_an_unavailable_value(self):
        lab=self.vehicle();sim=self.start(lab);sim.control('gear','D');sim.control('parking_brake',False)
        sim.advance(3,{'throttle':.4,'brake':0});sim.control('stop');s=sim.advance(.2,{'throttle':0})
        self.assertGreater(s['speed_kph'],1)
        self.assertEqual(s['fuel_l_h'],0)
        self.assertEqual(s['fuel_l_100km'],0)
        self.assertEqual(lab.signals(s)['fuel_l_100km']['validity'],'valid')

    def test_electric_vehicle_does_not_expose_fuel_or_manual_clutch_values(self):
        lab=self.vehicle('bev');signals={s['id']:s for s in lab.signal_catalog()}
        self.assertFalse(signals['fuel_l_100km']['installed'])
        self.assertFalse(signals['vehicle.clutch_coupling']['installed'])
        self.assertIsNone(lab.signals(lab.snapshot())['fuel_l_100km']['value'])

    def test_automatic_current_gear_and_ratio_follow_the_actual_shift(self):
        lab=self.vehicle();sim=self.start(lab)
        self.assertEqual(lab.signals(sim.snapshot())['vehicle.gear']['value'],'P')
        sim.control('gear','D');sim.control('parking_brake',False)
        s=sim.advance(15,{'throttle':.5,'brake':0});signals=lab.signals(s)
        self.assertGreater(s['vehicle']['gear'],1)
        self.assertEqual(signals['vehicle.gear']['value'],sim.actual_gear)
        self.assertEqual(signals['vehicle.gear_ratio']['value'],sim.RATIOS[sim.actual_gear-1])
        self.assertFalse(signals['vehicle.clutch_torque_nm']['installed'])

    def test_manual_gear_and_clutch_values_are_available_only_when_fitted(self):
        lab=self.vehicle(options={'transmission_type':'manual_6'});sim=self.start(lab,manual=True)
        sim.control('gear','2');s=sim.snapshot();signals=lab.signals(s)
        self.assertEqual(signals['vehicle.gear']['value'],2)
        self.assertEqual(signals['vehicle.gear_ratio']['value'],sim.RATIOS[1])
        self.assertTrue(signals['vehicle.clutch_coupling']['installed'])
        self.assertIsNotNone(signals['vehicle.clutch_torque_nm']['value'])
        hybrid=self.vehicle('hev')
        self.assertFalse(next(s for s in hybrid.signal_catalog() if s['id']=='vehicle.gear_ratio')['installed'])


if __name__=='__main__':unittest.main()
