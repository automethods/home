/* Real Session/ScannerView over the real API handlers using JSON lines instead
 * of sockets. The parsed DOM checks interactions; browser layout is separate. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const backend=spawn('python3',['-u','tests/http_stdio.py'],{cwd:root,env:{...process.env,PYTHONPATH:root},stdio:['pipe','pipe','inherit']});
const waiting=[],requests=[],timers=new Map();let timer=0;
readline.createInterface({input:backend.stdout}).on('line',line=>waiting.shift()?.(JSON.parse(line)));
const api=(url,init={})=>new Promise(resolve=>{const body=init.body?JSON.parse(init.body):undefined;requests.push({url,body});waiting.push(r=>resolve({ok:r.status<400,status:r.status,json:async()=>r.data}));backend.stdin.write(JSON.stringify({path:url,body})+'\n');});
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8'),begin=original.indexOf('const decodeEntities='),end=original.indexOf('const elements=new Node(');
const window={fetch:api,dispatchEvent(){}},sandbox={window,document:{activeElement:null},assert,console,CustomEvent:class{constructor(type,options){this.type=type;Object.assign(this,options);}},setTimeout(fn){const id=++timer;timers.set(id,fn);return id;},clearTimeout:id=>timers.delete(id),setInterval(){throw Error('One simulation clock only');}};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.TestNode=Node;',sandbox);
const Node=sandbox.TestNode,originalMatches=Node.prototype.matches;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{const attrs=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];return originalMatches.call(this,part.replace(/\[[^\]]+\]/g,'')||'*')&&attrs.every(match=>this.hasAttribute(match[1])&&(match[2]===undefined||this.getAttribute(match[1])===match[2]));});};
const document=new Node('document');document.hidden=false;document.visibilityState='visible';document.activeElement=null;sandbox.document=document;window.document=document;
const windowEvents=new Map();window.addEventListener=(name,fn)=>{if(!windowEvents.has(name))windowEvents.set(name,[]);windowEvents.get(name).push(fn);};window.removeEventListener=(name,fn)=>windowEvents.set(name,(windowEvents.get(name)||[]).filter(f=>f!==fn));window.dispatchEvent=event=>{for(const fn of windowEvents.get(event.type)||[])fn(event);};
const html=Object.getOwnPropertyDescriptor(Node.prototype,'innerHTML');Object.defineProperty(Node.prototype,'innerHTML',{get:html.get,set(value){if(this.tagName==='SELECT')this._value=undefined;html.set.call(this,value);}});
for(const file of ['session.js','protocols.js','scan-tool.js','cockpit.js','vehicle-monitor.js'])vm.runInContext(fs.readFileSync(path.join(root,'web',file),'utf8'),sandbox,{filename:file});
const session=window.AppSession.create(),container=new Node('main');
const view=window.ScannerView.create(container,{
 onScanner:(action,settings)=>session.scannerAction(action,settings),onRequest:(payload,canId)=>session.request(payload,canId),onPoll:settings=>session.setScannerPolling(settings),
 onLiveVisibility:visible=>{session.scanLive.visible=visible;},onReadLive:()=>session.readLiveData(),onLiveChange:settings=>{session.setLiveData(settings);if(session.liveDataActive())return session.readLiveData();}
});
const cockpitRoot=new Node('main'),monitorRoot=new Node('section');
const cockpit=window.CockpitView.create(cockpitRoot,{onInputs:inputs=>session.setInputs(inputs),onManualOverride:()=>session.overrideCycle()});
cockpit.setVisible(false);cockpit.setServiceInputEnabled(true);
const monitor=window.VehicleMonitor.create(monitorRoot,{bindPedals:(controls,active)=>cockpit.bindPedals(controls,'service',active)});monitor.setVisible(true);
const unsubscribeControls=session.subscribe(ctx=>{cockpit.update(ctx);monitor.update(ctx);});
const $=selector=>{const node=container.querySelector(selector);assert.ok(node,selector);return node;};
const flush=async()=>{for(let i=0;i<5;i++)await new Promise(resolve=>setImmediate(resolve));await session.command;};
const click=async selector=>{const target=$(selector);assert.equal(target.disabled,false,selector+' is enabled');await container.dispatchEvent({type:'click',target});await flush();};
const change=async(selector,value)=>{const target=$(selector);target.value=value;await target.dispatchEvent({type:'change'});await flush();};
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
(async()=>{try{
 await session.initialize();await session.commitSetup('petrol_advanced',{},session.testSettings);session.enterWorkspace('service');
 const unsubscribe=session.subscribe(ctx=>view.update(ctx));view.update(session.context());
 await session.control('ignition',true);session.setRunning(false);await session.advance(.1);
 await test('vehicle discovery is independent of a unit connection',async()=>{
  await click('[data-sc-tab="faults"]');assert.equal($('[data-sc="unit-picker"]').hidden,true);assert.equal($('[data-sc-action="connect"]').hidden,true);
  assert.equal(session.result.scanner.connected,false);await click('[data-sc-action="scan"]');assert.ok(session.scanReport.modules.filter(m=>m.installed).length>1);
  assert.equal(session.result.scanner.connected,false);assert.ok($('[data-sc-connect="transmission"]'));assert.equal(Object.keys(session.unitReports).length,0);
 });
 await test('connecting from discovery opens only that named module',async()=>{
  const report=session.scanReport;await click('[data-sc-connect="transmission"]');assert.equal(view.inspect().activeTab,'data');assert.equal(session.result.scanner.module_id,'transmission');
  assert.equal(session.scanReport,report);assert.deepEqual([...session.unitReports.transmission.modules].map(m=>m.id),['transmission']);
  assert.equal($('[data-sc-action="connect"]').textContent,'Connected to 6-speed automatic');assert.equal($('[data-sc-action="connect"]').disabled,true);assert.equal(container.querySelector('[data-sc-parameter="obd.rpm"]'),null);
 });
 await test('selected fault reads preserve the whole-vehicle discovery report',async()=>{
  await change('[data-sc="module"]','ecu');assert.equal($('[data-sc-action="connect"]').textContent,'Connect to Engine ECU');await click('[data-sc-action="connect"]');
  assert.deepEqual([...session.unitReports.ecu.modules].map(m=>m.id),['ecu']);const report=session.scanReport;
  await click('[data-sc-tab="unit"]');await click('[data-sc-action="scan-unit"]');assert.equal(requests.at(-1).body.action,'faults');assert.equal(session.scanReport,report);
  assert.equal($('[data-sc="unit-faults"]').textContent.includes('6-speed'),false);
 });
 await test('live cards use the chosen refresh interval on the shared clock',async()=>{
  await click('[data-sc-tab="data"]');await change('[data-sc="live-interval"]','1');assert.equal(session.scanLive.interval,1);
  const count=()=>requests.filter(r=>r.body?.action==='read').length,before=count();await session.advance(.5);assert.equal(count(),before);await session.advance(.5);assert.equal(count(),before+1);
  await session.pollScanner();assert.equal(count(),before+1);assert.match($('[data-sc="live-cadence"]').textContent,/every 1 s/);
 });
 await test('Read starts repeated numeric reads, with no Read once label',async()=>{
  assert.equal($('[data-sc-action="send"]').textContent,'Read');const rpm=session.definitions.services.find(s=>s.request_hex==='01 0C');await change('[data-sc="service"]',rpm.id);
  await $('[data-sc="request-form"]').dispatchEvent({type:'submit'});await flush();assert.equal(session.scanPolling.enabled,true);
  const count=()=>requests.filter(r=>r.url==='/api/diagnostic').length,before=count();await session.advance(1);assert.equal(count(),before+1);await session.pollScanner();assert.equal(count(),before+1);
  assert.equal(timers.size,0,'Reading owns no independent wall-clock timer');
 });
 await test('identity/services cannot accidentally repeat state-changing requests',async()=>{
  const vin=session.definitions.services.find(s=>s.request_hex==='22 F1 90');await change('[data-sc="service"]',vin.id);assert.equal(session.scanPolling.enabled,false);
  assert.equal($('[data-sc="poll-enabled"]').disabled,true);await $('[data-sc="request-form"]').dispatchEvent({type:'submit'});await flush();assert.equal(session.scanPolling.enabled,false);
 });
 await test('vehicle discovery cannot replace the selected parameter response with a fault reply',async()=>{
  await session.request('01 0C');const reading=session.diagnostic;await click('[data-sc-tab="faults"]');await click('[data-sc-action="scan"]');assert.equal(session.diagnostic,reading);assert.equal(session.diagnostic.request_hex,'01 0C');
 });
 unsubscribeControls();monitor.dispose();cockpit.dispose();unsubscribe();view.dispose();session.dispose();
 console.log(JSON.stringify({suite:'scanner connection, discovery and continuous reads v0.9.5',passed,failed:0}));
 }catch(error){console.error(error.stack);process.exitCode=1;}finally{session.dispose();backend.kill();}})();
