"""Optional DOM/API integration check, with an isolated disposable server.

Requires Node20+ and jsdom26.1.0 for development checks only. Install jsdom in
the project root with `npm install --no-save jsdom@26.1.0`, or set NODE_PATH to
an existing dependency directory. The simulator itself needs neither package.
"""
from pathlib import Path
import subprocess
import sys
import threading

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from obdii_lab.server import create_server


def main():
    server = create_server(0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        for test in ("test_ui_dom.cjs", "test_reader_dom.cjs"):
            server.lab.reset("engine", "engine_warmup", {})
            result = subprocess.run(
                ["node", str(ROOT / "tests" / test),
                 f"http://127.0.0.1:{server.server_port}"],
                cwd=ROOT, timeout=45,
            )
            if result.returncode:
                return result.returncode
        return 0
    except FileNotFoundError:
        print("Optional UI checks require Node20+ and jsdom26.1.0.")
        return 2
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


if __name__ == "__main__":
    raise SystemExit(main())
