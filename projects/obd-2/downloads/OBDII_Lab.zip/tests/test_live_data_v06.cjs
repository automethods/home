/* Actual LiveDataView callbacks + CPU Canvas, with real Python signal fixtures.
 * The established parsed-node harness is deliberately not a browser or layout test.
 */
'use strict';
const assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path'), vm=require('node:vm'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const run=spawnSync('python3',['-c',`
import json
from obdii_lab.core import Sim
from obdii_lab.instrumentation import signal_catalog,read_signals
from obdii_lab.network import network_catalog,observe_network
def result(s):
 st=s.snapshot();return {'state':st,'signals':read_signals(st),'network':observe_network(st)}
s=Sim('phev','city_drive');start=result(s);s.advance(3);healthy=result(s)
s.set_connection('ect',False);s.advance(.6);open_ect=result(s)
s.set_connection('ect',True);s.advance(.1);repaired=result(s)
s.set_connection('wheel_fl',False);s.advance(.1);wheel=result(s)
s.set_connection('bmu',False);s.advance(.4);stale=result(s)
bench=Sim('engine','manual');bench.advance(.1)
print(json.dumps({'signals':signal_catalog(),'catalog':network_catalog(),'start':start,'healthy':healthy,'open':open_ect,'repaired':repaired,'wheel':wheel,'stale':stale,'bench':result(bench)}))
`],{cwd:root,encoding:'utf8'});
assert.equal(run.status,0,run.stderr);const fixture=JSON.parse(run.stdout);
// Reuse the generic HTML-node/Canvas harness from the preceding UI suite.
const harness=fs.readFileSync(path.join(__dirname,'test_dashboard_contract.cjs'),'utf8');
const begin=harness.indexOf('const decodeEntities='),end=harness.indexOf('const elements=');
assert.ok(begin>0&&end>begin,'Generic node harness must be present');
const sandbox={assert,createCanvas,console,window:{devicePixelRatio:1},ResizeObserver:class{observe(){}disconnect(){}},setTimeout(){throw new Error('Live data must not create a clock');},setInterval(){throw new Error('Live data must not create a poller');}};
vm.createContext(sandbox);vm.runInContext(harness.slice(begin,end)+';globalThis.TestNode=Node;',sandbox);
vm.runInContext(fs.readFileSync(path.join(root,'web/session.js'),'utf8'),sandbox);
vm.runInContext(fs.readFileSync(path.join(root,'web/live-data.js'),'utf8'),sandbox);
const node=new sandbox.TestNode('div'),calls={watch:[],selection:[]};
const view=sandbox.window.LiveDataView.create(node,{onWatch:(id,on)=>calls.watch.push({id,on}),onSelect:id=>calls.selection.push(id)});
let ctx={state:fixture.healthy.state,result:fixture.healthy,network:fixture.healthy.network,catalog:fixture.catalog,signals:fixture.signals,selection:'overview',history:[fixture.start.state,fixture.healthy.state],running:false,watch:['speed_kph','rpm','coolant_c','sensors.ect_c']};
const $=selector=>{const found=node.querySelector(selector);assert.ok(found,selector);return found;};
const row=(id,selector)=>{const found=node.querySelectorAll('.ld-signal-row').find(x=>x.dataset.ldId===id)?.querySelector(selector);assert.ok(found,id+' '+selector);return found;};
function update(result,extra={}){ctx={...ctx,state:result.state,result,network:result.network,...extra};view.update(ctx);}
let passed=0,failed=0;async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name+'\n'+error.stack);}}
(async()=>{
await test('real state renders summary, catalog and independent-unit charts',()=>{
 update(fixture.healthy);assert.equal($('[data-ld-metric="speed_kph"]').textContent,sandbox.window.LiveDataView.format(fixture.healthy.state.speed_kph,'km/h'));
 assert.equal(view.inspect().rows.length,fixture.signals.length);assert.equal(view.inspect().watch.length,4);
 assert.ok($('[data-ld-chart]').native.toBuffer('image/png').length>3000);assert.equal(view.inspect().sampleCount,2);
});
await test('component selection scopes signals while preserving pinned comparison',()=>{
 update(fixture.healthy,{selection:'coolant_sensor'});assert.ok(view.inspect().rows.includes('sensors.ect_voltage_v'));assert.ok(!view.inspect().rows.includes('speed_kph'));
 assert.ok(view.inspect().watch.includes('speed_kph'));assert.equal(view.inspect().watch.length,4);
});
await test('search input and checkbox DOM survive ordinary model updates',async()=>{
 const search=$('[data-ld-search]');search.value='voltage';await search.dispatchEvent({type:'input'});
 const checkbox=row('sensors.ect_voltage_v','[data-ld-pin]');checkbox.checked=true;await checkbox.dispatchEvent({type:'change'});
 assert.deepEqual(calls.watch.at(-1),{id:'sensors.ect_voltage_v',on:true});update(fixture.open);
 assert.equal($('[data-ld-search]'),search);assert.equal(search.value,'voltage');assert.equal(row('sensors.ect_voltage_v','[data-ld-pin]'),checkbox);
});
await test('signal buttons route selection to the common object inspector',async()=>{
 await row('sensors.ect_voltage_v','[data-ld-select]').click();assert.equal(calls.selection.at(-1),'signal:sensors.ect_voltage_v');
});
await test('invalid ECU temperature remains labeled and cannot create a false physical trace',async()=>{
 $('[data-ld-search]').value='';await $('[data-ld-search]').dispatchEvent({type:'input'});update(fixture.open,{history:[fixture.start.state,fixture.healthy.state,fixture.open.state]});
 const meta=fixture.signals.find(s=>s.id==='sensors.ect_c');assert.equal(row('sensors.ect_c','[data-ld-validity]').textContent,'Invalid');
 assert.equal(sandbox.window.LiveDataView.plottedValue(meta,fixture.open.state),null);
 assert.ok(sandbox.window.LiveDataView.plottedValue(fixture.signals.find(s=>s.id==='coolant_c'),fixture.open.state)>0);
 assert.ok(sandbox.window.LiveDataView.plottedValue(meta,fixture.repaired.state)>0);
});
await test('dropped wheels, uninstalled hardware and stale reports retain their correct validity',()=>{
 const meta=id=>fixture.signals.find(s=>s.id===id);
 assert.equal(sandbox.window.LiveDataView.plottedValue(meta('sensors.wheel_speeds_kph.0'),fixture.wheel.state),null);
 assert.ok(sandbox.window.LiveDataView.plottedValue(meta('wheel_speeds_kph.0'),fixture.wheel.state)>0);
 assert.equal(sandbox.window.LiveDataView.validity(meta('bmu_report.pack_voltage_v'),fixture.stale.state),'stale');
 assert.equal(sandbox.window.LiveDataView.plottedValue(meta('soc_pct'),fixture.bench.state),null);
 update(fixture.bench);assert.equal($('[data-ld-metric="soc_pct"]').textContent,'—');
});
await test('one shared plot cursor selects saved time without advancing the model',async()=>{
 update(fixture.healthy,{history:[fixture.start.state,fixture.healthy.state]});const before=ctx.state.t;
 await $('[data-ld-chart]').dispatchEvent({type:'click',clientX:70});assert.equal(view.inspect().held,true);assert.equal(view.inspect().chart.sampleTime,fixture.start.state.t);assert.equal(ctx.state.t,before);
 await $('[data-ld-live]').click();assert.equal(view.inspect().held,false);assert.equal(view.inspect().cursor,null);
});
await test('all signals and watched-only filters work without resetting the run',async()=>{
 const scope=$('[data-ld-scope]');scope.value='all';await scope.dispatchEvent({type:'change'});assert.equal(view.inspect().rows.length,fixture.signals.length);
 scope.value='watched';await scope.dispatchEvent({type:'change'});assert.equal(view.inspect().rows.length,4);assert.equal(ctx.state.t,fixture.healthy.state.t);
});
await test('empty watch state has an actionable empty chart, and disposal is safe',()=>{
 update(fixture.healthy,{watch:[]});assert.equal($('[data-ld-no-chart]').hidden,false);assert.equal($('[data-ld-chart]').hidden,true);
 view.setVisible(false);assert.equal(view.inspect().visible,false);view.dispose();
});
console.log(JSON.stringify({suite:'v0.6 linked live data',passed,failed,scope:'Actual module callbacks and CPU Canvas with Python model fixtures; not browser layout or native DOM verification'}));process.exitCode=failed?1:0;
})();
