"""Topology faults, typed catalog consistency and physical UDS teaching requests."""
import json
import unittest

from obdii_lab.core import Sim
from obdii_lab.diagnostics import DiagnosticServer, IsoTpReceiver, SYNTHETIC_VIN, SYNTHETIC_PART_NUMBER
from obdii_lab.instrumentation import read_signals
from obdii_lab.network import network_catalog, observe_network


class ConnectionBehaviorTests(unittest.TestCase):
    def test_topology_change_does_not_advance_time_or_debounce(self):
        sim = Sim()
        initial = sim.t
        changed = sim.set_connection("ect", False)
        self.assertEqual(sim.t, initial)
        self.assertFalse(changed["connections"]["ect"])
        self.assertEqual(changed["pending_dtcs"], [])
        sampled = sim.advance(.02)
        self.assertEqual(sampled["sensors"]["ect_voltage_v"], 5)
        self.assertFalse(sampled["sensors"]["ect_sensor_valid"])

    def test_ect_repair_recovers_measurement_but_retains_diagnostic_memory(self):
        sim = Sim()
        sim.advance(1, {"throttle": .6})
        sim.set_connection("ect", False)
        early = sim.advance(.21)
        self.assertIn("P0118", early["pending_dtcs"])
        self.assertNotIn("P0118", early["dtcs"])
        confirmed = sim.advance(.31)
        self.assertIn("P0118", confirmed["dtcs"])
        self.assertEqual(confirmed["sensors"]["ect_used_c"], 80)
        self.assertGreater(confirmed["coolant_c"], 20)
        sim.set_connection("ect", True)
        repaired = sim.advance(.02)
        self.assertTrue(repaired["sensors"]["ect_sensor_valid"])
        self.assertFalse(repaired["pending_dtcs"])
        self.assertIn("P0118", repaired["dtcs"])
        self.assertEqual(repaired["ect_derate_factor"], 1)
        diagnostic = DiagnosticServer(sim.snapshot, sim.clear_emissions_dtcs)
        self.assertEqual(diagnostic.request("04")["response_hex"], "44")
        self.assertEqual(diagnostic.request("03")["response_hex"], "43 00")

    def test_clearing_memory_does_not_reconnect_the_sensor(self):
        sim = Sim()
        sim.set_connection("ect", False)
        sim.advance(.6)
        sim.clear_emissions_dtcs()
        self.assertFalse(sim.snapshot()["connections"]["ect"])
        self.assertIn("P0118", sim.advance(.6)["dtcs"])

    def test_legacy_fault_and_new_topology_are_independent(self):
        sim = Sim()
        sim.set_connection("ect", False)
        self.assertFalse(sim.advance(.02, {"fault": "none"})["sensors"]["ect_sensor_valid"])
        sim.set_connection("ect", True)
        still_open = sim.advance(.02, {"fault": "ect_open"})
        self.assertTrue(still_open["connections"]["ect"])
        self.assertFalse(still_open["effective_connections"]["ect"])
        self.assertFalse(observe_network(still_open)["wires"]["ect_signal"]["connected"])

    def test_diagnostic_branch_timeout_does_not_stop_engine_physics(self):
        disconnected, baseline = Sim(), Sim()
        disconnected.set_connection("dlc", False)
        left, right = disconnected.advance(2, {"throttle": .5}), baseline.advance(2, {"throttle": .5})
        for key in ("rpm", "coolant_c", "engine_torque_nm", "fuel_l_h"):
            self.assertEqual(left[key], right[key])
        diag = DiagnosticServer(disconnected.snapshot, disconnected.clear_emissions_dtcs)
        result = diag.request("01 0C")
        self.assertIsNone(result["response_hex"])
        self.assertEqual(result["frames"], [])
        self.assertTrue(result["timeout"])
        self.assertEqual(result["delivery"], "not_delivered")
        disconnected.set_connection("dlc", True)
        self.assertTrue(diag.request("01 0C")["response_hex"].startswith("41 0C"))

    def test_independent_open_connections_can_coexist(self):
        sim = Sim(profile="braking")
        for connection in ("ect", "dlc", "wheel_fl", "bmu"):
            sim.set_connection(connection, False)
        state = sim.advance(.6)
        self.assertIn("P0118", state["dtcs"])
        self.assertIn("ABS_WHEEL_FL_SIGNAL", state["module_dtc"]["ABS_ESP"])
        self.assertIn("BMU_STATUS_TIMEOUT", state["module_dtc"]["PHEV_ECU"])
        self.assertEqual(state["contactor"], "FAULT")
        sim.set_connection("ect", True)
        self.assertEqual(sim.snapshot()["connections"], {"ect": True, "dlc": False, "bmu": False, "wheel_fl": False})

    def test_wheel_keeps_turning_with_unavailable_sensor_and_recovers(self):
        sim = Sim(profile="braking", config={"initial_speed_kph": 60})
        sim.advance(.5)
        sim.set_connection("wheel_fl", False)
        lost = sim.advance(.02, {"brake": .2})
        self.assertGreater(lost["wheel_speeds_kph"][0], 20)
        self.assertIsNone(lost["sensors"]["wheel_speeds_kph"][0])
        self.assertEqual(read_signals(lost)["sensors.wheel_speeds_kph.0"]["validity"], "invalid")
        self.assertFalse(lost["abs_active"])
        sim.set_connection("wheel_fl", True)
        repaired = sim.advance(.02)
        self.assertIsNotNone(repaired["sensors"]["wheel_speeds_kph"][0])
        self.assertNotEqual(repaired["module_status"]["ABS_ESP"], "SIGNAL FAULT")
        self.assertIn("ABS_WHEEL_FL_SIGNAL", repaired["module_dtc"]["ABS_ESP"])

    def test_bmu_reconnection_restores_messages_but_shutdown_latch_needs_ignition(self):
        sim = Sim(profile="phev")
        sim.advance(1, {"throttle": .5})
        report = sim.snapshot()["bmu_report"]
        sim.set_connection("bmu", False)
        lost = sim.advance(.5)
        self.assertEqual(lost["bmu_report"], report)
        self.assertGreater(lost["sensors"]["bmu_message_age_ms"], 300)
        self.assertEqual(lost["motor_power_kw"], 0)
        sim.set_connection("bmu", True)
        fresh = sim.advance(.2)
        self.assertGreater(fresh["bmu_report"]["t"], report["t"])
        self.assertLessEqual(fresh["sensors"]["bmu_message_age_ms"], 101)
        self.assertEqual(fresh["contactor"], "FAULT")
        sim.advance(.2, {"ignition": False})
        restarted = sim.advance(.6, {"ignition": True})
        self.assertEqual(restarted["contactor"], "CLOSED")
        self.assertGreater(restarted["motor_power_kw"], 0)

    def test_connection_validation_preserves_state(self):
        sim = Sim()
        before = sim.snapshot()
        for name, connected in (("unknown", False), ("ect", 0), ("ect", "false"), (None, True), ("bmu", False), ("wheel_fl", False)):
            with self.assertRaises(ValueError):
                sim.set_connection(name, connected)
        self.assertEqual(sim.snapshot(), before)


class NetworkCatalogTests(unittest.TestCase):
    def test_graph_endpoints_and_object_ids_are_consistent(self):
        graph = network_catalog()
        components = {item["id"]: item for item in graph["components"]}
        sockets = {item["id"]: item for item in graph["sockets"]}
        self.assertEqual(len(components), len(graph["components"]))
        self.assertEqual(len(sockets), len(graph["sockets"]))
        for socket in sockets.values():
            self.assertIn(socket["component_id"], components)
            self.assertIn(socket["id"], components[socket["component_id"]]["socket_ids"])
        for wire in graph["wires"]:
            for end in (wire["from"], wire["to"]):
                self.assertIn(end["socket_id"], sockets)
                self.assertIn(end["pin"], {pin["number"] for pin in sockets[end["socket_id"]]["pins"]})
            self.assertEqual(wire["state_path"], wire["signal_id"])
        json.dumps(graph, allow_nan=False)

    def test_dlc_has_sixteen_pins_and_distinguishes_legacy_functions(self):
        dlc = next(socket for socket in network_catalog()["sockets"] if socket["id"] == "dlc_socket")
        pins = {pin["number"]: pin for pin in dlc["pins"]}
        self.assertEqual(set(pins), set(range(1, 17)))
        self.assertEqual(pins[6]["label"], "CAN-H")
        self.assertEqual(pins[14]["label"], "CAN-L")
        self.assertEqual(pins[16]["role"], "power")
        self.assertEqual(pins[7]["role"], "legacy")
        self.assertEqual(pins[1]["role"], "unassigned")

    def test_catalog_mutation_cannot_change_another_read(self):
        first = network_catalog()
        first["wires"][0]["properties"]["length_m"] = 900
        first["sockets"][0]["pins"][0]["label"] = "changed"
        second = network_catalog()
        self.assertNotEqual(second["wires"][0]["properties"]["length_m"], 900)
        self.assertNotEqual(second["sockets"][0]["pins"][0]["label"], "changed")

    def test_probes_preserve_missing_signals_and_observable_message_age(self):
        sim = Sim(profile="braking")
        sim.advance(.5)
        sim.set_connection("wheel_fl", False)
        sim.set_connection("bmu", False)
        state = sim.advance(.5)
        observed = observe_network(state)
        wheel = observed["wires"]["wheel_fl_signal"]
        self.assertIsNone(wheel["value"])
        self.assertIsNone(wheel["frequency_hz"])
        self.assertFalse(wheel["available"])
        bmu = observed["wires"]["bmu_can_h"]
        self.assertFalse(bmu["connected"])
        self.assertTrue(bmu["available"])
        self.assertGreater(bmu["value"], 300)
        self.assertEqual(bmu["unit"], "ms")
        json.dumps(observed, allow_nan=False)

    def test_engine_profile_does_not_fabricate_installed_vehicle_sensors(self):
        observed = observe_network(Sim().snapshot())
        self.assertFalse(observed["components"]["bmu"]["installed"])
        self.assertFalse(observed["wires"]["wheel_fl_signal"]["available"])
        self.assertIsNone(observed["wires"]["wheel_fl_signal"]["value"])
        self.assertTrue(observed["components"]["ecu"]["installed"])


class UdsTeachingTests(unittest.TestCase):
    def setUp(self):
        self.sim = Sim()
        self.diag = DiagnosticServer(self.sim.snapshot, self.sim.clear_emissions_dtcs)

    def request(self, payload):
        return self.diag.request(payload, can_id=0x7E0)

    def test_physical_uds_vin_reassembles_over_isotp(self):
        result = self.request("22 F1 90")
        expected = b"\x62\xF1\x90" + SYNTHETIC_VIN.encode()
        self.assertEqual(bytes.fromhex(result["response_hex"]), expected)
        receiver = IsoTpReceiver(padding_byte=0)
        assembled = None
        for i, frame in enumerate(result["frames"]):
            if frame["id"] == "7E8":
                assembled = receiver.feed(frame["data"], i * .001)
        self.assertEqual(assembled, expected)
        self.assertIn("FC", [frame["kind"] for frame in result["frames"]])
        self.assertIsNone(self.diag.request("22 F1 90", can_id=0x7DF)["response_hex"])

    def test_spare_part_number_is_separate_synthetic_identifier(self):
        raw = bytes.fromhex(self.request("22 F1 87")["response_hex"])
        self.assertEqual(raw, b"\x62\xF1\x87" + SYNTHETIC_PART_NUMBER.encode())
        self.assertNotEqual(raw[3:], SYNTHETIC_VIN.encode())

    def test_sessions_and_tester_present_follow_simulation_time(self):
        self.assertEqual(self.request("10 03")["response_hex"], "50 03 00 32 01 F4")
        self.sim.advance(4)
        self.assertEqual(self.diag.session_state()["hex"], "03")
        self.assertEqual(self.request("3E 00")["response_hex"], "7E 00")
        self.sim.advance(4)
        self.assertEqual(self.diag.session_state()["hex"], "03")
        self.sim.advance(1)
        self.assertEqual(self.diag.session_state()["hex"], "01")
        self.assertEqual(self.request("10 01")["response_hex"], "50 01 00 32 01 F4")

    def test_disconnected_tester_does_not_refresh_session(self):
        self.request("10 03")
        self.sim.set_connection("dlc", False)
        self.sim.advance(4)
        self.assertTrue(self.request("3E 00")["timeout"])
        self.sim.advance(1)
        self.assertEqual(self.diag.session_state()["hex"], "01")
        self.sim.set_connection("dlc", True)
        self.assertEqual(self.request("3E 00")["response_hex"], "7E 00")

    def test_negative_responses_and_suppression_are_not_fabricated_success(self):
        for request, expected in (("10 02", "7F 10 12"), ("10", "7F 10 13"),
                                  ("22 F1 99", "7F 22 31"), ("22 F1", "7F 22 13"),
                                  ("3E 01", "7F 3E 12"), ("27 01", "7F 27 11")):
            self.assertEqual(self.request(request)["response_hex"], expected)
        suppressed = self.request("10 83")
        self.assertIsNone(suppressed["response_hex"])
        self.assertIn("suppressed", suppressed["meaning"])
        self.assertEqual(suppressed["session"]["hex"], "03")
        self.assertIsNone(self.request("3E 80")["response_hex"])


if __name__ == "__main__":
    unittest.main()
