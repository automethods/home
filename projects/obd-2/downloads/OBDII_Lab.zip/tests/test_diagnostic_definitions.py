"""Keep declarative descriptions honest against the implemented diagnostic ECU."""
from copy import deepcopy
import json
import threading
import unittest
from urllib.request import Request, urlopen

from obdii_lab.core import Sim
from obdii_lab.diagnostic_definitions import diagnostic_definitions, decode_scalar, validate_catalog
from obdii_lab.diagnostics import MODE_01_PIDS, SYNTHETIC_PART_NUMBER, SYNTHETIC_VIN
from obdii_lab.runner import diagnostic_server
from obdii_lab.server import create_server


class DiagnosticDefinitionTests(unittest.TestCase):
    def test_every_declared_request_is_implemented_and_has_matching_response_shape(self):
        catalog = diagnostic_definitions()
        validate_catalog(catalog)
        requests = {s["request_hex"] for s in catalog["services"] if s["protocol"] == "OBD"}
        self.assertEqual(requests, {f"01 {pid:02X}" for pid in (0, *MODE_01_PIDS)} | {"03", "04", "07", "09 00", "09 02"})
        sim = Sim(scenario="city_drive")
        sim.advance(45)
        diag = diagnostic_server(sim)
        for service in catalog["services"]:
            reply = diag.request(service["request_hex"], int(service["can_id"], 16))
            self.assertTrue(reply["response_hex"].startswith(service["positive_prefix_hex"]), service["id"])
            raw = bytes.fromhex(reply["response_hex"])
            decode = service["decode"]
            if decode["data_length"] is not None:
                self.assertEqual(len(raw), decode["data_offset"] + decode["data_length"], service["id"])
            if service["id"] in ("obd.vin", "uds.vin"):
                self.assertEqual(decode_scalar(service, reply["response_hex"]), SYNTHETIC_VIN)
            if service["id"] == "uds.part_number":
                self.assertEqual(decode_scalar(service, reply["response_hex"]), SYNTHETIC_PART_NUMBER)
            if service["id"] == "obd.rpm":
                self.assertAlmostEqual(decode_scalar(service, reply["response_hex"]), sim.rpm, delta=.1251)
            if service["id"] == "obd.speed":
                self.assertAlmostEqual(decode_scalar(service, reply["response_hex"]), sim.v * 3.6, delta=.5001)

    def test_no_module_addresses_are_invented_and_runtime_availability_tracks_topology(self):
        sim = Sim(profile="phev")
        original = sim.snapshot()
        catalog = diagnostic_definitions(original)
        self.assertEqual(sim.snapshot(), original)
        for module in catalog["modules"]:
            if module["id"] != "ecu":
                self.assertEqual(module["availability"], "state_only")
                self.assertIsNone(module["addressing"])
                self.assertEqual(module["service_ids"], [])
                self.assertFalse(module["available_now"])
        self.assertTrue(all(service["available_now"] for service in catalog["services"]))
        sim.set_connection("dlc", False)
        disconnected = diagnostic_definitions(sim.snapshot())
        self.assertFalse(any(service["available_now"] for service in disconnected["services"]))
        # A caller cannot overwrite the cached descriptor data.
        catalog["services"][0]["name"] = "edited by caller"
        self.assertNotEqual(diagnostic_definitions()["services"][0]["name"], "edited by caller")

    def test_descriptor_validation_rejects_unsupported_routing_and_invalid_conversions(self):
        original = diagnostic_definitions()
        bad = deepcopy(original)
        bad["modules"][1]["addressing"] = {"physical_request_can_id": "7E1"}
        with self.assertRaises(ValueError):
            validate_catalog(bad)
        bad = deepcopy(original)
        service = next(s for s in bad["services"] if s["id"] == "obd.rpm")
        service["decode"]["factor"] = float("nan")
        with self.assertRaises(ValueError):
            validate_catalog(bad)
        rpm = next(s for s in original["services"] if s["id"] == "obd.rpm")
        self.assertEqual(decode_scalar(rpm, "41 0C 1A F8"), 1726)
        with self.assertRaises(ValueError):
            decode_scalar(rpm, "7F 01 11")
        with self.assertRaises(ValueError):
            decode_scalar(rpm, "41 0C 1A")

    def test_api_and_download_expose_the_same_definition_version(self):
        server = create_server(0)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            with urlopen(base + "/api/diagnostic-definitions") as response:
                live = json.load(response)
            with urlopen(base + "/web/models/diagnostic_definitions.json") as response:
                static = json.load(response)
            self.assertEqual(live["schema_version"], static["schema_version"])
            self.assertEqual(len(live["services"]), 19)
            request = Request(base + "/api/connection", data=b'{"id":"dlc","connected":false}', headers={"Content-Type": "application/json"})
            with urlopen(request) as response:
                response.read()
            with urlopen(base + "/api/diagnostic-definitions") as response:
                disconnected = json.load(response)
            self.assertFalse(disconnected["runtime"]["diagnostic_branch_connected"])
            self.assertFalse(disconnected["services"][0]["available_now"])
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
