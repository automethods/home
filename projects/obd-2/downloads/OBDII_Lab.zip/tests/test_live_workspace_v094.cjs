/* Real Session/ScannerView over the real API handlers using JSON lines instead
 * of sockets. The parsed DOM checks interactions; browser layout is separate. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const backend=spawn('python3',['-u','tests/http_stdio.py'],{cwd:root,env:{...process.env,PYTHONPATH:root},stdio:['pipe','pipe','inherit']});
const waiting=[],requests=[],timers=new Map();let timer=0;
readline.createInterface({input:backend.stdout}).on('line',line=>waiting.shift()?.(JSON.parse(line)));
const api=(url,init={})=>new Promise(resolve=>{const body=init.body?JSON.parse(init.body):undefined;requests.push({url,body});waiting.push(r=>resolve({ok:r.status<400,status:r.status,json:async()=>r.data}));backend.stdin.write(JSON.stringify({path:url,body})+'\n');});
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8'),begin=original.indexOf('const decodeEntities='),end=original.indexOf('const elements=new Node(');
const window={fetch:api,dispatchEvent(){}},sandbox={window,document:{activeElement:null},assert,console,CustomEvent:class{constructor(type,options){this.type=type;Object.assign(this,options);}},setTimeout(fn){const id=++timer;timers.set(id,fn);return id;},clearTimeout:id=>timers.delete(id),setInterval(){throw Error('One simulation clock only');}};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.TestNode=Node;',sandbox);
const Node=sandbox.TestNode,originalMatches=Node.prototype.matches;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{const attrs=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];return originalMatches.call(this,part.replace(/\[[^\]]+\]/g,'')||'*')&&attrs.every(match=>this.hasAttribute(match[1])&&(match[2]===undefined||this.getAttribute(match[1])===match[2]));});};
const document=new Node('document');document.hidden=false;document.visibilityState='visible';document.activeElement=null;sandbox.document=document;window.document=document;
const windowEvents=new Map();window.addEventListener=(name,fn)=>{if(!windowEvents.has(name))windowEvents.set(name,[]);windowEvents.get(name).push(fn);};window.removeEventListener=(name,fn)=>windowEvents.set(name,(windowEvents.get(name)||[]).filter(f=>f!==fn));window.dispatchEvent=event=>{for(const fn of windowEvents.get(event.type)||[])fn(event);};
const html=Object.getOwnPropertyDescriptor(Node.prototype,'innerHTML');Object.defineProperty(Node.prototype,'innerHTML',{get:html.get,set(value){if(this.tagName==='SELECT')this._value=undefined;html.set.call(this,value);}});
for(const file of ['session.js','protocols.js','scan-tool.js','cockpit.js','vehicle-monitor.js'])vm.runInContext(fs.readFileSync(path.join(root,'web',file),'utf8'),sandbox,{filename:file});
const session=window.AppSession.create(),container=new Node('main');
const view=window.ScannerView.create(container,{
 onScanner:(action,settings)=>session.scannerAction(action,settings),onRequest:(payload,canId)=>session.request(payload,canId),onPoll:settings=>session.setScannerPolling(settings),
 onLiveVisibility:visible=>{session.scanLive.visible=visible;},onReadLive:()=>session.readLiveData(),onLiveChange:settings=>{session.setLiveData(settings);if(session.result.scanner.status==='ready')return session.readLiveData();}
});
const cockpitRoot=new Node('main'),monitorRoot=new Node('section');
const cockpit=window.CockpitView.create(cockpitRoot,{onInputs:inputs=>session.setInputs(inputs),onManualOverride:()=>session.overrideCycle()});
cockpit.setVisible(false);cockpit.setServiceInputEnabled(true);
const monitor=window.VehicleMonitor.create(monitorRoot,{bindPedals:(controls,active)=>cockpit.bindPedals(controls,'service',active)});monitor.setVisible(true);
const unsubscribeControls=session.subscribe(ctx=>{cockpit.update(ctx);monitor.update(ctx);});
const $=selector=>{const node=container.querySelector(selector);assert.ok(node,selector);return node;};
const flush=async()=>{for(let i=0;i<5;i++)await new Promise(resolve=>setImmediate(resolve));await session.command;};
const click=async selector=>{const target=$(selector);assert.equal(target.disabled,false,selector+' is enabled');await container.dispatchEvent({type:'click',target});await flush();};
const change=async(selector,value)=>{const target=$(selector);target.value=value;await target.dispatchEvent({type:'change'});await flush();};
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
(async()=>{try{
 await session.initialize();await session.commitSetup('petrol_advanced',{},session.testSettings);session.enterWorkspace('service');
 const unsubscribe=session.subscribe(ctx=>view.update(ctx));view.update(session.context());
 await test('live data opens with the fitted primary ECU parameters, no cross-unit table',()=>{
  assert.equal(view.inspect().activeTab,'data');assert.equal($('[data-sc-panel="faults"]').hidden,true);assert.equal(container.querySelectorAll('[data-sc-parameter]').length,19);
  assert.equal($('[data-sc="live-title"]').textContent,'Engine ECU parameters');assert.equal($('[data-sc="live-grid"]').textContent.includes('6-speed'),false);
 });
 await session.control('ignition',true);session.setRunning(false);await session.advance(.2);await session.scannerAction('connect',{module:'ecu'});
 await test('connect reads real ECU replies without advancing simulation time',()=>{
  assert.equal(session.result.state.t,.2);assert.equal(Object.keys(session.scanLive.replies).length,7);assert.match($('[data-sc-parameter="obd.coolant"]').textContent,/°C/);
  assert.match($('[data-sc-parameter="obd.rpm"]').textContent,/OBD reply/);assert.equal(timers.size,0);assert.equal(session.diagnostic,null,'multi-parameter reads stay separate from the custom response');
 });
 await test('live cards expose received hex, byte decoding and the corresponding sensor conversion',()=>{
  const reply=session.scanLive.replies['obd.coolant'],card=$('[data-sc-parameter="obd.coolant"] [data-sc-conversion]');
  assert.match(card.textContent,/Request · hex01 05/);assert.ok(card.textContent.includes(reply.response_hex));
  const data=parseInt(reply.response_hex.split(' ')[2],16);assert.ok(card.textContent.includes('0x'+data.toString(16).toUpperCase().padStart(2,'0')+' = '+data));
  assert.match(card.textContent,/ADC code/);assert.match(card.textContent,/NTC resistance/);assert.match(card.textContent,/Temperature conversion/);
  const analog=$('[data-sc-parameter="map"] [data-sc-conversion]');assert.match(analog.textContent,/Voltage conversion/);assert.match(analog.textContent,/no ADC code/);
 });
 await test('Numbers/Graphs controls preserve selected parameters and plot real replies',async()=>{
  await click('[data-sc-display="graphs"]');assert.equal(container.querySelectorAll('.sc-live-card svg').length,19);assert.ok($('[data-sc-parameter="obd.rpm"] svg').querySelector('path.sc-trend-line'));
  await click('[data-sc-display="numbers"]');assert.equal(container.querySelectorAll('.sc-live-card svg').length,0);
 });
 await test('+ Add parameter adds a supported channel and removal updates the next batch',async()=>{
  await click('[data-sc-action="add-parameter"]');assert.equal($('[data-sc="parameter-picker"]').hidden,false);await change('[data-sc="parameter-choice"]','cam_sensor');await click('[data-sc-action="confirm-parameter"]');
  assert.ok(session.scanLive.ids.includes('cam_sensor'));assert.match($('[data-sc-parameter="cam_sensor"]').textContent,/rpm/);
  await click('[data-sc-remove="obd.load"]');assert.equal(session.scanLive.ids.includes('obd.load'),false);assert.equal(container.querySelector('[data-sc-parameter="obd.load"]'),null);
 });
 await test('shared clock polls every quarter second; pause and hidden data do not poll',async()=>{
  const count=()=>requests.filter(r=>r.body?.action==='read').length,before=count();await session.advance(.1);assert.equal(count(),before);await session.advance(.15);assert.equal(count(),before+1);
  await session.pollScanner();assert.equal(count(),before+1);view.setVisible(false);await session.advance(2);assert.equal(count(),before+1);view.setVisible(true);
 });
 await test('visible service pedals change actual RPM, speed and live ECU readings',async()=>{
  cockpit.update(session.context());monitor.update(session.context());await session.control('start');session.setRunning(false);await session.advance(1.2);
  await session.shift('D',{assist:true});await session.control('parking_brake',false);const idle=session.result.state.rpm;
  const gas=monitorRoot.querySelector('[data-vm-pedal-hold="throttle"]'),brake=monitorRoot.querySelector('[data-vm-pedal-hold="brake"]');
  assert.equal(gas.disabled,false);assert.equal(monitorRoot.classList.contains('vm-compact'),false);
  await gas.dispatchEvent({type:'pointerdown',pointerId:11,button:0});assert.equal(session.inputs.throttle,.35);await session.advance(3);
  const speed=session.result.state.speed_kph;assert.ok(speed>1,'Gas moves the car');assert.ok(session.result.state.rpm>idle,'RPM responds to gas');
  assert.ok(session.scanLive.replies['obd.rpm'].response_hex);assert.match($('[data-sc-parameter="obd.rpm"]').textContent,/OBD reply/);
  await gas.dispatchEvent({type:'pointerup',pointerId:11});assert.equal(session.inputs.throttle,0);
  await brake.dispatchEvent({type:'pointerdown',pointerId:12,button:0});assert.equal(session.inputs.brake,.35);await session.advance(3);
  assert.ok(session.result.state.speed_kph<speed,'Brake reduces actual vehicle speed');await brake.dispatchEvent({type:'pointerup',pointerId:12});assert.equal(session.inputs.brake,0);
 });
 await test('missing sampled input clears its number and leaves a graph gap',async()=>{
  await session.connection('maf',false);await session.advance(.5);await session.readLiveData();
  assert.equal(session.scanLive.replies['obd.airflow'].response_hex,null);assert.match($('[data-sc-parameter="obd.airflow"] .sc-live-value').textContent,/—/);
  await click('[data-sc-display="graphs"]');assert.match($('[data-sc-parameter="obd.airflow"]').textContent,/No valid sampled/);
 });
 await test('a single-service response cannot replace the multi-parameter dashboard',async()=>{
  await session.request('07');assert.equal(session.diagnostic.request_hex,'07');assert.equal(container.querySelectorAll('[data-sc-parameter]').length,19);assert.equal($('[data-sc="live-grid"]').textContent.includes('code(s)'),false);
 });
 await test('fault memory is scoped to selected ECU; the explicit vehicle scan lists all units',async()=>{
  await click('[data-sc-tab="unit"]');await click('[data-sc-action="scan-unit"]');assert.match($('[data-sc="unit-title"]').textContent,/Engine ECU/);assert.match($('[data-sc="unit-faults"]').textContent,/P0102/);
  assert.equal($('[data-sc="unit-faults"]').textContent.includes('6-speed'),false);await click('[data-sc-tab="faults"]');await click('[data-sc-action="scan"]');assert.match($('[data-sc="module-rows"]').textContent,/6-speed automatic/);
 });
 await test('changing to another unit hides prior ECU values and uses that unit’s model signals',async()=>{
  await click('[data-sc-tab="data"]');await change('[data-sc="module"]','transmission');assert.equal(session.scanLive.visible,false);assert.equal($('[data-sc="connection-status"]').textContent,'Selection not applied');
  assert.equal(container.querySelector('[data-sc-parameter="obd.rpm"]'),null);await click('[data-sc-action="connect"]');assert.match($('[data-sc="live-title"]').textContent,/6-speed automatic/);assert.equal($('[data-sc="custom-request"]').hidden,true);
  assert.equal(container.querySelector('[data-sc-action="read-live"]'),null);assert.ok(container.querySelectorAll('[data-sc-parameter]').length>0);
 });
 await test('WLTC continues across Drive/Diagnostics navigation and takeover stops it',async()=>{
  session.navigate('drive');await session.setInputs({throttle:0,brake:1});await session.advance(5);await session.setInputs({brake:0});await session.cycleAction('start');session.setRunning(false);await session.advance(5);const before=session.result.state.t,history=session.history;
  session.navigate('service');assert.equal(session.result.state.t,before);assert.equal(session.history,history);assert.ok(['active','preparing'].includes(session.result.state.drive_cycle.status));
  await session.advance(2);assert.ok(session.result.state.t>before);await session.cycleAction('stop');assert.equal(session.running,true);assert.equal(session.result.state.drive_cycle.status,'stopped');
 });
 await test('pressing a pedal during WLTC takes control without pausing the running car',async()=>{
  session.navigate('service');await session.cycleAction('start');await session.advance(5);session.setRunning(true);
  const gas=monitorRoot.querySelector('[data-vm-pedal-hold="throttle"]');assert.equal(gas.disabled,false);
  await gas.dispatchEvent({type:'pointerdown',pointerId:13,button:0});await flush();await flush();
  assert.equal(session.result.state.drive_cycle.status,'stopped');assert.equal(session.running,true);assert.equal(session.inputs.throttle,.35);
  session.setRunning(false);await session.advance(2);assert.ok(session.result.state.speed_kph>0);await gas.dispatchEvent({type:'pointerup',pointerId:13});assert.equal(session.inputs.throttle,0);
 });
 await test('every fitted module gets its own defaults, graphs and parameter picker',async()=>{
  await session.configure('phev');session.navigate('scan');await session.control('ignition',true);session.setRunning(false);await session.advance(.3);
  for(const module of session.scannerCatalog.modules.filter(m=>m.installed&&m.id!=='ecu')){
    await change('[data-sc="module"]',module.id);await click('[data-sc-action="connect"]');
    const unit=session.systems.units.find(u=>u.id===module.id),ids=view.inspect().parameters;
    assert.ok(ids.every(id=>unit.sensor_ids.includes(id)||session.signals.some(s=>s.id===id&&s.unit_id===unit.id)||(module.id==='transmission'&&['rpm','sensors.accelerator_pct','sensors.brake_pct'].includes(id))),'Module parameters belong to '+module.id);
    assert.equal(container.querySelector('[data-sc-parameter="obd.rpm"]'),null);assert.equal(container.querySelector('[data-sc-action="read-live"]'),null);
    if(unit.sensor_ids.length){assert.ok(ids.length>0);await click('[data-sc-display="graphs"]');assert.equal(container.querySelectorAll('.sc-live-card svg').length,ids.length);}
    else assert.match($('[data-sc="live-grid"]').textContent,/No live measurements are implemented/);
  }
 });
 await test('new BEV configuration clears old readings and removes combustion ECU',async()=>{
  await session.configure('bev');assert.deepEqual(Object.keys(session.scanLive.replies),[]);assert.deepEqual(Object.keys(session.scanLive.series),[]);assert.equal(container.querySelector('[data-sc="module"] option[value="ecu"]'),null);assert.equal(container.querySelector('[data-sc-parameter="obd.rpm"]'),null);
 });
 unsubscribeControls();monitor.dispose();cockpit.dispose();unsubscribe();view.dispose();session.dispose();assert.equal(timers.size,0);
 console.log(JSON.stringify({suite:'live workspace v0.9.4',passed,failed:0,transport:'Actual HTTP handlers via JSON lines, without network sockets'}));
 }catch(error){console.error(error.stack);process.exitCode=1;}finally{session.dispose();backend.kill();}})();
