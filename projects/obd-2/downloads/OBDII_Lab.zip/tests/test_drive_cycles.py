"""Trace provenance, independent clocks and closed-loop driving behavior."""
import json
import math
import unittest

from obdii_lab.drive_cycles import (
    DriveCycleRunner, cycle_info, cycle_phase, cycle_trace,
    drive_cycle_catalog, target_acceleration, target_speed,
)
from obdii_lab.vehicle import VehicleSim


class WLTCTargetTests(unittest.TestCase):
    def test_official_data_axis_phase_checksums_and_distance(self):
        info = cycle_info()
        trace = cycle_trace()
        self.assertEqual(len(trace), 1801)
        self.assertEqual([p[0] for p in trace], list(range(1801)))
        self.assertEqual((trace[0], trace[-1]), ([0, 0], [1800, 0]))
        self.assertEqual(max(p[1] for p in trace), 131.3)
        self.assertEqual(sum(round(p[1] * 10) for p in trace), 837586)
        checksums = (11140.3, 17121.2, 25782.2, 29714.9)
        self.assertEqual([p["duration_s"] for p in info["phases"]], [589, 433, 455, 323])
        for phase, checksum in zip(info["phases"], checksums):
            total = sum(round(speed * 10) for t, speed in trace if phase["start_s"] <= t <= phase["end_s"])
            self.assertEqual(total, round(checksum * 10))
        # Endpoints are zero: trapezoidal interpolation preserves this distance.
        self.assertAlmostEqual(info["target_distance_km"], 23.26627777777778)
        self.assertIn("legislation.gov.au/F2024L00446", info["source"]["url"])
        self.assertEqual(info["source"]["checksum_table"], "A1/13")
        self.assertIn("not a complete WLTP", info["scope"])
        self.assertEqual(drive_cycle_catalog()[0]["id"], "wltc_class3b")

    def test_interpolation_phase_edges_and_invalid_arguments(self):
        name = "wltc_class3b"
        self.assertEqual(target_speed(name, 12), .2)
        self.assertAlmostEqual(target_speed(name, 12.5), .95)
        self.assertAlmostEqual(target_acceleration(name, 12.5), 1.5 / 3.6)
        self.assertEqual(target_speed(name, -3), 0)
        self.assertEqual(target_speed(name, 1802), 0)
        for seconds, expected in ((0, "low"), (588.99, "low"), (589, "medium"), (1022, "high"), (1477, "extra_high"), (1800, "extra_high")):
            self.assertEqual(cycle_phase(name, seconds)["id"], expected)
        for bad in (True, None, "1", math.nan, math.inf):
            with self.assertRaises(ValueError):
                target_speed(name, bad)
        with self.assertRaises(ValueError):
            target_speed("invented_cycle", 1)
        modified = cycle_info()
        modified["phases"][0]["end_s"] = 3
        self.assertEqual(cycle_info()["phases"][0]["end_s"], 589)


class VirtualDriverTests(unittest.TestCase):
    def runner(self, configuration="petrol_basic"):
        sim = VehicleSim(configuration)
        return sim, DriveCycleRunner(sim)

    def test_prepare_uses_real_start_and_gear_interlocks_without_own_clock(self):
        for config in ("petrol_basic", "diesel", "hev", "bev"):
            with self.subTest(configuration=config):
                sim, runner = self.runner(config)
                initial = runner.start()
                self.assertEqual(sim.t, 0)
                self.assertEqual(initial["vehicle"]["selector"], "P")
                self.assertEqual(initial["drive_cycle"]["status"], "preparing")
                self.assertIsNone(initial["drive_target_kph"])
                self.assertEqual(sim.inputs["brake"], .35)
                runner.advance(.2)
                self.assertEqual(runner.elapsed_s, 0)
                self.assertEqual(sim.selector, "P")
                state = runner.advance(1)
                self.assertTrue(state["vehicle"]["ready"])
                self.assertEqual(sim.selector, "D")
                self.assertFalse(sim.parking_brake)
                self.assertEqual(runner.status, "active")
                self.assertGreater(runner.elapsed_s, 0)
                self.assertLess(runner.elapsed_s, sim.t)
                held = runner.snapshot()
                self.assertEqual(runner.snapshot(), held)
                self.assertEqual(runner.start(), held)  # A repeated click does not restart time.

    def test_pedals_drive_the_actual_vehicle_and_history_records_both_speeds(self):
        sim, runner = self.runner()
        runner.start()
        state = runner.advance(40)
        self.assertGreater(state["speed_kph"], 30)
        self.assertLess(state["drive_cycle"]["tracking_rmse_kph"], 2)
        self.assertGreater(state["distance_m"], 100)
        self.assertGreater(state["energy"]["fuel_l"], 0)
        self.assertGreater(state["rpm"], 850)
        self.assertTrue(any(p["inputs"]["throttle"] > .1 for p in sim.history))
        self.assertTrue(any(p["inputs"]["brake"] > .05 and p["speed_kph"] > 10 for p in sim.history))
        for point in sim.history[1:]:
            metadata = point["drive_cycle"]
            self.assertEqual(metadata["actual_speed_kph"], point["speed_kph"])
            if metadata["status"] == "active":
                self.assertAlmostEqual(point["drive_target_kph"], target_speed(runner.name, metadata["elapsed_s"]), places=8)
                self.assertAlmostEqual(metadata["tracking_error_kph"], point["drive_target_kph"] - point["speed_kph"])
            self.assertFalse(point["inputs"]["throttle"] > 0 and point["inputs"]["brake"] > 0)
            self.assertTrue(0 <= point["inputs"]["throttle"] <= .95)
            self.assertTrue(0 <= point["inputs"]["brake"] <= .85)
        json.dumps(state, allow_nan=False)

    def test_different_request_chunks_do_not_change_controls_or_vehicle(self):
        a_sim, a = self.runner()
        b_sim, b = self.runner()
        a.start()
        b.start()
        a.advance(22.2)
        for _ in range(600):
            b.advance(.037)
        self.assertEqual(a_sim.tick, b_sim.tick)
        self.assertEqual(a.snapshot(), b.snapshot())
        self.assertEqual(a_sim.history, b_sim.history)

    def test_faults_change_actual_motion_not_the_official_target(self):
        sim, runner = self.runner("bev")
        runner.start()
        runner.advance(20)
        sim.set_connection("bmu", False)
        state = runner.advance(12)
        self.assertEqual(state["contactor"], "FAULT")
        self.assertEqual(state["motor_power_kw"], 0)
        self.assertGreater(state["drive_target_kph"] - state["speed_kph"], 20)
        self.assertEqual(runner.status, "active")
        self.assertIn("unavailable", state["drive_cycle"]["note"])

    def test_manual_takeover_releases_pedals_without_changing_time_or_gear(self):
        sim, runner = self.runner()
        runner.start()
        runner.advance(22)
        self.assertGreater(sim.inputs["throttle"], 0)
        elapsed, vehicle_time, gear = runner.elapsed_s, sim.t, sim.selector
        state = runner.stop()
        self.assertEqual((sim.t, sim.selector), (vehicle_time, gear))
        self.assertEqual((sim.inputs["throttle"], sim.inputs["brake"]), (0, 0))
        self.assertEqual(state["drive_cycle"]["status"], "stopped")
        self.assertIsNone(state["drive_target_kph"])
        runner.advance(1, {"brake": .5})
        self.assertEqual(sim.inputs["brake"], .5)
        self.assertEqual(runner.elapsed_s, elapsed)

    def test_manual_transmission_and_moving_start_are_rejected_before_mutation(self):
        sim, runner = self.runner()
        sim.configuration["transmission_type"] = "manual_6"
        before = sim.snapshot()
        with self.assertRaisesRegex(ValueError, "automatic transmission"):
            runner.start()
        self.assertEqual(sim.snapshot(), before)
        sim.configuration["transmission_type"] = "automatic_6"
        runner.start()
        runner.advance(20)
        runner.stop()
        before = sim.snapshot()
        with self.assertRaisesRegex(ValueError, "Stop the vehicle"):
            runner.start()
        self.assertEqual(sim.snapshot(), before)

    def test_preparation_fault_times_out_without_starting_cycle_clock(self):
        sim, runner = self.runner()
        runner.start()
        sim.apply_sensor_effects({"engine_inhibit": True})
        state = runner.advance(8.1)
        self.assertEqual(runner.status, "fault")
        self.assertEqual(runner.elapsed_s, 0)
        self.assertEqual(state["speed_kph"], 0)
        self.assertEqual(sim.selector, "P")
        self.assertEqual(sim.inputs["throttle"], 0)
        self.assertGreater(sim.inputs["brake"], .1)

    def test_invalid_inputs_do_not_advance_the_simulation(self):
        sim, runner = self.runner()
        runner.start()
        for seconds, inputs in ((-1, None), (math.nan, None), (True, None), (1, []), (1, {"throttle": 5}), (1, {"road_mu": -1})):
            with self.assertRaises(ValueError):
                runner.advance(seconds, inputs)
            self.assertEqual(sim.t, 0)

    def test_whole_cycle_ends_stopped_with_brake_hold_and_idle_engine(self):
        sim, runner = self.runner()
        runner.start()
        state = runner.advance(1801)
        self.assertTrue(runner.complete)
        self.assertEqual(runner.elapsed_s, 1800)
        self.assertEqual(state["speed_kph"], 0)
        self.assertEqual(state["drive_target_kph"], 0)
        self.assertEqual(state["inputs"]["throttle"], 0)
        self.assertGreater(state["inputs"]["brake"], .1)
        self.assertTrue(state["engine_running"])
        self.assertGreater(state["rpm"], 700)
        self.assertAlmostEqual(state["distance_m"] / 1000, cycle_info()["target_distance_km"], delta=.5)
        self.assertLess(state["drive_cycle"]["tracking_rmse_kph"], 3)
        self.assertEqual(sim.history[-1]["drive_cycle"]["status"], "complete")


if __name__ == "__main__":
    unittest.main()
