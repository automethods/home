/* Driver warning integration: actual UI, Session and Python HTTP API.
 * Parsed DOM and CPU Canvas verify callbacks, state and accessible markup.
 * Native browser layout, focus behaviour and GPU rendering are not claimed.
 * Run: node tests/test_dashboard_warnings_v092.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const heldRequests=[];
function holdNext(url){let release,entered;const gate={url,wait:new Promise(resolve=>release=resolve),entered:new Promise(resolve=>entered=resolve)};gate.release=release;gate.mark=entered;heldRequests.push(gate);return gate;}
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});const held=heldRequests.findIndex(gate=>gate.url===url);if(held>=0){const [gate]=heldRequests.splice(held,1);gate.mark();await gate.wait;}return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){
 const server=await startServer();let app;const outstanding=new Set();
 try{
  const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
  document.readyState='interactive';await document.dispatchEvent(new CustomEvent('DOMContentLoaded'));
  app=window.VehicleApplication;await app.ready;
  const settle=async()=>{await app.session.command;await waitFor(()=>app.session.pending===0&&!app.views.drive.inspect().pending,'Driver command finishes');await flush();};
  const click=async selector=>{await $(selector).click();await settle();};
  const snapshot=()=>app.session.result.state;
  const v=()=>snapshot().vehicle;
  const lamp=name=>$(`[data-ck-lamp="${name}"]`);
  const lit=name=>lamp(name).classList.contains('lit');
  const assertRed=name=>{assert.equal(lit(name),true,name+' is visibly active');assert.ok(lamp(name).classList.contains('danger'),name+' uses red warning class');assert.ok(lamp(name).querySelector('svg'),name+' has a pictogram');assert.ok(lamp(name).getAttribute('aria-label'),name+' has a state description');};
  const controlRequests=(from,action)=>requests.slice(from).filter(r=>r.url==='/api/control'&&r.body.action===action);
  const key=(type,key,code)=>window.dispatchEvent({type,key,code,target:$('#cockpit-content'),preventDefault(){this.defaultPrevented=true;}});
  const newVehicle=async(id='petrol_basic',options={})=>{const settings={mode:'manual',road_mu:.9,grade_pct:0};if(app.session.setupComplete)await app.session.setup(id,options,settings,{enterDrive:false});else await app.session.commitSetup(id,options,settings);app.session.enterWorkspace('drive');await settle();assert.equal(snapshot().t,0);assert.equal(v().ignition,'off');};
  const start=async()=>{await click('[data-ck-action="ignition"]');await click('[data-ck-action="start"]');await app.session.advance(1.1);await settle();app.session.setRunning(false);};
  const held=route=>{const gate=holdNext(route);outstanding.add(gate);return gate;};
  const release=gate=>{gate.release();outstanding.delete(gate);};
  await newVehicle();
  await test('new vehicle has fastened belt and closed door, with warning lamps unlit while ignition is off',async()=>{
   assert.equal(v().driver_seatbelt_fastened,true);assert.equal(v().driver_door_open,false);assert.equal(v().parking_brake,true);
   for(const name of ['parking','seatbelt','door','oil','battery','mil'])assert.equal(lit(name),false,name+' ignition gating');
   assert.equal($('[data-ck="parking-alert"]').hidden,true);
   assert.ok($('[data-ck-action="seatbelt"]'));assert.ok($('[data-ck-action="driver-door"]'));
  });
  await test('ignition lights the red parking pictogram and normal engine-off warnings',async()=>{
   await click('[data-ck-action="ignition"]');app.session.setRunning(false);
   assertRed('parking');assert.equal(lit('oil'),true);assert.equal(lit('battery'),true);
   assert.equal(lit('seatbelt'),false);assert.equal(lit('door'),false);
   assert.ok(lamp('parking').closest('.ck-cluster'),'Parking lamp belongs to the instrument cluster');
   assert.equal($('[data-ck="parking-alert"]').hidden,true,'Park does not produce a drive-blocking alert');
  });
  await test('starting the engine and selecting D exposes an in-cluster parking warning with a direct release action',async()=>{
   await click('[data-ck-action="start"]');await app.session.advance(1.1);await settle();app.session.setRunning(false);
   await click('[data-ck-shift="D"]');assert.equal(v().selector,'D');assert.equal(v().parking_brake,true);assert.equal(snapshot().engine_running,true);
   assert.equal($('[data-ck="parking-alert"]').hidden,false);assert.ok($('[data-ck="parking-alert"]').closest('.ck-cluster'));
   assert.match($('[data-ck="parking-alert-text"]').textContent,/parking brake/i);
   assert.equal($('[data-ck-action="parking-release"]').disabled,false);assertRed('parking');
   assert.doesNotMatch($('[data-ck="notice"]').textContent,/Hold S.*select a gear|Brake \+ select D/,'Already in D must not be told to select D again');
  });
  await test('a held game accelerator in D cannot move the vehicle with its parking brake still applied',async()=>{
   document.activeElement=null;key('keydown','w','KeyW');assert.equal(app.session.inputs.throttle,1);
   await app.session.advance(2);await settle();assert.equal(snapshot().inputs.throttle,1);assert.equal(v().parking_brake,true);
   assert.equal(snapshot().speed_kph,0);assert.equal($('[data-ck="parking-alert"]').hidden,false);assertRed('parking');
  });
  await test('seat-belt and door controls update shared state and red lamps without advancing the paused clock',async()=>{
   const t=snapshot().t;app.session.setRunning(false);
   await click('[data-ck-action="seatbelt"]');assert.equal(v().driver_seatbelt_fastened,false);assertRed('seatbelt');
   await click('[data-ck-action="driver-door"]');assert.equal(v().driver_door_open,true);assertRed('door');
   assert.equal(snapshot().t,t);assert.equal(app.session.running,false);
   assert.match($('[data-ck="seatbelt-state"]').textContent,/unfastened|not fastened|unbuckled/i);
   assert.match($('[data-ck="door-state"]').textContent,/open/i);
   assert.equal($('[data-ck-action="parking-release"]').disabled,false,'Warnings do not disable parking release');
  });
  await test('cluster shortcut sends one release, keeps D selected, and restores motion with body warnings still active',async()=>{
   const from=requests.length,t=snapshot().t;await click('[data-ck-action="parking-release"]');
   const sent=controlRequests(from,'parking_brake');assert.equal(sent.length,1);assert.equal(sent[0].body.value,false);
   assert.equal(v().selector,'D');assert.equal(v().parking_brake,false);assert.equal(snapshot().t,t);
   assert.equal(lit('parking'),false);assert.equal($('[data-ck="parking-alert"]').hidden,true);
   await app.session.advance(3);await settle();assert.ok(snapshot().speed_kph>1,'Actual model drives after releasing parking brake');
   assert.equal(snapshot().inputs.throttle,1);assertRed('seatbelt');assertRed('door');
   assert.equal(snapshot().dtcs.length,0,'Belt and door warnings do not manufacture emissions DTCs');
  });
  await test('momentary accelerator key and focus-loss release still reach the shared vehicle inputs',async()=>{
   key('keyup','w','KeyW');assert.equal(app.session.inputs.throttle,0);await app.session.advance(.1);await settle();assert.equal(snapshot().inputs.throttle,0);
   key('keydown','ArrowUp','ArrowUp');assert.equal(app.session.inputs.throttle,1);window.dispatchEvent({type:'blur'});
   assert.equal(app.session.inputs.throttle,0);await app.session.advance(.1);await settle();assert.equal(snapshot().inputs.throttle,0);
  });
  await test('restoring belt and door clears their lamps and updates state descriptions',async()=>{
   const from=requests.length,t=snapshot().t;await click('[data-ck-action="seatbelt"]');await click('[data-ck-action="driver-door"]');
   assert.equal(v().driver_seatbelt_fastened,true);assert.equal(v().driver_door_open,false);assert.equal(lit('seatbelt'),false);assert.equal(lit('door'),false);
   assert.equal(controlRequests(from,'seatbelt')[0].body.value,true);assert.equal(controlRequests(from,'driver_door')[0].body.value,false);
   assert.match($('[data-ck="seatbelt-state"]').textContent,/fastened|buckled/i);assert.match($('[data-ck="door-state"]').textContent,/closed/i);assert.equal(snapshot().t,t);
  });
  await test('body warnings survive ignition cycling as states while their lamps follow ignition power',async()=>{
   await newVehicle();await click('[data-ck-action="seatbelt"]');await click('[data-ck-action="driver-door"]');
   assert.equal(lit('seatbelt'),false);assert.equal(lit('door'),false);assert.equal(lit('parking'),false);
   await click('[data-ck-action="ignition"]');app.session.setRunning(false);for(const name of ['parking','seatbelt','door'])assertRed(name);
   await click('[data-ck-action="ignition"]');for(const name of ['parking','seatbelt','door'])assert.equal(lit(name),false);
   assert.equal(v().driver_seatbelt_fastened,false);assert.equal(v().driver_door_open,true);assert.equal(v().parking_brake,true);
   await click('[data-ck-action="ignition"]');app.session.setRunning(false);for(const name of ['parking','seatbelt','door'])assertRed(name);
  });
  await test('pending body controls cannot issue duplicate toggles or optimistically clear a warning',async()=>{
   const gate=held('/api/control'),from=requests.length;await $('[data-ck-action="seatbelt"]').click();await gate.entered;await flush();
   assert.equal(v().driver_seatbelt_fastened,false);assertRed('seatbelt');assert.equal($('[data-ck-action="seatbelt"]').disabled,true);
   await $('[data-ck-action="seatbelt"]').click();release(gate);await settle();
   assert.equal(controlRequests(from,'seatbelt').length,1);assert.equal(v().driver_seatbelt_fastened,true);assert.equal(lit('seatbelt'),false);
  });
  await test('reset creates deterministic driver states and clears warning UI from the previous vehicle',async()=>{
   await app.session.reset();await settle();assert.equal(snapshot().t,0);assert.equal(v().driver_seatbelt_fastened,true);assert.equal(v().driver_door_open,false);
   assert.equal(v().parking_brake,true);assert.equal(v().ignition,'off');for(const name of ['parking','seatbelt','door'])assert.equal(lit(name),false);
   assert.equal($('[data-ck="parking-alert"]').hidden,true);
  });
  await test('petrol RPM red zone begins at the configured engine redline, not at a fixed visual percentage',async()=>{
   const zone=$('[data-ck-redzone="left"]'),redline=Number(v().configuration.redline_rpm),maximum=Number(zone.getAttribute('data-max-rpm'));
   assert.equal(Number(zone.getAttribute('data-redline-rpm')),redline);assert.ok(maximum>redline);assert.notEqual(zone.style.display,'none');
   const start=zone.getAttribute('d').match(/^M\s*([\d.-]+)[ ,]+([\d.-]+)/);assert.ok(start,'Red zone is a plotted instrument arc');
   const angle=(Math.atan2(Number(start[2])-144,Number(start[1])-204)*180/Math.PI+360)%360;
   const expected=(135+redline/maximum*270)%360;assert.ok(Math.abs(angle-expected)<.05,'Visible red zone starts at the backend redline');
  });
  for(const id of ['diesel','bev']){
   await test(id+' uses the same physical parking state and working driver tell-tales',async()=>{
    await newVehicle(id);await start();await click('[data-ck-shift="D"]');assert.equal(v().selector,'D');assertRed('parking');
    assert.equal($('[data-ck="parking-alert"]').hidden,false);await click('[data-ck-action="seatbelt"]');await click('[data-ck-action="driver-door"]');assertRed('seatbelt');assertRed('door');
    document.activeElement=null;key('keydown','w','KeyW');await app.session.advance(1);await settle();assert.equal(snapshot().speed_kph,0);
    await click('[data-ck-action="parking-release"]');await app.session.advance(2);await settle();assert.ok(snapshot().speed_kph>1,id+' moves after release');
    assert.equal(lit('parking'),false);assertRed('seatbelt');assertRed('door');key('keyup','w','KeyW');
    const zone=$('[data-ck-redzone="left"]');
    if(id==='bev'){assert.equal(lamp('oil').hidden,true,'BEV does not show an engine oil lamp');assert.equal(zone.style.display,'none','Electric power dial has no engine RPM red zone');assert.equal(zone.getAttribute('d'),'');}
    else{assert.notEqual(zone.style.display,'none');assert.equal(Number(zone.getAttribute('data-redline-rpm')),v().configuration.redline_rpm);assert.ok(Number(zone.getAttribute('data-max-rpm'))>v().configuration.redline_rpm);}
   });
  }
  await test('reverse and manual drive gears receive the same parking warning without changing gear automatically',async()=>{
   await newVehicle();await start();await click('[data-ck-shift="R"]');assert.equal(v().selector,'R');assert.equal($('[data-ck="parking-alert"]').hidden,false);
   await click('[data-ck-action="parking-release"]');assert.equal(v().selector,'R');assert.equal(v().parking_brake,false);
   await newVehicle('petrol_basic',{transmission_type:'manual_6'});await click('[data-ck-action="ignition"]');await click('[data-ck-action="start-assist"]');await app.session.advance(1.1);await settle();app.session.setRunning(false);
   await click('[data-ck-action="manual-shift"]');assert.equal(v().selector,'1');assert.equal($('[data-ck="parking-alert"]').hidden,false);assertRed('parking');
   await click('[data-ck-action="parking-release"]');assert.equal(v().selector,'1');assert.equal(v().parking_brake,false);assert.equal($('[data-ck="parking-alert"]').hidden,true);
  });
  assert.deepEqual(errors,[]);
  console.log(JSON.stringify({suite:'Dashboard warning integration v0.9.2',passed,failed:0,scope:'Actual application, Session and Python HTTP vehicle model; parsed DOM verifies state and callbacks. Native browser layout and events are not verified.'}));
 }finally{for(const gate of outstanding)gate.release();for(const gate of heldRequests)gate.release();app?.dispose();if(app)await app.session.command.catch(()=>{});server.child.kill('SIGTERM');server.lines.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
