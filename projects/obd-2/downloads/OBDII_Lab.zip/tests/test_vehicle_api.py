"""Loopback integration for the configured cockpit, scanner and run exports."""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.runner import export_run
from obdii_lab.server import create_server


class VehicleApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None):
        request = Request(self.base + path, data=None if body is None else json.dumps(body).encode(),
                          headers={"Content-Type": "application/json"})
        with urlopen(request, timeout=10) as response:
            raw = response.read()
            if "application/json" not in response.headers["Content-Type"]:
                return raw
            def invalid_constant(value):
                raise AssertionError("Non-finite JSON: " + value)
            return json.loads(raw, parse_constant=invalid_constant)

    def setUp(self):
        self.call("/api/vehicle", {"configuration": "petrol_basic"})

    def control(self, action, value=None, inputs=None):
        body = {"action": action, "value": value}
        if inputs is not None:
            body["inputs"] = inputs
        return self.call("/api/control", body)

    def start(self):
        self.control("ignition", True)
        self.control("start")
        return self.call("/api/advance", {"seconds": 1.6})

    def drive(self, seconds=3):
        self.start()
        self.control("gear", "D", {"brake": .3})
        self.control("parking_brake", False)
        return self.call("/api/advance", {"seconds": seconds, "inputs": {"brake": 0, "throttle": .5}})

    def connect(self, module="ecu", protocol="can11_500"):
        return self.call("/api/scanner", {"action": "connect", "module": module, "protocol": protocol})

    def diagnostic(self, payload, can_id=None):
        body = {"payload": payload}
        if can_id is not None:
            body["can_id"] = can_id
        return self.call("/api/diagnostic", body)

    def assert_bad_request(self, path, body):
        with self.assertRaises(HTTPError) as caught:
            self.call(path, body)
        self.assertEqual(caught.exception.code, 400)
        return json.loads(caught.exception.read())["error"]

    def test_all_six_configs_drive_scan_and_export_finite_self_describing_runs(self):
        for config in ("petrol_basic", "petrol_advanced", "diesel", "hev", "phev", "bev"):
            with self.subTest(configuration=config):
                initial = self.call("/api/vehicle", {"configuration": config})
                self.assertEqual(initial["state"]["vehicle"]["start_state"], "off")
                self.assertEqual(initial["state"]["configuration_id"], config)
                self.assertEqual(initial["scanner"]["status"], "disconnected")
                for route in ("/api/meta", "/api/systems", "/api/network", "/api/signals", "/api/scanner"):
                    self.assertIsInstance(self.call(route), dict)
                engine = config != "bev"
                electric = config in ("hev", "phev", "bev")
                observations = {item["signal_id"] for item in initial["explanation"]["observations"]}
                self.assertEqual("soc_pct" in observations, electric)
                self.assertEqual("rpm" in observations, engine)
                self.control("ignition", True)
                self.call("/api/advance", {"seconds": .1})
                self.connect("ecu" if engine else "inverter")
                off_engine = self.diagnostic("01 0C")
                if engine:
                    self.assertEqual(off_engine["diagnostic"]["response_hex"], "41 0C 00 00")
                else:
                    self.assertEqual(off_engine["diagnostic"]["status"], "state_only")
                    self.assertIn("simulation-state", off_engine["diagnostic_explanation"]["answer"])
                self.control("start")
                self.call("/api/advance", {"seconds": 1.5})
                self.control("gear", "D", {"brake": .3})
                self.control("parking_brake", False)
                driven = self.call("/api/advance", {"seconds": 3, "inputs": {"brake": 0, "throttle": .5}})
                self.assertGreater(driven["state"]["speed_kph"], 5)
                self.assertTrue(driven["state"]["vehicle"]["ready"])
                scanned = self.call("/api/scanner", {"action": "scan"})
                units = {unit["id"]: unit for unit in scanned["scan_report"]["modules"]}
                self.assertEqual(units["ecu"]["installed"], engine)
                self.assertEqual(units["bmu"]["installed"], electric)
                self.assertEqual(units["ecu"]["status"] == "not_installed", not engine)
                if engine:
                    identification = self.diagnostic("22 F1 90")
                    self.assertTrue(identification["diagnostic"]["response_hex"].startswith("62 F1 90"))
                    self.assertTrue(any(frame["kind"] == "FC" for frame in identification["diagnostic"]["frames"]))
                data = self.call("/api/export.json")
                self.assertEqual(data["vehicle_configuration"]["id"], config)
                self.assertEqual(data["summary"]["configuration_id"], config)
                self.assertEqual(data["summary"]["final_selector"], "D")
                self.assertTrue(data["measurement_notes"]["availability"])
                self.assertEqual(data["summary"]["final_soc_pct"] is None, not electric)
                self.assertEqual(data["summary"]["final_coolant_c"] is None, not engine)
                table = list(csv.DictReader(io.StringIO(self.call("/api/export.csv").decode())))
                self.assertEqual(table[-1]["configuration_id"], config)
                self.assertEqual(table[-1]["selector"], "D")
                self.assertGreater(float(table[-1]["speed_kph"]), 5)
                self.assertEqual(table[-1]["battery_current_a"] == "", not electric)
                self.assertEqual(table[-1]["coolant_c"] == "", not engine)
                self.assertIn("sensor_vehicle_speed_sampled_at", table[-1])
                self.assertIn("sensor_vehicle_speed_validity", table[-1])
                self.assertIn(b"generated diagnostic transcript", self.call("/api/trace.txt"))

    def test_scanner_connection_reasons_bitrate_and_module_routing_are_real(self):
        result = self.connect()
        self.assertEqual(result["scanner"]["status"], "vehicle_off")
        timeout = self.diagnostic("01 0C")
        self.assertEqual(timeout["diagnostic"]["frames"], [])
        self.assertIn("ignition", timeout["diagnostic_explanation"]["explanation"].lower())
        self.control("ignition", True)
        self.call("/api/advance", {"seconds": .1})
        mismatch = self.connect(protocol="can11_250")
        self.assertEqual(mismatch["scanner"]["status"], "bitrate_mismatch")
        response = self.diagnostic("01 0C")
        self.assertEqual(response["diagnostic"]["frames"], [])
        self.assertIn("bitrate", response["diagnostic_explanation"]["explanation"].lower())
        self.call("/api/vehicle", {"configuration": "petrol_advanced", "options": {"can_bitrate": 250000}})
        self.control("ignition", True)
        self.call("/api/advance", {"seconds": .1})
        self.connect(protocol="can11_250")
        self.assertEqual(self.diagnostic("01 0C")["diagnostic"]["response_hex"], "41 0C 00 00")
        before = self.call("/api/scanner")["state"]
        self.assert_bad_request("/api/scanner", {"action": "connect", "protocol": "iso9141", "module": "ecu"})
        self.assertEqual(self.call("/api/scanner")["state"], before)
        connected = self.connect(module="abs", protocol="can11_250")
        self.assertEqual(connected["scanner"]["module_id"], "abs")
        self.assertEqual(self.diagnostic("01 0C")["diagnostic"]["status"], "state_only")

    def test_configured_probe_and_definition_availability_matches_fitted_equipment(self):
        signals = self.call("/api/signals")
        catalog = {item["id"]: item for item in signals["catalog"]}
        for identifier in ("motor_power_kw", "regen_kw", "battery_voltage_v", "abs_active", "esp_active", "sensors.wheel_speeds_kph.0"):
            self.assertFalse(catalog[identifier]["installed"])
            self.assertIsNone(signals["signals"][identifier]["value"])
            self.assertEqual(signals["signals"][identifier]["validity"], "unavailable")
        self.assertTrue(catalog["wheel_speeds_kph.0"]["installed"])
        self.assertFalse(any(s["available_now"] for s in self.call("/api/diagnostic-definitions")["services"]))
        self.control("ignition", True)
        self.connect()
        self.assertTrue(all(s["available_now"] for s in self.call("/api/diagnostic-definitions")["services"]))
        self.call("/api/vehicle", {"configuration": "bev"})
        definitions = self.call("/api/diagnostic-definitions")
        self.assertFalse(next(m for m in definitions["modules"] if m["id"] == "ecu")["installed_now"])
        self.assertFalse(any(s["available_now"] for s in definitions["services"]))
        probes = self.call("/api/signals")["signals"]
        for identifier in ("rpm", "coolant_c", "fuel_l_h", "mil", "sensors.ect_node_v"):
            self.assertFalse(probes[identifier]["installed"])
            self.assertIsNone(probes[identifier]["value"])
        self.assertTrue(probes["battery_voltage_v"]["installed"])

    def test_unplug_sample_scan_clear_and_repair_keep_fault_memory_separate(self):
        self.start()
        self.connect()
        before = self.call("/api/state")["state"]["t"]
        unplugged = self.call("/api/connection", {"id": "maf", "connected": False})
        self.assertEqual(unplugged["state"]["t"], before)
        fault = self.call("/api/advance", {"seconds": .8})
        self.assertIn("P0102", fault["state"]["dtcs"])
        missing = self.diagnostic("01 10")
        self.assertEqual(missing["diagnostic"]["status"], "sample_unavailable")
        self.assertIsNone(missing["diagnostic"]["response_hex"])
        self.assertIn("unavailable", missing["diagnostic_explanation"]["answer"])
        self.assertIn("Mass air flow", self.diagnostic("03")["diagnostic_explanation"]["answer"])
        cleared = self.diagnostic("04")
        self.assertAlmostEqual(cleared["state"]["t"], before + .8)
        self.assertEqual(cleared["state"]["dtcs"], [])
        again = self.call("/api/advance", {"seconds": .6})
        self.assertIn("P0102", again["state"]["dtcs"])
        self.call("/api/connection", {"id": "maf", "connected": True})
        repaired = self.call("/api/advance", {"seconds": .1})
        self.assertEqual(repaired["state"]["vehicle_sensors"]["maf"]["validity"], "valid")
        self.assertIn("P0102", repaired["state"]["dtcs"])
        self.assertTrue(self.diagnostic("01 10")["diagnostic"]["response_hex"].startswith("41 10"))
        self.assertEqual(self.diagnostic("04")["state"]["dtcs"], [])

    def test_missing_wheel_measurement_exports_blank_without_erasing_wheel_motion(self):
        self.call("/api/vehicle", {"configuration": "petrol_advanced"})
        self.drive()
        self.call("/api/connection", {"id": "wheel_fr", "connected": False})
        result = self.call("/api/advance", {"seconds": .6})
        self.assertTrue(result["state"]["vehicle"]["abs_inhibited"])
        self.assertGreater(result["state"]["wheel_speeds_kph"][1], 5)
        self.assertIsNone(result["state"]["sensors"]["wheel_speeds_kph"][1])
        self.assertEqual(result["signals"]["vehicle_sensors.wheel_fr.value"]["validity"], "invalid")
        row = list(csv.DictReader(io.StringIO(self.call("/api/export.csv").decode())))[-1]
        self.assertGreater(float(row["wheel_fr_kph"]), 5)
        self.assertEqual(row["wheel_fr_measured_kph"], "")
        self.assertEqual(row["sensor_wheel_fr_value"], "")
        self.assertEqual(row["sensor_wheel_fr_validity"], "invalid")

    def test_dlc_unplug_blocks_scanner_without_stopping_shared_vehicle(self):
        driven = self.drive()
        self.connect()
        self.call("/api/connection", {"id": "dlc", "connected": False})
        reply = self.diagnostic("01 0C")
        self.assertTrue(reply["diagnostic"]["timeout"])
        self.assertEqual(reply["diagnostic"]["frames"], [])
        advanced = self.call("/api/advance", {"seconds": .3})
        self.assertGreater(advanced["state"]["speed_kph"], driven["state"]["speed_kph"])
        self.assertTrue(advanced["state"]["engine_running"])
        self.call("/api/connection", {"id": "dlc", "connected": True})
        self.assertTrue(self.diagnostic("01 0C")["diagnostic"]["response_hex"].startswith("41 0C"))

    def test_rejected_control_and_config_requests_preserve_state_and_pending_inputs(self):
        before = self.call("/api/state")
        cases = [
            ("/api/control", {"action": "unknown", "inputs": {"ignition": True, "throttle": .8}}),
            ("/api/control", {"action": "gear", "value": "D", "inputs": {"throttle": .8}}),
            ("/api/control", {"action": "ignition", "value": "on", "inputs": {"brake": .5}}),
            ("/api/vehicle", {"configuration": "missing"}),
            ("/api/vehicle", {"configuration": "petrol_basic", "options": {"can_bitrate": 12345}}),
            ("/api/advance", {"seconds": True}),
            ("/api/advance", {"seconds": .1, "inputs": {"road_mu": float("nan")}}),
        ]
        for path, body in cases:
            with self.subTest(path=path, body=body):
                self.assert_bad_request(path, body)
                self.assertEqual(self.call("/api/state"), before)
        self.drive()
        moving = self.call("/api/state")
        self.assert_bad_request("/api/control", {"action": "gear", "value": "P", "inputs": {"brake": 1}})
        self.assertEqual(self.call("/api/state"), moving)

    def test_low_charge_bev_never_advertises_engine_charge_sustain(self):
        self.call("/api/vehicle", {"configuration": "bev", "options": {"initial_soc_pct": 20}})
        result = self.drive()
        self.assertEqual(result["state"]["mode"], "EV")
        self.assertEqual(result["state"]["rpm"], 0)
        self.assertEqual(result["state"]["energy"]["fuel_l"], 0)
        self.assertNotIn("hybrid", result["explanation"]["summary"].lower())

    def test_read_only_api_and_direct_configured_exports_do_not_advance_or_connect_session(self):
        for config in ("petrol_basic", "bev"):
            with self.subTest(configuration=config):
                self.call("/api/vehicle", {"configuration": config})
                initial = self.call("/api/state")
                for route in ("/api/state", "/api/signals", "/api/network", "/api/systems", "/api/scanner", "/api/diagnostic-definitions", "/api/export.json", "/api/export.csv"):
                    self.call(route)
                with tempfile.TemporaryDirectory() as folder:
                    with self.server.lab.lock:
                        outputs = export_run(self.server.lab.sim, Path(folder) / "run")
                    exported = json.loads(outputs["json"].read_text())
                    self.assertEqual(exported["vehicle_configuration"]["id"], config)
                    self.assertEqual(exported["final_state"]["t"], 0)
                    self.assertTrue(all(path.is_file() for path in outputs.values()))
                self.assertEqual(self.call("/api/state"), initial)

    def test_legacy_reset_and_request_api_remain_available_without_scanner(self):
        reset = self.call("/api/reset", {"profile": "engine", "scenario": "manual"})
        self.assertNotIn("vehicle", reset["state"])
        self.assertIsNone(reset["scanner"])
        self.assertEqual(self.diagnostic("01 05")["diagnostic"]["response_hex"], "41 05 3C")
        self.assertTrue(all(s["available_now"] for s in self.call("/api/diagnostic-definitions")["services"]))
        self.assertNotIn("vehicle_configuration", self.call("/api/export.json"))


if __name__ == "__main__":
    unittest.main()
