/* Optional Node-only decoding contracts. Supply fixtures generated with Sim and
 * DiagnosticServer as JSON; these do not assert browser pixels or bus timing.
 * node tests/test_protocols_contract.cjs /path/to/protocol_fixtures.json
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const input=process.argv[2];if(!input)throw new Error('Supply a diagnostic fixture JSON path.');
const f=JSON.parse(fs.readFileSync(input,'utf8')),w={};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../web/protocols.js'),'utf8'),{window:w});
const api=w.ProtocolsView;let passed=0;
function test(name,fn){fn();passed++;process.stdout.write('PASS '+name+'\n');}
function same(value,expected){assert.deepEqual(JSON.parse(JSON.stringify(value)),expected);}
test('known engine-rpm example decodes exactly to 1726 rpm',()=>{
 const x=api.decodeResponse({request_hex:'01 0C',response_hex:'41 0C 1A F8'});
 assert.equal(x.value,1726);assert.equal(x.unit,'rpm');assert.match(x.calculation,/26 \+ 248/);
 same(x.fields.map(x=>x.label),['Response service','Parameter ID','A = 26','B = 248']);
});
test('actual model reply decodes to the rounded engine observation',()=>{
 const x=api.decodeResponse(f.rpm);assert.equal(x.value,Math.round(f.snapshot.rpm*4)/4);
 assert.notEqual(x.value,0);assert.equal(x.fields.length,4);
});
test('coolant marker decodes but is not passed off as physical temperature',()=>{
 const x=api.decodeResponse({request_hex:'01 05',response_hex:'41 05 00'});
 assert.equal(x.value,-40);assert.match(x.note,/invalid marker/);assert.match(x.title,/Reported/);
});
test('speed and load use the received data rather than any snapshot',()=>{
 assert.equal(api.decodeResponse({response_hex:'41 0D 32'}).value,50);
 assert.equal(api.decodeResponse({response_hex:'41 04 FF'}).value,100);
});
test('OBD and UDS identification recover the same synthetic ASCII identity',()=>{
 const a=api.decodeResponse(f.vin),b=api.decodeResponse(f.uds_vin);
 assert.equal(a.value,'LAB00000000000001');assert.equal(b.value,a.value);
 assert.equal(a.fields[1].label,'Info type');assert.equal(b.fields[1].label,'DID high');
});
test('negative response retains service and reason, without numeric sensor value',()=>{
 const x=api.decodeResponse(f.negative);assert.equal(x.title,'Negative response');assert.equal(x.value,'31');
 same(x.fields.map(x=>x.label),['Negative response','Requested service','Response code']);
});
test('disconnected DLC has no decoded value, bytes or invented delivered frame',()=>{
 const x=api.decodeResponse(f.isolated),j=api.buildJourney(f.isolated);
 assert.equal(x.value,null);assert.equal(x.fields.length,0);assert.equal(j[2].route,0);assert.equal(j[4].route,0);
 assert.equal(j[5].evidence,'Unavailable');assert.match(j[1].heading,/No delivered/);
});
test('single frame separates its declared four-byte response from padding',()=>{
 const x=api.inspectFrame(f.rpm.frames[1],1,f.rpm.frames);assert.equal(x.length,4);
 same(x.roles.map(x=>x.tone),['transport','value','value','value','value','padding','padding','padding']);
});
test('VIN FF gives 20 application bytes; FC contributes none to identity',()=>{
 const frames=f.uds_vin.frames;
 assert.equal(api.inspectFrame(frames[1],1,frames).length,20);
 const fc=api.inspectFrame(frames[2],2,frames);assert.equal(fc.roles.filter(x=>x.tone==='value').length,0);
 same(fc.roles.slice(0,3).map(x=>x.role),['Flow status','Block size','Separation time']);
});
test('last CF padding is computed from the application message length',()=>{
 const frames=f.part.frames,last=api.inspectFrame(frames.at(-1),frames.length-1,frames);
 const length=f.part.response_hex.split(' ').length,remaining=(length-6)%7||7;
 assert.equal(last.roles.filter(x=>x.tone==='value').length,remaining);
 assert.equal(last.roles.filter(x=>x.tone==='padding').length,7-remaining);
});
test('session timing and replay keep their roles separate',()=>{
 const x=api.decodeResponse(f.session);assert.equal(x.value,'Extended');assert.match(x.calculation,/P2 = 50 ms/);
 assert.match(x.calculation,/P2\* = 5000 ms/);assert.match(x.note,/simulation time/);
});
test('CAN and legacy highlights preserve their declared pin roles',()=>{
 same(api.pinModes.can.pins,[4,5,6,14,16]);assert.ok(api.pinModes.pwm.pins.includes(10));
 assert.ok(!api.pinModes.vpw.pins.includes(10));assert.equal(api.pins[6].name,'CAN-H');assert.equal(api.pins[14].name,'CAN-L');
 assert.equal(api.pins[1],undefined);assert.equal(api.layers.length,7);
});
console.log(JSON.stringify({suite:'protocol decoder and trace contracts',passed,failed:0,fixtures:'actual Python Sim / DiagnosticServer plus fixed encoding examples'}));
