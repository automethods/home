"""Conversion evidence must match held sensor samples and received bytes."""
from copy import deepcopy
import math
import unittest

from obdii_lab.core import Parameters, ect_circuit
from obdii_lab.server import Lab
from obdii_lab.vehicle_systems import SensorBank


class ConversionPathTests(unittest.TestCase):
    def vehicle(self):
        lab = Lab()
        lab.set_vehicle('petrol_advanced')
        lab.sim.control('ignition', True)
        lab.sim.advance(.2)
        return lab

    def test_ect_hex_and_inverse_equations_follow_custom_calibration(self):
        p = Parameters(ect_pullup_ohm=3300, ect_r25_ohm=4700, ect_beta_k=4100, ect_adc_bits=10)
        s = {'t': 0, 'inputs': {'ignition': True}, 'coolant_c': 73,
             'sensors': {**ect_circuit(73, p), 'ect_pullup_ohm': p.ect_pullup_ohm,
                         'ect_r25_ohm': p.ect_r25_ohm, 'ect_beta_k': p.ect_beta_k,
                         'ect_adc_bits': p.ect_adc_bits}}
        bank = SensorBank({'powertrain': 'petrol', 'engine_detail': 'extended'})
        bank.sample(s)
        reading = bank.readings['ect']
        rows = {row['label']: row['value'] for row in reading['conversion']['steps']}
        adc = s['sensors']['ect_adc_count']
        self.assertIn(f'0x{adc:03X} (10 bit)', rows['ADC code'])
        v = s['sensors']['ect_voltage_v']
        resistance = p.ect_pullup_ohm * v / (p.reference_voltage_v - v)
        reconstructed = 1 / (1 / 298.15 + math.log(resistance / p.ect_r25_ohm) / p.ect_beta_k) - 273.15
        displayed = float(rows['Temperature conversion'].split(' = ')[-1].split()[0])
        self.assertAlmostEqual(displayed, reconstructed, places=5)
        self.assertAlmostEqual(reading['value'], reconstructed)

    def test_analogue_path_is_held_until_sensor_sample_deadline(self):
        lab = self.vehicle()
        lab.sim.advance(.002)
        before = deepcopy(lab.sim.snapshot()['vehicle_sensors']['throttle_sensor'])
        lab.sim.advance(.002, {'throttle': .6})
        held = lab.sim.snapshot()['vehicle_sensors']['throttle_sensor']
        self.assertEqual(held['conversion'], before['conversion'])
        lab.sim.advance(.02)
        sampled = lab.sim.snapshot()['vehicle_sensors']['throttle_sensor']
        self.assertEqual(sampled['value'], 60)
        rows = {row['label']: row['value'] for row in sampled['conversion']['steps']}
        self.assertEqual(rows['Analogue input'], '2.9 V')
        self.assertTrue(rows['Voltage conversion'].endswith('= 60 %'))
        self.assertNotIn('ADC code', rows)

    def test_digital_hex_is_logic_state_and_missing_input_has_no_invented_bit(self):
        lab = self.vehicle()
        for pedal, expected in [(0, '0x00'), (.3, '0x01')]:
            lab.sim.advance(.03, {'brake': pedal})
            reading = lab.sim.snapshot()['vehicle_sensors']['brake_switch']
            self.assertIn(expected, reading['conversion']['steps'][0]['value'])
        lab.sim.set_connection('brake_switch', False)
        lab.sim.advance(.03)
        reading = lab.sim.snapshot()['vehicle_sensors']['brake_switch']
        self.assertEqual(reading['validity'], 'invalid')
        self.assertEqual([r['label'] for r in reading['conversion']['steps']], ['Input validity'])

    def test_pulse_conversion_matches_sampled_crankshaft_speed(self):
        lab = self.vehicle()
        lab.sim.control('start')
        lab.sim.advance(1)
        reading = lab.sim.snapshot()['vehicle_sensors']['crank_sensor']
        rows = {row['label']: row['value'] for row in reading['conversion']['steps']}
        self.assertIn('N = 60 pulses/rev', rows['Pulse input'])
        decoded = float(rows['Pulse conversion'].split(' = ')[-1])
        self.assertAlmostEqual(decoded, reading['value'], places=4)

    def test_open_ect_exposes_saturated_adc_and_invalid_marker_without_inversion(self):
        lab = self.vehicle()
        lab.sim.set_connection('ect', False)
        lab.sim.advance(.03)
        reading = lab.sim.snapshot()['vehicle_sensors']['ect']
        rows = {row['label']: row['value'] for row in reading['conversion']['steps']}
        self.assertIn('0xFFF', rows['ADC code'])
        self.assertIn('Invalid display marker', rows)
        self.assertNotIn('Temperature conversion', rows)

    def test_scanner_keeps_conversion_at_response_time_and_declines_missing_maf(self):
        lab = self.vehicle()
        lab.scanner.connect('can11_500', 'ecu')
        reply = lab.scanner.request('01 11')
        conversion = deepcopy(reply['sensor_conversion'])
        self.assertEqual(reply['response_hex'], '41 11 00')
        self.assertEqual(reply['sensor_id'], 'throttle_sensor')
        lab.sim.advance(.03, {'throttle': .5})
        self.assertEqual(reply['sensor_conversion'], conversion)
        self.assertNotEqual(reply['sensor_conversion'], lab.sim.snapshot()['vehicle_sensors']['throttle_sensor']['conversion'])
        lab.sim.set_connection('maf', False)
        lab.sim.advance(.06)
        missing = lab.scanner.request('01 10')
        self.assertIsNone(missing['response_hex'])
        self.assertEqual(missing['sensor_conversion']['steps'][0]['label'], 'Input validity')


if __name__ == '__main__':
    unittest.main()
