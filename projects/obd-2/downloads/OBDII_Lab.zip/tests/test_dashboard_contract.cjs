/* Dashboard interaction contracts using the actual module and an intentionally
 * limited generic HTML-node harness. Real NAPI Canvas draws the product charts;
 * Python Sim / DiagnosticServer generate the request fixtures without sockets.
 * This is not browser layout, accessibility-tree, GPU or native-event testing.
 * Run: node tests/test_dashboard_contract.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const fixtureRun=spawnSync('python',['-c',`
from obdii_lab.core import Sim
from obdii_lab.runner import diagnostic_server
import json
s=Sim('phev','city_drive'); states={'start':s.snapshot()}
s.advance(5); states['at5']=s.snapshot(); d=diagnostic_server(s)
requests=['01 0D','01 0C','01 05','01 04']
healthy={p:d.request(p,can_id=0x7df) for p in requests}
s.advance(1); states['at6']=s.snapshot(); s.advance(1); states['at7']=s.snapshot()
s.set_connection('dlc',False); states['open']=s.snapshot()
missing={p:d.request(p,can_id=0x7df) for p in requests}
s.advance(1); states['at8']=s.snapshot(); s.advance(1); states['at9']=s.snapshot()
m=Sim('phev','manual',{'initial_speed_kph':25});m.advance(.1,{'throttle':.15});states['manual']=m.snapshot()
print(json.dumps({'states':states,'healthy':healthy,'missing':missing,'events':s.events[-5:]}))
`],{cwd:root,encoding:'utf8'});
assert.equal(fixtureRun.status,0,fixtureRun.stderr);const fixtures=JSON.parse(fixtureRun.stdout);
const decodeEntities=s=>s.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'");
const kebab=s=>s.replace(/[A-Z]/g,x=>'-'+x.toLowerCase());
class Node {
 constructor(tag='div',attrs={},text=''){this.tagName=tag.toUpperCase();this.attrs={...attrs};this.children=[];this.parentElement=null;this.ownText=text;this.style={};this.listeners=new Map();this._value=undefined;this._checked=undefined;this._disabled=undefined;this.onclick=null;this.onchange=null;this.oninput=null;this._width=300;this._height=150;this.native=null;
  this.dataset=new Proxy({}, {get:(_,key)=>this.attrs['data-'+kebab(String(key))],set:(_,key,v)=>(this.attrs['data-'+kebab(String(key))]=String(v),true)});
  this.classList={contains:name=>(this.attrs.class||'').split(/\s+/).includes(name),add:(...names)=>{this.attrs.class=[...new Set([...(this.attrs.class||'').split(/\s+/).filter(Boolean),...names])].join(' ');},remove:(...names)=>{this.attrs.class=(this.attrs.class||'').split(/\s+/).filter(x=>!names.includes(x)).join(' ');},toggle:(name,on)=>{const present=this.classList.contains(name),next=on===undefined?!present:!!on;next?this.classList.add(name):this.classList.remove(name);return next;}};
 }
 appendChild(n){n.parentElement=this;this.children.push(n);return n;}
 setAttribute(k,v){this.attrs[k]=String(v);}getAttribute(k){return this.attrs[k]??null;}removeAttribute(k){delete this.attrs[k];}hasAttribute(k){return Object.hasOwn(this.attrs,k);}toggleAttribute(k,on){const next=on===undefined?!this.hasAttribute(k):!!on;next?this.setAttribute(k,''):this.removeAttribute(k);return next;}
 get value(){if(this._value!==undefined)return this._value;if(this.attrs.value!==undefined)return this.attrs.value;if(this.tagName==='SELECT'){const opts=this.querySelectorAll('option');return (opts.find(x=>x.hasAttribute('selected'))||opts[0])?.value||'';}return '';}
 set value(v){this._value=String(v);}get checked(){return this._checked??this.hasAttribute('checked');}set checked(v){this._checked=!!v;}get disabled(){return this._disabled??this.hasAttribute('disabled');}set disabled(v){this._disabled=!!v;}
 get hidden(){return this.hasAttribute('hidden');}set hidden(v){this.toggleAttribute('hidden',v);}
 set innerHTML(html){this.children=[];this.ownText='';parseHTML(String(html),this);this.rawHTML=String(html);}get innerHTML(){return this.rawHTML||this.textContent;}
 get textContent(){return this.ownText+this.children.map(c=>c.textContent).join('');}set textContent(value){this.children=[];this.ownText=String(value);this.rawHTML='';}
 matches(selector){selector=selector.trim();if(!selector)return false;const tag=selector.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;for(const match of selector.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;for(const match of selector.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}return true;}
 closest(selector){for(let n=this;n;n=n.parentElement)if(n.matches(selector))return n;return null;}
 querySelectorAll(selector){const choices=selector.split(',').map(x=>x.trim().split(/\s+/)),out=[];function test(node,parts){let k=parts.length-1;if(!node.matches(parts[k]))return false;let n=node.parentElement;while(--k>=0){while(n&&!n.matches(parts[k]))n=n.parentElement;if(!n)return false;n=n.parentElement;}return true;}function walk(node){for(const child of node.children){if(child.tagName!=='#TEXT'&&choices.some(parts=>test(child,parts)))out.push(child);walk(child);}}walk(this);return out;}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
 addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,[]);this.listeners.get(type).push(fn);}removeEventListener(type,fn){this.listeners.set(type,(this.listeners.get(type)||[]).filter(x=>x!==fn));}
 async dispatchEvent(event){event.target=event.target||this;event.currentTarget=this;event.preventDefault=event.preventDefault||(()=>{});if(this['on'+event.type])await this['on'+event.type](event);for(const fn of this.listeners.get(event.type)||[])await fn(event);return true;}
 async click(){if(!this.disabled)await this.dispatchEvent({type:'click',target:this});}
 getBoundingClientRect(){return {width:this.hasAttribute('data-spark')?230:480,height:this.hasAttribute('data-spark')?40:170,left:0,top:0,right:480,bottom:170};}
 get width(){return this._width;}set width(v){this._width=Math.max(1,Math.round(v));if(this.native)this.native.width=this._width;}get height(){return this._height;}set height(v){this._height=Math.max(1,Math.round(v));if(this.native)this.native.height=this._height;}
 getContext(type){assert.equal(type,'2d');if(!this.native)this.native=createCanvas(this._width,this._height);return this.native.getContext('2d');}
 replaceChildren(){this.children=[];this.ownText='';}
}
function parseHTML(html,root){const stack=[root],voids=new Set(['INPUT','META','LINK','BR','HR','IMG','AREA','BASE','COL','EMBED','PARAM','SOURCE','TRACK','WBR']);for(const token of html.match(/<!--[\s\S]*?-->|<[^>]+>|[^<]+/g)||[]){if(token.startsWith('<!--')||token.startsWith('<!'))continue;if(token.startsWith('</')){const tag=token.slice(2,-1).trim().toUpperCase();while(stack.length>1){const top=stack.pop();if(top.tagName===tag)break;}continue;}if(token.startsWith('<')){const tag=token.match(/^<([\w:-]+)/)?.[1];if(!tag)continue;const attrs={};const rest=token.slice(tag.length+1,-1).replace(/\/$/,'');for(const m of rest.matchAll(/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))attrs[m[1]]=decodeEntities(m[2]??m[3]??m[4]??'');const node=new Node(tag,attrs);stack.at(-1).appendChild(node);if(!voids.has(node.tagName)&&!token.endsWith('/>'))stack.push(node);}else stack.at(-1).appendChild(new Node('#text',{},decodeEntities(token)));}}
const elements=new Node('main'),events=new Map(),timers=new Map();let nextTimer=1,running=false,busy=false,rafCount=0;
const calls={requests:[],inputs:[],connections:[],presets:[],nested:0,errors:[],vehicleVisibility:[]};
const w={devicePixelRatio:1,addEventListener(type,fn){if(!events.has(type))events.set(type,[]);events.get(type).push(fn);},removeEventListener(type,fn){events.set(type,(events.get(type)||[]).filter(x=>x!==fn));},dispatchEvent(event){for(const fn of events.get(event.type)||[])fn(event);},LabUI:{isRunning:()=>running,isBusy:()=>busy,setInputs:x=>calls.inputs.push(x),report:x=>calls.errors.push(x),pause:async()=>{running=false;},advance:async()=>{}},VehicleView:{create(root){root.innerHTML='<button data-action="restore-sample" data-connection="nested-only"><em>Own control</em></button>';const button=root.querySelector('button');button.onclick=()=>{calls.nested++;};return{update(){},setVisible:x=>calls.vehicleVisibility.push(x),setTheme(){},resize(){},inspect:()=>({fixture:true}),dispose(){}};}}};
let source=fs.readFileSync(path.join(root,'web/dashboard.js'),'utf8');const anchor='      inspect:()=>({sampleCount:';assert.equal(source.split(anchor).length,2,'Dashboard test instrumentation anchor');source=source.replace(anchor,'      contractInspect:()=>({samples,scanSamples,details,frames,spec:chartSpec("compare")}),\n'+anchor);
vm.runInNewContext(source,{window:w,document:{activeElement:null},console,ResizeObserver:class{observe(){}disconnect(){}},requestAnimationFrame(fn){if(rafCount++<2000)fn(0);return rafCount;},setInterval(fn){const id=nextTimer++;timers.set(id,fn);return id;},clearInterval:id=>timers.delete(id)});
let missing=false,current=fixtures.states.at5;
const view=w.DashboardView.create(elements,{onPreset:async(id,definition)=>calls.presets.push({id,definition}),onConnection:async(id,value)=>calls.connections.push({id,value}),onRequest:async(payload,canId)=>{calls.requests.push({payload,canId});return JSON.parse(JSON.stringify((missing?fixtures.missing:fixtures.healthy)[payload]||{request_hex:payload,response_hex:'43 00',meaning:'No codes',frames:[]}));}});
const $=s=>{const x=elements.querySelector(s);assert.ok(x,'Missing actual markup '+s);return x;};
const equal=(actual,expected,message)=>assert.deepEqual(JSON.parse(JSON.stringify(actual)),expected,message);
const update=(state,history=[])=>{current=state;view.update({state,history,events:fixtures.events},{components:[{id:'engine',label:'Engine'}]});};
let passed=0,failed=0;async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(e){failed++;console.error('FAIL '+name+'\n'+e.stack);}}
const flush=async()=>{for(let i=0;i<20;i++)await new Promise(resolve=>setImmediate(resolve));};
(async()=>{
 await test('update renders real physical telemetry and draws actual Canvas charts',()=>{update(fixtures.states.at5,[fixtures.states.start,fixtures.states.at5]);assert.equal($('[data-metric="speed"]').textContent,fixtures.states.at5.speed_kph.toFixed(1));assert.equal($('[data-metric="rpm"]').textContent,fixtures.states.at5.rpm.toFixed(0));assert.ok($('[data-chart="speed"]').native);assert.ok($('[data-chart="speed"]').native.toBuffer('image/png').length>1000);assert.equal(view.inspect().sampleCount,2);});
 await test('nested vehicle controls retain their own handlers and status',async()=>{const nested=$('.dash-vehicle-root [data-action]');await nested.click();assert.equal(calls.nested,1);assert.equal(nested.querySelector('em').textContent,'Own control');assert.equal(calls.connections.length,0);});
 await test('Scan now issues the four real requests and decodes the selected PID',async()=>{await $('[data-action="scan-once"]').click();equal(calls.requests.map(x=>[x.payload,x.canId]),[['01 0D','7DF'],['01 0C','7DF'],['01 05','7DF'],['01 04','7DF']]);assert.equal(view.inspect().requests,4);assert.equal(view.inspect().replies,4);assert.equal(view.inspect().frameCount,8);assert.match($('[data-scan-count]').textContent,/4 requests · 4 replies/);assert.equal(view.contractInspect().details.speed.value,parseInt(fixtures.healthy['01 0D'].response_hex.split(' ')[2],16));});
 await test('selecting a signal updates metric selection, formula and raw reply',async()=>{await $('[data-signal="rpm"]').click();assert.equal(view.inspect().selectedSignal,'rpm');assert.equal($('[data-compare]').value,'rpm');assert.match($('[data-decode-formula]').textContent,/256 ×/);assert.equal($('[data-response-bytes]').textContent,fixtures.healthy['01 0C'].response_hex);assert.equal($('[data-signal="rpm"]').classList.contains('active'),true);});
 await test('manual profile enables controls and forwards normalized input',async()=>{update(fixtures.states.manual);assert.equal($('[data-input="throttle"]').disabled,false);$('[data-input="throttle"]').value='42';await $('[data-input="throttle"]').dispatchEvent({type:'input'});equal(calls.inputs.at(-1),{throttle:.42});await $('[data-preset="road_cruise"]').click();assert.equal(calls.presets.at(-1).definition.scenario,'road_cruise');});
 await test('connection toggle is scoped to the health list',async()=>{update(fixtures.states.at5);await $('.dash-connection-list [data-connection="dlc"]').click();equal(calls.connections.at(-1),{id:'dlc',value:false});});
 await test('a missing response adds a chart gap and cannot fabricate a decoded reply',async()=>{const previousReplies=view.inspect().replies,previousFrames=view.inspect().frameCount;missing=true;update(fixtures.states.open);await view.scanOnce();assert.equal(view.inspect().replies,previousReplies);assert.equal(view.inspect().frameCount,previousFrames);assert.equal(view.contractInspect().scanSamples.rpm.at(-1).v,null);assert.equal(view.contractInspect().details.rpm.d.response_hex,fixtures.healthy['01 0C'].response_hex);assert.match($('[data-decode-note]').textContent,/last successful reply|no new reply/i);});
 await test('capture pause leaves no false continuous bridge across uncaptured time',async()=>{update(fixtures.states.at7);await $('[data-action="record"]').click();const before=view.inspect().sampleCount;update(fixtures.states.at8);assert.ok(view.inspect().sampleCount<=before+1,'At most one gap marker when pausing');await $('[data-action="record"]').click();update(fixtures.states.at9);const samples=view.contractInspect().samples;assert.ok(samples.some(s=>s.t>=fixtures.states.at7.t&&s.t<=fixtures.states.at9.t&&(s.speed_kph===null||s.capture_gap===true)),'Uncaptured interval has an explicit missing-value marker');});
 await test('hiding the dashboard prevents the auto poll timer from issuing new requests',async()=>{running=true;update(fixtures.states.at9);view.setVisible(false);const before=calls.requests.length;for(const fn of timers.values())fn();await flush();assert.equal(calls.requests.length,before);assert.equal(calls.vehicleVisibility.at(-1),false);view.setVisible(true);running=false;});
 await test('reset clears counts, scan status and all captured diagnostic details',()=>{w.dispatchEvent({type:'lab:reset'});const info=view.inspect();assert.equal(info.requests,0);assert.equal(info.replies,0);assert.equal(info.frameCount,0);assert.equal(info.sampleCount,0);assert.match($('[data-scan-count]').textContent,/0 requests · 0 replies/);assert.doesNotMatch($('[data-scan-status]').textContent,/Reply received at|No response/);assert.equal($('[data-response-bytes]').textContent,'—');});
 await test('disposal clears the automatic poll timer',()=>{view.dispose();assert.equal(timers.size,0);assert.equal(calls.errors.length,0,calls.errors.join('\n'));});
 console.log(JSON.stringify({suite:'dashboard interaction contracts',passed,failed,canvas:'actual @napi-rs/canvas CPU rasterizer',fixtures:'actual Python Sim / DiagnosticServer',scope:'Parsed node harness and actual JS callbacks; no browser layout, native DOM or GPU verification'}));process.exitCode=failed?1:0;
})();
