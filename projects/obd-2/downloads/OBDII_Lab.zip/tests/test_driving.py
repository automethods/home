"""Natural demonstration routes must exercise the plant, not draw fake data."""
import json
import unittest

from obdii_lab.core import DRIVE_CYCLES, SCENARIOS, Sim
from obdii_lab.instrumentation import read_signals


class DrivingTests(unittest.TestCase):
    def test_live_routes_use_declared_initial_state_and_complete_metadata(self):
        for name, cycle in DRIVE_CYCLES.items():
            sim = Sim(scenario=name)
            state = sim.snapshot()
            self.assertEqual(state["profile"], "phev")
            self.assertEqual(state["speed_kph"], cycle["initial_config"]["initial_speed_kph"])
            self.assertEqual(state["coolant_c"], cycle["initial_config"]["initial_coolant_c"])
            self.assertEqual(state["drive_cycle"]["progress"], 0)
            entry = next(item for item in SCENARIOS if item["id"] == name)
            self.assertEqual(entry["phases"][-1]["end_s"], entry["duration"])
            # An explicit learner configuration still takes priority.
            changed = Sim(scenario=name, config={"initial_speed_kph": 5, "initial_soc_pct": 22})
            self.assertEqual(changed.snapshot()["speed_kph"], 5)
            self.assertEqual(changed.snapshot()["soc_pct"], 22)

    def test_targets_are_continuous_and_pedals_are_bounded(self):
        for name, cycle in DRIVE_CYCLES.items():
            sim = Sim(scenario=name)
            for phase in cycle["phases"][:-1]:
                edge = phase[1]
                before, after = sim._drive_program(edge - 1e-6), sim._drive_program(edge + 1e-6)
                self.assertAlmostEqual(before["target_kph"], after["target_kph"], places=8)
                self.assertAlmostEqual(before["target_acceleration_m_s2"], 0, places=5)
                self.assertAlmostEqual(after["target_acceleration_m_s2"], 0, places=5)
            sim.advance(cycle["duration"])
            for point in sim.history:
                self.assertGreaterEqual(point["inputs"]["throttle"], 0)
                self.assertLessEqual(point["inputs"]["throttle"], .9)
                self.assertGreaterEqual(point["inputs"]["brake"], 0)
                self.assertLessEqual(point["inputs"]["brake"], .6)
                self.assertFalse(point["inputs"]["throttle"] > 0 and point["inputs"]["brake"] > 0)
                json.dumps(point, allow_nan=False)

    def test_city_drives_stops_recovers_energy_and_uses_hybrid_engine(self):
        sim = Sim(scenario="city_drive")
        state = sim.advance(90)
        self.assertEqual(state["speed_kph"], 0)
        self.assertTrue(state["drive_cycle"]["complete"])
        self.assertGreater(state["distance_m"], 700)
        self.assertLess(state["distance_m"], 850)
        self.assertGreater(state["energy"]["fuel_l"], 0)
        self.assertGreater(state["energy"]["battery_charge_kwh"], 0)
        modes = {point["mode"] for point in sim.history}
        self.assertTrue({"EV", "HYBRID", "REGEN + FRICTION"}.issubset(modes))
        self.assertTrue(any(33 <= point["t"] <= 38 and point["speed_kph"] == 0 for point in sim.history))
        self.assertGreater(max(point["rpm"] for point in sim.history), 2000)
        self.assertLess(max(point["speed_kph"] for point in sim.history), 65)

    def test_actual_speed_and_faults_do_not_follow_a_forced_animation(self):
        sim = Sim(scenario="city_drive")
        sim.advance(4)
        sim.set_connection("bmu", False)
        state = sim.advance(12)
        self.assertEqual(state["contactor"], "FAULT")
        self.assertEqual(state["motor_power_kw"], 0)
        self.assertEqual(state["engine_power_kw"], 0)
        self.assertGreater(state["drive_target_kph"] - state["speed_kph"], 15)
        self.assertGreater(state["sensors"]["bmu_message_age_ms"], 300)

    def test_chunking_snapshot_and_manual_override_contract(self):
        a, b = Sim(scenario="road_cruise"), Sim(scenario="road_cruise")
        a.advance(8)
        for _ in range(80):
            b.advance(.1)
        self.assertEqual(a.snapshot(), b.snapshot())
        held = a.snapshot()
        self.assertEqual(a.snapshot(), held)  # Reading the dashboard never runs the plant.
        state = a.advance(1, {"throttle": 0, "brake": .3})
        state = a.advance(1)
        self.assertEqual(state["inputs"]["throttle"], 0)
        self.assertEqual(state["inputs"]["brake"], .3)
        self.assertEqual(state["drive_cycle"]["driver_overrides"], ["brake", "throttle"])
        self.assertEqual(state["drive_cycle"]["driver"], "manual override")

    def test_new_probes_are_actual_model_values_with_explicit_provenance(self):
        sim = Sim(scenario="city_drive")
        state = sim.advance(12)
        signals = read_signals(state)
        for key in ("distance_m", "acceleration_m_s2", "load_pct"):
            self.assertEqual(signals[key]["value"], state[key])
            self.assertEqual(signals[key]["validity"], "valid")
        self.assertEqual(signals["energy.fuel_l"]["value"], state["energy"]["fuel_l"])
        plain = Sim(profile="phev").snapshot()
        self.assertIsNone(plain["drive_target_kph"])
        self.assertIsNone(plain["drive_cycle"])


if __name__ == "__main__":
    unittest.main()
