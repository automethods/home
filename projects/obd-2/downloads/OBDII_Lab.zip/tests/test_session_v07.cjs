/* The actual Session module against the actual loopback Python HTTP API.
 * A controlled clock and deferred fetch gates exercise command ordering.
 * No browser, GPU or native DOM is involved.
 * Run: node tests/test_session_v07.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const child=spawn('python3',['-u','-c',"from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()"],{cwd:root,stdio:['ignore','pipe','pipe']});
let stderr='',startText='',settled=false;child.stderr.on('data',data=>stderr+=data);
const started=new Promise((resolve,reject)=>{const timer=setTimeout(()=>{if(!settled){settled=true;reject(new Error('Loopback server startup timeout: '+stderr));}},8000);child.stdout.on('data',data=>{startText+=data;if(startText.includes('\n')&&!settled){settled=true;clearTimeout(timer);resolve(Number(startText.trim().split('\n')[0]));}});child.on('error',error=>{if(!settled){settled=true;clearTimeout(timer);reject(error);}});child.on('exit',code=>{if(!settled){settled=true;clearTimeout(timer);reject(new Error('Loopback server exited '+code+': '+stderr));}});});
const equal=(a,b,message)=>assert.deepEqual(JSON.parse(JSON.stringify(a)),b,message);
const microtasks=async()=>{for(let i=0;i<5;i++)await Promise.resolve();};
let passed=0,failed=0;
async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(error){failed++;console.error('FAIL '+name+'\n'+error.stack);}}
const events=[],timers=new Map(),calls=[],gates=[];let nextTimer=1,activeMutations=0,maxMutations=0,session;
function holdNext(route){let release,mark;const wait=new Promise(resolve=>release=resolve),entered=new Promise(resolve=>mark=resolve);const gate={route,wait,entered,release,mark};gates.push(gate);return gate;}
async function fireClock(){const first=timers.entries().next();assert.equal(first.done,false,'A playback tick is scheduled');const [id,fn]=first.value;timers.delete(id);await fn();await microtasks();}
(async()=>{
 const port=await started;assert.ok(Number.isInteger(port)&&port>0);const base='http://127.0.0.1:'+port;
 const wrappedFetch=async(route,init={})=>{
   const mutation=init.method==='POST',entry={route,body:init.body?JSON.parse(init.body):null};calls.push(entry);
   if(mutation){activeMutations++;maxMutations=Math.max(maxMutations,activeMutations);}
   try{const index=gates.findIndex(gate=>gate.route===route);if(index>=0){const gate=gates.splice(index,1)[0];gate.mark();await gate.wait;}return await fetch(base+route,init);}
   finally{if(mutation)activeMutations--;}
 };
 const w={dispatchEvent:event=>events.push(event)},sandbox={window:w,console,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},setTimeout:(fn,delay)=>{assert.equal(delay,100);const id=nextTimer++;timers.set(id,fn);return id;},clearTimeout:id=>timers.delete(id)};
 vm.runInNewContext(fs.readFileSync(path.join(root,'web/session.js'),'utf8'),sandbox);
 session=w.AppSession.create({fetch:wrappedFetch});
 await test('initialization creates one parked vehicle with configured units and a disconnected scan tool',async()=>{
   await session.initialize();await session.command;
   const ctx=session.context();assert.equal(ctx.ready,true);assert.equal(ctx.state.vehicle.configuration.id,'petrol_basic');assert.equal(ctx.state.vehicle.ignition,'off');assert.equal(ctx.state.vehicle.selector,'P');assert.equal(ctx.state.t,0);assert.equal(ctx.running,false);assert.equal(ctx.busy,false);assert.ok(ctx.signals.length>73);assert.ok(ctx.catalog.components.length>13);assert.equal(ctx.history.length,1);assert.equal(timers.size,0);
   equal(calls.filter(c=>c.route==='/api/vehicle').map(c=>c.body),[{configuration:'petrol_basic',options:{}}]);assert.equal(ctx.scanner.connected,false);

 });
 await session.commitSetup('petrol_basic',{},session.testSettings);session.enterWorkspace('drive');await session.command;
 await test('selection, views and graph choices never issue simulator mutations',()=>{
   const before=calls.length,history=session.history;session.select('socket:coolant_socket');session.navigate('wiring');session.setWatch('sensors.ect_voltage_v',true);session.navigate('diagnosis');
   assert.equal(calls.length,before);assert.equal(session.context().state.t,0);assert.equal(session.history,history);assert.equal(session.view,'diagnostics');assert.equal(session.diagnosticView,'tests');assert.equal(session.selection,'socket:coolant_socket');assert.ok(session.watch.includes('sensors.ect_voltage_v'));
   const beforeWatch=session.watch.length;session.setWatch('unknown.channel',true);assert.equal(session.watch.length,beforeWatch);
 });
 await test('repeated Run retains one clock and advances by one physical tick per callback',async()=>{
   session.setRunning(true);session.setRunning(true);assert.equal(timers.size,1);await fireClock();assert.equal(session.context().state.t,.1);assert.equal(timers.size,1);await fireClock();assert.equal(session.context().state.t,.2);assert.equal(timers.size,1);
   const play=events.filter(e=>e.type==='lab:play').at(-1);assert.equal(play.detail.running,true);assert.equal(play.detail.playing,true);session.setRunning(false);assert.equal(timers.size,0);
 });
 await test('deferred playback, request and connection commands remain in strict order',async()=>{
   await session.control('ignition',true);session.setRunning(false);await session.scannerAction('connect',{protocol:'can11_500',module:'ecu'});
   const gate=holdNext('/api/advance'),start=calls.length;session.setRunning(true);const tick=fireClock();await gate.entered;
   const request=session.request('01 0C','7DF'),connection=session.connection('ect',false);await microtasks();
   equal(calls.slice(start).map(c=>c.route),['/api/advance']);assert.equal(session.context().busy,true);
   gate.release();await tick;const answer=await request;await connection;await session.command;session.setRunning(false);
   equal(calls.slice(start).map(c=>c.route),['/api/advance','/api/diagnostic','/api/connection']);assert.equal(answer.sample_t,.3);assert.equal(session.context().state.t,.3);assert.equal(maxMutations,1);assert.equal(activeMutations,0);
   assert.equal(session.context().state.connections.ect,false);assert.ok(answer.frames.length>0);assert.ok(session.records.every(record=>record.t===answer.sample_t));
 });
 await test('explicit step pauses playback and includes persisted driver inputs',async()=>{
   await session.setInputs({throttle:.42,brake:.07});session.setRunning(true);assert.equal(timers.size,1);
   const before=session.context().state.t;await session.advance(.2);await session.command;
   assert.equal(session.running,false);assert.equal(timers.size,0);assert.equal(session.context().state.t,Number((before+.2).toFixed(6)));
   equal(calls.filter(c=>c.route==='/api/advance').at(-1).body.inputs,{throttle:.42,brake:.07,steer_deg:0,road_mu:.9,grade_pct:0});assert.equal(session.context().state.inputs.throttle,.42);
 });
 await test('DLC timeout records the actual request time and no fabricated CAN frame',async()=>{
   await session.connection('dlc',false);const t=session.context().state.t,count=session.records.length;
   const answer=await session.request('01 0C','7DF');await session.command;
   assert.equal(answer.sample_t,t);assert.equal(answer.response_hex,null);assert.equal(answer.frames.length,0);assert.equal(session.records.length,count+1);assert.equal(session.records.at(-1).frame,null);assert.equal(session.records.at(-1).diagnostic.timeout,true);assert.equal(session.context().state.t,t);
 });
 await test('reset retains configured hardware and navigation while clearing the previous drive',async()=>{
   session.navigate('locations');session.select('wire:ect_signal');await session.reset();await session.command;
   const ctx=session.context();assert.equal(ctx.state.t,0);assert.equal(ctx.state.vehicle.configuration.id,'petrol_basic');assert.equal(ctx.state.vehicle.selector,'P');assert.equal(ctx.records.length,0);assert.equal(ctx.diagnostic,null);assert.equal(ctx.history.length,1);assert.equal(session.recordNumber,0);assert.equal(ctx.view,'units');assert.equal(ctx.unitView,'locations');assert.equal(ctx.selection,'overview');equal(ctx.inputs,{throttle:0,brake:0,steer_deg:0,road_mu:.9,grade_pct:0});
   assert.ok(ctx.events.every(e=>Number(e.t ?? e.time ?? 0)===0));
 });
 await test('hybrid timeout recovery requires an explicit ignition and READY restart',async()=>{
   await session.configure('phev');await session.control('ignition',true);await session.control('start');await session.advance(1);
   await session.connection('bmu',false);await session.advance(.6);assert.equal(session.context().state.contactor,'FAULT');
   await session.connection('bmu',true);await session.advance(.2);assert.equal(session.context().state.contactor,'FAULT');
   await session.control('ignition',false);await session.advance(.2);assert.equal(session.context().state.vehicle.ignition,'off');assert.equal(session.context().state.contactor,'OFF');
   await session.control('ignition',true);await session.advance(.2);assert.notEqual(session.context().state.contactor,'CLOSED');
   await session.control('start');await session.advance(1);await session.command;assert.equal(session.context().state.contactor,'CLOSED');assert.ok(session.context().state.module_dtc.PHEV_ECU.includes('BMU_STATUS_TIMEOUT'));
 });
 await test('helpers preserve unavailable numeric readings and resolve linked objects',async()=>{
   await session.connection('wheel_fl',false);await session.advance(.2);const ctx=session.context();
   assert.equal(w.AppModel.valueAt(ctx.state,'sensors.wheel_speeds_kph.0'),null);assert.equal(typeof w.AppModel.valueAt(ctx.state,'wheel_speeds_kph.0'),'number');
   const wire=w.AppModel.resolveSelection('wire:ect_signal',ctx.catalog,ctx.signals);assert.equal(wire.componentId,'coolant_sensor');assert.equal(wire.signalId,'sensors.ect_voltage_v');
   const pin=w.AppModel.resolveSelection('pin:dlc_socket:6',ctx.catalog,ctx.signals);assert.equal(pin.componentId,'dlc');assert.equal(pin.pin,6);
   assert.ok(w.AppModel.signalIdsForComponent('wheel_fl',ctx.signals).includes('sensors.wheel_speeds_kph.0'));assert.ok(w.AppModel.signalIdsForComponent('abs',ctx.signals).includes('abs_active'));
 });
 await test('a failed queued command reports the error and does not poison later commands',async()=>{
   session.setRunning(true);await assert.rejects(session.connection('unknown',false),/Unknown.*connection/);await session.command;
   assert.equal(session.running,true);assert.equal(timers.size,1);assert.match(session.error,/Unknown.*connection/);assert.equal(session.context().busy,false);
   await session.connection('wheel_fl',true);await session.command;assert.equal(session.error,'');assert.equal(session.context().state.connections.wheel_fl,true);
 });
 await test('diagnostic polling honors 250 ms simulated intervals without a second clock',async()=>{
   session.setRunning(false);await session.scannerAction('connect',{protocol:'can11_500',module:'ecu'});
   session.setScannerPolling({enabled:true,interval:.25,payload:'01 0C',canId:'7DF'});const before=session.context().state.t,start=calls.length;
   await session.advance(1);await session.command;
   const requests=calls.slice(start).filter(c=>c.route==='/api/diagnostic');assert.equal(requests.length,4);assert.equal(timers.size,0);
   const times=[...new Set(session.records.filter(r=>r.t>before).map(r=>r.t))];equal(times,[.25,.5,.75,1].map(dt=>Number((before+dt).toFixed(6))));
   session.setScannerPolling({enabled:false});
 });
 await test('intermittent commands share the command queue and simulation clock',async()=>{
   await session.configure('petrol_basic');await session.control('ignition',true);await session.control('start');await session.advance(1);
   const gate=holdNext('/api/advance'),start=calls.length;session.setRunning(true);const tick=fireClock();await gate.entered;
   const fault=session.connectionFault('maf',{mode:'intermittent',pattern:'regular',connected_s:1,dropout_s:1});await microtasks();
   equal(calls.slice(start).map(c=>c.route),['/api/advance']);gate.release();await tick;await fault;await session.command;session.setRunning(false);
   equal(calls.slice(start).map(c=>c.route),['/api/advance','/api/connection-fault']);assert.equal(maxMutations,1);assert.equal(timers.size,0);
   const paused=JSON.stringify(session.context().state.connection_faults);session.select('component:maf');session.navigate('wiring');await microtasks();
   assert.equal(JSON.stringify(session.context().state.connection_faults),paused);assert.equal(timers.size,0);
   await session.advance(1.7);let ctx=session.context();assert.equal(ctx.state.connection_faults.maf.phase,'dropout');assert.equal(ctx.state.vehicle_sensors.maf.validity,'invalid');assert.ok(ctx.state.dtcs.includes('P0102'));
   await session.advance(.5);ctx=session.context();assert.equal(ctx.state.connection_faults.maf.phase,'connected');assert.equal(ctx.state.vehicle_sensors.maf.validity,'valid');assert.ok(ctx.state.dtcs.includes('P0102'));
 });
 await test('invalid intermittent settings preserve the schedule and direct repair stops it',async()=>{
   const before=JSON.stringify(session.context().state.connection_faults);await assert.rejects(session.connectionFault('maf',{connected_s:-1}));await session.command;
   assert.equal(JSON.stringify(session.context().state.connection_faults),before);assert.equal(session.context().busy,false);
   await session.connection('maf',true);await session.advance(2);assert.equal(session.context().state.connection_faults.maf,undefined);assert.equal(session.context().state.connections.maf,true);assert.ok(session.context().state.dtcs.includes('P0102'));
 });
 await test('off-grid recording keeps anchored deadlines and includes the actual final snapshot',async()=>{
   await session.configure('petrol_basic');await session.advance(.35);session.setLogInterval(1);
   const start=session.logHistory.length;await session.advance(3);await session.command;
   equal(session.logHistory.slice(start).map(s=>s.t),[1.4,2.4,3.35]);assert.ok(Math.abs(session.nextLogTime-4.35)<1e-7);
   session.setLogInterval(.1);const fast=session.logHistory.length;await session.advance(.3);
   equal(session.logHistory.slice(fast).map(s=>s.t),[3.5,3.6,3.65]);assert.ok(Math.abs(session.nextLogTime-3.75)<1e-7);
   assert.ok(session.logHistory.every((s,i,a)=>i===0||s.t>a[i-1].t));
 });
 await test('minute recording does not slow controller samples and exports validity',async()=>{
   await session.configure('petrol_basic');session.setLogInterval(60);await session.control('ignition',true);await session.connection('ect',false);await session.advance(60);await session.command;
   assert.equal(session.logHistory.length,2);equal(session.logHistory.map(s=>s.t),[0,60]);assert.ok(session.history.length>500);assert.ok(session.context().state.dtcs.includes('P0118'));
   const meta=session.signals.find(s=>s.id==='sensors.ect_c'),record=w.AppModel.recordedSignal(meta,session.context().state);assert.equal(record.validity,'invalid');
   const battery=session.signals.find(s=>s.id==='battery_voltage_v');equal(w.AppModel.recordedSignal(battery,session.context().state),{value:null,validity:'unavailable'});
   assert.ok(session.logCSV().includes('vehicle_sensors.crank_sensor.value validity'));
 });
 session.dispose();assert.equal(timers.size,0);
 console.log(JSON.stringify({suite:'v0.7 shared session API integration',passed,failed,backend:'actual Python loopback HTTP server',clock:'controlled callbacks and deferred request gates',maxConcurrentMutations:maxMutations}));process.exitCode=failed?1:0;
})().catch(error=>{console.error(error.stack);process.exitCode=1;}).finally(()=>{if(session)session.dispose();for(const gate of gates)gate.release();child.kill('SIGTERM');});
