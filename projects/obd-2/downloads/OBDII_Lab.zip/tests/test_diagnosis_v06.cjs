/* Diagnosis interaction contracts using real Python model/diagnostic states.
 * Uses the existing parsed-node test harness. It does not test browser layout.
 * Run from the project: node tests/test_diagnosis_v06.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawnSync}=require('node:child_process');
const project=path.resolve(__dirname,'..');
const fixtureRun=spawnSync('python3',['-c',`
import json
from obdii_lab.core import Sim
from obdii_lab.runner import diagnostic_server
from obdii_lab.diagnostic_definitions import diagnostic_definitions
from obdii_lab.network import network_catalog
states={}
s=Sim('phev','city_drive');s.advance(1);states['healthy']=s.snapshot()
s.set_connection('ect',False);states['ect_open']=s.snapshot();s.advance(.6);states['ect_confirmed']=s.snapshot()
d=diagnostic_server(s);replies={'stored':d.request('03',can_id=0x7df)}
s.set_connection('ect',True);states['ect_reconnected']=s.snapshot();s.advance(.2);states['ect_repaired']=s.snapshot()
replies['clear']=d.request('04',can_id=0x7df);states['ect_cleared']=s.snapshot()
s.set_connection('dlc',False);states['dlc_open']=s.snapshot();replies['timeout']=d.request('01 0C',can_id=0x7df)
s.set_connection('dlc',True);replies['rpm']=d.request('01 0C',can_id=0x7df)
s=Sim('phev','city_drive');s.advance(1);s.set_connection('bmu',False);s.advance(.6);states['bmu_timeout']=s.snapshot()
s.set_connection('bmu',True);s.advance(.2);states['bmu_reconnected']=s.snapshot()
s.advance(.2,{'ignition':False});s.advance(1,{'ignition':True});states['bmu_recovered']=s.snapshot()
s=Sim('phev','city_drive');s.advance(1);s.set_connection('wheel_fl',False);s.advance(.2);states['wheel_open']=s.snapshot()
s.set_connection('wheel_fl',True);s.advance(.2);states['wheel_repaired']=s.snapshot()
states['engine']=Sim('engine','manual').snapshot()
print(json.dumps({'states':states,'replies':replies,'definitions':diagnostic_definitions(),'catalog':network_catalog()}))
`],{cwd:project,encoding:'utf8'});
assert.equal(fixtureRun.status,0,fixtureRun.stderr);const fixture=JSON.parse(fixtureRun.stdout);
const harness=fs.readFileSync(path.join(project,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=harness.indexOf('const decodeEntities='),end=harness.indexOf('const elements=new Node(');
assert.ok(begin>=0&&end>begin,'Existing parsed-node harness anchors');
const w={},sandbox={window:w,console,assert};vm.createContext(sandbox);
vm.runInContext(harness.slice(begin,end)+'\nglobalThis.TestNode=Node;',sandbox);
vm.runInContext(fs.readFileSync(path.join(project,'web/diagnosis.js'),'utf8'),sandbox);
const Node=sandbox.TestNode,container=new Node('main'),calls={select:[],navigate:[],watch:[],connection:[],advance:[],request:[],inputs:[],reset:0};
let current={state:fixture.states.healthy,catalog:fixture.catalog,definitions:fixture.definitions,signals:[],selection:'coolant_sensor',diagnostic:null,busy:false},respond='stored',advanceTarget=null;
const view=w.DiagnosisView.create(container,{
 onSelect:id=>{calls.select.push(id);current={...current,selection:id};view.update(current);},onNavigate:id=>calls.navigate.push(id),onWatch:(id,yes)=>calls.watch.push({id,yes}),
 onConnection:async(id,connected)=>calls.connection.push({id,connected}),
 onAdvance:async(seconds)=>{calls.advance.push(seconds);if(advanceTarget){current={...current,state:fixture.states[advanceTarget]};view.update(current);advanceTarget=null;}},
 onRequest:async(payload,canId)=>{calls.request.push({payload,canId});const d={...fixture.replies[respond],sample_t:current.state.t};current={...current,diagnostic:d};view.update(current);return d;},
 onInputs:async(inputs)=>calls.inputs.push(inputs),onReset:()=>calls.reset++
});
view.update(current);
const $=selector=>{const node=container.querySelector(selector);assert.ok(node,'Markup '+selector);return node;};
const equal=(value,wanted,message)=>assert.deepEqual(JSON.parse(JSON.stringify(value)),wanted,message);
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
const click=async(name)=>{const target=$(`[data-dg-action="${name}"]`);if(!target.disabled)await container.dispatchEvent({type:'click',target});await flush();};
const update=(name,selection=current.selection)=>{current={...current,state:fixture.states[name],selection};view.update(current);};
let passed=0,failed=0;
async function test(name,fn){try{await fn();passed++;console.log('PASS '+name);}catch(e){failed++;console.error('FAIL '+name+'\n'+e.stack);}}
(async()=>{
 await test('ECT evidence separates physical heat, invalid reading and stored memory',()=>{
   update('ect_confirmed');const result=view.inspect().state;
   assert.equal(result.phase,'Fault confirmed');assert.equal(result.active,true);assert.equal(result.clearAllowed,false);
   assert.notEqual(result.metrics[0].value,result.metrics[1].value);
   assert.match($('[data-dg="freeze-time"]').textContent,/Captured at/);
   assert.match($('[data-dg="freeze"]').textContent,/ECU-reported/);
 });
 await test('merely selecting a case preserves the vehicle and never resets or advances',async()=>{
   const before=calls.advance.length;view.selectCase('dlc');assert.equal(calls.advance.length,before);assert.equal(calls.reset,0);assert.equal(calls.select.at(-1),'dlc');
 });
 await test('connection injection and time sampling are explicit independent actions',async()=>{
   update('healthy','coolant_sensor');view.selectCase('ect',false);
   const before=calls.advance.length;await click('disconnect');equal(calls.connection.at(-1),{id:'ect',connected:false});assert.equal(calls.advance.length,before);
   await click('sample');assert.equal(calls.advance.at(-1),.6);
 });
 await test('clear is gated until a repaired fresh measurement and retained memory exist',async()=>{
   update('ect_reconnected');assert.equal($('[data-dg-action="clear"]').disabled,true);
   update('ect_repaired');assert.equal($('[data-dg-action="clear"]').disabled,false);assert.equal(view.inspect().state.phase,'Repaired · code retained');
   respond='clear';await click('clear');equal(calls.request.at(-1),{payload:'04',canId:'7DF'});
   update('ect_cleared');assert.equal($('[data-dg-action="clear"]').disabled,true);assert.equal(view.inspect().state.recovered,true);
 });
 await test('a DLC timeout retains an absent reply and creates no DTC',async()=>{
   update('dlc_open','dlc');respond='timeout';await click('read');
   equal(calls.request.at(-1),{payload:'01 0C',canId:'7DF'});assert.equal(view.inspect().lastReply.response_hex,fixture.replies.timeout.response_hex);
   assert.equal($('[data-dg="reply-bytes"]').textContent,'No reply');assert.equal(view.inspect().state.memory.length,0);
   assert.match($('[data-dg="evidence-note"]').textContent,/communication result/);
 });
 await test('BMU verifies freshness separately from a latched traction shutdown',async()=>{
   update('bmu_timeout','bmu');assert.equal(view.inspect().state.phase,'Report stale');assert.equal(view.inspect().state.recovered,false);
   update('bmu_reconnected');assert.equal(view.inspect().state.phase,'Shutdown latched');assert.equal($('[data-dg-action="cycle"]').disabled,false);
   const inputStart=calls.inputs.length,advanceStart=calls.advance.length;await click('cycle');
   equal(calls.inputs.slice(inputStart),[{ignition:false},{ignition:true}]);equal(calls.advance.slice(advanceStart),[.2,1]);assert.equal(calls.reset,0);
   update('bmu_recovered');assert.equal(view.inspect().state.recovered,true);assert.ok(view.inspect().state.memory.includes('BMU_STATUS_TIMEOUT'));
 });
 await test('missing wheel measurement is never rendered as zero or an OBD DTC',()=>{
   update('wheel_open','wheel_fl');const result=view.inspect().state;assert.equal(result.metrics[1].value,'—');assert.match(result.metrics[1].source,/not zero/);assert.notEqual(result.metrics[0].value,'—');
   assert.equal($('[data-dg-action="read"]').hidden,true);assert.equal($('[data-dg-action="clear"]').hidden,true);
   update('wheel_repaired');assert.equal(view.inspect().state.recovered,true);assert.ok(view.inspect().state.memory.includes('ABS_WHEEL_FL_SIGNAL'));
 });
 await test('linked graph, connector and location actions preserve the current selected component',async()=>{
   update('healthy','coolant_sensor');await click('graph');assert.equal(calls.navigate.at(-1),'live');assert.ok(calls.watch.some(item=>item.id==='sensors.ect_voltage_v'&&item.yes));
   await click('wiring');assert.equal(calls.select.at(-1),'socket:coolant_socket');assert.equal(calls.navigate.at(-1),'wiring');
   await click('location');assert.equal(calls.select.at(-1),'coolant_sensor');assert.equal(calls.navigate.at(-1),'locations');assert.equal(calls.reset,0);
 });
 await test('noninstalled systems disable simulated fault actions without fake measurements',()=>{
   update('engine','bmu');assert.equal(view.inspect().state.installed,false);assert.equal($('[data-dg-action="disconnect"]').disabled,true);assert.match($('[data-dg="metrics"]').textContent,/not installed/);
 });
 await test('another wheel is never silently treated as the executable front-left test',async()=>{
   const beforeSelection=calls.select.length,beforeConnection=calls.connection.length,beforeAdvance=calls.advance.length;
   update('healthy','wheel_fr');assert.equal(view.inspect().selected,'wheel_fl');assert.equal(view.inspect().context.compatible,false);assert.equal(calls.select.length,beforeSelection,'Updating the hidden or visible view must not change shared selection');
   assert.equal($('[data-dg="context-notice"]').hidden,false);assert.match($('[data-dg="context-message"]').textContent,/front-left/);assert.equal($('[data-dg-action="use-test"]').textContent,'Select front-left test');
   await click('disconnect');await click('sample');assert.equal(calls.connection.length,beforeConnection);assert.equal(calls.advance.length,beforeAdvance);
   await click('use-test');assert.equal(calls.select.at(-1),'wheel_fl');assert.equal(view.inspect().context.compatible,true);assert.equal($('[data-dg="context-notice"]').hidden,true);
   await click('disconnect');equal(calls.connection.at(-1),{id:'wheel_fl',connected:false});
   update('healthy','overview');assert.equal(view.inspect().context.compatible,false);assert.equal($('[data-dg-action="sample"]').disabled,true);
 });
 await test('reset clears the old request, while custom form edits survive state updates',()=>{
   $('input[data-dg="payload"]').value='22 F1 90';$('select[data-dg="address"]').value='7E0';update('healthy','dlc');
   assert.equal($('input[data-dg="payload"]').value,'22 F1 90');assert.equal($('select[data-dg="address"]').value,'7E0');
   current={...current,diagnostic:null};view.update(current);assert.equal(view.inspect().lastReply,null);assert.equal($('[data-dg="reply-bytes"]').textContent,'—');
 });
 view.dispose();console.log(JSON.stringify({suite:'v0.6 diagnosis interaction contracts',passed,failed,fixtures:'actual Python model and diagnostic replies',scope:'Parsed node harness; no browser layout or native DOM verification'}));process.exitCode=failed?1:0;
})();
