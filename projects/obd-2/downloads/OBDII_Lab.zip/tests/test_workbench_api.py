"""Connection API and beginner explanations match the real backend response."""
import json
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.core import Sim
from obdii_lab.diagnostics import DiagnosticServer
from obdii_lab.explanations import explain, explain_diagnostic
from obdii_lab.server import create_server


class WorkbenchApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None):
        request = Request(self.base + path, data=None if body is None else json.dumps(body).encode(),
                          headers={"Content-Type": "application/json"})
        with urlopen(request, timeout=10) as response:
            return json.load(response)

    def setUp(self):
        self.call("/api/reset", {"profile": "engine", "scenario": "manual"})

    def test_catalog_and_live_state_share_connection_and_wire_ids(self):
        catalog = self.call("/api/network")
        state = self.call("/api/state")
        self.assertEqual({wire["id"] for wire in catalog["wires"]}, set(state["network"]["wires"]))
        self.assertEqual({connection["id"] for connection in catalog["connections"]}, set(state["state"]["connections"]))
        self.assertEqual(state["state"]["t"], 0)

    def test_connection_api_changes_topology_then_controller_follows_on_step(self):
        opened = self.call("/api/connection", {"id": "ect", "connected": False})
        self.assertEqual(opened["state"]["t"], 0)
        self.assertFalse(opened["network"]["wires"]["ect_signal"]["connected"])
        self.assertEqual(opened["state"]["dtcs"], [])
        stepped = self.call("/api/advance", {"seconds": .6})
        self.assertIn("P0118", stepped["state"]["dtcs"])
        self.assertEqual(stepped["network"]["wires"]["ect_signal"]["value"], 5)
        self.call("/api/connection", {"id": "ect", "connected": True})
        repaired = self.call("/api/advance", {"seconds": .02})
        self.assertTrue(repaired["state"]["sensors"]["ect_sensor_valid"])
        self.assertIn("P0118", repaired["state"]["dtcs"])

    def test_invalid_switch_requests_are_atomic(self):
        initial = self.call("/api/state")["state"]
        for body in ({}, {"id": "unknown", "connected": False}, {"id": "ect", "connected": "false"},
                     {"id": "ect", "connected": 0}, {"id": "ect"}, {"connected": False},
                     {"id": "wheel_fl", "connected": False}, {"id": "bmu", "connected": False}):
            with self.assertRaises(HTTPError) as caught:
                self.call("/api/connection", body)
            self.assertEqual(caught.exception.code, 400)
            self.assertIn("error", json.load(caught.exception))
            self.assertEqual(self.call("/api/state")["state"], initial)

    def test_vehicle_profile_switch_and_reset_restore_independent_connections(self):
        self.call("/api/reset", {"profile": "braking", "scenario": "manual", "config": {"initial_speed_kph": 50}})
        self.call("/api/connection", {"id": "wheel_fl", "connected": False})
        self.call("/api/connection", {"id": "bmu", "connected": False})
        step = self.call("/api/advance", {"seconds": .4})
        self.assertGreater(step["state"]["wheel_speeds_kph"][0], 0)
        self.assertIsNone(step["state"]["sensors"]["wheel_speeds_kph"][0])
        self.assertFalse(step["network"]["wires"]["wheel_fl_signal"]["available"])
        reset = self.call("/api/reset", {"profile": "engine", "scenario": "manual"})
        self.assertTrue(all(reset["state"]["connections"].values()))
        self.assertFalse(reset["network"]["components"]["bmu"]["installed"])

    def test_disconnected_scan_and_uds_replies_get_accurate_plain_language(self):
        self.call("/api/connection", {"id": "dlc", "connected": False})
        silent = self.call("/api/diagnostic", {"payload": "01 0C"})
        self.assertTrue(silent["diagnostic"]["timeout"])
        self.assertIn("cannot reach", silent["diagnostic_explanation"]["answer"])
        self.assertIn("Reconnect", silent["diagnostic_explanation"]["next_step"])
        self.call("/api/connection", {"id": "dlc", "connected": True})
        vin = self.call("/api/diagnostic", {"payload": "22 F1 90", "can_id": "7E0"})
        self.assertTrue(vin["diagnostic"]["response_hex"].startswith("62 F1 90"))
        self.assertIn("invented vehicle identity", vin["diagnostic_explanation"]["answer"])


class WorkbenchExplanationTests(unittest.TestCase):
    def test_physical_bmu_connection_is_explained_before_and_after_latch(self):
        sim = Sim(profile="phev")
        sim.advance(1)
        sim.set_connection("bmu", False)
        early = explain(sim.advance(.02))
        self.assertEqual(early["fault"]["cause_name"], "bmu_timeout")
        self.assertTrue(early["fault"]["present"])
        self.assertIn("stopped arriving", early["heading"])
        latched = explain(sim.advance(.4))
        self.assertTrue(latched["fault"]["present"])
        self.assertEqual(latched["fault"]["state"], "latched")
        sim.set_connection("bmu", True)
        recovered = explain(sim.advance(.12))
        self.assertFalse(recovered["fault"]["present"])
        self.assertIn("restored", recovered["what_changed"])

    def test_physical_wheel_connection_is_not_described_as_healthy(self):
        sim = Sim(profile="braking")
        sim.set_connection("wheel_fl", False)
        result = explain(sim.advance(.02))
        self.assertEqual(result["fault"]["cause_name"], "wheel_fl_dropout")
        self.assertTrue(result["fault"]["present"])
        self.assertIn("missing", result["heading"])
        sim.set_connection("wheel_fl", True)
        repaired = explain(sim.advance(.02))
        self.assertEqual(repaired["fault"]["state"], "remembered")
        self.assertFalse(repaired["fault"]["present"])

    def test_uds_positive_negative_suppressed_and_wrong_address_differ(self):
        sim = Sim()
        server = DiagnosticServer(sim.snapshot)
        def description(payload, address=0x7E0):
            return explain_diagnostic(server.request(payload, address), sim.snapshot())
        self.assertIn("extended", description("10 03")["answer"])
        self.assertIn("keep-alive", description("3E 00")["answer"])
        self.assertIn("spare-part", description("22 F1 87")["answer"])
        negative = description("22 00 01")
        self.assertIn("declined", negative["answer"])
        self.assertEqual(negative["technical"]["negative_response_code"], "31")
        self.assertIn("suppressed", description("3E 80")["answer"])
        self.assertIn("direct engine", description("22 F1 90", 0x7DF)["next_step"])


if __name__ == "__main__":
    unittest.main()
