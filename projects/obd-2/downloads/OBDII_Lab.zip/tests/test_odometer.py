"""Odometer and resettable trip follow physical travel, including Reverse."""
from copy import deepcopy
import csv
import io
import json
import math
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.server import create_server
from obdii_lab.vehicle import VehicleSim


class OdometerTests(unittest.TestCase):
    def started(self, configuration="petrol_basic", initial=12345.6):
        sim = VehicleSim(configuration, {"initial_odometer_km": initial})
        sim.control("ignition", True)
        sim.control("start")
        sim.advance(1.6, {"brake": .3})
        self.assertTrue(sim.snapshot()["vehicle"]["ready"])
        return sim

    def drive(self, sim, selector="D", seconds=2):
        sim.control("gear", selector)
        sim.control("parking_brake", False)
        return sim.advance(seconds, {"brake": 0, "throttle": .6})

    def test_initial_reading_is_explicit_and_defaults_to_zero(self):
        sim = VehicleSim()
        self.assertEqual(sim.configuration["initial_odometer_km"], 0)
        self.assertEqual(sim.snapshot()["vehicle"]["odometer_km"], 0)
        self.assertEqual(sim.snapshot()["vehicle"]["trip_distance_km"], 0)
        for initial in (0, .1, 12345.6, 9_999_999):
            with self.subTest(initial=initial):
                vehicle = VehicleSim(options={"initial_odometer_km": initial}).snapshot()["vehicle"]
                self.assertEqual(vehicle["configuration"]["initial_odometer_km"], initial)
                self.assertEqual(vehicle["odometer_km"], initial)
                self.assertEqual(vehicle["trip_distance_km"], 0)

    def test_initial_reading_rejects_non_numbers_nonfinite_and_out_of_range(self):
        for initial in (True, False, None, "12000", [], {}, -.1, 10_000_000, 10 ** 1000, math.nan, math.inf, -math.inf):
            with self.subTest(initial=initial):
                with self.assertRaisesRegex(ValueError, "initial_odometer_km.*finite number"):
                    VehicleSim(options={"initial_odometer_km": initial})

    def test_forward_and_reverse_both_add_real_travel_for_each_powertrain(self):
        for configuration in ("petrol_basic", "diesel", "hev", "phev", "bev"):
            with self.subTest(configuration=configuration):
                sim = self.started(configuration)
                forward = self.drive(sim)
                self.assertGreater(forward["speed_kph"], 1)
                self.assertGreater(forward["distance_m"], 0)
                self.assertAlmostEqual(forward["vehicle"]["odometer_km"], 12345.6 + forward["distance_m"] / 1000)
                self.assertAlmostEqual(forward["vehicle"]["trip_distance_km"], forward["distance_m"] / 1000)
                sim.advance(4, {"brake": 1, "throttle": 0})
                stopped = sim.snapshot()
                self.assertEqual(stopped["speed_kph"], 0)
                reverse = self.drive(sim, "R")
                self.assertLess(reverse["signed_speed_kph"], 0)
                self.assertLess(reverse["signed_distance_m"], stopped["signed_distance_m"])
                self.assertGreater(reverse["distance_m"], stopped["distance_m"])
                self.assertGreater(reverse["vehicle"]["odometer_km"], stopped["vehicle"]["odometer_km"])
                self.assertAlmostEqual(reverse["vehicle"]["trip_distance_km"], reverse["distance_m"] / 1000)
                self.assertAlmostEqual(reverse["vehicle"]["odometer_km"], 12345.6 + reverse["distance_m"] / 1000)

    def test_stationary_engine_and_paused_readouts_do_not_add_distance(self):
        sim = self.started()
        sim.control("gear", "D")
        held = sim.advance(3, {"brake": 0, "throttle": .6})
        self.assertEqual(held["speed_kph"], 0)
        self.assertEqual(held["distance_m"], 0)
        self.assertEqual(held["vehicle"]["odometer_km"], 12345.6)
        self.assertEqual(held["vehicle"]["trip_distance_km"], 0)
        for _ in range(5):
            self.assertEqual(sim.snapshot()["vehicle"]["odometer_km"], 12345.6)
        self.assertEqual(sim.advance(0)["t"], held["t"])
        self.assertEqual(sim.distance_m, 0)

    def test_trip_reset_keeps_odometer_physics_time_and_recorded_history(self):
        sim = self.started()
        before = self.drive(sim)
        history = deepcopy(sim.history)
        events_before = len(sim.events)
        after = sim.control("reset_trip")
        self.assertEqual(after["vehicle"]["trip_distance_km"], 0)
        self.assertEqual(after["vehicle"]["odometer_km"], before["vehicle"]["odometer_km"])
        for key in ("t", "distance_m", "signed_distance_m", "speed_kph", "rpm", "inputs", "energy"):
            self.assertEqual(after[key], before[key], key)
        self.assertEqual(sim.history, history)
        self.assertEqual(len(sim.events), events_before + 1)
        self.assertEqual(sim.events[-1]["source"], "BODY")
        self.assertEqual(sim.events[-1]["t"], before["t"])
        self.assertIn("odometer unchanged", sim.events[-1]["message"])
        sim.control("reset_trip")
        self.assertEqual(len(sim.events), events_before + 1)
        next_point = sim.advance(.5)
        self.assertGreater(next_point["vehicle"]["trip_distance_km"], 0)
        self.assertAlmostEqual(next_point["vehicle"]["trip_distance_km"],
                               (next_point["distance_m"] - before["distance_m"]) / 1000)
        self.assertAlmostEqual(next_point["vehicle"]["odometer_km"], 12345.6 + next_point["distance_m"] / 1000)

    def test_zero_trip_reset_does_not_create_an_event(self):
        sim = VehicleSim()
        before, events = sim.snapshot(), list(sim.events)
        self.assertEqual(sim.control("reset_trip"), before)
        self.assertEqual(sim.events, events)


class OdometerApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None):
        request = Request(self.base + path, data=None if body is None else json.dumps(body).encode(),
                          headers={"Content-Type": "application/json"})
        with urlopen(request, timeout=10) as response:
            if "application/json" in response.headers["Content-Type"]:
                return json.load(response)
            return response.read().decode()

    def control(self, action, value=None, inputs=None):
        return self.call("/api/control", {"action": action, "value": value, "inputs": inputs or {}})

    def setUp(self):
        self.call("/api/vehicle", {"configuration": "petrol_basic", "options": {"initial_odometer_km": 12345.6}})

    def drive(self):
        self.control("ignition", True)
        self.control("start")
        self.call("/api/advance", {"seconds": 1.6})
        self.control("gear", "D", {"brake": .3})
        self.control("parking_brake", False)
        return self.call("/api/advance", {"seconds": 2, "inputs": {"throttle": .6, "brake": 0}})["state"]

    def test_configuration_rejection_preserves_live_vehicle_and_accepts_bounds(self):
        self.drive()
        before = self.call("/api/state")
        for initial in (True, None, "123", -.01, 10_000_000, 10 ** 1000, math.nan, math.inf):
            with self.subTest(initial=initial):
                with self.assertRaises(HTTPError) as caught:
                    self.call("/api/vehicle", {"configuration": "bev", "options": {"initial_odometer_km": initial}})
                self.assertEqual(caught.exception.code, 400)
                self.assertIn("initial_odometer_km", json.load(caught.exception)["error"])
                self.assertEqual(self.call("/api/state"), before)
        for initial in (0, 9_999_999):
            state = self.call("/api/vehicle", {"options": {"initial_odometer_km": initial}})["state"]
            self.assertEqual(state["vehicle"]["odometer_km"], initial)
            self.assertEqual(state["vehicle"]["trip_distance_km"], 0)

    def test_trip_reset_is_instant_and_json_csv_exports_match_recorded_distance(self):
        driven = self.drive()
        reset = self.control("reset_trip")["state"]
        self.assertEqual(reset["t"], driven["t"])
        self.assertEqual(reset["distance_m"], driven["distance_m"])
        self.assertEqual(reset["vehicle"]["odometer_km"], driven["vehicle"]["odometer_km"])
        self.assertEqual(reset["vehicle"]["trip_distance_km"], 0)
        report = self.call("/api/export.json")
        self.assertEqual(report["final_state"]["vehicle"]["trip_distance_km"], 0)
        self.assertGreater(report["history"][-1]["vehicle"]["trip_distance_km"], 0)
        self.assertEqual(report["vehicle_configuration"]["initial_odometer_km"], 12345.6)
        self.assertIn("odometer", report["measurement_notes"])
        after = self.call("/api/advance", {"seconds": .2})["state"]
        report = self.call("/api/export.json")
        recorded = report["history"][-1]["vehicle"]
        self.assertEqual(recorded["trip_distance_km"], after["vehicle"]["trip_distance_km"])
        rows = list(csv.DictReader(io.StringIO(self.call("/api/export.csv"))))
        self.assertEqual(float(rows[-1]["initial_odometer_km"]), 12345.6)
        for field in ("odometer_km", "trip_distance_km"):
            self.assertEqual(float(rows[-1][field]), recorded[field])
        self.assertEqual(float(rows[0]["trip_distance_km"]), 0)
        self.assertEqual(float(rows[0]["odometer_km"]), 12345.6)

    def test_new_run_returns_to_its_configured_reading_not_the_previous_journey(self):
        self.drive()
        self.control("reset_trip")
        self.call("/api/advance", {"seconds": .2})
        for configuration in ("diesel", "bev", "petrol_basic"):
            state = self.call("/api/vehicle", {"configuration": configuration,
                              "options": {"initial_odometer_km": 12345.6}})["state"]
            self.assertEqual(state["t"], 0)
            self.assertEqual(state["distance_m"], 0)
            self.assertEqual(state["vehicle"]["odometer_km"], 12345.6)
            self.assertEqual(state["vehicle"]["trip_distance_km"], 0)
        state = self.call("/api/vehicle", {"configuration": "petrol_basic"})["state"]
        self.assertEqual(state["vehicle"]["odometer_km"], 0)

    def test_trip_reset_during_wltc_does_not_take_control_from_virtual_driver(self):
        self.call("/api/cycle", {"action": "start", "name": "wltc_class3b"})
        for _ in range(5):
            self.call("/api/advance", {"seconds": 5})
        before = self.call("/api/state")["state"]
        self.assertEqual(before["drive_cycle"]["status"], "active")
        self.assertGreater(before["vehicle"]["trip_distance_km"], 0)
        after = self.control("reset_trip", inputs={"throttle": 1, "brake": 1, "clutch": 1, "steer_deg": 10})["state"]
        self.assertEqual(after["t"], before["t"])
        self.assertEqual(after["drive_cycle"], before["drive_cycle"])
        self.assertEqual(after["vehicle"]["odometer_km"], before["vehicle"]["odometer_km"])
        self.assertEqual(after["vehicle"]["trip_distance_km"], 0)
        for pedal in ("throttle", "brake", "clutch", "steer_deg"):
            self.assertEqual(after["inputs"][pedal], before["inputs"][pedal])
        running = self.call("/api/advance", {"seconds": .2})["state"]
        self.assertEqual(running["drive_cycle"]["status"], "active")
        self.assertGreater(running["vehicle"]["trip_distance_km"], 0)


if __name__ == "__main__":
    unittest.main()
