/* Whole-workspace contracts: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_application_v07.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){
 const server=await startServer();
 try{
  const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
  document.readyState='interactive';await document.dispatchEvent(new CustomEvent('DOMContentLoaded'));
  const app=window.VehicleApplication;assert.ok(app);
  await app.ready;await flush();
  const settle=async()=>{await app.session.command;await waitFor(()=>app.session.pending===0&&!app.views.diagnosis.inspect().pending&&!app.views.drive.inspect().pending&&!app.views.scan.inspect().pending,'Queued commands settle');await flush();};
  const click=async selector=>{await $(selector).click();await settle();};
  const input=async(selector,value)=>{const node=$(selector);node.value=value;await node.dispatchEvent({type:'input'});await settle();};
  const change=async(selector,value)=>{const node=$(selector);node.value=value;await node.dispatchEvent({type:'change'});await settle();};
  await test('one parked bootstrap vehicle opens the staged setup, with two operational workspaces and no old driver drawer',async()=>{
   assert.equal(requests.filter(r=>r.url==='/api/vehicle').length,1);assert.equal(requests.filter(r=>r.url==='/api/reset').length,0);
   assert.deepEqual(Array.from(document.querySelectorAll('[data-workspace]'),n=>n.dataset.workspace),['drive','service']);assert.equal(document.querySelectorAll('[data-action="play"]').length,1);
   assert.equal(document.querySelector('#driver-drawer'),null);assert.equal(renderers.length,1);assert.equal(renderers[0].options.locator,true);
   const s=app.session.result.state;assert.equal(s.vehicle.ignition,'off');assert.equal(s.vehicle.selector,'P');assert.equal(s.vehicle.parking_brake,true);assert.equal(s.rpm,0);assert.equal(s.speed_kph,0);assert.equal(app.session.view,'setup');assert.equal(app.session.result.scanner.connected,false);assert.equal($('#application-error').hidden,true);
   assert.equal($('[data-ck="cluster-selector"]').textContent,'P');assert.ok(document.querySelector('.ck-road-settings'));assert.ok(document.querySelector('.ck-configuration'));
  });
  await test('ignition, engine start and driver gear selector control the real model',async()=>{
   await change('[data-setup="driving_mode"]','manual');await click('[data-setup-action="apply"]');await click('[data-workspace-choice="drive"]');
   await click('[data-ck-action="ignition"]');assert.equal(app.session.result.state.vehicle.ignition,'on');assert.equal(app.session.result.state.rpm,0);assert.equal(app.session.running,true);
   await click('[data-ck-action="start"]');await app.session.advance(1);await settle();assert.equal(app.session.result.state.vehicle.start_state,'running');assert.ok(app.session.result.state.rpm>500);
   await click('[data-ck-gear="D"]');assert.equal(app.session.result.state.vehicle.selector,'P');assert.match(app.views.drive.inspect().error,/brake/i);
   await input('[data-ck="brake"]','25');await click('[data-ck-gear="D"]');assert.equal(app.session.result.state.vehicle.selector,'D');
   await click('[data-ck-action="parking"]');await input('[data-ck="brake"]','0');await input('[data-ck="throttle"]','45');await app.session.advance(6);await settle();
   assert.ok(app.session.result.state.speed_kph>5);assert.ok(app.session.result.state.vehicle.gear>=1);assert.equal($('[data-ck="cluster-selector"]').textContent,'D');assert.equal($('#application-error').hidden,true);
  });
  await test('gaming keys drive the real model and Help releases input until a fresh press',async()=>{
   await click('[data-ck-action="release"]');document.activeElement=null;
   const key=(type,value,code)=>window.dispatchEvent({type,key:value,code,target:$('#cockpit-content'),preventDefault(){this.defaultPrevented=true;}});
   key('keydown','w','KeyW');key('keydown','ArrowUp','ArrowUp');key('keyup','w','KeyW');key('keydown','d','KeyD');
   assert.equal(app.session.inputs.throttle,1);assert.equal(app.session.inputs.steer_deg,10);
   await app.session.advance(.2);await settle();assert.equal(app.session.result.state.inputs.throttle,1);assert.equal(app.session.result.state.inputs.steer_deg,10);
   await click('[data-action="help"]');assert.equal(app.views.drive.inspect().inputEnabled,false);assert.equal(app.session.inputs.throttle,0);assert.equal(app.session.inputs.steer_deg,0);
   key('keydown','w','KeyW');assert.equal(app.session.inputs.throttle,0);key('keyup','ArrowUp','ArrowUp');key('keyup','d','KeyD');
   await click('[data-action="close-drawer"]');assert.equal(app.views.drive.inspect().inputEnabled,true);assert.equal(app.session.inputs.throttle,0);
   key('keydown','s','KeyS');await app.session.advance(.1);await settle();assert.equal(app.session.result.state.inputs.brake,1);
   key('keyup','s','KeyS');await app.session.advance(.1);await settle();assert.equal(app.session.result.state.inputs.brake,0);assert.equal(app.session.inputs.throttle,0);
  });
  await test('unit map, signals, wiring and location share selection and clock',async()=>{
   const before=app.inspect();await click('[data-workspace="service"]');await click('[data-service-view="units"]');assert.equal(app.session.unitView,'overview');
   await click('[data-um-unit="ecu"]');assert.equal(app.session.selection,'ecu');assert.equal(app.views.overview.inspect().selectedUnit,'ecu');
   await click('[data-um-action="signals"]');assert.equal(app.session.view,'units');assert.equal(app.session.unitView,'signals');assert.equal($('#view-live').hidden,false);
   await click('[data-unit-view="wiring"]');assert.equal($('#view-wiring').hidden,false);await click('[data-unit-view="locations"]');assert.equal($('#view-locations').hidden,false);
   assert.equal(app.inspect().time,before.time);assert.equal(app.inspect().history,before.history);
   assert.equal(app.session.selection,'ecu');assert.equal(renderers[0].state.t,before.time);
  });
  await test('scan-tool connection and actual OBD request decode agree with vehicle sample',async()=>{
   await click('[data-workspace="service"]');await click('[data-service-view="diagnostics"]');await click('[data-sc-action="connect"]');assert.equal(app.session.result.scanner.status,'ready');
   await click('[data-sc-action="scan"]');assert.ok(app.session.scanReport.modules.find(m=>m.id==='ecu').source.includes('OBD'));
   await click('[data-sc-action="send"]');assert.equal(app.session.diagnostic.request_hex,'01 0C');assert.ok(app.session.diagnostic.response_hex.startsWith('41 0C'));
   const rpm=window.ProtocolsView.decodeResponse(app.session.diagnostic).value;assert.ok(Math.abs(rpm-app.session.result.state.vehicle_sensors.crank_sensor.value)<1);
   assert.ok(app.session.records.length>0);assert.match($('[data-sc="response-value"]').textContent,/rpm/);
  });
  await test('reference transports change connector explanation without becoming runnable',async()=>{
   await change('[data-sc="protocol"]','iso9141');assert.equal($('[data-sc-action="connect"]').disabled,true);assert.match($('[data-sc="protocol-scope"]').textContent,/Reference/);
   await click('[data-sc-pin="7"]');assert.match($('[data-sc="pin-title"]').textContent,/K-line/);assert.ok($('[data-sc-pin="7"]').classList.contains('active'));assert.equal($('[data-sc-pin="6"]').classList.contains('active'),false);
   await change('[data-sc="protocol"]','can11_500');assert.equal($('[data-sc-action="connect"]').disabled,false);
  });
  await test('DLC unplug produces actual no-reply and repaired connection resumes',async()=>{
   const t=app.session.result.state.t;await app.session.connection('dlc',false);await app.session.request('01 0C');await settle();
   assert.equal(app.session.result.scanner.status,'dlc_open');assert.equal(app.session.diagnostic.response_hex,null);assert.equal(app.session.diagnostic.frames.length,0);assert.equal(app.session.result.state.t,t);
   await app.session.connection('dlc',true);await app.session.request('01 0C');await settle();assert.ok(app.session.diagnostic.response_hex);
  });
  await test('a visible sensor action stops combustion and explains the crank fault while time continues',async()=>{
   app.session.select('ecu');app.session.navigate('wiring');await settle();
   const before=app.session.result.state.t;assert.equal(app.session.result.state.engine_running,true);
   await click('[data-cv-node-connection="crank_sensor"]');assert.equal(app.session.result.state.t,before);
   await app.session.advance(.6);await settle();const failed=app.session.result.state;
   assert.equal(failed.engine_running,false);assert.equal(failed.vehicle.start_state,'inhibited');
   assert.equal(failed.vehicle_sensors.crank_sensor.value,null);assert.equal(failed.vehicle_sensors.crank_sensor.validity,'invalid');
   assert.ok([...failed.pending_dtcs,...failed.dtcs].includes('P0335'));assert.ok(failed.t>before);
   assert.match($('[data-cv-node-state="crank_sensor_socket"]').textContent,/Unplugged/);
   assert.match($('[data-cv-node-action-text="crank_sensor"]').textContent,/Reconnect/);
   assert.match($('[data-cv-impact-facts]').textContent,/stopped|inhibited/i);
   assert.match($('#simulation-phase').textContent,/Engine stopped.*start inhibited/);
   await click('[data-cv-node-connection="crank_sensor"]');await app.session.advance(.6);await settle();
   assert.equal(app.session.result.state.vehicle_sensors.crank_sensor.validity,'valid');
   assert.match($('[data-cv-node-state="crank_sensor_socket"]').textContent,/Connected/);
   app.session.navigate('scan');await settle();
  });
  await test('recording cadence is separate from signal sampling and diagnostic polling',async()=>{
   app.session.setLogInterval(1);const start=app.session.logHistory.length;await app.session.advance(3);await settle();assert.equal(app.session.logHistory.length-start,3);
   const checkbox=$('[data-sc="poll-enabled"]');checkbox.checked=true;await checkbox.dispatchEvent({type:'change'});await settle();assert.equal(app.session.scanPolling.enabled,true);
   const count=app.session.records.length;await app.session.advance(1);await settle();assert.ok(app.session.records.length>count);
   assert.ok(app.session.logCSV().includes('vehicle_sensors.crank_sensor.value validity'));assert.ok(app.session.logCSV().includes('selector'));
   app.session.setRecording(false);const stopped=app.session.logHistory.length;await app.session.advance(1);await settle();assert.equal(app.session.logHistory.length,stopped);
  });
  await test('schematic intermittent controls reach the real API, freeze while paused and stop with a lasting repair',async()=>{
   app.session.select('maf');app.session.navigate('wiring');await settle();
   assert.equal($('[data-cv-fault-controls]').hidden,false);await change('[data-cv-fault-pattern]','regular');await change('[data-cv-fault-connected]','0.3');await change('[data-cv-fault-dropout]','1');
   const startedAt=app.session.result.state.t;await click('[data-cv-action="start-intermittent"]');
   const request=requests.filter(r=>r.url==='/api/connection-fault').at(-1);assert.ok(request);assert.deepEqual(request.body,{mode:'intermittent',pattern:'regular',connected_s:.3,dropout_s:1,id:'maf'});
   assert.equal(app.session.result.state.t,startedAt);assert.equal(app.session.result.state.connection_faults.maf.phase,'connected');assert.match($('[data-cv-fault-status]').textContent,/Connected · disconnects in/);
   await app.session.advance(.35);await settle();const dropout=app.session.result.state;assert.equal(dropout.connection_faults.maf.phase,'dropout');assert.equal(dropout.effective_connections.maf,false);assert.equal(dropout.vehicle_sensors.maf.value,null);assert.equal(dropout.vehicle_sensors.maf.validity,'invalid');assert.match($('[data-cv-node-state="maf_socket"]').textContent,/Unplugged/);assert.match($('[data-cv-fault-status]').textContent,/Disconnected · reconnects in/);
   app.session.setRunning(false);await settle();const pausedAt=app.session.result.state.t,countdown=app.session.result.state.connection_faults.maf.time_to_change_s,status=$('[data-cv-fault-status]').textContent;
   await change('[data-cv-arrangement]','rate');await change('[data-cv-arrangement]','function');assert.equal(app.session.running,false);assert.equal(app.session.result.state.t,pausedAt);assert.equal(app.session.result.state.connection_faults.maf.time_to_change_s,countdown);assert.equal($('[data-cv-fault-status]').textContent,status);
   await click('[data-cv-action="stop-intermittent"]');assert.deepEqual(requests.filter(r=>r.url==='/api/connection-fault').at(-1).body,{mode:'normal',id:'maf'});assert.equal(app.session.result.state.connection_faults.maf,undefined);assert.equal(app.session.result.state.effective_connections.maf,true);assert.equal($('[data-cv-action="stop-intermittent"]').hidden,true);
   await app.session.advance(1.6);await settle();const repaired=app.session.result.state;assert.equal(repaired.connection_faults.maf,undefined);assert.equal(repaired.effective_connections.maf,true);assert.equal(repaired.vehicle_sensors.maf.validity,'valid');assert.match($('[data-cv-node-state="maf_socket"]').textContent,/Connected/);assert.match($('[data-cv-fault-status]').textContent,/Connected · steady input/);
   app.session.navigate('scan');await settle();
  });
  await test('BEV reconfiguration removes engine/ABS when unfitted and exposes electric READY',async()=>{
   await app.session.configure('bev',{abs_installed:false,esp_installed:false,can_bitrate:250000});await settle();
   assert.equal(app.session.result.state.vehicle.ignition,'off');assert.equal(app.session.logHistory.length,0);assert.equal(app.session.scanPolling.enabled,false);
   assert.equal(app.session.systems.units.find(u=>u.id==='ecu').installed,false);assert.equal(app.session.systems.units.find(u=>u.id==='abs').installed,false);
   await click('[data-workspace="drive"]');assert.match($('[data-ck="start-label"]').textContent,/READY/);assert.match($('[data-ck="left-title"]').textContent,/POWER/);
   await click('[data-ck-action="ignition"]');await click('[data-ck-action="start"]');await app.session.advance(1);await settle();assert.equal(app.session.result.state.vehicle.ready,true);assert.equal(app.session.result.state.rpm,0);assert.equal(app.session.result.state.energy.fuel_l,0);
  });
  await test('state-only module and wrong bitrate are explicit in scanner mode',async()=>{
   await click('[data-workspace="service"]');await click('[data-service-view="diagnostics"]');await change('[data-sc="module"]','inverter');await change('[data-sc="protocol"]','can11_500');await click('[data-sc-action="connect"]');assert.equal(app.session.result.scanner.status,'bitrate_mismatch');
   await change('[data-sc="protocol"]','can11_250');await click('[data-sc-action="connect"]');assert.equal(app.session.result.scanner.status,'state_only');assert.equal($('[data-sc-action="send"]').disabled,true);
   await click('[data-sc-action="scan"]');assert.equal(app.session.scanReport.diagnostics.length,0);assert.equal(app.session.scanReport.modules.find(m=>m.id==='inverter').source,'simulation module state');
  });
  await test('keyboard and shared controls leave one clock and no UI exceptions',async()=>{
   await document.dispatchEvent({type:'keydown',key:'1',target:document.body});assert.equal(app.session.view,'drive');
   await document.dispatchEvent({type:'keydown',key:'2',target:document.body});assert.equal(app.session.view,'diagnostics');
   await document.dispatchEvent({type:'keydown',key:'3',target:document.body});assert.equal(app.session.view,'diagnostics');
   await document.dispatchEvent({type:'keydown',key:'4',target:document.body});assert.equal(app.session.view,'diagnostics');
   assert.deepEqual(errors,[]);assert.equal($('#application-error').hidden,true);assert.ok([...timers.values()].filter(t=>t.ms<=100).length<=1);
  });
  console.log(`${passed} whole-application v0.7 contracts passed; parsed DOM + actual HTTP + CPU Canvas, not native browser layout.`);
  app.dispose();
 } finally {server.child.kill('SIGTERM');server.lines.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
