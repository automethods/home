"""Run the real HTTP handlers over in-memory streams, without binding a socket.

Also provides a JSON-lines adapter for frontend integration checks in restricted
local environments: each input is {path, body?}; each output is {status, data}.
"""
import io
import json
from types import SimpleNamespace
from unittest.mock import patch
from obdii_lab.server import create_server


class HandlerClient:
    def __init__(self):
        with patch('obdii_lab.server.ThreadingHTTPServer',
                   side_effect=lambda address, handler: SimpleNamespace(handler=handler)):
            self.server = create_server(0)
        self.lab = self.server.lab

    def request(self, path, body=None):
        handler = object.__new__(self.server.handler)
        handler.path = path
        data = b'' if body is None else json.dumps(body).encode()
        handler.headers = {'Content-Length': str(len(data))}
        handler.rfile = io.BytesIO(data)
        response = {}

        def send(content, mime='application/json', status=200, filename=None):
            response.update(status=status, data=json.loads(content))

        handler.send_bytes = send
        if body is None:
            handler.do_GET()
        else:
            handler.do_POST()
        return response


if __name__ == '__main__':
    import sys
    client = HandlerClient()
    for line in sys.stdin:
        try:
            request = json.loads(line)
            result = client.request(request['path'], request.get('body'))
        except Exception as error:
            result = {'status': 500, 'data': {'error': str(error)}}
        print(json.dumps(result, allow_nan=False), flush=True)
