'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const run=spawnSync('python3',['-c',`
import json
from obdii_lab.server import Lab
from obdii_lab.vehicle_systems import vehicle_system_catalog
def context(lab):
    return {**lab.state(), 'catalog':lab.catalog(), 'signals':lab.signal_catalog(), 'systems':vehicle_system_catalog(lab.sim.configuration), 'scannerCatalog':lab.scanner.catalog()}
e=Lab();e.set_vehicle('petrol_advanced');e.sim.control('ignition',True);e.sim.advance(.2);e.sim.control('start');e.sim.advance(1)
engine=context(e)
e.sim.set_connection('crank_sensor',False);e.sim.advance(.6);crank_open=context(e)
e.sim.set_connection('crank_sensor',True);e.sim.set_connection('maf',False);e.sim.advance(.7);maf_open=context(e)
e.sim.set_connection('maf',True);e.sim.advance(.1);maf_recovered=context(e)
b=Lab();b.set_vehicle('bev');b.sim.control('ignition',True);b.sim.advance(.2);battery=context(b)
b.sim.set_connection('pack_voltage',False);b.sim.advance(.7);battery_open=context(b)
b.sim.set_connection('pack_voltage',True);b.sim.advance(.2);battery_recovered=context(b)
i=Lab();i.set_vehicle('petrol_advanced');i.sim.control('ignition',True);i.sim.advance(.2);i.sim.control('start');i.sim.advance(1)
i.sim.set_connection_fault('crank_sensor',mode='intermittent',pattern='regular',connected_s=.2,dropout_s=1);intermittent_start=context(i)
i.sim.advance(.25);intermittent_open=context(i)
i.sim.advance(.6);intermittent_confirmed=context(i)
i.sim.advance(.4);intermittent_recovered=context(i)
j=Lab();j.set_vehicle('bev');j.sim.control('ignition',True);j.sim.advance(.2)
j.sim.set_connection_fault('pack_voltage',connected_s=.1,dropout_s=.8);j.sim.advance(.75);battery_intermittent_open=context(j)
j.sim.advance(.2);battery_intermittent_recovered=context(j)
print(json.dumps({'engine':engine,'crank_open':crank_open,'maf_open':maf_open,'maf_recovered':maf_recovered,'battery':battery,'battery_open':battery_open,'battery_recovered':battery_recovered,'intermittent_start':intermittent_start,'intermittent_open':intermittent_open,'intermittent_confirmed':intermittent_confirmed,'intermittent_recovered':intermittent_recovered,'battery_intermittent_open':battery_intermittent_open,'battery_intermittent_recovered':battery_intermittent_recovered}))
`],{cwd:root,encoding:'utf8',maxBuffer:24*1024*1024});
assert.equal(run.status,0,run.stderr||String(run.error||''));const fixture=JSON.parse(run.stdout);
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const harness=original.slice(original.indexOf('const decodeEntities='),original.indexOf("const elements=new Node('main')"));
const window={},context=vm.createContext({window,console,assert,document:{activeElement:null},Map,Set,createCanvas(){throw Error('No chart needed');}});
vm.runInContext(harness+'\nthis.HarnessNode=Node;',context);
const originalMatches=context.HarnessNode.prototype.matches;
context.HarnessNode.prototype.matches=function(selector){return selector.split(',').some(part=>{const base=part.replace(/\[[^\]]+\]/g,'').trim();if(base&&!originalMatches.call(this,base))return false;for(const m of part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)){if(!this.hasAttribute(m[1])||(m[2]!==undefined&&this.getAttribute(m[1])!==m[2]))return false;}return true;});};
vm.runInContext(fs.readFileSync(path.join(root,'web/session.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'web/connection-view.js'),'utf8'),context);
const calls={selected:[],connection:[],fault:[]},container=new context.HarnessNode('main');
let faultBehavior=null;
const view=window.ConnectionView.create(container,{onSelect:id=>calls.selected.push(id),onConnection:(id,connected)=>calls.connection.push([id,connected]),onConnectionFault:async(id,settings)=>{calls.fault.push([id,JSON.parse(JSON.stringify(settings))]);if(faultBehavior)await faultBehavior(id,settings);}});
const $=selector=>{const element=container.querySelector(selector);assert.ok(element,'Actual markup exists: '+selector);return element;};
const click=selector=>container.dispatchEvent({type:'click',target:$(selector)});
const update=(name,selection,extra={})=>view.update({...fixture[name],selection,controlsBusy:false,...extra});
const arrange=async value=>{const control=$('[data-cv-arrangement]');control.value=value;await container.dispatchEvent({type:'change',target:control});};
const plain=value=>JSON.parse(JSON.stringify(value));
const exactPins=()=>container.querySelectorAll('g[data-cv-select]').map(node=>node.dataset.cvSelect).filter(id=>id.startsWith('pin:')).sort();
function geometry(){
  const info=view.inspect();assert.equal(container.querySelectorAll('[data-cv-central="true"]').length,1);
  for(const side of ['left','right','footer']){
    const banks=info.groups.filter(bank=>bank.side===side).sort((a,b)=>a.y-b.y);
    for(let i=1;i<banks.length;i++)assert.ok(banks[i-1].y+banks[i-1].height<banks[i].y,'Bank sections do not overlap on '+side);
    const nodes=info.nodes.filter(node=>node.side===side).sort((a,b)=>a.y-b.y);
    for(let i=1;i<nodes.length;i++)assert.ok(nodes[i-1].y+nodes[i-1].height<nodes[i].y,'Device nodes do not overlap on '+side);
  }
  for(const node of info.nodes){
    assert.ok(node.x+node.width<info.body.x||node.x>info.body.x+info.body.width,'Each sensor is outside the single central housing');
    assert.ok(node.y+node.height<info.height,'Device fits within the sheet');
    assert.ok(node.pins[0].y>=node.y+166,'Pins leave room for characteristics and electrical value');
    for(let i=0;i<node.pins.length;i++){const pin=node.pins[i];assert.ok(pin.y+12<node.y+node.height,'Pin label stays in its node');if(i)assert.ok(pin.y-node.pins[i-1].y>=26,'Pin labels retain vertical separation');}
  }
}
function saveSvg(name){
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
  const serialize=node=>node.tagName==='#TEXT'?escape(node.textContent):`<${node.tagName.toLowerCase()}${Object.entries(node.attrs).map(([key,value])=>` ${key}="${escape(value)}"`).join('')}>${escape(node.ownText)}${node.children.map(serialize).join('')}</${node.tagName.toLowerCase()}>`;
  let svg=serialize($('.cv-schematic'));
  const css=fs.readFileSync(path.join(root,'web/connection-view.css'),'utf8');svg=svg.replace(/(<svg[^>]*>)/,'$1<style><![CDATA['+css+']]></style>');
  const output=path.resolve(root,'../qa/v091');fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,name),svg);
}
let passed=0;
async function check(name,fn){await fn();passed++;console.log('PASS '+name);}
(async()=>{
await check('functional arrangement remains the default and shows characteristics on each connected sensor',()=>{
  update('engine','ecu');assert.equal($('[data-cv-arrangement]').value,'function');assert.equal(view.inspect().arrangement,'function');geometry();
  for(const sensor of fixture.engine.systems.sensors.filter(sensor=>sensor.unit_id==='ecu'&&sensor.installed&&sensor.connection_id)){
    const badge=$('[data-cv-node-characteristics="'+sensor.socket_id+'"]');assert.match(badge.textContent,/sample/);assert.match(badge.textContent,new RegExp(sensor.period_ms+' ms'));assert.match(badge.textContent,new RegExp((1000/sensor.period_ms)+' Hz'));
  }
  assert.match($('[data-cv-arrangement-note]').textContent,/connector names and pins are unchanged/);
});
await check('signal-type arrangement splits bank sections without changing sockets, pins, wires or state',async()=>{
  const old=plain(view.inspect()),pins=plain(exactPins()),before=JSON.stringify(fixture.engine),callsBefore=calls.connection.length;
  await arrange('type');const next=plain(view.inspect());
  assert.equal(next.arrangement,'type');assert.deepEqual(next.nodes.map(n=>n.socketId).sort(),old.nodes.map(n=>n.socketId).sort());assert.deepEqual([...next.wires].sort(),[...old.wires].sort());assert.deepEqual(plain(exactPins()),pins);
  assert.deepEqual(next.categories.map(category=>category.id),['analog','pulse','network']);
  const split=next.groups.filter(group=>group.anchorId==='ecu_socket');assert.equal(split.length,2);assert.deepEqual(split.map(g=>g.categoryId).sort(),['analog','network']);assert.ok(split.every(group=>group.bankCode==='X1'));
  assert.equal(JSON.stringify(fixture.engine),before);assert.equal(calls.connection.length,callsBefore);geometry();saveSvg('ecu_signal_type.svg');
});
await check('sampling groups use exact configured periods and retain both parts of a split physical bank',async()=>{
  await arrange('rate');const info=plain(view.inspect());assert.ok(info.categories.some(c=>c.id==='period_20ms'));assert.ok(info.categories.some(c=>c.id==='period_500ms'));assert.ok(info.categories.some(c=>c.id==='network'));
  const air=info.groups.filter(group=>group.anchorId==='ecu_air_socket');assert.ok(air.length>=2,'Air intake bank split by its configured rates');assert.ok(air.some(part=>part.categoryId==='period_50ms'));assert.ok(air.some(part=>part.categoryId==='period_500ms'));assert.ok(air.every(part=>part.bankCode===air[0].bankCode));geometry();
});
await check('live pulse frequency is separate from sample rate and cannot reflow groups',()=>{
  const sensor=fixture.engine.systems.sensors.find(s=>s.id==='crank_sensor'),reading=fixture.engine.state.vehicle_sensors.crank_sensor;
  assert.match($('[data-cv-node-characteristics="crank_sensor_socket"]').textContent,/Pulse · sample 20 ms \/ 50 Hz/);
  assert.match($('[data-cv-node-electrical="crank_sensor_socket"]').textContent,new RegExp('Pulses '+Math.round(reading.frequency_hz)));
  const before=plain(view.inspect()),svg=$('.cv-schematic'),changed=structuredClone(fixture.engine);changed.state.vehicle_sensors.crank_sensor.frequency_hz=4200;changed.state.vehicle_sensors.crank_sensor.value=4200;
  view.update({...changed,selection:'ecu'});assert.equal($('.cv-schematic'),svg);assert.deepEqual(plain(view.inspect().groups),before.groups);assert.equal($('[data-cv-node-electrical="crank_sensor_socket"]').textContent,'Pulses 4,200 Hz');assert.equal(sensor.period_ms,20);
});
await check('an unplugged pulse input stays unavailable even while the last valid sample is held',()=>{
  const pending=structuredClone(fixture.engine);pending.network.effective_connections.crank_sensor=false;view.update({...pending,selection:'crank_sensor'});
  assert.equal($('[data-cv-node-electrical="crank_sensor_socket"]').textContent,'Pulses unavailable');assert.match($('[data-cv-node-sample="crank_sensor_socket"]').textContent,/waiting for next sample/);assert.match($('[data-cv-impact-facts]').textContent,/Last sample.*update pending/);
  update('crank_open','pin:crank_sensor_socket:2');assert.equal($('[data-cv-node-electrical="crank_sensor_socket"]').textContent,'Pulses unavailable');assert.match($('[data-cv-detail-body]').textContent,/Pulses unavailable/);assert.doesNotMatch($('[data-cv-detail-body]').textContent,/Pulses 0 Hz/);assert.match($('[data-cv-impact-facts]').textContent,/P0335 stored/);
});
await check('analogue pin detail includes transfer, range and sample timing without changing selected identity',()=>{
  update('engine','ecu');update('engine','pin:maf_socket:2');assert.equal(view.inspect().selection,'pin:maf_socket:2');const text=$('[data-cv-detail-body]').textContent;assert.match(text,/Analogue/);assert.match(text,/50 ms between readings · 20 Hz/);assert.match(text,/0.5 V to 4.5 V/);assert.match(text,/illustrat/i);assert.match(text,/Sensor electrical characteristics/);
});
await check('digital switch detail declares logic levels while a discrete selector does not invent voltage',async()=>{
  update('engine','body');update('engine','pin:brake_switch_socket:2');assert.match($('[data-cv-detail-body]').textContent,/0 V/);assert.match($('[data-cv-detail-body]').textContent,/5 V/);assert.match($('[data-cv-node-characteristics="brake_switch_socket"]').textContent,/Digital on\/off/);
  update('engine','transmission');update('engine','pin:transmission_range_socket:2');assert.match($('[data-cv-node-characteristics="transmission_range_socket"]').textContent,/Discrete state/);assert.match($('[data-cv-node-electrical="transmission_range_socket"]').textContent,/no voltage waveform/);assert.doesNotMatch($('[data-cv-detail-body]').textContent,/Sensor electrical characteristics/);
});
await check('CAN bit rate has its own category and detail rather than a fabricated sensor sample rate',()=>{
  update('engine','ecu');update('engine','pin:dlc_socket:6');const text=$('[data-cv-detail-body]').textContent;assert.match(text,/CAN network timing/);assert.match(text,/500,000 bit\/s/);assert.match(text,/not a sensor sample frequency/);assert.match($('[data-cv-node-characteristics="dlc_socket"]').textContent,/CAN network · 500 kbit\/s/);assert.doesNotMatch($('[data-cv-node-characteristics="dlc_socket"]').textContent,/sample/);
});
await check('BMU maps all modeled pack sensors by period and does not invent a connector for SOC',async()=>{
  update('battery','bmu');await arrange('function');const pins=plain(exactPins()),wireIds=plain(view.inspect().wires).sort();await arrange('rate');const info=plain(view.inspect());
  assert.equal(info.unitId,'bmu');assert.equal(info.nodes.filter(node=>['pack_voltage','pack_current','pack_temperature'].includes(node.componentId)).length,3);assert.equal(info.nodes.some(node=>node.componentId==='battery_soc'),false);
  assert.ok(info.categories.some(category=>category.id==='period_100ms'));assert.ok(info.categories.some(category=>category.id==='period_500ms'));assert.deepEqual(plain(exactPins()),pins);assert.deepEqual([...info.wires].sort(),wireIds);geometry();saveSvg('bmu_sample_rate.svg');
});
await check('type and sample grouping retain exact pin selection and direct disconnect callbacks',async()=>{
  update('battery','pin:pack_current_socket:2');const selection=view.inspect().selection;await arrange('type');assert.equal(view.inspect().selection,selection);assert.equal($('[data-cv-wire="pack_current_signal"]').classList.contains('cv-highlight'),true);
  await click('g[data-cv-node-connection="pack_current"]');assert.deepEqual(calls.connection.at(-1),['pack_current',false]);assert.equal(calls.selected.at(-1),'pack_current');geometry();
});
await check('focused connector disables whole-unit arrangement and restores it without touching the model',async()=>{
  await click('[data-cv-action="focus"]');assert.equal($('[data-cv-arrangement]').disabled,true);assert.equal(view.inspect().mode,'connector');const before=JSON.stringify(fixture.battery);await click('[data-cv-action="whole"]');assert.equal($('[data-cv-arrangement]').disabled,false);assert.equal(view.inspect().arrangement,'type');assert.equal(JSON.stringify(fixture.battery),before);
});
await check('BMU fault panel shows retained module event memory after input recovery',()=>{
  update('battery_open','pack_voltage');assert.match($('[data-cv-impact-facts]').textContent,/PACK_VOLTAGE_SIGNAL_MISSING.*retained unit events/);assert.doesNotMatch($('[data-cv-impact-facts]').textContent,/No sensor DTC/);
  update('battery_recovered','pack_voltage');assert.match($('[data-cv-impact-title]').textContent,/Connected/);assert.match($('[data-cv-impact-facts]').textContent,/PACK_VOLTAGE_SIGNAL_MISSING.*retained unit events/);
});
await check('intermittent controls send an explicit start request and view refresh never restarts the test',async()=>{
  update('engine','crank_sensor');assert.equal($('[data-cv-fault-controls]').hidden,false);assert.equal($('[data-cv-fault-connected]').value,'3');assert.equal($('[data-cv-fault-dropout]').value,'1');
  $('[data-cv-fault-pattern]').value='irregular';$('[data-cv-fault-connected]').value='2.2';$('[data-cv-fault-dropout]').value='0.3';await click('[data-cv-action="start-intermittent"]');assert.deepEqual(calls.fault.at(-1),['crank_sensor',{mode:'intermittent',pattern:'irregular',connected_s:2.2,dropout_s:.3}]);
  const before=calls.fault.length;update('engine','crank_sensor');update('engine','crank_sensor');assert.equal(calls.fault.length,before);assert.match($('[data-cv-fault-controls]').textContent,/Pause freezes the test/);assert.match($('[data-cv-fault-controls]').textContent,/stored codes remain/);
});
await check('explicit connected sensor selection stays the fault-control target when another sensor opens or recovers',async()=>{
  const maf=fixture.engine.systems.sensors.find(sensor=>sensor.id==='maf');
  update('crank_open','maf',{running:false});assert.equal($('[data-cv-impact-title]').textContent,maf.label+' · Connected');assert.match($('[data-cv-impact-clock]').textContent,/paused; use Run or Step to advance/);assert.doesNotMatch($('[data-cv-impact-clock]').textContent,/continues/);
  await click('[data-cv-action="start-intermittent"]');assert.equal(calls.fault.at(-1)[0],'maf','Connected MAF is the explicit target, not the unplugged crank input');
  for(const name of ['intermittent_start','intermittent_open','intermittent_confirmed','intermittent_recovered']){
    update(name,'maf',{running:true});assert.equal($('[data-cv-impact-title]').textContent,maf.label+' · Connected');assert.match($('[data-cv-impact-clock]').textContent,/· running\./);await click('[data-cv-action="start-intermittent"]');assert.equal(calls.fault.at(-1)[0],'maf','Other sensor phase must not retarget the fault controls');
  }
});
await check('fault impact shows live vehicle-global torque allowance on MAF loss and recovery',()=>{
  update('maf_open','maf');assert.equal(fixture.maf_open.state.vehicle.torque_factor,.7);assert.match($('[data-cv-impact-facts]').textContent,/Vehicle torque allowance70 %/);
  update('maf_recovered','maf');assert.equal(fixture.maf_recovered.state.vehicle.torque_factor,1);assert.match($('[data-cv-impact-facts]').textContent,/Vehicle torque allowance100 %/);
  update('battery_intermittent_open','pack_voltage');assert.match($('[data-cv-impact-facts]').textContent,/Vehicle torque allowance0 %/);
});
await check('real intermittent snapshots update phase, countdown, pulse validity and fault persistence without a browser timer',async()=>{
  update('intermittent_start','crank_sensor');assert.match($('[data-cv-fault-status]').textContent,/Connected · disconnects in 0.2 s · 0 dropouts/);assert.equal($('[data-cv-fault-connected]').value,'0.2');assert.equal($('[data-cv-action="stop-intermittent"]').hidden,false);
  update('intermittent_open','crank_sensor');assert.match($('[data-cv-fault-status]').textContent,/Disconnected · reconnects in 0.95 s · 1 dropouts/);assert.equal($('[data-cv-node-electrical="crank_sensor_socket"]').textContent,'Pulses unavailable');assert.equal($('[data-cv-state="crank_sensor_signal"]').textContent,'open');
  const text=$('[data-cv-fault-status]').textContent;update('intermittent_open','crank_sensor');assert.equal($('[data-cv-fault-status]').textContent,text,'No simulation advance means no countdown change');
  update('intermittent_confirmed','crank_sensor');assert.match($('[data-cv-impact-facts]').textContent,/P0335 stored/);assert.match($('[data-cv-fault-status]').textContent,/0.35 s/);
  update('intermittent_recovered','crank_sensor');assert.match($('[data-cv-fault-status]').textContent,/Connected · disconnects in 0.15 s · 1 dropouts/);assert.equal($('[data-cv-state="crank_sensor_signal"]').textContent,'connected');assert.match($('[data-cv-impact-facts]').textContent,/P0335 stored/);await click('[data-cv-action="stop-intermittent"]');assert.deepEqual(calls.fault.at(-1),['crank_sensor',{mode:'normal'}]);
});
await check('real BMU intermittent recovery preserves unit fault events and restores sampled voltage',()=>{
  update('battery_intermittent_open','pack_voltage');assert.match($('[data-cv-fault-status]').textContent,/Disconnected/);assert.match($('[data-cv-impact-facts]').textContent,/PACK_VOLTAGE_SIGNAL_MISSING.*retained unit events/);assert.equal($('[data-cv-node-electrical="pack_voltage_socket"]').textContent,'Voltage unavailable');
  update('battery_intermittent_recovered','pack_voltage');assert.match($('[data-cv-fault-status]').textContent,/Connected/);assert.match($('[data-cv-node-electrical="pack_voltage_socket"]').textContent,/Signal .* V/);assert.match($('[data-cv-impact-facts]').textContent,/PACK_VOLTAGE_SIGNAL_MISSING.*retained unit events/);assert.doesNotMatch($('[data-cv-impact-facts]').textContent,/P0335/);
});
await check('invalid durations and rejected operations produce visible errors without phantom scheduling',async()=>{
  update('engine','crank_sensor');const before=calls.fault.length;$('[data-cv-fault-dropout]').value='0';await click('[data-cv-action="start-intermittent"]');assert.equal(calls.fault.length,before);assert.match($('[data-cv-fault-error]').textContent,/0.002/);assert.equal($('[data-cv-fault-error]').hidden,false);
  $('[data-cv-fault-dropout]').value='1';faultBehavior=async()=>{throw Error('Fixture backend rejection');};await click('[data-cv-action="start-intermittent"]');assert.match($('[data-cv-fault-error]').textContent,/Fixture backend rejection/);assert.equal($('[data-cv-action="start-intermittent"]').disabled,false);faultBehavior=null;
});
await check('pending intermittent request disables all connection actions and module/network selections do not expose a sensor test',async()=>{
  let finish;faultBehavior=()=>new Promise(resolve=>{finish=resolve;});const pending=click('[data-cv-action="start-intermittent"]');await Promise.resolve();assert.equal($('[data-cv-action="start-intermittent"]').disabled,true);assert.equal($('g[data-cv-node-connection="crank_sensor"]').getAttribute('aria-disabled'),'true');finish();await pending;faultBehavior=null;
  update('engine','dlc');assert.equal($('[data-cv-fault-controls]').hidden,true);update('battery','bmu');assert.equal($('[data-cv-fault-controls]').hidden,true);
});
view.dispose();console.log(JSON.stringify({suite:'Sensor schematic characteristics and fault controls v0.9.1',passed,fixtures:'Actual Python Lab / sensor catalog / VehicleSim snapshots, including intermittent phases and retained ECU / BMU memory',scope:'Actual JS callbacks and parsed SVG geometry. No native browser, electrical waveform, GPU or Mint claim.'}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
