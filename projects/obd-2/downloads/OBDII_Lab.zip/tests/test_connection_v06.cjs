'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const fixtures=spawnSync('python3',['-c',`
import json
from obdii_lab.core import Sim
from obdii_lab.network import network_catalog, observe_network
from obdii_lab.instrumentation import signal_catalog
from obdii_lab.server import Lab
from obdii_lab.vehicle_systems import vehicle_system_catalog
s=Sim('phev','city_drive');s.advance(.1);healthy=s.snapshot()
s.set_connection('ect',False);s.advance(.6);ect=s.snapshot()
s.set_connection('dlc',False);dlc=s.snapshot()
s.set_connection('wheel_fl',False);s.advance(.1);wheel=s.snapshot()
e=Sim('engine','manual');e.advance(.1);engine=e.snapshot()
lab=Lab();lab.set_vehicle('petrol_advanced');lab.sim.control('ignition',True);lab.sim.advance(.2)
advanced={**lab.state(),'catalog':lab.catalog(),'signals':lab.signal_catalog(),'systems':vehicle_system_catalog(lab.sim.configuration),'scannerCatalog':lab.scanner.catalog()}
lab.sim.control('start');lab.sim.advance(1.0);advanced_running={**advanced,**lab.state()}
lab.sim.set_connection('crank_sensor',False);lab.sim.advance(.6);crank_fault={**advanced,**lab.state()}
print(json.dumps({'advanced_running':advanced_running,'crank_fault':crank_fault,'catalog':network_catalog(),'signals':signal_catalog(),'advanced':advanced,'states':{name:{'state':state,'network':observe_network(state)} for name,state in [('healthy',healthy),('ect',ect),('dlc',dlc),('wheel',wheel),('engine',engine)]}}))
`],{cwd:root,encoding:'utf8',maxBuffer:8*1024*1024});assert.equal(fixtures.status,0,fixtures.stderr||String(fixtures.error||''));const f=JSON.parse(fixtures.stdout);
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const harness=original.slice(original.indexOf('const decodeEntities='),original.indexOf("const elements=new Node('main')"));
const calls={selected:[],watch:[],navigation:[],vehicle:[],connection:[]};
const window={fetch(){},VehicleView:{create(container,options){calls.vehicle.push(['create',options]);return{update(...args){calls.vehicle.push(['update',...args]);},select(id){calls.vehicle.push(['select',id]);},setVisible(value){calls.vehicle.push(['visible',value]);},resize(){},dispose(){},inspect(){return{fixture:true};}};}}};
const context=vm.createContext({assert,window,console,document:{activeElement:null},AbortController,Map,Set,createCanvas(){throw Error('No chart needed');}});
vm.runInContext(harness+'\nthis.HarnessNode=Node;',context);
const originalMatches=context.HarnessNode.prototype.matches;
context.HarnessNode.prototype.matches=function(selector){return selector.split(',').some(part=>{const base=part.replace(/\[[^\]]+\]/g,'').trim();if(base&&!originalMatches.call(this,base))return false;for(const m of part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)){if(!this.hasAttribute(m[1])||(m[2]!==undefined&&this.getAttribute(m[1])!==m[2]))return false;}return true;});};
vm.runInContext(fs.readFileSync(path.join(root,'web/session.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'web/connection-view.js'),'utf8'),context);
const container=new context.HarnessNode('main');
const view=window.ConnectionView.create(container,{onSelect:value=>calls.selected.push(value),onWatch:(id,value)=>calls.watch.push([id,value]),onNavigate:value=>calls.navigation.push(value),onConnection:(id,value)=>calls.connection.push([id,value])});
const ctx=(name,selection)=>({...f.states[name],catalog:f.catalog,signals:f.signals,selection,watch:[],busy:false});
const $=selector=>{const element=container.querySelector(selector);assert.ok(element,'Markup exists: '+selector);return element;};
const click=selector=>container.dispatchEvent({type:'click',target:$(selector)});
let passed=0;
async function check(name,fn){await fn();passed++;console.log('PASS '+name);}
(async()=>{
await check('overview exposes four existing circuits through shared component selection',async()=>{view.update(ctx('healthy','overview'));assert.equal(container.querySelectorAll('.cv-circuit-row').length,4);await click('[data-cv-select="coolant_sensor"]');assert.equal(calls.selected.at(-1),'coolant_sensor');});
await check('coolant diagram uses catalog endpoints and actual open-circuit observation',()=>{view.update(ctx('ect','coolant_sensor'));assert.equal(view.inspect().anchorId,'coolant_socket');assert.equal($('[data-cv-value="ect_signal"]').textContent,'5 V');assert.equal($('[data-cv-state="ect_signal"]').textContent,'open');assert.equal($('[data-cv-wire="ect_signal"]').classList.contains('cv-open'),true);assert.match($('[data-cv-diagram]').innerHTML,/pin:ecu_socket:2/);});
await check('wire selection preserves the socket being inspected and Graph shares its real state path',async()=>{view.update(ctx('healthy','ecu'));view.update(ctx('healthy','wire:ect_signal'));assert.equal(view.inspect().anchorId,'ecu_socket');await click('[data-cv-watch="sensors.ect_voltage_v"]');assert.deepEqual(calls.watch.at(-1),['sensors.ect_voltage_v',true]);assert.equal(calls.navigation.at(-1),'live');});
await check('DLC face exposes all sixteen pins, CAN loss and independent supply reference',()=>{view.update(ctx('dlc','dlc'));assert.equal(container.querySelectorAll('.cv-dlc-pin').length,16);assert.equal($('[data-cv-value="dlc_can_h"]').textContent,'Unavailable');assert.equal($('[data-cv-value="dlc_power"]').textContent,'12.6 V');assert.equal($('[data-cv-state="dlc_power"]').textContent,'connected');assert.match($('[data-cv-diagram]').innerHTML,/scan_socket/);});
await check('keyboard selection of a schematic pin preserves exact socket and cavity',async()=>{const target=$('g[data-cv-select="pin:dlc_socket:14"]');await container.dispatchEvent({type:'keydown',key:'Enter',target});assert.equal(calls.selected.at(-1),'pin:dlc_socket:14');});
await check('missing wheel input remains unavailable and noninstalled modules are labeled',()=>{view.update(ctx('wheel','wheel_fl'));assert.equal($('[data-cv-value="wheel_fl_signal"]').textContent,'Unavailable');view.update(ctx('engine','abs'));assert.match($('[data-cv-connection]').textContent,/Not installed/);});
await check('hiding and returning uses the latest snapshot without a view-owned timer',()=>{view.update(ctx('healthy','coolant_sensor'));view.setVisible(false);view.update(ctx('ect','coolant_sensor'));view.setVisible(true);assert.equal($('[data-cv-value="ect_signal"]').textContent,'5 V');});
await check('location and diagnosis actions navigate without resetting the model',async()=>{await click('[data-cv-action="location"]');assert.equal(calls.navigation.at(-1),'locations');await click('[data-cv-action="diagnosis"]');assert.equal(calls.navigation.at(-1),'diagnosis');});
await check('configured ECU wiring includes all fitted sensor connector banks in one sheet',()=>{
  view.update({...f.advanced,selection:'ecu'});const info=view.inspect();assert.equal(info.unitId,'ecu');assert.equal(info.mode,'system');assert.ok(info.groups.length>=4);
  for(const id of ['ect_signal','crank_sensor_signal','maf_signal'])assert.ok(info.wires.includes(id),id+' stays in the complete unit');
  const svg=$('.cv-schematic'),box=svg.getAttribute('viewBox').split(' ').map(Number);assert.equal(box[2],1440);
  assert.equal(svg.querySelectorAll('[data-cv-central="true"]').length,1,'Exactly one controller housing');assert.equal(svg.querySelectorAll('.cv-controller-title').length,1);
  for(const circle of svg.querySelectorAll('circle')){const x=Number(circle.getAttribute('cx')),y=Number(circle.getAttribute('cy'));assert.ok(x>=0&&x<=box[2]&&y>=0&&y<=box[3],'Every connector cavity fits within the sheet');}
  for(const side of ['left','right','footer']){const groups=info.groups.filter(g=>g.side===side).sort((a,b)=>a.y-b.y);for(let i=1;i<groups.length;i++)assert.ok(groups[i-1].y+groups[i-1].height<groups[i].y,'Connector groups do not overlap on '+side);}
  for(const node of info.nodes){assert.ok(node.x<info.body.x||node.x>info.body.x+info.body.width,'Sensors surround the central controller');assert.ok(node.y+node.height<box[3]);}
  assert.ok(info.nodes.some(n=>n.side==='left')&&info.nodes.some(n=>n.side==='right'),'Sensors are placed around both sides');
});
await check('a selected sensor pin highlights its path while retaining all ECU groups and SVG identity',()=>{
  const before=$('.cv-schematic'),groups=view.inspect().groups.length;
  view.update({...f.advanced,selection:'pin:maf_socket:2'});
  assert.equal(view.inspect().unitId,'ecu');assert.equal(view.inspect().groups.length,groups);assert.equal($('.cv-schematic'),before);
  assert.equal($('[data-cv-wire="maf_signal"]').classList.contains('cv-highlight'),true);
  assert.equal($('[data-cv-wire="ect_signal"]').classList.contains('cv-dim'),true);
  assert.match($('[data-cv-detail]').textContent,/Unplug effect/);assert.match($('[data-cv-detail]').textContent,/Fictional ECU/);
});
await check('connector focus and zoom are explicit view-only actions',async()=>{
  const time=f.advanced.state.t;await click('[data-cv-action="focus"]');assert.equal(view.inspect().mode,'connector');assert.equal(view.inspect().groups.length,1);assert.equal(view.inspect().unitId,'ecu');assert.equal($('.cv-controller-title').textContent,'Engine ECU');
  await click('[data-cv-action="actual"]');assert.equal(view.inspect().zoom,1);
  await click('[data-cv-action="zoom-in"]');assert.ok(view.inspect().zoom>1);
  await click('[data-cv-action="fit"]');assert.equal(view.inspect().zoom,'fit');
  await click('[data-cv-action="whole"]');assert.equal(view.inspect().mode,'system');assert.ok(view.inspect().groups.length>=4);
  assert.equal(f.advanced.state.t,time);
});
await check('DLC pin detail explains paired data and the limited branch unplug model',()=>{
  view.update({...f.advanced,selection:'dlc'});view.update({...f.advanced,selection:'pin:dlc_socket:6'});
  assert.match($('[data-cv-detail]').textContent,/Companion cavity 14/);
  assert.match($('[data-cv-detail]').textContent,/vehicle control continues/);
  assert.match($('[data-cv-detail]').textContent,/not simulated/);
});
await check('local connector action sends the declared sensor connection without changing the selected sheet',async()=>{
  view.update({...f.advanced,selection:'ecu'});view.update({...f.advanced,selection:'pin:maf_socket:2',busy:true,controlsBusy:false});
  const before=$('.cv-schematic'),button=$('[data-cv-action="connection"]');assert.equal(button.disabled,false);assert.match(button.textContent,/Disconnect sensor connector/);
  await click('[data-cv-action="connection"]');assert.deepEqual(calls.connection.at(-1),['maf',false]);assert.equal($('.cv-schematic'),before);
  const disconnected=JSON.parse(JSON.stringify(f.advanced));disconnected.network.effective_connections.maf=false;
  view.update({...disconnected,selection:'pin:maf_socket:2'});assert.match(button.textContent,/Reconnect sensor connector/);
  await click('[data-cv-action="connection"]');assert.deepEqual(calls.connection.at(-1),['maf',true]);
  view.update({...f.advanced,selection:'pin:maf_socket:2',controlsBusy:true});assert.equal(button.disabled,true);
});
await check('local DLC action opens only its CAN branch and reference pins have no invented switch',async()=>{
  view.update({...f.advanced,selection:'pin:dlc_socket:6'});assert.match($('[data-cv-action="connection"]').textContent,/Open tester CAN branch/);
  await click('[data-cv-action="connection"]');assert.deepEqual(calls.connection.at(-1),['dlc',false]);
  view.update({...f.advanced,selection:'pin:dlc_socket:16'});assert.equal($('[data-cv-connection-action]').hidden,true);
  view.update({...f.advanced,selection:'wire:dlc_power'});assert.equal($('[data-cv-connection-action]').hidden,true);
  view.update(ctx('engine','abs'));assert.equal($('[data-cv-action="connection"]').disabled,true);
});
await check('each supported peripheral sensor has a visible direct connector action with keyboard activation',async()=>{
  view.update({...f.advanced_running,selection:'ecu'});
  for(const node of view.inspect().nodes.filter(n=>n.connectionId)){
    const button=$('g[data-cv-node-connection="'+node.connectionId+'"]');assert.equal(button.getAttribute('role'),'button');assert.equal(button.getAttribute('tabindex'),'0');assert.equal(button.getAttribute('aria-disabled'),'false');
    assert.match($('[data-cv-node-state="'+node.socketId+'"]').textContent,/Connected/);
  }
  const button=$('g[data-cv-node-connection="crank_sensor"]'),svg=$('.cv-schematic');
  await container.dispatchEvent({type:'keydown',key:'Enter',target:button});assert.deepEqual(calls.connection.at(-1),['crank_sensor',false]);assert.equal(calls.selected.at(-1),'crank_sensor');assert.equal($('.cv-schematic'),svg);
});
await check('crank unplug shows the real missing input, stopped combustion and stored DTC beside its reconnect control',async()=>{
  view.update({...f.crank_fault,selection:'crank_sensor'});assert.equal($('[data-cv-node-state="crank_sensor_socket"]').textContent,'Unplugged');assert.match($('[data-cv-node-sample="crank_sensor_socket"]').textContent,/unavailable/);
  assert.equal($('[data-cv-node-action-text="crank_sensor"]').textContent,'Reconnect');
  assert.equal($('[data-cv-impact]').hidden,false);assert.match($('[data-cv-impact-title]').textContent,/Crankshaft speed.*Unplugged/);
  assert.match($('[data-cv-impact-facts]').textContent,/Combustion stopped \/ start inhibited/);assert.match($('[data-cv-impact-facts]').textContent,/P0335 stored/);
  assert.match($('[data-cv-impact-clock]').textContent,/motion can coast/);assert.match($('[data-cv-impact-effect]').textContent,/inhibit/i);
  assert.equal($('[data-cv-output="engine_running"]').textContent,'Stopped');
  await click('g[data-cv-node-connection="crank_sensor"]');assert.deepEqual(calls.connection.at(-1),['crank_sensor',true]);
});
await check('output nodes read actual model values and contain no invented actuator disconnect controls',()=>{
  view.update({...f.advanced_running,selection:'ecu'});const output=$('.cv-output-node');assert.match(output.textContent,/Engine response/);assert.match(output.textContent,/READ ONLY/);assert.match(output.textContent,/No unplug control/);
  assert.equal(output.querySelectorAll('[data-cv-node-connection]').length,0);assert.equal($('[data-cv-output="engine_running"]').textContent,'Running');
  view.update({...f.advanced_running,selection:'ecu',controlsBusy:true});assert.equal($('g[data-cv-node-connection="crank_sensor"]').getAttribute('aria-disabled'),'true');
});
await check('Locations resolves pin to its component and keeps model state shared',()=>{const locationContainer=new context.HarnessNode('main'),locations=window.LocationsView.create(locationContainer,{onNavigate:value=>calls.navigation.push(value)});locations.update(ctx('healthy','pin:dlc_socket:14'));assert.equal(locations.inspect().selected,'dlc');assert.equal(calls.vehicle.find(call=>call[0]==='create')[1].locator,true);assert.equal(calls.vehicle.findLast(call=>call[0]==='update')[1],f.states.healthy.state);assert.equal(calls.vehicle.findLast(call=>call[0]==='select')[1],'dlc');locations.setVisible(false);assert.equal(calls.vehicle.at(-1)[1],false);locations.dispose();});
view.dispose();console.log(JSON.stringify({suite:'Wiring and Locations contracts',passed,fixtures:'actual Python model and network observations',scope:'Actual module callbacks via limited parsed-node harness; no native browser layout or GPU claims'}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
