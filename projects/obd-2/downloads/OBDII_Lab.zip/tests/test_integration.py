"""End-to-end local API, CLI exports, and deterministic bridge checks.

Uses only loopback and temporary files. No external network or vehicle adapter.
"""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.core import Sim
from obdii_lab.runner import run_experiment
from obdii_lab.server import create_server

ROOT = Path(__file__).resolve().parents[1]


class HttpIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None, headers=None):
        headers = dict(headers or {})
        if body is not None:
            headers["Content-Type"] = "application/json"
        request = Request(self.base + path,
                          data=None if body is None else json.dumps(body).encode(),
                          headers=headers)
        with urlopen(request, timeout=10) as response:
            raw = response.read()
            return json.loads(raw) if "application/json" in response.headers["Content-Type"] else raw

    def setUp(self):
        self.call("/api/reset", {"profile": "engine", "scenario": "manual"})

    def test_served_application_and_scenario_metadata(self):
        page = self.call("/").decode()
        self.assertIn("OBD II Lab", page)
        self.assertIn('src="/web/session.js"', page)
        self.assertIn('src="/web/application.js"', page)
        self.assertNotIn('src="/web/app.js"', page)
        self.assertIn("AppSession", self.call("/web/session.js").decode())
        meta = self.call("/api/meta")
        self.assertIn("phev_city", [s["id"] for s in meta["scenarios"]])
        self.assertEqual(meta["plant_step_s"], Sim.DT)

    def test_signal_api_reports_units_periods_provenance_and_uninstalled_modules(self):
        meta = self.call("/api/meta")
        catalog = {item["id"]: item for item in meta["signals"]}
        self.assertGreaterEqual(len(catalog), 25)
        self.assertEqual(catalog["sensors.ect_voltage_v"]["unit"], "V")
        self.assertEqual(catalog["sensors.ect_voltage_v"]["source"], "ECU ADC")
        self.assertEqual(catalog["sensors.ect_voltage_v"]["period_ms"], 10)
        self.assertEqual(catalog["bmu_report.pack_voltage_v"]["period_ms"], 100)
        self.assertEqual(catalog["mil"]["kind"], "digital")
        self.assertEqual(catalog["contactor"]["kind"], "state")
        self.assertIn("teaching", catalog["sensors.ect_voltage_v"]["provenance"].lower())
        probes = self.call("/api/signals")
        self.assertEqual(len(probes["catalog"]), len(catalog))
        self.assertEqual(probes["signals"]["sensors.ect_c"]["validity"], "valid")
        self.assertAlmostEqual(probes["signals"]["sensors.ect_c"]["value"], 20, delta=.03)
        self.assertEqual(probes["signals"]["battery_voltage_v"]["validity"], "unavailable")
        self.assertIsNone(probes["signals"]["battery_voltage_v"]["value"])
        # Reading probe metadata and values must not advance simulation time.
        self.assertEqual(self.call("/api/state")["state"]["t"], 0)

    def test_guided_ect_workflow_exposes_electrical_fault_fallback_and_repaired_memory(self):
        reset = self.call("/api/reset", {"profile": "engine", "scenario": "manual",
                                       "config": {"initial_coolant_c": 25, "ambient_c": 25}})
        baseline = reset["signals"]
        self.assertEqual(baseline["sensors.ect_resistance_ohm"]["value"], 2500)
        self.assertAlmostEqual(baseline["sensors.ect_node_v"]["value"], 2.6595744680851063)
        self.assertEqual(baseline["sensors.ect_adc_count"]["value"], 2178)
        self.assertEqual(baseline["sensors.ect_c"]["validity"], "valid")
        pid = self.call("/api/diagnostic", {"payload": "01 05"})
        self.assertEqual(pid["diagnostic"]["response_hex"], "41 05 41")  # 25 + 40 = 65.

        opened = self.call("/api/advance", {"seconds": .02, "inputs": {"fault": "ect_open"}})
        self.assertEqual(opened["signals"]["sensors.ect_node_v"]["value"], 5)
        self.assertEqual(opened["signals"]["sensors.ect_node_v"]["validity"], "valid")
        self.assertEqual(opened["signals"]["sensors.ect_adc_count"]["value"], 4095)
        self.assertEqual(opened["signals"]["sensors.ect_current_ma"]["value"], 0)
        self.assertIsNone(opened["signals"]["sensors.ect_resistance_ohm"]["value"])
        self.assertEqual(opened["signals"]["sensors.ect_c"]["value"], -40)
        self.assertEqual(opened["signals"]["sensors.ect_c"]["validity"], "invalid")
        self.assertFalse(opened["state"]["pending_dtcs"])
        self.assertGreater(opened["state"]["coolant_c"], 24.9)

        pending = self.call("/api/advance", {"seconds": .2})
        self.assertEqual(pending["state"]["pending_dtcs"], ["P0118"])
        self.assertFalse(pending["state"]["mil"])
        self.assertEqual(pending["signals"]["sensors.ect_used_c"]["value"], 80)
        self.assertEqual(pending["signals"]["sensors.ect_used_c"]["validity"], "substituted")
        self.assertEqual(pending["signals"]["ect_derate_factor"]["value"], .65)
        confirmed = self.call("/api/advance", {"seconds": .3})
        self.assertEqual(confirmed["state"]["dtcs"], ["P0118"])
        self.assertTrue(confirmed["signals"]["mil"]["value"])
        self.assertEqual(confirmed["state"]["freeze_frame"]["t"], .5)
        stored = self.call("/api/diagnostic", {"payload": "03"})
        self.assertEqual(stored["diagnostic"]["response_hex"], "43 01 01 18")
        self.assertEqual(stored["signals"]["sensors.ect_used_c"]["validity"], "substituted")
        self.assertEqual(stored["signals"]["sensors.ect_c"]["validity"], "invalid")
        failed_pid = self.call("/api/diagnostic", {"payload": "01 05"})
        self.assertEqual(failed_pid["diagnostic"]["response_hex"], "41 05 00")

        repaired = self.call("/api/advance", {"seconds": .02, "inputs": {"fault": "none"}})
        self.assertEqual(repaired["signals"]["sensors.ect_c"]["validity"], "valid")
        self.assertEqual(repaired["signals"]["sensors.ect_used_c"]["validity"], "valid")
        self.assertLess(repaired["signals"]["sensors.ect_voltage_v"]["value"], 4.95)
        self.assertEqual(repaired["signals"]["ect_derate_factor"]["value"], 1)
        self.assertTrue(repaired["signals"]["mil"]["value"])
        cleared = self.call("/api/diagnostic", {"payload": "04"})
        self.assertEqual(cleared["diagnostic"]["response_hex"], "44")
        self.assertFalse(cleared["signals"]["mil"]["value"])
        self.assertEqual(cleared["signals"]["sensors.ect_c"]["validity"], "valid")
        self.assertEqual(self.call("/api/diagnostic", {"payload": "03"})["diagnostic"]["response_hex"], "43 00")

    def test_reset_advance_and_core_match(self):
        config = {"initial_soc_pct": 62, "initial_speed_kph": 18}
        initial = self.call("/api/reset", {"profile": "phev", "scenario": "manual", "config": config})
        self.assertEqual(initial["state"]["profile"], "phev")
        self.assertEqual(initial["state"]["soc_pct"], 62)
        inputs = {"throttle": .32, "abs_enabled": True}
        reference = Sim("phev", "manual", config)
        expected = reference.advance(.2, inputs)
        result = self.call("/api/advance", {"seconds": .2, "inputs": inputs})
        self.assertEqual(result["state"], expected)
        self.assertEqual([p["t"] for p in result["history"]], [.1, .2])
        # Empty input dict preserves previous driver overrides.
        result = self.call("/api/advance", {"seconds": .2})
        self.assertEqual(result["state"], reference.advance(.2))

    def test_fault_diagnostics_clear_and_redetect(self):
        self.call("/api/reset", {"scenario": "ect_open"})
        state = self.call("/api/advance", {"seconds": 4})["state"]
        self.assertEqual(state["dtcs"], ["P0118"])
        self.assertGreater(state["coolant_c"], 20)
        self.assertEqual(state["sensors"]["ect_c"], -40)
        read = self.call("/api/diagnostic", {"payload": "03"})
        self.assertEqual(read["diagnostic"]["response_hex"], "43 01 01 18")
        clear = self.call("/api/diagnostic", {"payload": "04"})
        self.assertEqual(clear["diagnostic"]["response_hex"], "44")
        self.assertEqual(clear["state"]["dtcs"], [])
        self.assertEqual(clear["state"]["inputs"]["fault"], "ect_open")
        self.assertEqual(self.call("/api/advance", {"seconds": .6})["state"]["dtcs"], ["P0118"])

    def test_exports_capture_trace_and_simulation(self):
        self.call("/api/advance", {"seconds": 1})
        self.call("/api/diagnostic", {"payload": "09 02", "can_id": "7DF"})
        data = self.call("/api/export.json")
        self.assertEqual(data["schema_version"], "obdii-lab.run.v1")
        self.assertEqual(data["final_state"]["t"], 1)
        self.assertEqual(data["diagnostics"][0]["frames"][2]["kind"], "FC")
        table = list(csv.DictReader(io.StringIO(self.call("/api/export.csv").decode())))
        self.assertEqual(len(table), 11)  # t=0 followed by 10 Hz logging.
        self.assertEqual(float(table[-1]["t"]), 1)
        self.assertIn("wheel_fl_kph", table[-1])
        trace = self.call("/api/trace.txt").decode()
        self.assertIn("7E0  30 00 00", trace)
        self.assertIn("LAB00000000000001", trace)

    def test_exports_preserve_electrical_measurement_and_held_bmu_report_evidence(self):
        self.call("/api/reset", {"scenario": "ect_open"})
        self.call("/api/advance", {"seconds": 4})
        table = list(csv.DictReader(io.StringIO(self.call("/api/export.csv").decode())))
        fault = table[-1]
        self.assertEqual(float(fault["ect_node_v"]), 5)
        self.assertEqual(float(fault["ect_voltage_v"]), 5)
        self.assertEqual(int(fault["ect_adc_count"]), 4095)
        self.assertEqual(fault["ect_resistance_ohm"], "")  # Open is not a zero-ohm short.
        self.assertEqual(float(fault["ect_current_ma"]), 0)
        self.assertEqual(fault["ect_sensor_valid"], "False")
        self.assertEqual(float(fault["ect_sensed_c"]), -40)
        self.assertEqual(float(fault["ect_used_c"]), 80)
        self.assertAlmostEqual(float(fault["ect_fault_elapsed_s"]), .99)
        self.assertEqual(float(fault["ect_derate_factor"]), .65)
        self.assertEqual(fault["bmu_report_pack_voltage_v"], "")
        exported = self.call("/api/export.json")
        self.assertIn("Synthetic educational model", exported["provenance"])
        self.assertIn("not Toyota calibration", exported["provenance"])
        self.assertEqual(exported["parameters"]["ect_r25_ohm"], 2500)
        self.assertEqual(exported["parameters"]["ect_pullup_ohm"], 2200)
        self.assertEqual(exported["parameters"]["ect_adc_bits"], 12)

        self.call("/api/reset", {"scenario": "bmu_timeout"})
        self.call("/api/advance", {"seconds": 5})
        self.call("/api/advance", {"seconds": 3.4})
        probes = self.call("/api/signals")["signals"]
        self.assertEqual(probes["bmu_report.pack_current_a"]["validity"], "stale")
        self.assertEqual(probes["battery_current_a"]["validity"], "valid")
        table = list(csv.DictReader(io.StringIO(self.call("/api/export.csv").decode())))
        stale = table[-1]
        self.assertEqual(float(stale["bmu_report_time_s"]), 7.9)
        self.assertGreater(float(stale["bmu_report_pack_current_a"]), 0)
        self.assertEqual(float(stale["battery_current_a"]), 0)
        self.assertEqual(stale["bmu_report_stale"], "True")
        self.assertGreater(float(stale["bmu_message_age_ms"]), 300)

    def test_invalid_requests_preserve_existing_state(self):
        before = self.call("/api/state")["state"]
        cases = [
            ("/api/advance", {"seconds": -1}),
            ("/api/advance", {"seconds": 1, "inputs": {"throttle": 2}}),
            ("/api/reset", {"profile": "unknown", "scenario": "manual"}),
            ("/api/reset", {"config": {"capacity_ah": 0}}),
        ]
        for path, body in cases:
            with self.subTest(path=path, body=body):
                with self.assertRaises(HTTPError) as caught:
                    self.call(path, body)
                self.assertEqual(caught.exception.code, 400)
                self.assertEqual(self.call("/api/state")["state"], before)

    def test_external_origin_rejected(self):
        with self.assertRaises(HTTPError) as caught:
            self.call("/api/advance", {"seconds": 1}, {"Origin": "https://example.invalid"})
        self.assertEqual(caught.exception.code, 400)
        self.assertEqual(self.call("/api/state")["state"]["t"], 0)


class CommandLineIntegrationTests(unittest.TestCase):
    def run_cli(self, args, stdin=None):
        return subprocess.run([sys.executable, str(ROOT / "run.py"), *args],
                              cwd=ROOT, input=stdin, text=True, capture_output=True,
                              timeout=20)

    def test_cli_exports_reproduce_runner(self):
        with tempfile.TemporaryDirectory(prefix="obdii-lab-") as directory:
            prefix = Path(directory) / "ect"
            result = self.run_cli(["--scenario", "ect_open", "--duration", "4",
                                   "--request", "03", "--output", str(prefix)])
            self.assertEqual(result.returncode, 0, result.stderr)
            run = json.loads(prefix.with_suffix(".json").read_text())
            expected = run_experiment("ect_open", 4)
            self.assertEqual(run["final_state"], expected.snapshot())
            self.assertEqual(run["diagnostics"][0]["response_hex"], "43 01 01 18")
            self.assertTrue(prefix.with_suffix(".csv").is_file())
            self.assertTrue(prefix.with_suffix(".trace.txt").is_file())

    def test_cli_rejects_unknown_scenario_and_bad_input(self):
        for args in [["--scenario", "missing"], ["--scenario", "manual", "--set", "throttle=2"]]:
            result = self.run_cli(args)
            self.assertEqual(result.returncode, 2)
            self.assertIn("error:", result.stderr)

    def test_bridge_deterministic_exchange_and_recovery(self):
        commands = [
            {"op": "reset", "profile": "phev", "config": {"initial_soc_pct": 65}},
            {"op": "step", "dt_s": .2, "inputs": {"throttle": .3}},
            {"op": "observe"},
            {"op": "diagnostic", "payload": "01 0C", "can_id": "7DF"},
            {"op": "step", "dt_s": -1},
            {"op": "observe"},
            {"op": "quit"},
        ]
        result = self.run_cli(["--bridge"], "\n".join(json.dumps(c) for c in commands) + "\n")
        self.assertEqual(result.returncode, 0, result.stderr)
        replies = [json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual(len(replies), len(commands))
        reference = Sim("phev", "manual", {"initial_soc_pct": 65})
        expected = reference.advance(.2, {"throttle": .3})
        self.assertEqual(replies[1]["state"], expected)
        self.assertEqual(replies[2]["state"], expected)
        self.assertEqual(replies[3]["diagnostic"]["response_hex"], "41 0C 00 00")
        self.assertFalse(replies[4]["ok"])
        self.assertEqual(replies[5]["state"], expected)
        self.assertTrue(replies[6]["stopped"])


if __name__ == "__main__":
    unittest.main()
