"""Circuit and probe checks for the teaching schematics, not an OEM validation.

Reference equations/topology: TI SBAA338A and Analog Devices' "A Simple
Thermistor Interface to an ADC" (URLs in core.ect_circuit). The numerical
component choices and accelerated diagnostic times belong to this lab.
"""
from copy import deepcopy
import json
import unittest

from obdii_lab.core import Parameters, Sim, ect_circuit
from obdii_lab.instrumentation import read_signals, signal_catalog, signals, value_at


class EctCircuitTests(unittest.TestCase):
    def test_25_degree_reference_has_expected_voltage_current_and_adc(self):
        circuit = ect_circuit(25, Parameters())
        self.assertEqual(circuit["ect_resistance_ohm"], 2500)
        self.assertAlmostEqual(circuit["ect_node_v"], 2.6595744680851063)
        self.assertAlmostEqual(circuit["ect_current_ma"], 1.0638297872340425)
        self.assertEqual(circuit["ect_adc_count"], 2178)
        self.assertEqual(circuit["ect_adc_full_scale"], 4095)
        self.assertAlmostEqual(circuit["ect_voltage_v"], 2.659340659340659)
        self.assertAlmostEqual(circuit["ect_c"], 25, delta=.01)
        self.assertTrue(circuit["ect_sensor_valid"])

    def test_warming_reduces_resistance_and_voltage_with_small_quantization_error(self):
        previous = None
        for temperature in (-40, 0, 20, 25, 90, 130):
            with self.subTest(temperature=temperature):
                circuit = ect_circuit(temperature, Parameters())
                self.assertTrue(circuit["ect_sensor_valid"])
                self.assertAlmostEqual(circuit["ect_c"], temperature, delta=.15)
                self.assertLessEqual(abs(circuit["ect_voltage_v"] - circuit["ect_node_v"]), 5 / 4095 / 2)
                if previous:
                    self.assertLess(circuit["ect_resistance_ohm"], previous["ect_resistance_ohm"])
                    self.assertLess(circuit["ect_node_v"], previous["ect_node_v"])
                    self.assertGreater(circuit["ect_current_ma"], previous["ect_current_ma"])
                previous = circuit

    def test_open_is_pullup_voltage_and_unpowered_is_zero_without_nonfinite_json(self):
        circuit = ect_circuit(90, Parameters(), open_circuit=True)
        self.assertEqual(circuit["ect_node_v"], 5)
        self.assertEqual(circuit["ect_voltage_v"], 5)
        self.assertEqual(circuit["ect_adc_count"], 4095)
        self.assertEqual(circuit["ect_current_ma"], 0)
        self.assertIsNone(circuit["ect_resistance_ohm"])
        self.assertEqual(circuit["ect_c"], -40)
        self.assertFalse(circuit["ect_sensor_valid"])
        self.assertTrue(circuit["ect_high_input"])
        json.dumps(circuit, allow_nan=False)
        for disconnected in (False, True):
            off = ect_circuit(90, Parameters(), powered=False, open_circuit=disconnected)
            self.assertEqual(off["ect_node_v"], 0)
            self.assertEqual(off["ect_reference_v"], 0)
            self.assertEqual(off["ect_adc_count"], 0)
            self.assertEqual(off["ect_current_ma"], 0)
            self.assertFalse(off["ect_sensor_valid"])
            self.assertFalse(off["ect_high_input"])
            json.dumps(off, allow_nan=False)

    def test_reference_supply_is_ratiometric_and_adc_resolution_is_configurable(self):
        default = ect_circuit(25, Parameters())
        lower_supply = ect_circuit(25, Parameters(reference_voltage_v=3.3))
        self.assertEqual(default["ect_adc_count"], lower_supply["ect_adc_count"])
        self.assertAlmostEqual(default["ect_c"], lower_supply["ect_c"])
        self.assertAlmostEqual(lower_supply["ect_node_v"], default["ect_node_v"] * 3.3 / 5)
        custom = Sim(config={"reference_voltage_v": 3.3, "ect_adc_bits": 10,
                             "ect_pullup_ohm": 1000, "ect_r25_ohm": 1000,
                             "initial_coolant_c": 25}).snapshot()["sensors"]
        self.assertEqual(custom["ect_adc_full_scale"], 1023)
        self.assertEqual(custom["ect_adc_count"], 512)
        self.assertAlmostEqual(custom["ect_node_v"], 1.65)
        self.assertEqual(custom["ect_reference_v"], 3.3)
        self.assertEqual(custom["sensor_return_v"], 0)

    def test_voltage_monitor_debounce_and_repair_preserve_fault_memory(self):
        sim = Sim(scenario="ect_open")
        before = sim.advance(3.19)
        self.assertTrue(before["sensors"]["ect_high_input"])
        self.assertFalse(before["pending_dtcs"])
        self.assertEqual(before["ect_derate_factor"], 1)
        pending = sim.advance(.02)
        self.assertEqual(pending["pending_dtcs"], ["P0118"])
        self.assertFalse(pending["mil"])
        self.assertEqual(pending["sensors"]["ect_used_c"], 80)
        self.assertEqual(pending["ect_derate_factor"], .65)
        confirmed = sim.advance(.3)
        self.assertEqual(confirmed["dtcs"], ["P0118"])
        self.assertEqual(confirmed["freeze_frame"]["t"], 3.5)
        repaired = sim.advance(.02, {"fault": "none"})
        self.assertTrue(repaired["sensors"]["ect_sensor_valid"])
        self.assertEqual(repaired["ect_derate_factor"], 1)
        self.assertFalse(repaired["pending_dtcs"])
        self.assertTrue(repaired["mil"])
        # High voltage comes from the divider, not just the injected fault flag.
        cold = Sim(config={"initial_coolant_c": -90, "ambient_c": -90})
        cold_state = cold.advance(.52)
        self.assertEqual(cold_state["inputs"]["fault"], "none")
        self.assertFalse(cold_state["sensors"]["ect_circuit_open"])
        self.assertTrue(cold_state["sensors"]["ect_high_input"])
        self.assertEqual(cold_state["dtcs"], ["P0118"])

    def test_invalid_circuit_parameters_are_rejected(self):
        for config in ({"ect_adc_bits": 12.5}, {"ect_adc_bits": True}, {"ect_adc_bits": 25},
                       {"reference_voltage_v": 0}, {"ect_pullup_ohm": -10},
                       {"ect_r25_ohm": 0}, {"ect_beta_k": 0}, {"initial_coolant_c": -274}):
            with self.subTest(config=config):
                with self.assertRaises(ValueError):
                    Sim(config=config)
        for temperature in (-273.15, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                ect_circuit(temperature, Parameters())


class SignalProbeTests(unittest.TestCase):
    def test_catalog_paths_and_snapshots_are_read_only_and_json_finite(self):
        catalog = signal_catalog()
        self.assertGreaterEqual(len(catalog), 25)
        self.assertEqual(len(catalog), len({item["id"] for item in catalog}))
        catalog[0]["label"] = "caller edit"
        self.assertNotEqual(signal_catalog()[0]["label"], "caller edit")
        for profile in Sim.PROFILES:
            sim = Sim(profile=profile)
            snapshot = sim.advance(.5)
            original = deepcopy(snapshot)
            records = read_signals(snapshot)
            self.assertEqual(snapshot, original)
            self.assertEqual(sim.snapshot(), original)
            self.assertEqual(signals(snapshot), list(records.values()))
            json.dumps(records, allow_nan=False)
            for record in records.values():
                self.assertIn(record["kind"], ("analog", "digital", "state"))
                self.assertGreater(record["period_ms"], 0)
                if profile in record["profiles"]:
                    self.assertIsNotNone(value_at(snapshot, record["id"]), record["id"])
                    self.assertEqual(record["validity"], "valid", record["id"])
                else:
                    self.assertEqual(record["validity"], "unavailable")
                    self.assertIsNone(record["value"])

    def test_probe_validity_separates_physical_input_invalid_reading_and_fallback(self):
        sim = Sim(scenario="ect_open")
        initial_fault = read_signals(sim.advance(3.1))
        self.assertEqual(initial_fault["sensors.ect_node_v"]["value"], 5)
        self.assertEqual(initial_fault["sensors.ect_node_v"]["validity"], "valid")
        self.assertEqual(initial_fault["coolant_c"]["validity"], "valid")
        self.assertEqual(initial_fault["sensors.ect_c"]["validity"], "invalid")
        self.assertEqual(initial_fault["sensors.ect_used_c"]["validity"], "invalid")
        self.assertEqual(initial_fault["sensors.ect_resistance_ohm"]["validity"], "invalid")
        fallback = read_signals(sim.advance(.2))
        self.assertEqual(fallback["sensors.ect_used_c"]["validity"], "substituted")
        self.assertEqual(fallback["sensors.ect_used_c"]["value"], 80)
        self.assertEqual(fallback["battery_voltage_v"]["validity"], "unavailable")
        off = read_signals(sim.advance(.02, {"ignition": False}))
        self.assertEqual(off["sensors.ect_c"]["validity"], "unavailable")
        self.assertEqual(off["sensors.ect_reference_v"]["value"], 0)

    def test_bmu_reports_hold_on_dropout_and_have_explicit_stale_validity(self):
        sim = Sim(scenario="bmu_timeout")
        before = sim.advance(8)
        packet = deepcopy(before["bmu_report"])
        self.assertEqual(packet["t"], 7.9)
        snapshot = sim.advance(.24)
        self.assertEqual(snapshot["bmu_report"], packet)
        self.assertNotEqual(snapshot["soc_pct"], packet["soc_pct"])
        self.assertEqual(snapshot["battery_current_a"], 0)
        self.assertGreater(packet["pack_current_a"], 0)
        records = read_signals(snapshot)
        self.assertEqual(records["bmu_report.pack_current_a"]["validity"], "stale")
        self.assertEqual(records["battery_current_a"]["validity"], "valid")
        self.assertEqual(records["sensors.bmu_message_age_ms"]["validity"], "valid")
        self.assertGreater(records["sensors.bmu_message_age_ms"]["value"], 300)
        # Snapshot objects cannot alter the held packet used in later reads.
        snapshot["bmu_report"]["soc_pct"] = -1
        self.assertEqual(sim.snapshot()["bmu_report"], packet)

    def test_missing_wheel_input_is_distinct_from_a_stopped_physical_wheel(self):
        snapshot = Sim(profile="braking").advance(.02, {"fault": "wheel_fl_dropout"})
        records = read_signals(snapshot)
        self.assertIsNone(records["sensors.wheel_speeds_kph.0"]["value"])
        self.assertEqual(records["sensors.wheel_speeds_kph.0"]["validity"], "invalid")
        self.assertGreater(snapshot["wheel_speeds_kph"][0], 0)
        self.assertEqual(records["sensors.wheel_speeds_kph.1"]["validity"], "valid")
        self.assertIsNone(value_at(snapshot, "sensors.wheel_speeds_kph.99"))
        self.assertIsNone(value_at(snapshot, "sensors.unknown.value"))


if __name__ == "__main__":
    unittest.main()
