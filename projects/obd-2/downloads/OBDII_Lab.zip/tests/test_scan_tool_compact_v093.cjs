/* Compact scan-tool contracts: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_scan_tool_compact_v093.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){const server=await startServer();try{
 const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
 for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
 const app=window.VehicleApplication;await app.ready;await flush();
 const state=()=>app.session.result.state;
 const settle=async()=>{await app.session.command;await waitFor(()=>app.session.pending===0&&!app.views.scan.inspect().pending,'Scanner command queue settles');await flush();};
 const click=async selector=>{await $(selector).click();await settle();};
 const change=async(selector,value)=>{const node=$(selector);node.value=value;await node.dispatchEvent({type:'change'});await settle();};
 const choose=async(id='petrol_basic',options={})=>{const settings={mode:'manual',road_mu:.9,grade_pct:0};if(app.session.setupComplete)await app.session.setup(id,options,settings,{enterDrive:false});else await app.session.commitSetup(id,options,settings);app.session.enterWorkspace('service');app.session.setRunning(false);await settle();};
 await choose();
 await test('The initial scanner opens live data and keeps custom requests and pins separate',async()=>{
   assert.equal(app.views.scan.inspect().activeTab,'data');
   assert.equal($('[data-sc-panel="faults"]').hidden,true);assert.equal($('[data-sc-panel="data"]').hidden,false);assert.equal($('[data-sc-panel="connector"]').hidden,true);
   assert.equal($('[data-sc="vehicle-name"]').textContent,state().vehicle.configuration.label);
   assert.match($('[data-sc="connection-status"]').textContent,/disconnected/);
   for(const key of ['request-details','response-details']){assert.equal($(`[data-sc="${key}"]`).tagName,'DETAILS');assert.equal($(`[data-sc="${key}"]`).hasAttribute('open'),false);}
   assert.equal($('[data-sc="protocol"]').closest('[data-sc-panel]'),null);
   assert.equal($('[data-sc-action="scan"]').closest('[data-sc-panel]').dataset.scPanel,'faults');
   assert.equal($('[data-sc="port"]').closest('[data-sc-panel]').dataset.scPanel,'connector');
   assert.equal(document.querySelectorAll('[data-sc-tab]').length,4);
 });
 await test('Tabs preserve the vehicle and request queue; keyboard tab navigation cannot steer the car',async()=>{
   const time=state().t,count=requests.length,steer=state().inputs.steer_deg;
   await click('[data-sc-tab="data"]');assert.equal(app.views.scan.inspect().activeTab,'data');assert.equal($('[data-sc-panel="data"]').hidden,false);assert.equal($('[data-sc-panel="faults"]').hidden,true);
   await $('[data-sc-tab="data"]').dispatchEvent({type:'keydown',key:'ArrowRight'});await settle();
   assert.equal(app.views.scan.inspect().activeTab,'unit');assert.equal(document.activeElement,$('[data-sc-tab="unit"]'));
   await $('[data-sc-tab="connector"]').dispatchEvent({type:'keydown',key:'Home'});await settle();
   assert.equal(app.views.scan.inspect().activeTab,'data');assert.equal(state().inputs.steer_deg,steer);assert.equal(state().t,time);assert.equal(requests.length,count);
   for(const node of document.querySelectorAll('[data-sc-tab]')){const selected=node.dataset.scTab==='data';assert.equal(node.getAttribute('aria-selected'),String(selected));assert.equal(node.getAttribute('tabindex'),selected?'0':'-1');}
 });
 await test('Live data reads actual ECU bytes and leaves expert details closed',async()=>{
   await app.session.control('ignition',true);await app.session.control('start');await app.session.advance(1.6);app.session.setRunning(false);await settle();
   await click('[data-sc-action="connect"]');assert.equal(app.session.result.scanner.status,'ready');
   await click('[data-sc-tab="data"]');await click('[data-sc-action="send"]');
   const reply=app.session.diagnostic,bytes=reply.response_hex.split(' ').map(x=>parseInt(x,16)),rpm=(256*bytes[2]+bytes[3])/4;
   assert.equal(reply.request_hex,'01 0C');assert.ok(rpm>500);assert.equal($('[data-sc="response-value"]').textContent,rpm.toLocaleString('en-GB',{maximumFractionDigits:2})+' rpm');
   assert.equal($('[data-sc="request-details"]').hasAttribute('open'),false);assert.equal($('[data-sc="response-details"]').hasAttribute('open'),false);
   assert.equal($('[data-sc="response-bytes"]').textContent,reply.response_hex);assert.equal($('[data-sc-panel="connector"]').hidden,true);
 });
 await test('Requests leave the trace dock closed until the user opens or expands it',async()=>{
   assert.equal($('#dock-content').hidden,true);assert.equal(app.inspect().dock,null);
   await click('[data-dock="messages"]');assert.equal($('#dock-content').hidden,false);assert.equal(app.inspect().dock,'messages');assert.equal($('[data-dock="messages"]').getAttribute('aria-expanded'),'true');
   await click('[data-action="expand-dock"]');assert.equal($('#message-dock').classList.contains('expanded'),true);assert.equal($('[data-action="expand-dock"]').getAttribute('aria-expanded'),'true');
   await click('[data-action="collapse-dock"]');assert.equal($('#dock-content').hidden,true);assert.equal($('#message-dock').classList.contains('expanded'),false);assert.equal($('[data-action="expand-dock"]').hidden,true);
   await click('[data-sc-action="send"]');assert.equal($('#dock-content').hidden,true);assert.equal(app.inspect().dock,null);
 });
 await test('Changing a connection draft blocks old-unit reads until the selection is applied',async()=>{
   const before=requests.length;await change('[data-sc="protocol"]','can11_250');
   assert.equal($('[data-sc="connection-status"]').textContent,'Selection not applied');assert.equal($('[data-sc-action="send"]').disabled,true);assert.equal($('[data-sc-action="scan"]').disabled,false);assert.equal(app.session.result.scanner.protocol,'can11_500');assert.equal(requests.length,before);
   await change('[data-sc="protocol"]','can11_500');assert.equal($('[data-sc-action="send"]').disabled,false);
 });
 await test('Custom request opens its own details without transmitting or opening the connector',async()=>{
   const count=requests.length;await change('[data-sc="service"]','');
   assert.equal($('[data-sc="request-details"]').hasAttribute('open'),true);assert.equal(document.activeElement,$('[data-sc="payload"]'));assert.equal(requests.length,count);
   assert.equal(app.views.scan.inspect().activeTab,'data');assert.equal($('[data-sc-panel="connector"]').hidden,true);
   const service=app.session.definitions.services.find(s=>s.request_hex==='01 05');await change('[data-sc="service"]',service.id);await click('[data-sc-action="send"]');assert.equal(app.session.diagnostic.request_hex,'01 05');assert.match($('[data-sc="response-value"]').textContent,/°C/);
 });
 await test('Response trend records actual timestamps, gaps missing values and does not invent clock samples',async()=>{
   const service=app.session.definitions.services.find(s=>s.request_hex==='01 10');await change('[data-sc="service"]',service.id);assert.equal(app.views.scan.inspect().trend.length,0);
   await click('[data-sc-action="send"]');await app.session.advance(.2);await settle();await click('[data-sc-action="send"]');
   let points=app.views.scan.inspect().trend;assert.equal(points.length,2);assert.ok(points.every(point=>Number.isFinite(point.value)));assert.equal(points[1].t,state().t);assert.ok(Math.abs(points[1].t-points[0].t-.2)<1e-8);
   const recorded=JSON.stringify(points);for(let i=0;i<5;i++)app.session.emit();await app.session.advance(.2);await settle();assert.equal(JSON.stringify(app.views.scan.inspect().trend),recorded);
   await app.session.connection('maf',false);await app.session.advance(.1);await settle();await click('[data-sc-action="send"]');points=app.views.scan.inspect().trend;assert.equal(points.length,3);assert.equal(points.at(-1).value,null);assert.equal($('[data-sc="response-value"]').textContent,'—');assert.match($('[data-sc="trend-note"]').textContent,/Latest request has no valid value/);
   await app.session.connection('maf',true);await app.session.advance(.1);await settle();await click('[data-sc-action="send"]');points=app.views.scan.inspect().trend;assert.equal(points.length,4);assert.ok(Number.isFinite(points.at(-1).value));assert.equal(points[2].value,null);assert.equal(($('.sc-trend-line').getAttribute('d').match(/M/g)||[]).length,2);assert.match($('[data-sc="trend-note"]').textContent,/1 missing/);
   const before=points.length;await click('[data-sc-action="send"]');assert.equal(app.views.scan.inspect().trend.length,before,'A second paused request replaces its timestamp rather than adding synthetic time');
   await change('[data-sc="service"]',app.session.definitions.services.find(s=>s.request_hex==='01 05').id);assert.equal(app.views.scan.inspect().trend.length,0);await click('[data-sc-action="send"]');assert.equal(app.views.scan.inspect().trend.length,1);await change('[data-sc="address"]','7E0');assert.equal(app.views.scan.inspect().trend.length,0);await change('[data-sc="address"]','7DF');
 });
 await test('Connector remains fully interactive and maps the selected pin to shared wiring',async()=>{
   const time=state().t;await click('[data-sc-tab="connector"]');await click('[data-sc-pin="14"]');assert.equal(app.views.scan.inspect().pin,14);assert.match($('[data-sc="pin-title"]').textContent,/CAN-L/);
   await click('[data-sc-action="pin"]');assert.equal(app.session.selection,'pin:dlc_socket:14');assert.equal(app.session.unitView,'wiring');assert.equal(state().t,time);
   app.session.navigate('scan');await settle();assert.equal(app.views.scan.inspect().activeTab,'connector');assert.equal($('[data-sc-pin="14"]').getAttribute('aria-pressed'),'true');
 });
 await test('Fault scan and clear refresh actual fault memory in the visible results panel',async()=>{
   await app.session.connection('maf',false);await app.session.advance(.8);await settle();await click('[data-sc-tab="faults"]');await click('[data-sc-action="scan"]');
   assert.match($('[data-sc="module-rows"]').textContent,/P0102/);assert.match($('[data-sc="scan-summary"]').textContent,/stored/);
   await app.session.connection('maf',true);await app.session.advance(.2);await settle();const time=state().t,count=requests.filter(r=>r.url==='/api/scanner'&&r.body?.action==='scan').length;
   await click('[data-sc-action="clear"]');assert.equal(state().t,time);assert.match(app.session.records.filter(record=>record.diagnostic.request_hex==='04').at(-1).diagnostic.response_hex,/^44/);assert.doesNotMatch($('[data-sc="module-rows"]').textContent,/P0102/);
   assert.equal(requests.filter(r=>r.url==='/api/scanner'&&r.body?.action==='scan').length,count+1);assert.equal(app.views.scan.inspect().activeTab,'faults');assert.equal($('[data-sc="notice"]').hidden,true);
 });
 await test('A new committed PHEV or BEV updates identity and resets tool pages without fake ECU support',async()=>{
   for(const id of ['phev','bev']){await choose(id);assert.equal($('[data-sc="vehicle-name"]').textContent,state().vehicle.configuration.label);assert.equal(app.views.scan.inspect().activeTab,'data');assert.equal(app.views.scan.inspect().trend.length,0);assert.equal($('[data-sc="request-details"]').hasAttribute('open'),false);assert.equal($('[data-sc="response-details"]').hasAttribute('open'),false);assert.match($('[data-sc="module-rows"]').textContent,/No scan results/);assert.match($('[data-sc="connection-status"]').textContent,/disconnected/);}
   await app.session.control('ignition',true);await app.session.advance(.1);await settle();await change('[data-sc="module"]','bmu');await click('[data-sc-action="connect"]');assert.equal(app.session.result.scanner.status,'state_only');assert.equal($('[data-sc-action="send"]').disabled,true);assert.equal($('[data-sc-action="clear"]').disabled,true);await click('[data-sc-action="scan"]');assert.doesNotMatch($('[data-sc="module-rows"]').textContent,/Engine ECU/);assert.match($('[data-sc="module-rows"]').textContent,/Simulation state/);
 });
 assert.deepEqual(errors,[]);console.log(`${passed} compact scanner contracts passed; actual HTTP + parsed DOM, no native layout claim.`);app.dispose();
}finally{server.child.kill('SIGTERM');server.lines.close();}}
main().catch(error=>{console.error(error);process.exitCode=1;});
