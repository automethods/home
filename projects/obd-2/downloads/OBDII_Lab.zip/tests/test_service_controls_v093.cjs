/* Shared service pedal controls: actual index, controller and all views; actual
 * Python HTTP API on an ephemeral loopback port. A parsed-node harness and
 * CPU Canvas stand in for native DOM/layout. Vehicle rendering is stubbed
 * here and verified separately by test_vehicle.cjs. No browser/GPU claim.
 * Run: node tests/test_service_controls_v093.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[],heldRequests=[],gates=new Set();let nextTimer=1,baseURL='';
function holdNext(url){let release,entered;const gate={url,wait:new Promise(resolve=>release=resolve),entered:new Promise(resolve=>entered=resolve)};gate.release=()=>{release();gates.delete(gate);};gate.mark=entered;heldRequests.push(gate);gates.add(gate);return gate;}
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});const index=heldRequests.findIndex(gate=>gate.url===url);if(index>=0){const gate=heldRequests.splice(index,1)[0];gate.mark();await gate.wait;}return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.setPointerCapture=function(id){this.capturedPointer=id;};
Node.prototype.hasPointerCapture=function(id){return this.capturedPointer===id;};
Node.prototype.releasePointerCapture=function(id){if(this.capturedPointer===id)this.capturedPointer=null;};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){
 const server=await startServer();let app;
 try{
  const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
  app=window.VehicleApplication;await app.ready;await flush();
  const session=app.session,inputChanges=[],setInputs=session.setInputs.bind(session);
  session.setInputs=values=>{inputChanges.push({...values});return setInputs(values);};
  const state=()=>session.result.state;
  const settle=async()=>{await session.command;await waitFor(()=>session.pending===0&&!app.monitor.inspect().pending,'Shared service controls settle');await flush();};
  const click=async selector=>{await $(selector).click();await settle();};
  const keyboard=async(type,code,flags={})=>{
   const target=flags.target||document.activeElement||$('#service-dashboard');
   const key=flags.key||({KeyW:'w',KeyS:'s',KeyA:'a',KeyD:'d',KeyC:'c'}[code]||code);
   const event={type,code,key,target,...flags};await target.dispatchEvent(event);
   if(flags.handled)event.preventDefault();window.dispatchEvent(event);await flush();return event;
  };
  const down=(code,flags)=>keyboard('keydown',code,flags),up=(code,flags)=>keyboard('keyup',code,flags);
  const focus=async node=>{document.activeElement=node;await document.dispatchEvent({type:'focusin',target:node});await flush();};
  const neutralFocus=()=>{document.activeElement=null;};
  const pointer=async(type,node,pointerId)=>{const event={type,target:node,pointerId,button:0};await node.dispatchEvent(event);window.dispatchEvent(event);await flush();};
  const readout=name=>$(`[data-vm-pedal-value="${name}"]`).textContent;
  const hold=name=>$(`[data-vm-pedal-hold="${name}"]`),range=name=>$(`[data-vm-pedal-range="${name}"]`);
  const close=(actual,expected,message)=>assert.ok(Math.abs(actual-expected)<1e-8,`${message}: ${actual} versus ${expected}`);
  const released=()=>{assert.equal(session.inputs.throttle||0,0,'Desired accelerator released');assert.equal(session.inputs.brake||0,0,'Desired brake released');assert.equal(session.inputs.clutch||0,0,'Desired clutch released');};
  const next=async(id='petrol_basic',options={})=>{
   neutralFocus();window.dispatchEvent({type:'blur'});document.hidden=false;document.visibilityState='visible';
   const settings={mode:'manual',road_mu:.9,grade_pct:0};
   if(session.setupComplete)await session.setup(id,options,settings,{enterDrive:false});else await session.commitSetup(id,options,settings);
   session.enterWorkspace('service');session.setRunning(false);await settle();neutralFocus();
  };
  const start=async()=>{await click('[data-vm-action="ignition"]');session.setRunning(false);await click('[data-vm-action="start"]');session.setRunning(false);await session.advance(1);await settle();neutralFocus();};

  await test('Uncommitted setup cannot accept service driving keys',async()=>{
   assert.equal(session.workflowStage,'vehicle');assert.equal($('#service-dashboard').hidden,true);
   await down('KeyW',{target:document.body});await up('KeyW',{target:document.body});released();
  });
  await next();
  await test('Compact service pedals share one keyboard handler and expose 0–100 percent pressure',async()=>{
   assert.equal($('#view-drive').hidden,true);assert.equal($('#service-dashboard').hidden,false);
   assert.equal(app.views.drive.inspect().serviceInputEnabled,true);
   assert.equal((windowEvents.get('keydown')||[]).length,1,'The monitor must not create a second keyboard controller');
   for(const name of ['throttle','brake']){assert.equal(range(name).getAttribute('min'),'0');assert.equal(range(name).getAttribute('max'),'100');assert.equal(range(name).getAttribute('aria-orientation'),'vertical');assert.equal(readout(name),'0%');assert.equal(hold(name).closest('[hidden]'),null);}
   assert.ok(hold('clutch').closest('[hidden]'),'Automatic vehicle does not show a clutch');
  });
  await start();
  await test('Held W survives repeated actual updates with the full cockpit hidden and revs the same engine',async()=>{
   const rpm=state().rpm,count=inputChanges.length,time=state().t;
   const event=await down('KeyW');assert.equal(event.defaultPrevented,true);assert.equal(session.inputs.throttle,1);assert.equal(readout('throttle'),'100%');
   assert.equal(inputChanges.length,count+1,'One key press produces one shared input write');
   for(let i=0;i<4;i++){session.emit();await session.advance(.3);await settle();assert.equal(session.inputs.throttle,1);assert.equal(readout('throttle'),'100%');assert.equal($('#view-drive').hidden,true);}
   assert.ok(state().rpm>rpm+300,'Real engine model responds to held throttle');assert.ok(state().t>time);
   assert.equal(inputChanges.length,count+1,'Visibility updates must not erase or reassert the held source');
   await down('KeyW',{repeat:true});assert.equal(inputChanges.length,count+1);
   await up('KeyW');assert.equal(session.inputs.throttle,0);assert.equal(readout('throttle'),'0%');assert.equal(inputChanges.length,count+2);
  });
  await test('W/Up and S/Down aliases stay held until every physical alias is released',async()=>{
   for(const [letter,arrow,name] of [['KeyW','ArrowUp','throttle'],['KeyS','ArrowDown','brake']]){
    await down(letter);await down(arrow);assert.equal(session.inputs[name],1);await up(letter);assert.equal(session.inputs[name],1);assert.equal(readout(name),'100%');await up(arrow);assert.equal(session.inputs[name],0);assert.equal(readout(name),'0%');
   }
   await down('KeyW');await down('KeyS');assert.equal(session.inputs.throttle,1);assert.equal(session.inputs.brake,1);await up('KeyW');assert.equal(session.inputs.brake,1);await up('KeyS');released();
  });
  await test('Service tool and unit subtab navigation preserve a keyboard hold without resetting the vehicle',async()=>{
   const time=state().t;await down('KeyW');
   for(const route of ['units','wiring','live','locations','diagnosis','configuration','scan']){
    session.navigate(route);await flush();assert.equal(session.inputs.throttle,1,route+' preserves the held key');assert.equal($('#service-dashboard').hidden,false);assert.equal(state().t,time);assert.equal(state().vehicle.configuration.id,'petrol_basic');
   }
   await session.advance(.2);assert.equal(session.inputs.throttle,1);await up('KeyW');released();
  });
  await test('Service accelerator moves the actual vehicle and service brake reduces its actual speed',async()=>{
   const gear=$('[data-vm="gear-select"]');gear.value='D';await gear.dispatchEvent({type:'change'});await click('[data-vm-action="shift"]');assert.equal(state().vehicle.selector,'D');released();
   await click('[data-vm-action="release-parking"]');assert.equal(state().vehicle.parking_brake,false);neutralFocus();
   const stationary=state().speed_kph;await down('ArrowUp');await session.advance(3);await settle();assert.ok(state().speed_kph>stationary+2);assert.equal(state().inputs.throttle,1);assert.equal(state().vehicle.selector,'D');
   const moving=state().speed_kph;await up('ArrowUp');await down('ArrowDown');await session.advance(1);await settle();assert.ok(state().speed_kph<moving,'Braking changes the same vehicle, not only a UI readout');assert.equal(state().inputs.brake,1);assert.equal(Number($('[data-vm="speed-value"]').textContent),Math.round(state().speed_kph));
   await up('ArrowDown');released();assert.equal(readout('brake'),'0%');
  });
  await test('Service pointer and keyboard sources release independently in either press order',async()=>{
   neutralFocus();const pedal=hold('throttle');await pointer('pointerdown',pedal,41);close(session.inputs.throttle,.35,'Pointer face pressure');assert.equal(pedal.capturedPointer,41);
   await down('KeyW');assert.equal(session.inputs.throttle,1);await pointer('pointerup',pedal,41);assert.equal(session.inputs.throttle,1);await up('KeyW');released();
   await down('KeyW');await pointer('pointerdown',pedal,42);close(session.inputs.throttle,.35,'Latest analog pressure remains authoritative');await up('KeyW');close(session.inputs.throttle,.35,'Releasing key preserves held pointer');await pointer('pointercancel',pedal,42);released();
  });
  await test('Service vertical pressure range holds arbitrary percentage and springs back on release or lost capture',async()=>{
   const slider=range('brake');await focus(slider);await pointer('pointerdown',slider,51);slider.value=73;await slider.dispatchEvent({type:'input'});close(session.inputs.brake,.73,'Range pressure');assert.equal(readout('brake'),'73%');session.emit();assert.equal(readout('brake'),'73%');
   await pointer('lostpointercapture',slider,51);released();assert.equal(slider.value,'0');assert.equal(readout('brake'),'0%');
   await pointer('pointerdown',slider,52);slider.value=24;await slider.dispatchEvent({type:'input'});close(session.inputs.brake,.24,'Second range pressure');await pointer('pointerup',slider,52);released();neutralFocus();
  });
  await test('Search, text, number, select and editable focus release controls and cannot drive the car',async()=>{
   const targets=[$('#system-filter'),new Node('input',{type:'text'}),new Node('input',{type:'number'}),new Node('select'),new Node('textarea'),new Node('div',{contenteditable:'true'})];
   for(const target of targets){
    const detached=!target.parentElement;if(detached)document.body.appendChild(target);neutralFocus();await down('KeyW');assert.equal(session.inputs.throttle,1);await focus(target);released();const count=inputChanges.length;
    for(const code of ['KeyW','KeyS','ArrowUp','ArrowDown']){const event=await down(code,{target});assert.equal(event.defaultPrevented,false,'Typing/native key remains unhandled');await up(code,{target});}
    assert.equal(inputChanges.length,count);if(detached)target.remove();
   }
   neutralFocus();await down('KeyW',{repeat:true});released();await up('KeyW');
  });
  await test('Service range arrows retain native editing and do not become accelerator or brake shortcuts',async()=>{
   const slider=range('brake');await focus(slider);const count=inputChanges.length;
   for(const code of ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight']){const event=await down(code,{target:slider});assert.equal(event.defaultPrevented,false);await up(code,{target:slider});released();}
   assert.equal(inputChanges.length,count);
   await down('KeyW',{target:slider});assert.equal(session.inputs.throttle,1,'Letter gaming shortcut still works on a pressure range');await up('KeyW',{target:slider});released();neutralFocus();
  });
  await test('Modified, composing and already handled service keys cannot create pedal inputs',async()=>{
   neutralFocus();const count=inputChanges.length;
   for(const flags of [{ctrlKey:true},{metaKey:true},{altKey:true},{isComposing:true},{handled:true}])for(const code of ['KeyW','KeyS','ArrowUp','ArrowDown']){await down(code,flags);await up(code,flags);}
   released();assert.equal(inputChanges.length,count);
  });
  await test('Window blur and document hiding release service inputs until a fresh press',async()=>{
   neutralFocus();await down('KeyW');await down('KeyS');window.dispatchEvent({type:'blur'});released();assert.equal(readout('throttle'),'0%');assert.equal(readout('brake'),'0%');
   await down('KeyW',{repeat:true});released();await up('KeyW');await up('KeyS');await down('KeyW');assert.equal(session.inputs.throttle,1);
   document.hidden=true;document.visibilityState='hidden';await document.dispatchEvent({type:'visibilitychange'});released();document.hidden=false;document.visibilityState='visible';await document.dispatchEvent({type:'visibilitychange'});
   await down('KeyW',{repeat:true});released();await up('KeyW');await down('KeyW');assert.equal(session.inputs.throttle,1);await up('KeyW');released();
  });
  await test('Help stays an input gate across synchronous session renders and requires a fresh press after closing',async()=>{
   neutralFocus();await down('KeyW');await click('[data-action="help"]');released();assert.equal(app.views.drive.inspect().inputEnabled,false);assert.equal($('#help-drawer').hidden,false);
   for(let i=0;i<3;i++)session.emit();await down('KeyW');await pointer('pointerdown',hold('brake'),61);released();assert.equal(app.views.drive.inspect().inputEnabled,false);
   await click('[data-action="close-drawer"]');assert.equal($('#help-drawer').hidden,true);neutralFocus();await down('KeyW',{repeat:true});released();await up('KeyW');await down('KeyW');assert.equal(session.inputs.throttle,1);await up('KeyW');released();
  });
  await test('Entering vehicle setup releases service controls and cancelling does not restore old holds',async()=>{
   neutralFocus();await down('KeyS');assert.equal(session.inputs.brake,1);const time=state().t;session.beginSetup();await settle();released();assert.equal($('#service-dashboard').hidden,true);assert.equal(app.views.drive.inspect().serviceInputEnabled,false);
   await down('KeyW',{target:document.body});released();session.cancelSetup();await settle();assert.equal(state().t,time);assert.equal($('#service-dashboard').hidden,false);neutralFocus();await down('KeyS',{repeat:true});released();await up('KeyS');await up('KeyW');await down('KeyS');assert.equal(session.inputs.brake,1);await up('KeyS');released();
  });
  await test('Drive and service transitions release disappearing controls once and permit a new press in either mode',async()=>{
   neutralFocus();await down('KeyW');session.navigate('drive');await settle();released();assert.equal($('#service-dashboard').hidden,true);const count=inputChanges.length;for(let i=0;i<3;i++)session.emit();assert.equal(inputChanges.length,count);
   await up('KeyW');await down('KeyW',{target:$('#cockpit-content')});
   assert.equal(session.inputs.throttle,1,'Fresh press works after returning to Drive');
   session.navigate('service');await settle();released();assert.equal($('#service-dashboard').hidden,false);
   neutralFocus();await up('KeyW');await down('KeyW');
   assert.equal(session.inputs.throttle,1,'Fresh press after Drive → service must reach current shared inputs, not a stale pre-release context');
   await up('KeyW');released();
  });
  await test('Key release is accepted while an actual diagnostic request holds the foreground command lock',async()=>{
   neutralFocus();await down('KeyW');const gate=holdNext('/api/diagnostic'),request=session.request('01 0C','7DF');await gate.entered;
   assert.equal(session.controlsPending>0,true);await up('KeyW');released();assert.equal(readout('throttle'),'0%');gate.release();await request;await settle();released();
  });
  await test('Manual transmission shows a real shared clutch; automatic vehicles hide it',async()=>{
   await next('petrol_basic',{transmission_type:'manual_6'});assert.equal(hold('clutch').closest('[hidden]'),null);await down('KeyC');assert.equal(session.inputs.clutch,1);assert.equal(readout('clutch'),'100%');await up('KeyC');released();
   await pointer('pointerdown',hold('clutch'),71);assert.equal(session.inputs.clutch,1);await pointer('pointerup',hold('clutch'),71);released();
   await next();assert.ok(hold('clutch').closest('[hidden]'));const count=inputChanges.length;await down('KeyC');await up('KeyC');released();assert.equal(inputChanges.length,count);
  });
  await test('WLTC displays its pedal inputs while manual pedals stay available and explicit takeover pauses',async()=>{
   neutralFocus();await down('KeyW');assert.equal(session.inputs.throttle,1);await session.cycleAction('start');session.setRunning(false);await settle();assert.equal(state().drive_cycle.status,'preparing');released();
   assert.equal(hold('throttle').disabled,false);assert.equal(range('brake').disabled,false);assert.equal($('[data-vm-action="take-control"]').hidden,false);
   await session.advance(25);await settle();assert.equal(state().drive_cycle.status,'active');assert.equal(readout('throttle'),Math.round(state().inputs.throttle*100)+'%');assert.equal(readout('brake'),Math.round(state().inputs.brake*100)+'%');
   const time=state().t,gear=state().vehicle.selector;await click('[data-vm-action="take-control"]');assert.equal(state().drive_cycle.status,'stopped');assert.equal(state().t,time);assert.equal(session.running,false);assert.equal(state().vehicle.selector,gear);released();assert.equal(hold('throttle').disabled,false);
   neutralFocus();await down('KeyW',{repeat:true});released();await up('KeyW');await down('KeyW');assert.equal(session.inputs.throttle,1);await up('KeyW');released();
  });
  await test('Disposal removes shared keyboard and monitor pedal handlers',async()=>{
   neutralFocus();await down('KeyS');const pedal=hold('brake');app.dispose();released();assert.equal((windowEvents.get('keydown')||[]).length,0);assert.equal((pedal.listeners.get('pointerdown')||[]).length,0);app=null;
  });
  assert.equal(errors.length,0,errors.join('\n'));
  const result={suite:'service shared controls 0.9.3',passed,errors,requests:requests.length,native_browser:false};
  if(process.argv[2])fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }finally{for(const gate of gates)gate.release();app?.dispose();server.lines.close();server.child.kill('SIGTERM');}
}
main().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
