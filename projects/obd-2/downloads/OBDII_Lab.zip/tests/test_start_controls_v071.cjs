/* Focused regressions for driver controls during background updates and
 * assisted gear selection. Actual application scripts and loopback HTTP API;
 * parsed nodes/CPU Canvas stand in for browser DOM/layout. Vehicle rendering
 * is stubbed and verified separately. No native event/GPU claim.
 * Run: node tests/test_start_controls_v071.cjs
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{spawn}=require('node:child_process'),readline=require('node:readline');
const root=path.resolve(__dirname,'..');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {createCanvas}=require(path.join(runtime,'@napi-rs/canvas'));
const original=fs.readFileSync(path.join(root,'tests/test_dashboard_contract.cjs'),'utf8');
const begin=original.indexOf('const decodeEntities='),end=original.indexOf("const elements=new Node('main')");
assert.ok(begin>=0&&end>begin,'Existing generic parsed-node harness is available.');
const requests=[],timers=new Map(),windowEvents=new Map(),errors=[],renderers=[];let nextTimer=1,baseURL='';
const heldRequests=[];
function holdNext(url){let release,entered;const gate={url,wait:new Promise(resolve=>release=resolve),entered:new Promise(resolve=>entered=resolve)};gate.release=release;gate.mark=entered;heldRequests.push(gate);return gate;}
const window={devicePixelRatio:1,innerWidth:1440,innerHeight:1000,location:{href:'http://127.0.0.1/',origin:'http://127.0.0.1'},
  fetch:async(url,options)=>{requests.push({url,body:options?.body?JSON.parse(options.body):null});const held=heldRequests.findIndex(gate=>gate.url===url);if(held>=0){const [gate]=heldRequests.splice(held,1);gate.mark();await gate.wait;}return fetch(baseURL+url,options);},
  addEventListener(type,fn){if(!windowEvents.has(type))windowEvents.set(type,[]);windowEvents.get(type).push(fn);},
  removeEventListener(type,fn){windowEvents.set(type,(windowEvents.get(type)||[]).filter(x=>x!==fn));},
  dispatchEvent(event){for(const fn of windowEvents.get(event.type)||[])fn(event);return true;},
  matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),open(){},
  VehicleView:{create(container,options){const renderer={options,visible:true,selection:'',state:null,network:null,catalog:null};renderers.push(renderer);container.innerHTML='<div class="vehicle-stub">Vehicle renderer tested separately</div>';return{update(state,network,catalog){Object.assign(renderer,{state,network,catalog});},select(id){renderer.selection=id;},setVisible(value){renderer.visible=value;},resize(){},dispose(){},inspect(){return renderer;}};}}
};
const storage=new Map();window.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,String(value)),removeItem:key=>storage.delete(key)};
class CustomEvent {constructor(type,options={}){this.type=type;Object.assign(this,options);}}
const sandbox={window,console:{...console,error:(...args)=>errors.push(args.map(String).join(' '))},assert,createCanvas,Map,Set,AbortController,CustomEvent,URL,Blob,performance,
  setTimeout(fn,ms){const id=nextTimer++;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
  setInterval(){throw new Error('The application must not create an independent polling loop.');},clearInterval(){},
  requestAnimationFrame:fn=>{fn(0);return 1;},cancelAnimationFrame(){},ResizeObserver:class{observe(){}disconnect(){}}
};
vm.createContext(sandbox);vm.runInContext(original.slice(begin,end)+'\nglobalThis.HarnessNode=Node;',sandbox);
const Node=sandbox.HarnessNode;
Node.prototype.matches=function(selector){return selector.split(',').some(part=>{
  part=part.trim();if(!part)return false;
  const attributes=[...part.matchAll(/\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g)];
  let base=part.replace(/\[[^\]]+\]/g,'');
  const not=[...base.matchAll(/:not\(([^)]+)\)/g)];base=base.replace(/:not\([^)]+\)/g,'');if(not.some(m=>this.matches(m[1])))return false;
  const tag=base.match(/^[a-zA-Z][\w-]*/);if(tag&&this.tagName!==tag[0].toUpperCase())return false;
  for(const match of base.matchAll(/#([\w-]+)/g))if(this.getAttribute('id')!==match[1])return false;
  for(const match of base.matchAll(/\.([\w-]+)/g))if(!this.classList.contains(match[1]))return false;
  for(const match of attributes){if(!this.hasAttribute(match[1]))return false;if(match[2]!==undefined&&this.getAttribute(match[1])!==match[2])return false;}
  return true;
});};
Node.prototype.contains=function(child){for(let node=child;node;node=node.parentElement)if(node===this)return true;return false;};
Node.prototype.focus=function(){document.activeElement=this;};
Node.prototype.blur=function(){if(document.activeElement===this)document.activeElement=null;};
Node.prototype.scrollIntoView=function(){};
Node.prototype.append=function(...nodes){for(const node of nodes)this.appendChild(typeof node==='string'?new Node('#text',{},node):node);};
Node.prototype.remove=function(){const owner=this.parentElement;if(owner)owner.children=owner.children.filter(node=>node!==this);this.parentElement=null;};
Node.prototype.insertAdjacentHTML=function(position,html){assert.equal(position,'beforeend');const holder=new Node();holder.innerHTML=html;this.append(...holder.children);};
Node.prototype.dispatchEvent=async function(event){
  event.target=event.target||this;event.bubbles=event.bubbles!==false;event.defaultPrevented=false;
  event.preventDefault=()=>{event.defaultPrevented=true;};event.stopPropagation=()=>{event.stopped=true;};
  for(let node=this;node;node=event.bubbles&&!event.stopped?node.parentElement:null){event.currentTarget=node;
    if(node['on'+event.type])await node['on'+event.type](event);
    for(const fn of [...node.listeners.get(event.type)||[]])await fn(event);
  }
  return !event.defaultPrevented;
};
Node.prototype.click=async function(){if(this.disabled)return;const success=await this.dispatchEvent({type:'click'});if(success&&this.tagName==='BUTTON'&&(this.attrs.type||'submit')==='submit'){const form=this.closest('form');if(form)await form.dispatchEvent({type:'submit'});}};
Node.prototype.getBoundingClientRect=function(){return{width:this.tagName==='CANVAS'?650:900,height:this.tagName==='CANVAS'?450:600,left:0,top:0,right:900,bottom:600};};
Object.defineProperty(Node.prototype,'id',{get(){return this.getAttribute('id')||'';},set(value){this.setAttribute('id',value);}});
Object.defineProperty(Node.prototype,'parentNode',{get(){return this.parentElement;}});
Object.defineProperty(Node.prototype,'isConnected',{get(){return document.contains(this);}});
Object.defineProperty(Node.prototype,'clientWidth',{get(){return this.tagName==='CANVAS'?650:900;}});
Object.defineProperty(Node.prototype,'clientHeight',{get(){return 600;}});
Object.defineProperty(Node.prototype,'scrollHeight',{get(){return 800;}});
const document=new Node('document');document.readyState='loading';document.activeElement=null;document.innerHTML=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
document.documentElement=document.querySelector('html');document.body=document.querySelector('body');
document.createElement=tag=>new Node(tag);document.createElementNS=(_,tag)=>new Node(tag);document.getElementById=id=>document.querySelector('#'+id);
sandbox.document=document;window.document=document;
Object.assign(window,{setTimeout:sandbox.setTimeout,clearTimeout:sandbox.clearTimeout,requestAnimationFrame:sandbox.requestAnimationFrame});
const $=selector=>{const node=document.querySelector(selector);assert.ok(node,'Product markup exists: '+selector);return node;};
const waitFor=async(predicate,message)=>{for(let i=0;i<500;i++){if(predicate())return;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Timed out: '+message);};
const flush=async()=>{for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));};
async function startServer(){
  const child=spawn('python3',['-u','-c','from obdii_lab.server import create_server\ns=create_server(0)\nprint(s.server_port,flush=True)\ns.serve_forever()'],{cwd:root,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',chunk=>{stderr+=chunk;});const lines=readline.createInterface({input:child.stdout});
  const port=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{child.kill();reject(Error('Local API startup timed out. '+stderr));},15000);
    lines.once('line',line=>{clearTimeout(timeout);resolve(Number(line));});child.once('exit',code=>{clearTimeout(timeout);reject(Error('Local API startup failed ('+code+'): '+stderr));});});
  assert.ok(port>0,'An ephemeral Python HTTP server started');baseURL='http://127.0.0.1:'+port;
  return{child,lines};
}
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}
async function main(){
 const server=await startServer();let app;const outstanding=new Set();
 try{
  const scripts=[...fs.readFileSync(path.join(root,'web/index.html'),'utf8').matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const file of scripts){if(file==='/web/vehicle.js')continue;vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});}
  document.readyState='interactive';await document.dispatchEvent(new CustomEvent('DOMContentLoaded'));
  app=window.VehicleApplication;await app.ready;await app.session.commitSetup('petrol_basic',{}, {mode:'manual',road_mu:.9,grade_pct:0});app.session.enterWorkspace('drive');await flush();
  const settle=async()=>{await app.session.command;await waitFor(()=>app.session.pending===0&&!app.views.drive.inspect().pending,'Driver command finishes');await flush();};
  const hold=route=>{const gate=holdNext(route);outstanding.add(gate);return gate;};
  const release=gate=>{gate.release();outstanding.delete(gate);};
  const fireClock=()=>{const clock=[...timers.entries()].find(([,timer])=>timer.ms===100);assert.ok(clock,'One simulation timer is scheduled');timers.delete(clock[0]);return clock[1].fn();};
  const controls=(from,action)=>requests.slice(from).filter(r=>r.url==='/api/control'&&r.body.action===action);
  const assertPedals=(throttle,brake,message)=>{
   assert.equal(app.session.inputs.throttle,throttle,message+' desired throttle');assert.equal(app.session.inputs.brake,brake,message+' desired brake');
   assert.equal(app.session.result.state.inputs.throttle,throttle,message+' backend throttle');assert.equal(app.session.result.state.inputs.brake,brake,message+' backend brake');
  };
  const park=async()=>{app.session.setRunning(false);await app.session.setInputs({throttle:0,brake:.5});await app.session.control('gear','P');await settle();assert.equal(app.session.result.state.vehicle.selector,'P');};
  await test('Start stays available during background updates and queues exactly once',async()=>{
   await $('[data-ck-action="ignition"]').click();await settle();await app.session.advance(19.5);await settle();
   assert.equal(app.session.result.state.vehicle.start_state,'ignition_on');assert.equal(app.session.result.state.rpm,0);assert.equal($('[data-ck-action="start"]').disabled,false);
   const gate=hold('/api/advance');app.session.setRunning(true);const tick=fireClock();await gate.entered;await flush();
   assert.equal(app.session.context().busy,true);assert.equal($('[data-ck-action="start"]').disabled,false,'A background update must not disable Start engine.');
   const before=requests.length;await $('[data-ck-action="start"]').click();await flush();assert.equal(app.views.drive.inspect().pending,true);
   await $('[data-ck-action="start"]').click();await flush();assert.equal(controls(before,'start').length,0,'Start waits behind the in-flight update.');
   release(gate);await tick;await settle();assert.equal(controls(before,'start').length,1,'Duplicate pending clicks cannot enqueue a second Start.');
   await app.session.advance(1);await settle();assert.equal(app.session.result.state.vehicle.start_state,'running');assert.ok(app.session.result.state.rpm>500);
  });
  await test('D accepts a newly held virtual brake while a background update is in flight',async()=>{
   const gate=hold('/api/advance');app.session.setRunning(true);const tick=fireClock();await gate.entered;await flush();
   const brake=$('[data-ck="brake"]');brake.value='36';await brake.dispatchEvent({type:'input'});await flush();
   assert.equal(app.session.inputs.brake,.36);assert.equal($('[data-ck-gear="D"]').disabled,false,'Background simulation must not grey out a permitted gear selection.');
   const before=requests.length;await $('[data-ck-gear="D"]').click();await flush();assert.equal(app.views.drive.inspect().pending,true);
   await $('[data-ck-gear="D"]').click();await flush();assert.equal(controls(before,'gear').length,0);
   release(gate);await tick;await settle();assert.equal(controls(before,'gear').length,1);assert.equal(app.session.result.state.vehicle.selector,'D');assert.equal(app.session.result.state.inputs.brake,.36);
   app.session.setRunning(false);
  });
  await test('assisted shift uses a temporary virtual brake and restores desired pedals without advancing time',async()=>{
   assert.equal(typeof app.session.shift,'function','Session exposes the assisted shift action.');await park();await app.session.setInputs({throttle:.22,brake:0});
   const before=requests.length,t=app.session.result.state.t;await app.session.shift('D',{assist:true});await settle();
   const sent=controls(before,'gear');assert.equal(sent.length,1);assert.equal(sent[0].body.inputs.brake,.35);assert.equal(sent[0].body.inputs.throttle,0);
   assert.equal(app.session.result.state.vehicle.selector,'D');assert.equal(app.session.result.state.t,t);assertPedals(.22,0,'Successful assisted shift restores');
   const restore=requests.slice(before).filter(r=>r.url==='/api/inputs');assert.ok(restore.length>=1,'Pedal restoration reaches the backend without a physics tick.');
   assert.equal(restore.at(-1).body.inputs.brake,0);assert.equal(restore.at(-1).body.inputs.throttle,.22);
  });
  await test('assisted shift preserves a deliberately held foot brake',async()=>{
   await park();await app.session.setInputs({throttle:0,brake:.6});const t=app.session.result.state.t;
   await app.session.shift('D',{assist:true});await settle();assertPedals(0,.6,'Held brake remains applied');assert.equal(app.session.result.state.t,t);
  });
  await test('pedal release during a pending assisted shift is not reasserted from stale inputs',async()=>{
   await park();await app.session.setInputs({throttle:.3,brake:.65});const t=app.session.result.state.t;
   const gate=hold('/api/control'),shift=app.session.shift('D',{assist:true});await gate.entered;
   await app.session.setInputs({throttle:0,brake:0});release(gate);await shift;await settle();
   assertPedals(0,0,'Latest release is respected');assert.equal(app.session.result.state.t,t);
  });
  await test('a newly pressed pedal during a pending shift is not released by stale restoration',async()=>{
   await park();await app.session.setInputs({throttle:0,brake:0});const t=app.session.result.state.t;
   const gate=hold('/api/control'),shift=app.session.shift('D',{assist:true});await gate.entered;
   await app.session.setInputs({throttle:.1,brake:.75});release(gate);await shift;await settle();
   assertPedals(.1,.75,'Latest press is respected');assert.equal(app.session.result.state.t,t);
  });
  await test('a rejected assisted shift restores user pedals and retains the previous gear',async()=>{
   await park();await app.session.setInputs({throttle:.18,brake:.42});const t=app.session.result.state.t;
   const gate=hold('/api/control'),outcome=app.session.shift('invalid',{assist:true}).then(()=>({accepted:true}),error=>({accepted:false,error}));
   const reachedBackend=await Promise.race([gate.entered.then(()=>true),outcome.then(()=>false)]);
   assert.equal(reachedBackend,true,'Failure-restoration case expects backend rejection; adapt it if shift validates gear IDs before POST.');
   await app.session.setInputs({throttle:0,brake:.2});release(gate);const result=await outcome;await settle();
   assert.equal(result.accepted,false);assert.match(result.error.message,/selector|gear/i);assert.equal(app.session.result.state.vehicle.selector,'P');assert.equal(app.session.result.state.t,t);assertPedals(0,.2,'Rejected shift restores latest inputs');
  });
  await test('assistance cannot bypass the moving-vehicle reverse interlock',async()=>{
   await app.session.setInputs({throttle:.6,brake:0});await app.session.shift('D',{assist:true});await app.session.control('parking_brake',false);await app.session.advance(5);await settle();assert.ok(app.session.result.state.speed_kph>1);
   const t=app.session.result.state.t;await assert.rejects(app.session.shift('R',{assist:true}),/stop|speed|moving|brake/i);await settle();
   assert.equal(app.session.result.state.vehicle.selector,'D');assert.equal(app.session.result.state.t,t);assertPedals(.6,0,'Rejected moving shift retains pedals');
   assert.deepEqual(errors,[]);
  });
  console.log(JSON.stringify({suite:'Driver controls and assisted shifts v0.7.1',passed,failed:0,scope:'Actual Session and UI callbacks with held HTTP requests and real VehicleSim; parsed DOM, not native browser event verification.'}));
 }finally{for(const gate of outstanding)gate.release();for(const gate of heldRequests)gate.release();app?.dispose();if(app)await app.session.command.catch(()=>{});server.child.kill('SIGTERM');server.lines.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
