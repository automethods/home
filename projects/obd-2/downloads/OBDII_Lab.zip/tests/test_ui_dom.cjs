/* Optional interface-state regression check. Requires Node20+ and jsdom26.
 * Run against a disposable local server, never a user's ongoing experiment:
 *   python3 run.py --serve --port 8766
 *   NODE_PATH=/path/to/jsdom/node_modules node tests/test_ui_dom.cjs http://127.0.0.1:8766
 * This checks DOM events/state and downloads; it is not a browser rendering test.
 */
const assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require('jsdom');
const base=process.argv[2]||'http://127.0.0.1:8766';
const errors=[],downloads=[],requests=[],blobs=[];
const vc=new VirtualConsole();vc.on('jsdomError',error=>{if(!error.message.includes('navigation (except hash changes)'))errors.push(error.message);});vc.on('error',error=>errors.push(String(error)));
function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
async function main(){
  const dom=await JSDOM.fromURL(base,{resources:'usable',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(window){
    window.fetch=async(path,options)=>{requests.push({path,body:options?.body});return fetch(new URL(path,base),options);};
    window.HTMLElement.prototype.scrollIntoView=function(){};
    window.HTMLCanvasElement.prototype.getBoundingClientRect=function(){return {width:600,height:120,left:0,top:0,right:600,bottom:120,x:0,y:0};};
    const context={scale(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fill(){},closePath(){},fillText(){},setLineDash(){},arc(){},createLinearGradient(){return {addColorStop(){}};}};
    window.HTMLCanvasElement.prototype.getContext=function(type){return type==='webgl2'?null:new Proxy(context,{get:(target,key)=>target[key]||(()=>{})});};
    window.URL.createObjectURL=blob=>{blobs.push(blob);return 'blob:obdii-test-'+blobs.length;};window.URL.revokeObjectURL=()=>{};
    const click=window.HTMLAnchorElement.prototype.click;window.HTMLAnchorElement.prototype.click=function(){if(this.download){downloads.push({name:this.download,url:this.href});return;}return click.call(this);};
  }});
  const w=dom.window,d=w.document,$=id=>d.getElementById(id);
  async function until(test,why){const start=Date.now();while(!test()){if(Date.now()-start>8000)throw new Error('Timed out: '+why+'; errors='+errors.join('|'));await sleep(10);}}
  async function action(id){$(id).click();await until(()=>!$('task-start').disabled&&!w.LabUI.isBusy(),id);await sleep(15);}
  function blobText(blob){return new Promise((resolve,reject)=>{const reader=new w.FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsText(blob);});}
  async function select(id,value){$(id).value=value;$(id).dispatchEvent(new w.Event('change',{bubbles:true}));await sleep(15);await until(()=>!w.LabUI.isBusy(),'select '+id);}
  try{
    await until(()=>$('scope').querySelectorAll('.scope-row').length===4&&w.LabUI?.state()&&w.Workbench?.ready(),'initial workspace');
    await w.Workbench.chooseExperiment('ect');
    $('show-instruments').click();
    assert.equal($('instrument-workspace').hidden,false);
    assert.equal($('signal-rows').children.length,73,'complete catalog');
    assert.equal($('soc').textContent,'—','inactive battery is unavailable in dashboard');
    assert.equal($('contactor').textContent,'NOT INSTALLED');
    assert.equal($('tab-task').getAttribute('aria-selected'),'true');
    assert.equal(d.querySelectorAll('[data-screen]:not([hidden])').length,1);
    await action('task-start');
    assert.equal(w.LabUI.state().t,1);assert.equal($('diagram').value,'ect_circuit');assert.equal(w.LabUI.state().profile,'engine');
    assert.ok(w.LabUI.state().sensors.ect_voltage_v>2.65&&w.LabUI.state().sensors.ect_voltage_v<2.67);
    await action('task-open');assert.equal(w.LabUI.state().sensors.ect_adc_count,4095);assert.match($('task-monitor').textContent,/high input/);
    await action('task-pending');assert.deepEqual([...w.LabUI.state().pending_dtcs],['P0118']);assert.equal(w.LabUI.state().sensors.ect_used_c,80);assert.match($('task-trace').textContent,/47 01 01 18/);
    await action('task-confirm');assert.deepEqual([...w.LabUI.state().dtcs],['P0118']);assert.match($('task-events').textContent,/P0118/);
    await action('task-read');assert.match($('task-trace').textContent,/43 01 01 18/);
    $('scope-export').click();$('export-diagram').click();assert.ok(downloads.some(x=>x.name==='obdii_scope.csv'));assert.ok(downloads.some(x=>x.name==='obdii_ect_circuit.svg'));assert.ok(blobs.every(b=>b.size>100));
    const csv=await blobText(blobs[0]),svg=await blobText(blobs[1]);assert.match(csv,/sensors.ect_c.validity/);assert.match(csv,/invalid/);assert.match(csv,/substituted/);assert.match(svg,/<svg/);assert.match(svg,/4095/);
    $('scope').querySelector('canvas').dispatchEvent(new w.MouseEvent('click',{clientX:300,bubbles:true}));assert.match($('scope').textContent,/CURSOR/);$('scope').querySelector('.scope-hint button').click();assert.match($('scope').textContent,/live values/);
    await action('task-repair');assert.deepEqual([...w.LabUI.state().dtcs],[]);assert.equal(w.LabUI.state().sensors.ect_sensor_valid,true);assert.match($('task-diagnostic').textContent,/clear/i);
    $('tab-connections').click();assert.equal($('screen-connections').hidden,false);assert.equal($('screen-task').hidden,true);assert.ok($('connector-workspace').querySelector('svg'));
    $('tab-signals').click();$('signal-filter').value='ADC count';$('signal-filter').dispatchEvent(new w.Event('input'));assert.equal($('signal-rows').children.length,1);assert.match($('signal-rows').textContent,/valid/);
    $('signal-rows').querySelector('button').click();assert.equal($('screen-task').hidden,false);assert.equal($('scope').querySelectorAll('.scope-row').length,5);
    $('tab-diagnostics').click();$('payload').value='09 02';$('send').click();await until(()=>$('trace').textContent.includes('10 14'),'VIN transcript');assert.match($('decoded').textContent,/LAB00000000000001/);
    $('tab-dashboard').click();assert.equal($('screen-dashboard').hidden,false);assert.equal(d.querySelectorAll('[data-screen]:not([hidden])').length,1);
    await select('lesson','bmu_timeout');assert.equal($('diagram').value,'hybrid');await w.LabUI.advance(5);await w.LabUI.advance(4);
    $('tab-signals').click();$('signal-filter').value='BMU report: pack current';$('signal-filter').dispatchEvent(new w.Event('input'));assert.match($('signal-rows').textContent,/stale/);
    await select('lesson','abs_split_mu');assert.equal($('diagram').value,'brakes');await w.LabUI.advance(2);assert.equal(w.LabUI.state().profile,'braking');
    $('tab-task').click();assert.ok($('schematic-canvas').querySelector('svg'));
    assert.equal(errors.length,0,errors.join('\n'));assert.ok(requests.length>=17);
    console.log(JSON.stringify({status:'PASS',checks:['initial five-screen workspace','73-signal catalog','six-step ECT workflow','voltage/ADC/validity','pending and stored OBD bytes','repair and clear','SVG and scope CSV download triggers','tab navigation','signal filter and add-probe','VIN multi-frame request','BMU stale report','braking diagram selection'],requests:requests.length,download_names:downloads.map(d=>d.name),console_errors:errors.length},null,2));
  }finally{w.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
