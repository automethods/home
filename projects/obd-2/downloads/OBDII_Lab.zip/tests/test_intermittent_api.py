"""Intermittent sensor controls through the actual HTTP boundary."""
import json
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from obdii_lab.server import create_server


class IntermittentApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = create_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def call(self, path, body=None):
        req = Request(self.base + path, data=None if body is None else json.dumps(body).encode(),
                      headers={"Content-Type": "application/json"})
        with urlopen(req, timeout=10) as response:
            return json.load(response)

    def setUp(self):
        self.call("/api/vehicle", {"configuration": "petrol_advanced"})
        self.call("/api/control", {"action": "ignition", "value": True})
        self.call("/api/control", {"action": "start"})
        self.call("/api/advance", {"seconds": 1})

    def test_dropout_is_shared_by_wire_reading_controller_and_diagnostic_memory(self):
        initial = self.call("/api/connection-fault", {
            "id": "maf", "mode": "intermittent", "pattern": "regular", "connected_s": 1, "dropout_s": 1})
        self.assertEqual(initial["state"]["t"], 1)
        self.assertEqual(initial["state"]["connection_faults"]["maf"]["phase"], "connected")
        dropped = self.call("/api/advance", {"seconds": 1.7})
        self.assertFalse(dropped["state"]["effective_connections"]["maf"])
        self.assertFalse(dropped["network"]["effective_connections"]["maf"])
        self.assertEqual(dropped["state"]["vehicle_sensors"]["maf"]["validity"], "invalid")
        self.assertIn("P0102", dropped["state"]["dtcs"])
        restored = self.call("/api/advance", {"seconds": .5})
        self.assertTrue(restored["state"]["effective_connections"]["maf"])
        self.assertEqual(restored["state"]["vehicle_sensors"]["maf"]["validity"], "valid")
        self.assertIn("P0102", restored["state"]["dtcs"])
        self.call("/api/scanner", {"action": "connect", "protocol": "can11_500", "module": "ecu"})
        reply = self.call("/api/diagnostic", {"payload": "03", "can_id": "7DF"})
        self.assertIn("01 02", reply["diagnostic"]["response_hex"])

    def test_read_only_state_and_export_do_not_advance_or_remove_schedule(self):
        self.call("/api/connection-fault", {"id": "maf", "pattern": "irregular"})
        before = self.call("/api/state")["state"]
        for _ in range(3):
            self.assertEqual(self.call("/api/state")["state"], before)
        exported = self.call("/api/export.json")
        self.assertEqual(exported["final_state"]["connection_faults"], before["connection_faults"])
        self.assertEqual(self.call("/api/state")["state"], before)

    def test_invalid_fault_requests_do_not_change_the_live_session(self):
        self.call("/api/connection-fault", {"id": "maf", "pattern": "regular"})
        before = self.call("/api/state")["state"]
        for body in ({}, {"id": "fuel_level"}, {"id": "pack_voltage"}, {"id": "unit_ecu"},
                     {"id": "maf", "connected_s": -1}, {"id": "maf", "dropout_s": True},
                     {"id": "maf", "pattern": "unrepeatable"}, {"id": "maf", "extra": 1}):
            with self.subTest(body=body), self.assertRaises(HTTPError) as caught:
                self.call("/api/connection-fault", body)
            self.assertEqual(caught.exception.code, 400)
            self.assertIn("error", json.load(caught.exception))
            self.assertEqual(self.call("/api/state")["state"], before)

    def test_manual_connection_overrides_and_vehicle_replacement_cancel_schedules(self):
        self.call("/api/connection-fault", {"id": "maf", "connected_s": .2, "dropout_s": 1})
        self.call("/api/advance", {"seconds": .4})
        repaired = self.call("/api/connection", {"id": "maf", "connected": True})
        self.assertNotIn("maf", repaired["state"]["connection_faults"])
        advanced = self.call("/api/advance", {"seconds": 2})
        self.assertTrue(advanced["state"]["effective_connections"]["maf"])
        self.call("/api/connection-fault", {"id": "maf"})
        replaced = self.call("/api/vehicle", {"configuration": "petrol_basic"})
        self.assertEqual(replaced["state"]["connection_faults"], {})

    def test_legacy_stand_requires_a_configured_sensor_inventory(self):
        self.call("/api/reset", {"profile": "engine", "scenario": "manual"})
        before = self.call("/api/state")["state"]
        with self.assertRaises(HTTPError) as caught:
            self.call("/api/connection-fault", {"id": "ect"})
        self.assertEqual(caught.exception.code, 400)
        self.assertIn("configured vehicle", json.load(caught.exception)["error"])
        self.assertEqual(self.call("/api/state")["state"], before)


if __name__ == "__main__":
    unittest.main()
