"""Driver warnings follow shared state without inventing propulsion interlocks."""
from copy import deepcopy
import unittest

from obdii_lab.vehicle import VehicleSim


class DashboardWarningTests(unittest.TestCase):
    def started(self, configuration="petrol_basic"):
        sim = VehicleSim(configuration)
        sim.control("ignition", True)
        sim.control("start")
        sim.advance(1.6, {"brake": .3})
        self.assertTrue(sim.snapshot()["vehicle"]["ready"])
        return sim

    def test_parked_initial_state_has_a_physical_brake_but_unpowered_lamps(self):
        for configuration in ("petrol_basic", "diesel", "bev"):
            with self.subTest(configuration=configuration):
                sim = VehicleSim(configuration)
                vehicle = sim.snapshot()["vehicle"]
                self.assertTrue(vehicle["parking_brake"])
                self.assertTrue(vehicle["driver_seatbelt_fastened"])
                self.assertFalse(vehicle["driver_door_open"])
                self.assertFalse(vehicle["warning_lamps"]["parking_brake"])
                self.assertFalse(vehicle["warning_lamps"]["seatbelt"])
                self.assertFalse(vehicle["warning_lamps"]["door_open"])

    def test_switching_ignition_gates_lamps_without_repairing_body_state(self):
        sim = VehicleSim()
        sim.control("seatbelt", False)
        sim.control("driver_door", True)
        self.assertFalse(sim.snapshot()["vehicle"]["warning_lamps"]["seatbelt"])
        self.assertFalse(sim.snapshot()["vehicle"]["warning_lamps"]["door_open"])
        sim.control("ignition", True)
        for name in ("parking_brake", "seatbelt", "door_open"):
            self.assertTrue(sim.snapshot()["vehicle"]["warning_lamps"][name], name)
        sim.control("ignition", False)
        for name in ("parking_brake", "seatbelt", "door_open"):
            self.assertFalse(sim.snapshot()["vehicle"]["warning_lamps"][name], name)
        self.assertFalse(sim.driver_seatbelt_fastened)
        self.assertTrue(sim.driver_door_open)
        self.assertTrue(sim.parking_brake)

    def test_parking_brake_blocks_launch_and_manual_release_enables_forward_or_reverse(self):
        for configuration in ("petrol_basic", "diesel", "bev"):
            for selector in ("D", "R"):
                with self.subTest(configuration=configuration, selector=selector):
                    sim = self.started(configuration)
                    sim.control("gear", selector)
                    sim.advance(1, {"brake": 0, "throttle": .6})
                    held = sim.snapshot()
                    self.assertEqual(held["speed_kph"], 0)
                    self.assertEqual(held["inputs"]["throttle"], .6)
                    self.assertTrue(held["vehicle"]["warning_lamps"]["parking_brake"])
                    when = sim.t
                    released = sim.control("parking_brake", False)
                    self.assertEqual(sim.t, when)
                    self.assertFalse(released["vehicle"]["warning_lamps"]["parking_brake"])
                    sim.advance(2)
                    moving = sim.snapshot()
                    self.assertGreater(moving["speed_kph"], 5)
                    self.assertEqual(moving["signed_speed_kph"] > 0, selector == "D")

    def test_live_body_warnings_do_not_cut_drive_or_create_diagnostic_faults(self):
        for configuration in ("petrol_basic", "bev"):
            with self.subTest(configuration=configuration):
                sim = self.started(configuration)
                sim.control("gear", "D")
                sim.control("parking_brake", False)
                sim.advance(1, {"brake": 0, "throttle": .5})
                before = sim.snapshot()
                sim.control("seatbelt", False)
                sim.control("driver_door", True)
                changed = sim.snapshot()
                self.assertEqual(changed["t"], before["t"])
                self.assertEqual(changed["speed_kph"], before["speed_kph"])
                self.assertTrue(changed["vehicle"]["warning_lamps"]["seatbelt"])
                self.assertTrue(changed["vehicle"]["warning_lamps"]["door_open"])
                sim.advance(1)
                after = sim.snapshot()
                self.assertGreater(after["speed_kph"], before["speed_kph"])
                self.assertTrue(after["vehicle"]["ready"])
                self.assertEqual(after["dtcs"], before["dtcs"])
                self.assertEqual(after["pending_dtcs"], before["pending_dtcs"])
                sim.control("seatbelt", True)
                sim.control("driver_door", False)
                self.assertFalse(sim.snapshot()["vehicle"]["warning_lamps"]["seatbelt"])
                self.assertFalse(sim.snapshot()["vehicle"]["warning_lamps"]["door_open"])

    def test_body_actions_log_only_transitions_and_do_not_advance_or_rewrite_history(self):
        sim = self.started()
        when, history = sim.t, deepcopy(sim.history)
        sim.control("seatbelt", True)
        sim.control("driver_door", False)
        self.assertFalse([event for event in sim.events if event["source"] == "BODY"])
        for _ in range(3):
            sim.control("seatbelt", False)
            sim.control("driver_door", True)
        sim.control("seatbelt", True)
        sim.control("driver_door", False)
        body = [event for event in sim.events if event["source"] == "BODY"]
        self.assertEqual([event["message"] for event in body], [
            "Driver seat belt unfastened", "Driver door opened",
            "Driver seat belt fastened", "Driver door closed"])
        self.assertTrue(all(event["t"] == when for event in body))
        self.assertEqual(sim.t, when)
        self.assertEqual(sim.history, history)

    def test_body_controls_require_boolean_values_and_rejection_is_atomic(self):
        sim = self.started()
        before, events = sim.snapshot(), list(sim.events)
        for action in ("seatbelt", "driver_door"):
            for value in (None, 0, 1, "false", [], {}):
                with self.subTest(action=action, value=value):
                    with self.assertRaisesRegex(ValueError, "must be boolean"):
                        sim.control(action, value)
                    self.assertEqual(sim.snapshot(), before)
                    self.assertEqual(sim.events, events)


if __name__ == "__main__":
    unittest.main()
