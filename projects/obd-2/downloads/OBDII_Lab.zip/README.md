# OBD II Lab — Virtual vehicle 0.9.10

A local vehicle and diagnostics teaching application. First choose and configure a vehicle, then choose **Drive** or **Diagnostics & service**. The cockpit, connector faults, diagnostic requests and recordings share one vehicle and simulation clock.

Release: **14 November 2026**.

## Changes in 0.9.10

Clearer shared dashboard SVG symbols for seat belt, oil pressure, engine, battery,
open doors, parking brake, ABS and stability, including the driver-check buttons.

## Changes in 0.9.9

Expand **Bytes & calculation** on a live OBD parameter to see its actual received
hex, CAN/ISO-TP frames, data bytes in hexadecimal and decimal, formula and worked
calculation. The sensor-to-ECU path is retained from the response's sample time.
**Conversion path** in sensor cards, Unit map, wiring and the selected-object
inspector shows analogue voltage conversion, ECT ADC code and NTC equations,
digital voltage/logic state, or pulse frequency conversion. The model's
illustrative transfers are labelled; no additional ADC or bus bytes are invented.
Invalid and missing inputs show their status instead of a fabricated conversion.

## Changes in 0.9.8

Engine ECU opens with 15 primary readings on Petrol basic and 19 on Petrol
extended, filtered to fitted equipment. Defaults include instantaneous L/100 km,
L/h, exhaust lambda, intake values, torque, shaft power, fuel used and 12 V
supply. L/100 km is unavailable below 1 km/h; use L/h while stationary. OBD
replies and model measurements retain their separate labels. Adding/removing
parameters is preserved while changing views or reconnecting the same vehicle.

The automatic ICE gearbox opens with eight readings: selector, actual current
gear, gearbox ratio, vehicle speed, temperature, engine speed and both pedals.
Manual vehicles additionally show clutch position, coupling and transmitted
torque. Hybrid power-split uses AUTO and does not invent numbered gears or an
unmodeled ratio. Unit map and Locations now grow with the main document; their
contents no longer need an inner vertical scrollbar.

## Changes in 0.9.7

- English / Українська switch for the interface and in-app help, using AutoMethods' shared language preference. Language changes keep the active vehicle and diagnostic data.
- Ukrainian module/sensor labels, controls, status messages and bilingual component/signal search. Protocol bytes, DTCs and identifiers retain their original values. Existing PDF/reference guides remain in English.
- Short desktop screens retain gauges and more usable tool space; narrow screens allow scrolling to all service tools.

See [language and integration notes](docs/LANGUAGES.md). The AutoMethods website itself has not been modified.

## Changes in 0.9.6

- The vehicle clock starts when a workspace opens. Engine/READY and OBD connection remain separate; stopping WLTC leaves manual driving live.
- Automatic D/R requires running engine or READY. Service gauges stay visible. WLTC explains its stopped-vehicle requirement and starts its own vehicle preparation.
- Sidebar modules and scanner targets stay synchronized, with explicit named connections.
- ECU live data includes available MAP/lambda/pressure sensors and fuel/engine model channels; OBD replies and model samples are labelled. Basic/Extended remain teaching sensor sets, without Euro certification claims.
- Plain JavaScript + Python remain the runtime. Vite is not used.

## Changes in 0.9.5

- Connect names the selected unit, reads that unit’s fault memory and opens its parameters. The unit fault action is scoped to that unit in the API.
- Scan all control units is independent discovery, with a Connect action on each result. It preserves any existing unit connection.
- Live-data Refresh selects 0.25 s, 1 s or 1 min. Custom numeric **Read** starts repeated reads; identity and service commands stay individual operations.

## Changes in 0.9.4

- A rolling 120-second speed graph and current speed stay beside the shared clock, with a separate WLTC target trace.
- The shared Driving task bar shows WLTC status in Drive and Diagnostics. Changing workspaces keeps the same task, vehicle and recording.
- Live data opens with the selected module’s main parameters. Numbers, Graphs and + Add parameter apply to all fitted modules. Measurements refresh automatically every 0.25 seconds of simulation time; Pause freezes the model and readings.
- Accelerator and brake remain visible during diagnostics. Pressing a pedal takes control from WLTC while the vehicle keeps updating. Gauges remain visible.
- Fault codes shows only the selected module. Vehicle scan is explicitly the whole-vehicle overview. Engine values come from OBD replies; other modules use labelled sampled model values. The reference-only charging interface has no implemented live measurements.

## Changes in 0.9.3

- ODO and Trip A use actual distance traveled, with a configurable starting reading and an independent trip reset.
- The compact service dashboard has physical momentary pedals, shared driving keys, gear selection and explicit WLTC takeover.
- The scan tool uses a compact connection toolbar and separate fault, live-data and connector tabs. Messages and Events stay collapsed until opened.
- The diesel choice is labelled **Diesel · common-rail**. Its current Basic/Extended sensor set appears in setup; the [diesel sensor guide](docs/DIESEL_SENSORS.html) states the exact channels and model limits.

## Start locally

The Google Drive **OBD** download folder needs only `run.sh` and `START_HERE.txt`. The standalone launcher embeds the application, editable source, original vehicle model, WLTC trace and reference documents.

```bash
python3 --version
bash run.sh
```

Python **3.10 or newer** and a modern browser are required. No additional Python packages are required; the simulator runs offline. Open <http://127.0.0.1:8765> if the browser does not open automatically. Keep the terminal open and press **Ctrl+C** there to stop the server and remove temporary working files. Export wanted logs before resetting or stopping. For another port, use `bash run.sh --port 8766 --no-browser`.

This is a local browser application, not a native desktop installer. Running the download does not require Node, Electron or Rust. Development tests can have separate dependencies.

## Prepare the vehicle before driving

At **step 1 · Vehicle**, choose a base vehicle. Open **Customize vehicle & test conditions** for the transmission, driven wheels, mass, tires/road load, ABS/ESP, cabin equipment, driving task and environment. Field changes edit a draft. **Continue** commits it once and advances to **step 2 · Choose workspace**.

Choose **Drive** for the cockpit, pedals, gears and WLTC controls, or **Diagnostics & service** for scan tools, faults, vehicle units, grouped signals, wiring, locations and the fitted-configuration summary. These are the two operational modes. Entering either uses the vehicle already prepared; switching between them keeps time, faults, selection and recorded data. Held manual controls release when leaving Drive.

Inside the service workspace, **Diagnostics** contains Scan tool and Guided faults; **Vehicle units** contains Unit map, Signals, Wiring & connectors and Locations; **Vehicle configuration** shows current hardware and an **Edit vehicle** action. This action and the global **Change vehicle** button open the same configuration flow.

**Change vehicle** pauses the current run and releases manual inputs. Edit a draft, then **Cancel** to return to the unchanged vehicle, time, faults and log, still paused. **Apply vehicle & return** explicitly starts a new parked, ignition-off run, clears the previous log and faults, disconnects the scan tool and returns to the prior workspace. Export wanted data first. Back from the initial workspace choice preserves the committed vehicle; continuing an unchanged setup does not recreate it. A failed application keeps the draft and error visible.

| Powertrain | Available transmission | Cabin heat in this model |
|---|---|---|
| Petrol basic or extended; diesel | Six-speed automatic or manual with clutch | Engine coolant |
| HEV / PHEV | Hybrid power-split automatic | Electric heater |
| BEV | Single-speed reduction | Electric heater |

FWD/RWD/AWD changes the driven wheels. Mass, rolling radius, drag area and rolling resistance affect the physical model. ESP requires ABS; BEV omits combustion-engine components. HVAC and A/C installation are configurable. Cabin and engine coolant temperature initialize from the chosen outside temperature.

Choose **You drive** for momentary pedal control or **WLTC Class 3b** for the automatic virtual driver. Automated WLTC supports the automatic transmission configurations; a manual gearbox selects manual driving. Dry, level road is the baseline. Other grip, slope and temperature settings are separate experiments.

## Drive with usable pedals and explicit power states

For a first manual drive, choose petrol with an automatic transmission and **You drive** at step 1, press **Continue**, then choose **Drive** at step 2. Switch ignition on, then press **Start engine**. Ignition powers the units; engine starting is separate. The header **VEHICLE LIVE** means time is advancing, while the cluster reports ignition, cranking, engine operation or electric READY.

Hold **S** or **Down Arrow** and click D, or use **Brake + select D**. The helper temporarily applies the virtual brake for the shift, then restores the current user inputs. Release the parking brake and use these driving keys:

| Hold key | Action | On release |
|---|---|---|
| W or Up Arrow | Full accelerator, 100% | Accelerator returns to 0% |
| S or Down Arrow | Full foot brake, 100% | Brake returns to 0% |
| A or Left Arrow | Steer left | Keyboard steering centers |
| D or Right Arrow | Steer right | Keyboard steering centers |
| C, manual gearbox | Full clutch, 100% | Clutch returns to 0% |

Hold an on-screen accelerator or brake pedal face for 35% pressure, or its adjacent vertical 0–100% slider for variable pressure. Live percentages and pedal depression show the same input. Brake is on the left, accelerator on the right, and a manual vehicle adds the clutch at the far left; holding its face applies 100%. Driving keys work in Drive and Diagnostics & service, outside text entry and Help, while you have manual control. Inputs release when you switch windows, hide the browser tab, change workspaces or enter vehicle setup. Each physical key is tracked independently, so releasing W does not release an Up Arrow that is still held. Arrow keys adjust a focused slider normally; click the dashboard away from the slider before using arrows to drive. The vehicle clock updates automatically.

Manual transmission uses N/R/1–6 and **C** for a fully pressed clutch. Start in Neutral with C held, or use **Clutch + start engine**. Select first with the clutch pressed, release the parking brake, apply accelerator pressure and use the clutch slider for a progressive release. W gives full accelerator pressure; the on-screen accelerator pedal face gives 35%, and its vertical slider provides finer control. The **Clutch + select gear** helper only assists the shift; it does not perform a smooth launch. Abrupt clutch loading can stall the engine. Recover by stopping, selecting N, pressing the clutch and restarting.

Cabin controls in Drive set temperature, fan and A/C. A cold ICE cannot immediately provide full cabin heat. Heating/cooling changes cabin temperature gradually and affects fuel or traction-battery energy. The HVAC unit and its temperature input can be disconnected and inspected.

## Dashboard warnings and engine red zone

The dashboard uses a large red circled-P parking-brake indicator, plus red seat-belt and driver-door-open indicators. The lamps follow the same vehicle state as the controls and illuminate with ignition on. The new vehicle starts with the driver belted and the driver door closed.

If D or R is selected but speed remains zero with accelerator pressure applied, check the parking-brake indicator and the parking-brake message. Release parking brake explicitly before accelerating. Selecting a gear and pressing the accelerator do not release it automatically. The warning gives a direct release action; it changes the same parking brake as the transmission control.

Use the seat-belt and driver-door controls to unfasten/fasten the belt or open/close the driver door. The red warning clears when its cause is removed. These switches record BODY events only when their state changes; they do not create engine fault codes or add a propulsion interlock. They are warning demonstrations, not a complete occupant-restraint or door-mechanism model.

Engine tachometers show a red band beginning at the selected vehicle's configured redline. Petrol and diesel use their own limits; changing the vehicle changes the band. The BEV instrument shows motor power and has no combustion-engine RPM red band.

## Keep the vehicle visible while diagnosing

A compact live dashboard stays above the tools throughout Diagnostics & service: Scan tool, Guided faults, Unit map, Signals, Wiring & connectors, Locations and the fitted Vehicle configuration summary. It shows small RPM and speed gauges, selected gear, ignition/engine/READY state, warning lamps and relevant coolant, fuel or traction-charge and 12 V readings. A BEV shows motor power instead of engine RPM.

Switch ignition on and start the engine or enable READY from this dashboard while the diagnostic tools stay open. Stop, Release parking brake, seat-belt and driver-door controls act on the same vehicle. The usual starter and vehicle-state interlocks still apply. The service dashboard also has momentary accelerator/brake pedals, a manual clutch when fitted, and assisted gear selection. W / Up Arrow, S / Down Arrow, A / D or Left / Right Arrow and C operate the same controls here. The full Drive workspace offers the larger instruments and cabin controls.

This display shares the existing session and clock. It does not start a second simulation or polling loop. The clock continues while you change service tools, independently of the OBD connection. Disconnecting a sensor or applying an intermittent fault changes the shared controller state, and the compact dashboard updates from that state. Sampled fault effects still follow the sensor/controller timing. Opening Edit vehicle enters the separate global configuration flow and pauses the session as before.

## Odometer and Trip A

Both dashboards display ODO and Trip A from the shared vehicle snapshot. In vehicle setup, **Cabin & equipment → Starting odometer · km** sets the initial reading; the default is zero. Actual forward or reverse travel adds distance. Remaining parked adds none. **Reset Trip A** clears only the trip counter, leaving total mileage, engine, clock and recordings unchanged; it also works during WLTC.

A new vehicle or session reset starts from the configured starting reading. Mileage is not persisted across launcher sessions. Complete JSON/CSV exports include the baseline, odometer and trip distance.

## Repeatable WLTC exercise

The bundled [official Class 3b target](https://www.legislation.gov.au/F2024L00446/asmade/2024-04-15/text/original/epub/OEBPS/document_1/document_1.html) contains one-second samples over 1,800 seconds, with Low, Medium, High and Extra high phases and a peak target of 131.3 km/h. Source/version/checksum metadata accompanies the trace in `data/wltc_class3b.json`.

Continuing to the workspace choice does not start the cycle. Press **Start WLTC** in Drive. The virtual driver starts the vehicle and controls its ordinary pedals and selector; actual speed comes from the physical model and is logged separately from the target. Inspect units or send diagnostics while it runs. **Drive manually** releases the virtual driver’s pedal commands while the vehicle keeps updating.

This is an official speed target used with a generic training vehicle and controller. It is **not a certified WLTP emissions, consumption or range test**. Low grip, grade, insufficient power and injected faults can cause tracking error. Road-surface and slope choices are not parts of the speed trace.

## Inspect by function, then follow the wiring

Open **Diagnostics & service → Vehicle units**. The Unit Map groups sampled inputs by **purpose** and by sensor/system group. Starting and engine timing appear first, followed by running control, braking/stability, energy/temperature, cabin comfort and information/monitoring. Each input states its modeled importance and loss consequence.

A missing crank input inhibits engine operation. MAF/MAP loss uses the limited-torque fallback. Wheel/steering/yaw loss affects installed assistance. Fuel level is an information channel with no independent sender connector or simulated fuel-starvation behavior. These are implemented teaching choices, not universal production-vehicle rules.

**Open full wiring schematic** shows one central controller housing, with connector banks inside and fitted wired sensors around it. **Whole unit** and **Focus connector** retain that controller identity. Each supported sensor card shows **Connected/Unplugged**, its current controller-input value/validity, and **Disconnect/Reconnect**. Follow component, connector, pin and wire links to their endpoints; the fault summary keeps connection, input, engine state, shaft RPM and pending/stored codes visible together.

The **Engine response** card reads actual combustion state, shaft RPM, mean shaft torque and fuel flow. It is a read-only output view; separate injector/ignition-actuator circuits and pin faults are not modeled. Pin explanations separate role, protocol use and signal examples. The standard DLC access roles are distinct from illustrative ECU/sensor connector assignments; its **Open CAN branch/Reconnect CAN** action isolates tester communication. The cutaway **Locations** view uses the same object identities and physical wheel motion.

## Sensor characteristics, sampling and intermittent faults

In **Unit map**, **Group by** offers Purpose, Sensor system, Signal type and Sample rate. In **Wiring & connectors**, **Arrangement** offers Functional group, Signal type and Sample rate around the same central controller. These controls reorganize the display without changing a connector, sample schedule or running vehicle.

Each input identifies **analogue**, **digital on/off**, **pulse**, **discrete state**, or **derived/calculated** behavior. Expand **Characteristics** for its declared range, voltage transfer or pulse conversion, update period and model limits. Calculated channels such as battery SOC have no independent sensor connector. The BMU view includes the implemented pack voltage, current and temperature sensors plus calculated SOC; it is not an individual-cell wiring model.

Sampling groups are **10, 20, 50, 100, 500 and 1,000 ms**, corresponding to **100, 50, 20, 10, 2 and 1 samples/second**. Pulse frequency is a separate live quantity. For example, the selected 60-pulses/revolution crank model produces 850 Hz at 850 rpm while its sampled input updates every 20 ms (50 samples/second). CAN bitrate, controller task periods, scan polling and recorded-log spacing are separate timings. Changing RPM never moves a sensor into another sampling group.

**Disconnect/Reconnect** works during a live run from the sensor map or schematic. Select a sensor in the schematic to use **Start intermittent**. Set its connected and dropout durations; defaults are 3 seconds connected and 1 second open. **Regular** repeats those durations; **Irregular** varies each phase reproducibly by approximately ±25%, resolved to the 2 ms plant step. This represents intermittent contact loss, not a physical vibration/corrosion model. The phase, countdown and dropout count use simulation time and stop while paused.

The contact opens and restores through the existing sampling and controller logic. A running MAF dropout invokes the implemented torque fallback; a crank dropout inhibits engine operation; other sensors follow their stated loss consequence. Very short interruptions can be missed by sampling or recover before diagnostic confirmation. Stored codes remain after signal recovery. **Stop & reconnect** cancels the schedule and restores the connector; a direct Disconnect/Reconnect also cancels it. Clearing codes does not repair the connection or stop the test. Events record transition timestamps; use a short recording interval to capture short dropouts in graphs, and export the complete run JSON for its event history.

## Diagnose and record the same vehicle

The compact scan console has a connection toolbar naming the current vehicle and ECU, followed by **Fault codes & units**, **Live data** and **Connector** tabs. Open Request details or Response details when you need addresses and raw bytes. Messages and Events remain collapsed after reads; open their counter for a compact trace and use Expand trace only when you want more room.

In **Diagnostics & service**, use **Switch ignition on** in the compact live dashboard when the vehicle is off. The units become available without starting the engine. In **Diagnostics → Scan tool**, select a matching 11-bit CAN bitrate and Engine ECU, then Connect. For a running-engine test, use **Start engine** or **Enable READY** in the compact live dashboard; the diagnostic tool stays open. Full Drive remains available for its larger driving controls. Live parameters repeat at the Refresh interval. In Custom diagnostic request, **Read** starts repeated numeric readings; identity/services execute individually. Message inspection identifies hexadecimal/decimal values, transport framing, service, PID and data bytes. Engine-speed request `01 0C` is service 1, PID 12; its data formula is `(256*A+B)/4` rpm.

The implemented engine OBD/UDS subset generates actual in-memory request/reply transcripts. Other units expose labelled simulation state. BEV has no combustion-engine diagnostic endpoint. Wrong bitrate, ignition off and open connectors produce unavailable/no-reply states. K-line/J1850/29-bit CAN/DoIP selections are references in this release.

Repair and clearing are distinct. Reconnect and obtain a fresh sample before checking recovery; stored emissions memory persists until cleared. Physical temperature or wheel motion must not become a false valid zero merely because a measurement is missing.

For a visible example, click **Disconnect** in the **Crankshaft speed** card, then advance to the next sample. The input becomes unavailable and the engine is inhibited with the teaching P0335 fault. The summary distinguishes this from **VEHICLE LIVE**, which continues to advance the rest of the model. Check engine state, RPM and sampled-input validity; a moving vehicle may coast after propulsion stops. For a fault overview, open **Vehicle scan** and choose **Scan all control units** with ignition on. Use **Connect** on a discovered row to open just that unit. This scan is explicit: engine results use OBD replies, and other units are labelled simulation-state inspection. Reconnect, obtain a fresh sample and restart if needed before clearing fault memory.

Saved-log intervals are 0.1 s, 1 s or 1 minute of simulation time. Diagnostic polling has its own interval; neither changes the fast controller/sensor periods. CSV preserves units, validity, configuration and gear. Export before **Apply vehicle & return**, Reset or shutdown. See the [current guide and local acceptance checklist](docs/WORKSPACE.html).

After entering an activity, **1** opens Drive and **2** opens Diagnostics & service. The clock advances automatically; ignition, engine/READY and OBD are separate controls. These shortcuts do not bypass the initial vehicle/workspace steps and are inactive while typing or in Help.

## Architecture and model limits

- `obdii_lab/vehicle.py`: configured powertrain, start/READY, transmissions/clutch, driven wheels, chassis parameters and cabin thermal/energy model over the existing plant.
- `obdii_lab/vehicle_systems.py`: installed units, sampled channels, purpose/importance metadata, fault consequences and connector graph.
- `obdii_lab/drive_cycles.py`: official target lookup and virtual driver using the same simulation instance and clock.
- `obdii_lab/scanner.py`: virtual connection, module capability, readiness checks and sampled engine diagnostics.
- `web/session.js`: staged setup and activity routing, serialized commands, clock ownership, temporary input assistance, shared state, recording and polling.
- `web/setup.js`, `cockpit.js`, `unit-map.js` and the wiring/scanner views: related views of that shared state.

The coolant divider is electrically solved. Other transfer functions, pulse previews and CAN waveforms identify their approximate provenance. The clutch, transmission, longitudinal tire model, yaw assistance and cabin heat balance are simplified. Detailed suspension, refrigerant dynamics, clutch temperature, full body electronics, airbag deployment, external charging and OEM calibration are outside this model. Ignition-only blower demand can be shown, but its energy is not integrated without engine/READY because there is no low-voltage battery plant.

CAN/ISO-TP frames are diagnostic lesson transcripts, not a physical bus arbitration/electrical-error simulation. No real-adapter support, ECU flashing/coding/security access, MCD/ODX importer, CARLA integration or reverse-engineering pipeline is included. Earlier PDF books remain theory references with older navigation screenshots.

## Verification and development

Automated checks cover model causality, real loopback APIs, parsed-node UI contracts and CPU rendering where applicable. They do not establish native browser event/layout, GPU or particular Linux Mint behavior. The guide’s 45 local checks are for those observations; it is not a pre-filled pass record. The [release validation record](docs/VALIDATION_0_9_3.txt) records completed automated results separately.

```bash
python3 -m unittest discover -s tests
node tests/test_session_v07.cjs
node tests/test_application_v07.cjs
node tests/test_workflow_v09.cjs
node tests/test_cockpit_units_v07.cjs
node tests/test_start_controls_v071.cjs
node tests/test_unit_purpose_v08.cjs
node tests/test_sensor_map_v091.cjs
node tests/test_schematic_characteristics_v091.cjs
node tests/test_scan_tool_v07.cjs
node tests/test_vehicle.cjs
python3 tools/build_standalone.py --output ../OBDII_Release_0_9_3
python3 tests/check_download.py --downloads ../OBDII_Release_0_9_3
```

The retained test filenames identify their original suite; the tests exercise the current source. Development-only Canvas contracts use `@napi-rs/canvas`, which is not a simulator runtime dependency. Sensor-role references include [Bosch](https://www.bosch-mobility.com/en/solutions/sensors/overview-powertrain-sensors/); diagnostic transport concepts use the [Linux ISO-TP documentation](https://docs.kernel.org/networking/iso15765-2.html). Exact model assumptions are defined by the packaged code and tests.

## Article experiment · 0.9.7+article.1

Open Help → MAF · experiment / дослід, or `/web/article-experiment.html`.
Run the 22 fixed cases; inspect the table and timing chart, export JSON/CSV.
The experiment uses separate vehicles and preserves the current driving session.
To reproduce from the command line, run:

```sh
python3 -m obdii_lab.article_experiment --output article_results
```

See `docs/ARTICLE_EXPERIMENT.md` for timing, assumptions and checks.
