#!/usr/bin/env python3
"""Live diagnostic exchange through python-can's existing VirtualBus backend.

Run from the lab folder:
    python3 -m pip install -r requirements-optional.txt
    python3 examples/python_can_demo.py

Two bus endpoints run cooperatively in one Python process. Requests reach the
live Sim/DiagnosticServer; replies cross the bus queues and are reassembled.
The multi-frame path waits for and validates a real received FC before sending
CFs. This is a deliberately small sender: normal addressing, one SF request at
a time, and FC=CTS/BS0/STmin0 only. It is not a complete asynchronous ECU server.

The explicit VirtualBus class never selects hardware from CAN configuration.
Timestamp increments illustrate event order, not 500-kbit/s wire timing.
VirtualBus provides ordered delivery, not bitrate limits or CAN arbitration.

API reference: https://python-can.readthedocs.io/en/v4.6.1/interfaces/virtual.html
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import sys

# Support execution as a file, without requiring the learning package installed.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    import can
    from can.interfaces.virtual import VirtualBus
except ImportError as exc:
    raise SystemExit(
        "This optional example requires python-can. From the lab folder run:\n"
        "  python3 -m pip install -r requirements-optional.txt\n"
        "The main learning lab works without this optional dependency."
    ) from exc

from obdii_lab.core import Sim
from obdii_lab.diagnostics import (
    DiagnosticServer, IsoTpReceiver, SYNTHETIC_VIN, hex_bytes, segment_payload,
    FUNCTIONAL_ID, ENGINE_REQUEST_ID, ENGINE_RESPONSE_ID,
)


@dataclass
class EventClock:
    """Model-time event labels; advancing this clock does not advance the plant."""
    seconds: float = 0.0

    def next(self) -> float:
        self.seconds = round(self.seconds + 0.001, 6)
        return self.seconds


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def send(bus, identifier: int, data: bytes, direction: str,
         clock: EventClock, transcript: list[dict]) -> None:
    message = can.Message(arbitration_id=identifier, is_extended_id=False,
                          data=data, timestamp=clock.next(), check=True)
    bus.send(message, timeout=0.2)
    transcript.append({"t": message.timestamp, "direction": direction,
                       "id": f"{identifier:03X}", "data": hex_bytes(data)})
    print(f"  {message.timestamp:8.3f}s  {direction:12s} {identifier:03X}  {hex_bytes(data)}")


def receive(bus, identifier: int):
    message = bus.recv(timeout=0.2)
    if message is None:
        raise TimeoutError("Expected virtual CAN frame did not arrive")
    if message.arbitration_id != identifier or message.is_extended_id:
        raise ValueError("Unexpected virtual CAN identifier/addressing")
    return message


def validate_flow_control(message) -> None:
    """This sender intentionally accepts only the one FC form used here."""
    if message.arbitration_id != ENGINE_REQUEST_ID or bytes(message.data) != bytes.fromhex("30 00 00 00 00 00 00 00"):
        raise ValueError("Example sender requires physical FC: CTS, BS=0, STmin=0, zero padding")


def exchange(server, tester, ecu, payload: str, clock: EventClock,
             transcript: list[dict]) -> bytes:
    """Execute one real queue exchange, in cooperative tester/ECU phases."""
    request = bytes.fromhex(payload)
    if not 1 <= len(request) <= 7:
        raise ValueError("This adapter lesson accepts single-frame requests only")
    print(f"\nRequest {payload}")

    # Tester transmits; ECU receives and parses the actual delivered frame.
    send(tester, FUNCTIONAL_ID, segment_payload(request)[0], "tester > ECU", clock, transcript)
    incoming = receive(ecu, FUNCTIONAL_ID)
    require(incoming.timestamp == clock.seconds, "VirtualBus did not preserve model timestamp")
    application_request = IsoTpReceiver(padding_byte=0).feed(bytes(incoming.data), incoming.timestamp)
    reply = server.request(hex_bytes(application_request), incoming.arbitration_id)
    if reply["response_hex"] is None:
        raise ValueError(reply.get("error") or reply["meaning"])
    # Reuse only the live application payload, not the generated ideal transcript.
    application_reply = bytes.fromhex(reply["response_hex"])
    outgoing = segment_payload(application_reply)
    send(ecu, ENGINE_RESPONSE_ID, outgoing[0], "ECU > tester", clock, transcript)

    receiver = IsoTpReceiver(timeout_s=1.0, padding_byte=0)
    incoming = receive(tester, ENGINE_RESPONSE_ID)
    assembled = receiver.feed(bytes(incoming.data), incoming.timestamp)
    if len(outgoing) > 1:
        require(assembled is None, "First frame unexpectedly completed the reply")
        require(tester.recv(timeout=0) is None, "Sender emitted CF before receiving FC")

        # The ECU has sent only FF so far. Tester grants permission on physical ID.
        send(tester, ENGINE_REQUEST_ID, bytes.fromhex("30 00 00 00 00 00 00 00"),
             "tester > ECU", clock, transcript)
        flow_control = receive(ecu, ENGINE_REQUEST_ID)
        validate_flow_control(flow_control)
        for frame in outgoing[1:]:
            send(ecu, ENGINE_RESPONSE_ID, frame, "ECU > tester", clock, transcript)
            incoming = receive(tester, ENGINE_RESPONSE_ID)
            require(incoming.timestamp == clock.seconds, "VirtualBus replaced model timestamp")
            assembled = receiver.feed(bytes(incoming.data), incoming.timestamp)

    require(assembled == application_reply, "Reassembled reply differs from live ECU payload")
    print(f"  Reassembled: {hex_bytes(assembled)}")
    print(f"  {reply['meaning']}")
    return assembled


def main() -> None:
    print(f"OBD-II Lab + python-can {can.__version__}: two VirtualBus endpoints")
    print("Live plant data; same-process queues; no hardware; no wire-timing/arbitration model.")
    sim = Sim(profile="engine", scenario="manual")
    sim.advance(4, {"throttle": 0.25})
    diagnostic = DiagnosticServer(sim.snapshot, sim.clear_emissions_dtcs)
    clock, transcript = EventClock(sim.t), []
    # An unguessable local object makes this channel private to these endpoints.
    channel = object()
    with VirtualBus(channel=channel, preserve_timestamps=True,
                    receive_own_messages=False, rx_queue_size=64) as tester, \
         VirtualBus(channel=channel, preserve_timestamps=True,
                    receive_own_messages=False, rx_queue_size=64) as ecu:
        first = exchange(diagnostic, tester, ecu, "01 0C", clock, transcript)
        first_rpm = int.from_bytes(first[2:], "big") / 4
        require(abs(first_rpm - sim.rpm) <= 0.1251, "First RPM reply is not the live plant reading")

        # Change the plant, then send the same request: this is not trace replay.
        sim.advance(3, {"throttle": 0.60})
        clock.seconds = max(clock.seconds, sim.t)
        second = exchange(diagnostic, tester, ecu, "01 0C", clock, transcript)
        second_rpm = int.from_bytes(second[2:], "big") / 4
        require(abs(second_rpm - sim.rpm) <= 0.1251, "Second RPM reply is not the live plant reading")
        require(second_rpm > first_rpm, "Higher accelerator input did not change the returned RPM")

        vin = exchange(diagnostic, tester, ecu, "09 02", clock, transcript)
        require(vin[3:].decode("ascii") == SYNTHETIC_VIN, "VIN failed multi-frame reassembly")

    # Demonstrate that an unsupported FC is rejected rather than silently ignored.
    try:
        validate_flow_control(can.Message(arbitration_id=ENGINE_REQUEST_ID,
                                        is_extended_id=False, data=[0x31, 0, 0, 0, 0, 0, 0, 0]))
    except ValueError:
        pass
    else:
        raise AssertionError("Sender accepted unsupported WAIT flow control")

    print(f"\nPASS: two live RPM readings ({first_rpm:.2f} -> {second_rpm:.2f}), "
          "VIN FF/FC/CF reassembly, preserved model timestamps, and invalid-FC rejection.")
    print(f"Transferred {len(transcript)} frames through python-can VirtualBus.")
    print("Next: a complete ISO-TP stack, then an explicitly configured virtual network adapter.")


if __name__ == "__main__":
    main()
