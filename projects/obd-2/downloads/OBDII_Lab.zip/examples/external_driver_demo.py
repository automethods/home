#!/usr/bin/env python3
"""A separate driver controller talks to the plant through JSON lines.

This replaces the driver, not an ECU or firmware image. All ECU models remain
inside the simulator. Run from any directory; no optional packages required.
"""
import csv
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    process = subprocess.Popen([sys.executable, str(ROOT / "run.py"), "--bridge"],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    def request(obj):
        process.stdin.write(json.dumps(obj) + "\n")
        process.stdin.flush()
        response = json.loads(process.stdout.readline())
        if not response.get("ok"):
            raise RuntimeError(response)
        return response
    rows = []
    try:
        state = request({"op": "reset", "profile": "phev"})["state"]
        integral = 0.0
        for _ in range(1500):
            target = 35.0 if state["t"] < 20 else 15.0
            error = target - state["speed_kph"]
            integral = max(-5.0, min(10.0, integral + error * 0.02))
            demand = 0.035 * error + 0.015 * integral
            throttle = max(0.0, min(0.5, demand))
            brake = max(0.0, min(0.4, -demand))
            state = request({"op": "step", "dt_s": 0.02,
                             "inputs": {"ignition": True, "throttle": throttle, "brake": brake}})["state"]
            rows.append({"t": state["t"], "target_kph": target, "speed_kph": state["speed_kph"],
                         "throttle": throttle, "brake": brake, "soc_pct": state["soc_pct"]})
        destination = Path(__file__).parent / "external_driver.csv"
        with destination.open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        print(f"Separate driver / JSON-lines plant: {state['t']:.2f} s complete.")
        print(f"Final target {target:.1f} km/h; actual {state['speed_kph']:.2f} km/h.")
        print(f"Saved {destination}")
        request({"op": "quit"})
    finally:
        process.stdin.close()
        process.stdout.close()
        process.wait(timeout=5)


if __name__ == "__main__":
    main()
