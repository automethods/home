#!/usr/bin/env python3
"""Start the offline lab, run a repeatable scenario, or expose a JSON-lines plant."""
import argparse
import json
import sys

from obdii_lab.core import SCENARIOS
from obdii_lab.runner import run_experiment, export_run, summary, diagnostic_server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--serve", action="store_true", help="Open local dashboard server (default without arguments)")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--list", action="store_true", help="List repeatable lessons")
    parser.add_argument("--scenario", default="engine_warmup")
    parser.add_argument("--profile", choices=["engine", "phev", "braking"])
    parser.add_argument("--duration", type=float)
    parser.add_argument("--output", help="Export prefix, e.g. examples/my_run")
    parser.add_argument("--request", action="append", help="OBD payload in hex, e.g. '01 0C'")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="Input override; numeric, true/false, or string")
    parser.add_argument("--config", help="JSON file containing initial state / plant parameters")
    parser.add_argument("--bridge", action="store_true", help="Read deterministic JSON-lines commands on stdin")
    args = parser.parse_args()
    if args.list:
        for s in SCENARIOS:
            print(f"{s['id']:20s} {s['duration']:>6}s  {s['title']}")
        return
    if args.bridge:
        from obdii_lab.bridge import main as bridge_main
        bridge_main()
        return
    if args.serve or len(sys.argv) == 1:
        from obdii_lab.server import serve
        serve(args.port)
        return
    overrides = {}
    for item in args.set:
        if "=" not in item:
            parser.error("--set must be KEY=VALUE")
        key, raw = item.split("=", 1)
        try:
            overrides[key] = json.loads(raw)
        except json.JSONDecodeError:
            overrides[key] = raw
    config = {}
    if args.config:
        with open(args.config, encoding="utf-8") as handle:
            config = json.load(handle)
    try:
        sim = run_experiment(args.scenario, args.duration, args.profile, config, overrides)
        print(json.dumps(summary(sim), indent=2, allow_nan=False))
        if args.output:
            for kind, path in export_run(sim, args.output, args.request).items():
                print(f"Saved {kind}: {path}")
        elif args.request:
            diag = diagnostic_server(sim)
            for payload in args.request:
                print(json.dumps(diag.request(payload), indent=2, allow_nan=False))
    except (ValueError, TypeError, KeyError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
