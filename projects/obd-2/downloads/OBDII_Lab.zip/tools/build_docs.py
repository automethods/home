"""Build the offline HTML and composed learning PDF from the delivered Markdown."""
from pathlib import Path
import html
import json
import re
import subprocess
import textwrap

import matplotlib
matplotlib.use("Agg")
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
                               PageBreak, Table, TableStyle, Image, Preformatted, KeepTogether)
from reportlab.platypus.tableofcontents import TableOfContents

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
FIG = DOCS / "figures"
FIG.mkdir(exist_ok=True)
PARTS = ["BEGINNER_HANDBOOK", "SCHEMATIC_WORKSPACE", "CONNECTOR_REFERENCE", "LEARNING_GUIDE", "WORKED_CASES", "PROTOCOL", "FIRMWARE_ROADMAP", "EXISTING_BASES", "ENGDOC_INTEGRATION", "SOURCES"]
CSS = """
:root{color-scheme:light;--ink:#15333e;--accent:#007e80;--sub:#627780}*{box-sizing:border-box}
body{font:16px/1.7 system-ui,-apple-system,'Segoe UI',sans-serif;color:var(--ink);background:#f2f5f3;margin:0}
header{background:#102c36;color:#fff;padding:22px max(24px,calc((100vw - 1080px)/2));font-size:15px;letter-spacing:.4px}
header a{color:#c5e4dd;margin-right:24px}.page{max-width:1080px;padding:40px 55px 65px;background:#fff;margin:28px auto;border:1px solid #dae3e3;border-radius:12px}
h1{font-size:34px;line-height:1.2;letter-spacing:-.8px;margin:0 0 25px}h2{font-size:24px;margin:44px 0 16px;border-top:1px solid #dce6e4;padding-top:22px;line-height:1.3}h3{font-size:19px;margin:30px 0 12px}p{margin:13px 0}a{color:#007e80;overflow-wrap:anywhere}a:hover{text-decoration:none}
table{width:100%;border-collapse:collapse;font-size:12.5px;line-height:1.6;margin:22px 0;table-layout:fixed}th{background:#173944;color:white;text-align:left}th,td{padding:11px 13px;border:1px solid #dce5e5;vertical-align:top;overflow-wrap:anywhere}tr:nth-child(even){background:#f3f7f6}
code{font:13px ui-monospace,Consolas,monospace;background:#edf3f1;padding:2px 4px;border-radius:3px;overflow-wrap:anywhere}pre{background:#102c36;color:#d8eee8;padding:18px 22px;border-radius:8px;overflow-x:auto;font-size:12px;line-height:1.7}pre code{background:transparent;color:inherit;padding:0;overflow-wrap:normal}
blockquote{border-left:4px solid #67b29a;margin:20px 0;padding:6px 22px;background:#eff6f3}img{max-width:100%;height:auto}math[display=block]{margin:24px auto;font-size:1.05em;overflow-x:auto}#TOC{border:1px solid #dce6e2;background:#f6faf7;padding:18px 25px;border-radius:8px;font-size:13px}#TOC>h2{border:0;margin:0;padding:0;font-size:16px}#TOC ul{padding-left:20px;margin:5px 0}li{margin:5px 0}.cards{display:grid;grid-template-columns:1fr 1fr;gap:15px;margin:25px 0}.card{padding:22px;background:#f2f7f5;border:1px solid #dce7e3;border-radius:8px}.card strong{display:block;font-size:18px}.tag{font-size:11px;letter-spacing:1.2px;color:var(--accent)}.note{font-size:13px;color:var(--sub)}.launch{font-size:22px;background:#007e80;color:white;padding:14px 18px;border-radius:8px;display:inline-block;text-decoration:none}footer{font-size:12px;color:#647a81;margin-top:35px;border-top:1px solid #d9e5e3;padding-top:20px}
@media(max-width:720px){.page{margin:0;padding:28px 20px;border-radius:0}h1{font-size:28px}table{font-size:11px}th,td{padding:7px}.cards{grid-template-columns:1fr}header{padding:18px 20px}header a{margin-right:12px;font-size:12px}}
@media print{body{background:white}.page{margin:0;border:0;padding:0;max-width:none}header,#TOC{display:none}a{color:inherit}pre{white-space:pre-wrap;background:#f1f5f3;color:#173640}h2,h3{break-after:avoid}tr,img,pre{break-inside:avoid}}
"""
(DOCS / "guide.css").write_text(CSS)

def source_text(name):
    text = (DOCS / f"{name}.md").read_text()
    text = re.sub("[\u2010-\u2015]", "-", text)
    return re.sub(r"\]\(([^)]+)\.md(#[^)]*)?\)", lambda m: "]("+m[1]+".html"+(m[2] or "")+")", text)

def build_html():
    header='<header><a href="../START_HERE.html">OBD II Lab</a><a href="BEGINNER_HANDBOOK.html">Beginner book</a><a href="SCHEMATIC_WORKSPACE.html">Schematics</a><a href="CONNECTOR_REFERENCE.html">Connectors</a><a href="LEARNING_GUIDE.html">Concepts</a><a href="WORKED_CASES.html">Working cases</a><a href="PROTOCOL.html">Bytes</a><a href="FIRMWARE_ROADMAP.html">Firmware</a></header>'
    for name in PARTS:
        body=subprocess.run(["pandoc","-f","markdown+tex_math_single_backslash","-t","html5","--mathml","--toc","--toc-depth=2","--standalone","--metadata",f"title={name.replace('_',' ').title()}"],input=source_text(name),text=True,capture_output=True,check=True).stdout
        body=re.sub(r"<style>.*?</style>","",body,flags=re.S)
        body=body.replace("</head>",'<link rel="stylesheet" href="guide.css"></head>').replace("<body>","<body>"+header+'<main class="page">').replace("</body>",'<footer>OBD II Lab v0.3.0 · 9 November 2026 · Synthetic educational models. See Sources for evidence boundaries.</footer></main></body>')
        (DOCS / f"{name}.html").write_text(body)

FONT_DIR=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('LabSans','DejaVuSans.ttf'),('LabSans-Bold','DejaVuSans-Bold.ttf'),('LabSans-Italic','DejaVuSans-Oblique.ttf'),('LabMono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONT_DIR/file)))
pdfmetrics.registerFontFamily('LabSans',normal='LabSans',bold='LabSans-Bold',italic='LabSans-Italic',boldItalic='LabSans-Bold')
INK=colors.HexColor('#17343f'); ACCENT=colors.HexColor('#007e80'); PALE=colors.HexColor('#f1f6f4')
WIDTH=A4[0]-88
ST={
'body':ParagraphStyle('body',fontName='LabSans',fontSize=9.3,leading=14.5,textColor=INK,spaceAfter=8,allowWidows=0,allowOrphans=0),
'h1':ParagraphStyle('h1',fontName='LabSans-Bold',fontSize=25,leading=31,textColor=INK,spaceBefore=4,spaceAfter=20,keepWithNext=True),
'h2':ParagraphStyle('h2',fontName='LabSans-Bold',fontSize=15,leading=20,textColor=INK,spaceBefore=20,spaceAfter=10,keepWithNext=True),
'h3':ParagraphStyle('h3',fontName='LabSans-Bold',fontSize=11.6,leading=16,textColor=ACCENT,spaceBefore=15,spaceAfter=8,keepWithNext=True),
'table':ParagraphStyle('table',fontName='LabSans',fontSize=7.8,leading=11.4,textColor=INK,spaceAfter=0,splitLongWords=True),
'tablehead':ParagraphStyle('tablehead',fontName='LabSans-Bold',fontSize=7.8,leading=11.4,textColor=colors.white,spaceAfter=0),
'code':ParagraphStyle('code',fontName='LabMono',fontSize=7.3,leading=10.8,textColor=INK,backColor=PALE,borderPadding=9,spaceBefore=6,spaceAfter=12),
'small':ParagraphStyle('small',fontName='LabSans',fontSize=8,leading=12,textColor=colors.HexColor('#61777f'),spaceAfter=9),
'cover':ParagraphStyle('cover',fontName='LabSans-Bold',fontSize=39,leading=46,textColor=INK,spaceAfter=22),
'subtitle':ParagraphStyle('subtitle',fontName='LabSans',fontSize=16,leading=24,textColor=ACCENT,spaceAfter=20),
}

def inlines(items):
    out=[]
    for item in items:
        typ=item['t'];c=item.get('c')
        if typ=='Str':out.append(html.escape(c))
        elif typ in ('Space','SoftBreak'):out.append(' ')
        elif typ=='LineBreak':out.append('<br/>')
        elif typ=='Code':out.append('<font name="LabMono" size="8">'+html.escape(c[1])+'</font>')
        elif typ in ('Strong','Emph'):out.append(('<b>' if typ=='Strong' else '<i>')+inlines(c)+('</b>' if typ=='Strong' else '</i>'))
        elif typ=='Link':out.append('<link href="'+html.escape(c[2][0],quote=True)+'" color="#007e80">'+inlines(c[1])+'</link>')
        elif typ=='Math':out.append('<font name="LabMono">'+html.escape(c[1])+'</font>')
        elif typ=='Quoted':out.append('“'+inlines(c[1])+'”')
        elif typ=='Image':out.append(inlines(c[1]))
        elif typ in ('Superscript','Subscript'):out.append(('<super>' if typ=='Superscript' else '<sub>')+inlines(c)+('</super>' if typ=='Superscript' else '</sub>'))
        elif typ=='Span':out.append(inlines(c[1]))
    return ''.join(out)

equation_count=0
def equation(tex):
    global equation_count
    equation_count+=1
    tex=tex.replace('\\tfrac12','\\frac{1}{2}').replace('\\dot Q','\\dot{Q}').replace('\\dot v','\\dot{v}').replace('\\dot\\omega','\\dot{\\omega}')
    path=FIG/f'equation_{equation_count:02}.png'
    math_to_image('$'+tex.replace('\n',' ')+'$',str(path),prop=FontProperties(size=15),dpi=220,color='#17343f')
    iw,ih=PILImage.open(path).size
    width=min(WIDTH-30,iw*72/220);height=width*ih/iw
    return [Spacer(1,7),Image(str(path),width=width,height=height,hAlign='CENTER'),Spacer(1,14)]

bookmark=0
def blocks(items):
    global bookmark
    out=[]
    for item in items:
        typ=item['t'];c=item.get('c')
        if typ=='Header':
            level=c[0];p=Paragraph(inlines(c[2]),ST['h'+str(min(level,3))]);bookmark+=1;p.bookmark='heading'+str(bookmark);p.level=level;out.append(p)
        elif typ in ('Para','Plain'):
            if len(c)==1 and c[0]['t']=='Math' and c[0]['c'][0]['t']=='DisplayMath':out.extend(equation(c[0]['c'][1]))
            elif len(c)==1 and c[0]['t']=='Image':
                target=c[0]['c'][2][0];file=DOCS/target
                if file.exists():
                    iw,ih=PILImage.open(file).size;out.append(Image(str(file),width=WIDTH,height=WIDTH*ih/iw))
            else:out.append(Paragraph(inlines(c),ST['body']))
        elif typ=='CodeBlock':
            code='\n'.join('\n'.join(textwrap.wrap(line,102,subsequent_indent='  ',replace_whitespace=False,drop_whitespace=False) or ['']) for line in c[1].splitlines())
            out.append(Preformatted(code,ST['code']))
        elif typ in ('BulletList','OrderedList'):
            rows=c if typ=='BulletList' else c[1];start=1 if typ=='BulletList' else c[0][0]
            for i,row in enumerate(rows):
                prefix='• ' if typ=='BulletList' else str(start+i)+'. '
                children=blocks(row)
                if children and isinstance(children[0],Paragraph):
                    child=children[0];children[0]=Paragraph(prefix+child.text,ParagraphStyle('list',parent=ST['body'],leftIndent=12,firstLineIndent=-10))
                out.extend(children)
        elif typ=='BlockQuote':out.extend(blocks(c))
        elif typ=='HorizontalRule':out.append(Spacer(1,12))
        elif typ=='Table':
            head=c[3][1];body=[]
            for b in c[4]:body.extend(b[2]+b[3])
            raw=head+body+c[5][1]
            data=[]
            for ri,row in enumerate(raw):
                cells=[]
                for cell in row[1]:
                    chunks=[]
                    for block in cell[4]:
                        if block['t'] in ('Plain','Para'):chunks.append(inlines(block['c']))
                        else:chunks.append(html.escape(str(block.get('c',''))))
                    cells.append(Paragraph('<br/>'.join(chunks),ST['tablehead' if ri<len(head) else 'table']))
                data.append(cells)
            if not data:continue
            count=len(data[0]);first=data[0][0].getPlainText()
            widths={2:[.34,.66],3:[.19,.37,.44],4:[.16,.28,.25,.31],5:[.16,.21,.21,.21,.21]}.get(count,[1/count]*count)
            if count==3 and first=='ID':widths=[.065,.47,.465]
            if count==4 and first.lower().startswith('controller'):widths=[.16,.31,.23,.30]
            table=Table(data,colWidths=[WIDTH*x for x in widths],repeatRows=len(head),hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,len(head)-1),INK),('ROWBACKGROUNDS',(0,len(head)),(-1,-1),[colors.white,PALE]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.4,colors.HexColor('#dbe5e3'))]))
            table.spaceBefore=6
            out.extend([table,Spacer(1,14)])
        elif typ=='Div':out.extend(blocks(c[1]))
        elif typ=='Figure':
            picture=blocks(c[2])
            caption=' '.join(inlines(b['c']) for b in c[1][1] if b['t'] in ('Plain','Para'))
            if caption:picture.append(Paragraph(caption,ST['small']))
            picture.append(Spacer(1,9))
            if out and isinstance(out[-1],Paragraph) and hasattr(out[-1],'bookmark'):
                picture.insert(0,out.pop())
            out.append(KeepTogether(picture))
    return out

def page(canvas,doc):
    w,h=A4
    if doc.page>1:
        canvas.setFillColor(ACCENT);canvas.rect(44,h-32,24,3,fill=1,stroke=0)
        canvas.setFont('LabSans',7.2);canvas.setFillColor(colors.HexColor('#647d85'));canvas.drawString(76,h-32,'OBD II LAB')
        canvas.setStrokeColor(colors.HexColor('#dae6e2'));canvas.line(44,39,w-44,39)
        canvas.setFont('LabSans',7);canvas.drawString(44,26,'Version 0.3.0 • Synthetic teaching models • 9 November 2026');canvas.drawRightString(w-44,26,str(doc.page))

class Manual(BaseDocTemplate):
    def beforeDocument(self):
        self._outline_depth = -1
        self.canv.showOutline()

    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and hasattr(flowable,'bookmark'):
            self.canv.bookmarkPage(flowable.bookmark)
            level = min(flowable.level - 1, 2, self._outline_depth + 1)
            self.canv.addOutlineEntry(flowable.getPlainText(),flowable.bookmark,level,closed=level>0)
            self._outline_depth = level
            if flowable.level == 1 or (getattr(self, 'beginner', False) and flowable.level == 2):
                self.notify('TOCEntry',(flowable.level-1,flowable.getPlainText(),self.page,flowable.bookmark))


def build_pdf(beginner=False):
    target=ROOT/('OBDII_Beginner_Handbook.pdf' if beginner else 'OBDII_Learning_Guide.pdf')
    title='A beginner’s book of vehicle signals' if beginner else 'OBD II Lab: Complete Learning and Reference Guide'
    doc=Manual(str(target),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=51,bottomMargin=52,title=title,author='OBD II Lab')
    doc.beginner=beginner
    doc.addPageTemplates(PageTemplate(id='main',frames=[Frame(44,52,WIDTH,A4[1]-103,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=page))
    story=[Spacer(1,40),Paragraph('READ • CHANGE • UNDERSTAND',ST['small']),Spacer(1,18),
        Paragraph('A beginner’s book<br/>of vehicle signals' if beginner else 'OBD II<br/>Lab',ST['cover']),
        Paragraph('One change. A visible result. An explanation.' if beginner else 'From one ECU to a virtual vehicle',ST['subtitle']),
        Paragraph('Start with ordinary words, then watch a sensor, a computer and a physical system respond. This reading copy accompanies the interactive learning workbench.' if beginner else 'A complete reference with beginner lessons, diagrams, connector maps, signal scopes, model equations, worked cases, diagnostic examples and a staged route toward real firmware.',ST['body']),Spacer(1,22)]
    cover_rows=[[Paragraph('READ AND PREDICT',ST['tablehead']),Paragraph('TRY AND EXPLAIN',ST['tablehead'])],
        [Paragraph('Choose a chapter. Follow the diagram. Predict what should change before you move a control.',ST['body']),Paragraph('Disconnect a virtual sensor. Advance time. Read the computer’s response and try a repair.',ST['body'])]]
    cover=Table(cover_rows,colWidths=[WIDTH/2]*2)
    cover.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('BACKGROUND',(0,1),(-1,1),PALE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),14),('RIGHTPADDING',(0,0),(-1,-1),14),('TOPPADDING',(0,0),(-1,-1),13),('BOTTOMPADDING',(0,0),(-1,-1),13)]))
    story += [cover,Spacer(1,25),Paragraph('OPEN THE MATCHING WORKBENCH',ST['h3']),
        Paragraph('On Linux Mint, download the standalone run.sh into any folder, open a terminal there and run the command below. For editable source, extract OBDII_Lab.zip; run.sh and run.py are at its top level. On Windows, use START_LAB.bat from the extracted ZIP.',ST['body']),
        Preformatted('bash run.sh',ST['code']),
        Paragraph('Python 3.10 or newer is required. The core needs no extra packages; the launcher does not download or install software. It opens your browser at the printed local address. Keep the terminal open; Ctrl+C stops the lab.',ST['small']),
        Spacer(1,12),Paragraph('Version 0.3.0 · 9 November 2026',ST['small']),
        Paragraph('Generic teaching models, with separate Toyota architecture references. This is not a calibrated vehicle, a full emissions implementation or an original-firmware emulator.',ST['small']),
        PageBreak(),Paragraph('Choose a chapter',ST['h1'])]
    toc=TableOfContents()
    toc.levelStyles=[ParagraphStyle('toc',parent=ST['body'],fontSize=10.5,leading=17,spaceBefore=8,leftIndent=0),ParagraphStyle('toc2',parent=ST['body'],fontSize=9.2,leading=15,spaceBefore=3,leftIndent=14)]
    story += [toc,Spacer(1,24),Paragraph('The bookmarks panel in your PDF viewer contains the document tree. In the live workbench, the tree stays beside the explanation, diagram and experiment controls. Start with the beginner chapters; open electrical details and message bytes when you want them.',ST['body']),
        Paragraph('The ZIP includes the simulator, this reading copy, offline HTML, editable sources, recorded experiments and verification notes. The complete guide also contains the model mathematics, connectors, diagnostic protocols, software reuse options and firmware roadmap.',ST['small']),PageBreak()]
    for i,name in enumerate(['BEGINNER_HANDBOOK'] if beginner else PARTS):
        if i:story.append(PageBreak())
        parsed=json.loads(subprocess.run(['pandoc','-f','markdown+tex_math_single_backslash','-t','json'],input=source_text(name),text=True,capture_output=True,check=True).stdout)
        story.extend(blocks(parsed['blocks']))
    doc.multiBuild(story)
    print(target)

def build_start():
    cards=''.join('<a class="card" href="docs/'+name+'.html"><strong>'+title+'</strong>'+desc+'</a>' for name,title,desc in [
      ('BEGINNER_HANDBOOK','Start with ordinary words','Ten chapters, friendly diagrams, fault exercises and a glossary.'),('ENGDOC_INTEGRATION','Try the EngDoc worksheet','An importable coolant-sensor calculation and a concrete integration boundary.'),('SCHEMATIC_WORKSPACE','Follow every signal','Five screens, a guided coolant fault, live probes and a scope.'),('CONNECTOR_REFERENCE','2. Inspect the connectors','DLC orientation and the illustrative ECU/sensor circuit.'),('LEARNING_GUIDE','3. Understand the model','ECUs, sensors, timing, equations and learning sequence.'),('WORKED_CASES','4. Reproduce the results','Eight lessons and controlled ABS / regeneration comparisons.'),('PROTOCOL','5. Follow the bytes','OBD PIDs, fault codes, CAN frames and ISO-TP.'),('FIRMWARE_ROADMAP','6. Connect the next layer','Virtual vehicles, controller interfaces and firmware milestones.'),('EXISTING_BASES','7. Reuse existing software','python-can, SocketCAN, ELM327 and the Toyota reference base.'),('SOURCES','8. Check the evidence','Primary sources, exact Drive references and assumptions.')])
    page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Start here | OBD II Lab</title><style>'''+CSS+'''</style></head><body><header>OBD II LAB</header><main class="page"><div class="tag">A RUNNABLE FIRST STEP TOWARD A VIRTUAL VEHICLE</div><h1>One sensor.<br/>One decision.<br/>A whole control loop.</h1><p>Read a short explanation, change one input and see what the vehicle computer decides. Begin with one sensor, then explore the battery, hybrid coordination and braking.</p><h2>Linux Mint: download one file and run it</h2>
<ol>
<li>Download <strong><code>run.sh</code></strong> from the OBDII folder and save it in any folder on your computer. This standalone file contains the complete simulator and learning book.</li>
<li>Open that folder in a terminal and run <code>bash run.sh</code>. The launcher prepares its bundled files in a temporary folder, starts the lab and opens your browser.</li>
<li>Keep the terminal open. In the <strong>Learning book</strong>, choose a chapter and press <strong>Start this experiment</strong>. Press <strong>Ctrl+C</strong> in the terminal when you finish; the temporary folder is then removed.</li>
</ol>
<p><a class="launch" href="http://127.0.0.1:8765">Open the learning book →</a></p>
<p class="note"><strong>Python 3.10 or newer must be available.</strong> The launcher checks for it. The core needs no additional Python packages, and the launcher does not download files or install software. The button works after the server starts on your computer. If the browser does not open, use the address printed in the terminal.</p>
<p><code>bash run.sh</code> also works on shared drives without executable permission. To choose another port, use <code>bash run.sh --port 8766</code>. To open the browser yourself, use <code>bash run.sh --no-browser</code>.</p>
<h2>Full source ZIP: keep and edit the files</h2>
<p>Download <strong><code>OBDII_Lab.zip</code></strong> and extract its contents into any folder. The files <code>run.sh</code>, <code>launcher.py</code> and <code>run.py</code> appear immediately at the top level, beside the <code>obdii_lab/</code>, <code>web/</code> and <code>docs/</code> folders and the PDF books. Open that folder in a terminal and run <code>bash run.sh</code>.</p>
<p>Choose the ZIP to edit the simulator, run command-line examples or keep the books directly accessible. On Windows, double-click <code>START_LAB.bat</code>. You can also start the extracted simulator with <code>python3 run.py --serve</code>. Google Drive preview displays documents; start the launcher on your computer to use the simulation controls.</p>
<p><a href="docs/SCHEMATIC_GALLERY.html">Preview eight exported schematics without starting the simulator →</a></p>
<h2>Learn and explore</h2><div class="cards">'''+cards+'''</div><p><a href="OBDII_Beginner_Handbook.pdf">Read the beginner PDF</a> · <a href="OBDII_Learning_Guide.pdf">Read the complete PDF guide</a> · <a href="docs/VALIDATION.txt">See executed verification</a> · <a href="examples/RESULTS.csv">Open the experiment summary</a></p><h2>What the model includes</h2><p>The engine, battery, generic parallel hybrid and longitudinal ABS are executable teaching models. ESC is approximate. The Toyota references describe a separate power-split architecture. Original firmware, grid charging and a complete vehicle network are future stages described in the guide.</p><p>Optional existing-library integration from the extracted source folder: <code>python3 -m pip install -r requirements-optional.txt</code>, then <code>python3 examples/python_can_demo.py</code>. This exchanges live diagnostic frames on an in-process virtual bus.</p><footer>9 November 2026 · Offline by default · Source and reproducible results included</footer></main></body></html>'''
    (ROOT/'START_HERE.html').write_text(page)

if __name__=='__main__':
    build_html();build_pdf();build_pdf(beginner=True);build_start()
