"""Independent worksheet arithmetic check; does not run the EngDoc editor."""
from pathlib import Path
import ast, json, math, operator, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from obdii_lab.core import Parameters, ect_circuit
path=root/'examples/engdoc_coolant_sensor.json'
doc=json.loads(path.read_text()); definitions={v['id']:v for v in doc['values']}
ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv}
def eval_ast(n,scope):
 if isinstance(n,ast.Expression):return eval_ast(n.body,scope)
 if isinstance(n,ast.Constant) and type(n.value) in (int,float):return n.value
 if isinstance(n,ast.Name):return scope[n.id]
 if isinstance(n,ast.BinOp) and type(n.op) in ops:return ops[type(n.op)](eval_ast(n.left,scope),eval_ast(n.right,scope))
 if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -eval_ast(n.operand,scope)
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='exp' and len(n.args)==1 and not n.keywords:return math.exp(eval_ast(n.args[0],scope))
 raise ValueError('Unsupported worksheet formula syntax')
def evaluate(overrides):
 cache={}; active=set()
 def get(i):
  if i in cache:return cache[i]
  assert i not in active,'dependency cycle'; active.add(i);v=definitions[i]
  if v['role']=='input': result=overrides.get(i,v['value']['value'])
  else:
   expr=v['expression'];scope={b['token']:get(b['valueId']) for b in expr['bindings']};result=eval_ast(ast.parse(expr['source'],mode='eval'),scope)
  assert math.isfinite(result),(i,result);cache[i]=result;active.remove(i);return result
 for i in definitions:get(i)
 return cache
baseline=evaluate({})
assert math.isclose(baseline['value.sensor_ohm'],2500,abs_tol=1e-12)
assert math.isclose(baseline['value.signal_v'],12500/4700,abs_tol=1e-12)
assert math.isclose(baseline['value.branch_ma'],5000/4700,abs_tol=1e-12)
cases=0
for t in [-20,25,110]:
 for vref in [3.3,5,5.5]:
  for rp in [100,2200,10000]:
   for opened in [0,1]:
    result=evaluate({'input.temperature_c':t,'input.reference_v':vref,'input.pullup_ohm':rp,'input.open':opened})
    expected=ect_circuit(t,Parameters(reference_voltage_v=vref,ect_pullup_ohm=rp),open_circuit=bool(opened))
    assert math.isclose(result['value.signal_v'],expected['ect_node_v'],abs_tol=1e-12)
    assert math.isclose(result['value.branch_ma'],expected['ect_current_ma'],abs_tol=1e-12)
    if opened:assert result['value.signal_v']==vref and result['value.branch_ma']==0
    cases+=1
curve=[]
for j,t in enumerate([-20,0,25,60,90,110]):
 expected=ect_circuit(t,Parameters())
 assert math.isclose(baseline['value.curve_v'+str(j)],expected['ect_node_v'],abs_tol=1e-12)
 assert math.isclose(baseline['value.curve_i'+str(j)],expected['ect_current_ma'],abs_tol=1e-12)
 curve.append({'temperature_c':t,'voltage_v':baseline['value.curve_v'+str(j)],'current_ma':baseline['value.curve_i'+str(j)]})
report={'status':'passed','method':'restricted Python AST evaluation of every supplied expression, cross-checked against the lab ECT circuit; not the EngDoc UI runtime','values':len(definitions),'boundary_combinations':cases,'baseline_resistance_ohm':baseline['value.sensor_ohm'],'baseline_signal_v':baseline['value.signal_v'],'baseline_current_ma':baseline['value.branch_ma'],'curve':curve}
(root/'docs/ENGDOC_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
