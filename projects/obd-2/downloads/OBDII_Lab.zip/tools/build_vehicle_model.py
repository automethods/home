#!/usr/bin/env python3
"""Build the original, editable teaching vehicle GLB using only the stdlib.

The original crossover has contoured panels and named movable parts.
No manufacturer model, textures, third-party geometry or runtime dependency.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "web" / "models"


def box():
    points, normals, indices = [], [], []
    faces = [
        ((1, 0, 0), [(1, -1, -1), (1, 1, -1), (1, 1, 1), (1, -1, 1)]),
        ((-1, 0, 0), [(-1, -1, 1), (-1, 1, 1), (-1, 1, -1), (-1, -1, -1)]),
        ((0, 1, 0), [(-1, 1, -1), (-1, 1, 1), (1, 1, 1), (1, 1, -1)]),
        ((0, -1, 0), [(-1, -1, 1), (-1, -1, -1), (1, -1, -1), (1, -1, 1)]),
        ((0, 0, 1), [(1, -1, 1), (1, 1, 1), (-1, 1, 1), (-1, -1, 1)]),
        ((0, 0, -1), [(-1, -1, -1), (-1, 1, -1), (1, 1, -1), (1, -1, -1)]),
    ]
    for normal, corners in faces:
        start = len(points)
        points.extend([[v / 2 for v in p] for p in corners])
        normals.extend([normal] * 4)
        indices.extend([start, start + 1, start + 2, start, start + 2, start + 3])
    return points, normals, indices


def cylinder(segments=36):
    """Unit diameter, unit length cylinder along X; wheel pivot at origin."""
    points, normals, indices = [], [], []
    for end in [-0.5, 0.5]:
        for i in range(segments + 1):
            angle = i * 2 * math.pi / segments
            points.append([end, math.cos(angle) / 2, math.sin(angle) / 2])
            normals.append([0, math.cos(angle), math.sin(angle)])
    for i in range(segments):
        j = i + segments + 1
        indices.extend([i, j, i + 1, i + 1, j, j + 1])
    for end, direction in [(-0.5, -1), (0.5, 1)]:
        start = len(points)
        points.append([end, 0, 0]); normals.append([direction, 0, 0])
        for i in range(segments + 1):
            angle = i * 2 * math.pi / segments
            points.append([end, math.cos(angle) / 2, math.sin(angle) / 2])
            normals.append([direction, 0, 0])
        for i in range(segments):
            indices.extend([start, start + i + 1, start + i + 2] if direction > 0
                           else [start, start + i + 2, start + i + 1])
    return points, normals, indices


class Builder:
    def __init__(self):
        self.blob = bytearray()
        self.doc = {"asset": {"version": "2.0", "generator": "OBD II Lab original teaching geometry"},
                    "scene": 0, "scenes": [{"name": "Transparent training vehicle", "nodes": []}],
                    "nodes": [], "meshes": [], "materials": [], "accessors": [], "bufferViews": []}
        self.materials = {}
        self.geometries = {}
        self.shapes = {}
        self.meshes = {}

    def accessor(self, values, shape, component=5126):
        flat = [v for row in values for v in row] if shape == "VEC3" else list(values)
        while len(self.blob) % 4:
            self.blob.append(0)
        offset = len(self.blob)
        self.blob.extend(struct.pack("<" + ("f" if component == 5126 else "H") * len(flat), *flat))
        view = len(self.doc["bufferViews"])
        self.doc["bufferViews"].append({"buffer": 0, "byteOffset": offset, "byteLength": len(self.blob) - offset})
        entry = {"bufferView": view, "componentType": component, "count": len(values), "type": shape}
        if shape == "VEC3":
            entry["min"] = [min(v[i] for v in values) for i in range(3)]
            entry["max"] = [max(v[i] for v in values) for i in range(3)]
        self.doc["accessors"].append(entry)
        return len(self.doc["accessors"]) - 1

    def material(self, name, color):
        if name not in self.materials:
            self.materials[name] = len(self.doc["materials"])
            self.doc["materials"].append({"name": name, "pbrMetallicRoughness": {
                "baseColorFactor": color, "metallicFactor": 0.12, "roughnessFactor": 0.62},
                "doubleSided": True, "alphaMode": "BLEND" if color[3] < 1 else "OPAQUE"})
        return self.materials[name]

    def mesh(self, shape, material):
        key = (shape, material)
        if key in self.meshes:
            return self.meshes[key]
        if shape not in self.geometries:
            p, n, i = self.shapes[shape] if shape in self.shapes else (box() if shape == "box" else cylinder())
            self.geometries[shape] = {"attributes": {"POSITION": self.accessor(p, "VEC3"),
                                                     "NORMAL": self.accessor(n, "VEC3")},
                                      "indices": self.accessor(i, "SCALAR", 5123), "mode": 4}
        prim = {**self.geometries[shape], "material": material}
        self.doc["meshes"].append({"primitives": [prim]})
        self.meshes[key] = len(self.doc["meshes"]) - 1
        return self.meshes[key]

    def node(self, name, pos, size, material, *, shape="box", component=None, role=None, parent=None, rotation=None):
        node = {"name": name, "translation": pos, "scale": size,
                "mesh": self.mesh(shape, material), "extras": {}}
        if rotation:
            node["rotation"] = rotation
        if component:
            node["extras"]["component_id"] = component
        if role:
            node["extras"]["role"] = role
        index = len(self.doc["nodes"])
        self.doc["nodes"].append(node)
        if parent is None:
            self.doc["scenes"][0]["nodes"].append(index)
        else:
            self.doc["nodes"][parent].setdefault("children", []).append(index)
        return index

    def group(self, name, pos, extras=None):
        index = len(self.doc["nodes"])
        self.doc["nodes"].append({"name": name, "translation": pos, "children": [], "extras": extras or {}})
        self.doc["scenes"][0]["nodes"].append(index)
        return index

    def save(self, path):
        while len(self.blob) % 4:
            self.blob.append(0)
        self.doc["buffers"] = [{"byteLength": len(self.blob)}]
        data = json.dumps(self.doc, separators=(",", ":")).encode()
        data += b" " * (-len(data) % 4)
        total = 12 + 8 + len(data) + 8 + len(self.blob)
        path.write_bytes(struct.pack("<III", 0x46546C67, 2, total) +
                         struct.pack("<II", len(data), 0x4E4F534A) + data +
                         struct.pack("<II", len(self.blob), 0x004E4942) + self.blob)


def surface(rows):
    """Create a smooth quad patch with accumulated, area-weighted normals."""
    vertices = [list(p) for row in rows for p in row]
    normals = [[0., 0., 0.] for _ in vertices]
    columns = len(rows[0]); indices = []
    for j in range(len(rows) - 1):
        for i in range(columns - 1):
            a = j * columns + i; b = a + 1; c = a + columns; d = c + 1
            indices.extend([a, c, b, b, c, d])
    for i in range(0, len(indices), 3):
        a,b,c = indices[i:i+3]
        u = [vertices[b][k]-vertices[a][k] for k in range(3)]
        v = [vertices[c][k]-vertices[a][k] for k in range(3)]
        n = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        for j in (a,b,c):
            for k in range(3): normals[j][k] += n[k]
    for n in normals:
        length = math.sqrt(sum(x*x for x in n)) or 1
        for k in range(3): n[k] /= length
    return vertices, normals, indices


def ring(profile, segments=40):
    """Rounded tyre section rotated about X; radii are in metres."""
    return surface([[[x,r*math.cos(i*2*math.pi/segments),r*math.sin(i*2*math.pi/segments)]
                     for i in range(segments+1)] for x,r in profile])


def qx(angle):
    return [math.sin(angle/2),0,0,math.cos(angle/2)]


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    b = Builder()
    colors = {
        "body": [.40,.58,.67,1], "glass": [.10,.22,.28,.82],
        "chassis": [.20,.26,.29,1], "tyre": [.075,.09,.105,1],
        "rubber": [.04,.055,.07,1], "hub": [.70,.76,.78,1],
        "chrome": [.80,.85,.87,1], "interior": [.19,.24,.27,1],
        "engine": [.40,.46,.49,1], "engine_cover": [.17,.22,.25,1],
        "ecu": [.28,.36,.70,1], "sensor": [.98,.61,.18,1],
        "battery": [.12,.60,.59,1], "can": [.12,.65,.75,1],
        "brake": [.82,.29,.25,1], "screen": [.08,.15,.20,1],
        "headlamp": [.87,.96,1,1], "tail": [.94,.19,.22,1],
    }
    m = {name: b.material(name,color) for name,color in colors.items()}
    def patch(name, rows, color="body", role="body", component=None):
        b.shapes[name] = surface(rows)
        return b.node(name,[0,0,0],[1,1,1],m[color],shape=name,role=role,component=component)
    def top_panel(name, sections, color="body"):
        # Each longitudinal section: z, half width, crown height, shoulder drop.
        return patch(name,[[[w*u,h-drop*u*u,z] for u in [(-1+i/10) for i in range(21)]]
                           for z,w,h,drop in sections],color)
    # Hood has a curved nose and distinct shoulders. The rear is a compact tailgate.
    top_panel("body_hood",[(-2.23,.81,.91,.08),(-2.13,.96,1.02,.12),(-1.84,1.01,1.10,.13),
                            (-1.35,1.01,1.16,.12),(-.92,.94,1.19,.06),(-.79,.90,1.18,.03)])
    top_panel("body_tail",[(1.32,.88,1.20,.05),(1.64,.98,1.14,.06),(2.0,1.0,1.07,.10),(2.22,.86,.96,.09)])
    # Side panels have actual open wheel arches rather than solid boxes.
    for side in [-1,1]:
        zs=sorted(set([round(-2.2+i*.05,4) for i in range(89)]+[-1.81,-.99,.99,1.81]))
        rows=[]
        for z in zs:
            arch=max([.36+math.sqrt(max(0,.415**2-(z-c)**2)) if abs(z-c)<.415 else .43 for c in [-1.4,1.4]])
            crown=1.13-.09*(abs(z)/2.2)**2
            width=1.01-.16*(abs(z)/2.2)**8
            rows.append([[side*(width-.055+ .055*math.sin(u*math.pi*.85)),arch+(crown-arch)*u,z] for u in [0,.2,.5,.8,1]])
        patch("body_side_"+str(side),rows)
        # Fine door waist moulding, lower sill and mirror housings.
        b.node("body_sill_"+str(side),[side*.98,.44,0],[.07,.095,1.88],m["body"],role="body")
        b.node("trim_sill_"+str(side),[side*1.002,.455,0],[.025,.028,1.82],m["chrome"],role="body")
        b.node("mirror_"+str(side),[side*1.10,1.19,-.62],[.23,.12,.25],m["body"],role="body")
        b.node("mirror_glass_"+str(side),[side*1.11,1.19,-.49],[.19,.08,.015],m["glass"],role="body")
        for z in [-.31,.74]:
            b.node("door_handle_"+str(side)+"_"+str(z),[side*1.018,1.035,z],[.028,.035,.19],m["chrome"],role="body")
        # Sloping side glazing with a B pillar. One original profile on each side.
        for name,sections in [("front",[(-.78,.90,1.18),(-.29,.78,1.61),(.23,.78,1.63)]),
                              ("rear",[(.29,.78,1.63),(.92,.79,1.60),(1.50,.94,1.17)])]:
            patch("glass_"+name+"_"+str(side),[[[side*(w+(0.95-w)*t),h+(1.15-h)*t,z] for t in [0,.25,.5,.75,1]] for z,w,h in sections],"glass")
        b.node("body_b_pillar_"+str(side),[side*.85,1.39,.26],[.05,.49,.055],m["rubber"],role="body")
        # Headlamps, slim LED signatures, and red rear lights.
        b.node("headlamp_"+str(side),[side*.72,.955,-2.17],[.40,.105,.055],m["headlamp"],role="body")
        b.node("lamp_brow_"+str(side),[side*.72,1.015,-2.172],[.39,.024,.06],m["chrome"],role="body")
        b.node("tail_lamp_"+str(side),[side*.73,1.0,2.18],[.38,.09,.06],m["tail"],role="body")
    top_panel("body_roof",[(-.30,.78,1.62,.04),(-.12,.80,1.67,.04),(.40,.81,1.69,.04),(.85,.80,1.66,.05),(1.0,.77,1.59,.03)])
    top_panel("glass_front",[(-.81,.90,1.185,.025),(-.64,.86,1.35,.03),(-.45,.81,1.51,.035),(-.30,.78,1.62,.04)],"glass")
    top_panel("glass_rear",[(1.0,.77,1.59,.03),(1.18,.82,1.45,.04),(1.40,.90,1.25,.04),(1.50,.94,1.17,.04)],"glass")
    # Bumpers curve in plan; lower fascia and grille are dark and recessed.
    for front,zsign in [(True,-1),(False,1)]:
        sections=[]
        for u in [-1+i*.1 for i in range(21)]:
            x=u*.96; z=zsign*(2.22-.16*u*u)
            sections.append([[x,y,z+.025*math.sin((y-.44)*math.pi)] for y in [.44,.54,.67,.79,.91]])
        patch("body_front" if front else "body_rear",sections)
    b.node("front_grille",[0,.71,-2.25],[1.05,.22,.025],m["rubber"],role="body")
    for y in [.63,.69,.75,.81]:
        b.node("grille_bar_"+str(y),[0,y,-2.267],[.98,.013,.014],m["chrome"],role="body")
    b.node("front_license",[0,.57,-2.27],[.44,.085,.018],m["hub"],role="body")
    b.node("rear_fascia",[0,.56,2.23],[1.52,.12,.03],m["rubber"],role="body")
    b.node("rear_license",[0,.85,2.247],[.44,.095,.018],m["hub"],role="body")
    b.node("chassis",[0,.46,0],[1.68,.10,3.9],m["chassis"])
    # Seats and a dashboard can be seen through the cabin glass.
    for x in [-.43,.43]:
        for z in [-.12,.80]:
            b.node("seat_base_"+str(x)+"_"+str(z),[x,.89,z],[.46,.16,.48],m["interior"],role="cabin")
            b.node("seat_back_"+str(x)+"_"+str(z),[x,1.13,z+.19],[.47,.44,.12],m["interior"],role="cabin",rotation=qx(-.12))
            b.node("headrest_"+str(x)+"_"+str(z),[x,1.42,z+.22],[.24,.14,.11],m["interior"],role="cabin")
    b.node("dashboard",[0,1.06,-.56],[1.64,.16,.22],m["interior"],role="cabin")
    # Smooth tyres and alloy rims. Every wheel is a rigid named pivot.
    b.shapes["tyre_rounded"] = ring([[-.15,.22],[-.15,.275],[-.13,.305],[-.10,.31],[.10,.31],[.13,.305],[.15,.275],[.15,.22]])
    b.shapes["rim_ring"] = ring([[-.151,.18],[-.154,.222],[-.145,.231],[.145,.231],[.154,.222],[.151,.18]])
    for name,x,z,idx in [("wheel_fl",-1.01,-1.4,0),("wheel_fr",1.01,-1.4,1),("wheel_rl",-1.01,1.4,2),("wheel_rr",1.01,1.4,3)]:
        wheel=b.group(name,[x,.34,z],{"component_id":name,"wheel_index":idx})
        b.node(name+"_tyre",[0,0,0],[1,1,1],m["tyre"],shape="tyre_rounded",parent=wheel)
        b.node(name+"_rim",[0,0,0],[1,1,1],m["hub"],shape="rim_ring",parent=wheel)
        b.node(name+"_disc",[0,0,0],[.21,.35,.35],m["engine"],shape="cylinder",parent=wheel)
        for k in range(7):
            a=k*math.tau/7
            b.node(name+"_spoke_"+str(k),[0,math.cos(a)*.12,math.sin(a)*.12],[.31,.21,.036],m["chrome"],parent=wheel,rotation=qx(a))
        b.node(name+"_hub",[0,0,0],[.32,.095,.095],m["hub"],shape="cylinder",parent=wheel)
        for k in range(24):
            a=k*math.tau/24
            b.node(name+"_tread_"+str(k),[0,math.cos(a)*.308,math.sin(a)*.308],[.20,.006,.014],m["rubber"],parent=wheel,rotation=qx(a))
    for z in [-1.4,1.4]: b.node("axle_"+str(z),[0,.34,z],[1.90,.055,.055],m["chassis"])
    parts=[
        ("engine",[0,.83,-1.27],[.84,.43,.77],"engine"),
        ("ecu",[.63,1.04,-1.25],[.32,.11,.45],"ecu"),
        ("coolant_sensor",[-.46,1.01,-1.25],[.12,.18,.13],"sensor"),
        ("battery",[0,.60,.63],[1.24,.20,1.67],"battery"),
        ("bmu",[.72,.82,.65],[.27,.18,.42],"can"),
        ("abs",[-.70,.87,-.68],[.30,.24,.33],"brake"),
        ("supervisor",[.36,1.01,-.55],[.29,.12,.30],"ecu"),
        ("dlc",[-.67,1.01,-.13],[.24,.14,.16],"sensor"),
        ("scan_tool",[-1.95,.67,-.30],[.34,.12,.56],"screen"),
    ]
    for name,pos,size,color in parts: b.node(name,pos,size,m[color],component=name)
    b.node("engine_top",[0,1.06,-1.26],[.72,.035,.64],m["engine_cover"],component="engine")
    for x in [-.28,-.14,0,.14,.28]: b.node("engine_rib_"+str(x),[x,1.087,-1.26],[.034,.018,.48],m["hub"],component="engine")
    for z in [.03,.31,.59,.87,1.15]: b.node("battery_cell_"+str(z),[0,.71,z],[1.12,.018,.20],m["can"],component="battery")
    b.node("scan_display",[-1.95,.737,-.32],[.27,.008,.31],m["can"],component="scan_tool")
    for k in range(3): b.node("scan_button_"+str(k),[-2.04+k*.09,.738,-.10],[.05,.009,.025],m["hub"],component="scan_tool")
    b.save(DEST/"training_vehicle.glb")
    bindings={
        "schema":"obdii-lab.vehicle-bindings.v1","model":"training_vehicle.glb",
        "description":"Original contoured training crossover with selectable systems; not a manufacturer service model.",
        "coordinate_system":{"up":"+Y","front":"-Z","left":"-X","units":"metres"},
        "body_nodes":[n["name"] for n in b.doc["nodes"] if n.get("extras",{}).get("role")=="body"],
        "components":{name:{"node":name,"object_id":name} for name,*_ in parts},
        "wheels":[{"node":name,"object_id":name,"signal_path":f"wheel_speeds_kph.{i}",
                   "measurement_path":f"sensors.wheel_speeds_kph.{i}","axis":"x","direction":-1,"radius_m":.31}
                  for i,name in enumerate(["wheel_fl","wheel_fr","wheel_rl","wheel_rr"])],
        "signals":{"coolant_sensor":"sensors.ect_voltage_v","battery":"soc_pct","engine":"rpm","bmu":"sensors.bmu_message_age_ms"},
        "connections":{"coolant_sensor":"ect","dlc":"dlc","scan_tool":"dlc","bmu":"bmu","wheel_fl":"wheel_fl"},
        "animation":"Wheel angles integrate physical wheel-speed samples. Intermediate frames interpolate completed simulation steps. Signal dots show information flow, not electrical timing."
    }
    (DEST/"vehicle_bindings.json").write_text(json.dumps(bindings,indent=2)+"\n",encoding="utf-8")
    print(f"Created {DEST/'training_vehicle.glb'} ({(DEST/'training_vehicle.glb').stat().st_size} bytes, {len(b.doc['nodes'])} nodes)")


if __name__ == "__main__":
    main()
