#!/usr/bin/env python3
"""Build a flat source ZIP and a single-file Linux launcher using only Python.

Run from any directory: python3 tools/build_standalone.py --output ../OBDII_Downloads
The output directory must be outside the source tree to avoid recursive bundles.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import stat
import zipfile


ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = r'''#!/bin/sh
# OBD II Lab: complete, offline Linux launcher.
# Save this one file in any folder and run: bash run.sh
# Requires Python 3.10 or newer. No extra packages or downloads are needed.
set -eu
if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' 'Python 3.10 or newer is needed to run the simulator.' >&2
    printf '%s\n' 'Install Python 3, then run: bash run.sh' >&2
    exit 1
fi
export PYTHONDONTWRITEBYTECODE=1
exec python3 -u - "$0" "$@" <<'PYTHON'
import sys

if sys.version_info < (3, 10):
    print("Python 3.10 or newer is required. Found Python " + sys.version.split()[0] + ".", file=sys.stderr)
    print("Install a newer Python 3, then run: bash run.sh", file=sys.stderr)
    raise SystemExit(1)

import base64
import hashlib
import io
import os
from pathlib import Path, PurePosixPath
import runpy
import signal
import stat
import tempfile
import zipfile

EXPECTED_ARCHIVE_SHA256 = "@@ARCHIVE_SHA256@@"
sys.dont_write_bytecode = True

def stop_requested(_signum, _frame):
    raise KeyboardInterrupt

signal.signal(signal.SIGTERM, stop_requested)

def unpack_bundle(destination):
    try:
        source = Path(sys.argv[1]).resolve().read_bytes()
        encoded = source.split(b"\n: <<'OBDII_PAYLOAD'\n", 1)[1]
        encoded, tail = encoded.rsplit(b"\nOBDII_PAYLOAD", 1)
        if tail.strip():
            raise ValueError("unexpected text after the bundled files")
        payload = base64.b64decode(b"".join(encoded.split()), validate=True)
    except (OSError, ValueError, IndexError) as exc:
        raise ValueError("The download is incomplete or damaged. Download run.sh again.") from exc
    if hashlib.sha256(payload).hexdigest() != EXPECTED_ARCHIVE_SHA256:
        raise ValueError("The bundled files did not pass their checksum. Download run.sh again.")
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        names = set()
        for item in archive.infolist():
            relative = PurePosixPath(item.filename)
            if (item.is_dir() or relative.is_absolute() or ".." in relative.parts
                    or "\\" in item.filename or "\x00" in item.filename
                    or relative.as_posix() != item.filename or not relative.parts
                    or stat.S_ISLNK(item.external_attr >> 16) or item.filename in names):
                raise ValueError("The bundled file layout is invalid. Download run.sh again.")
            names.add(item.filename)
        required = {"launcher.py", "run.py", "obdii_lab/server.py", "web/index.html", "SHA256SUMS.txt"}
        if not required.issubset(names):
            raise ValueError("The download is missing simulator files. Download run.sh again.")
        checksums = {}
        for line in archive.read("SHA256SUMS.txt").decode("utf-8").splitlines():
            digest, name = line.split("  ", 1)
            if name in checksums or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise ValueError("The bundled checksum list is invalid. Download run.sh again.")
            checksums[name] = digest
        if set(checksums) != names - {"SHA256SUMS.txt"}:
            raise ValueError("The bundled checksum list is incomplete. Download run.sh again.")
        for item in archive.infolist():
            content = archive.read(item)
            if item.filename != "SHA256SUMS.txt" and hashlib.sha256(content).hexdigest() != checksums[item.filename]:
                raise ValueError("A bundled file is damaged. Download run.sh again.")
            target = destination.joinpath(*PurePosixPath(item.filename).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
            target.chmod(0o755 if (item.external_attr >> 16) & 0o111 else 0o644)

def main():
    previous_directory = Path.cwd()
    with tempfile.TemporaryDirectory(prefix="obdii-lab-") as temporary:
        destination = Path(temporary)
        try:
            unpack_bundle(destination)
            sys.path.insert(0, str(destination))
            sys.argv = ["run.sh", *sys.argv[2:]]
            os.chdir(destination)
            runpy.run_path(str(destination / "launcher.py"), run_name="__main__")
        finally:
            os.chdir(previous_directory)

try:
    main()
except KeyboardInterrupt:
    print("\nLab stopped.")
except (OSError, ValueError, UnicodeError, zipfile.BadZipFile) as exc:
    print("Could not prepare the simulator: " + str(exc), file=sys.stderr)
    raise SystemExit(1)
PYTHON
: <<'OBDII_PAYLOAD'
'''


def included_files():
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if any(part.startswith(".") or part == "__pycache__" for part in relative.parts):
            continue
        if path.is_symlink():
            raise ValueError("Source bundles cannot contain symlinks: " + str(relative))
        if not path.is_file() or path.suffix in {".pyc", ".pyo", ".zip"}:
            continue
        if relative.as_posix() in {"SHA256SUMS.txt", "CHANGELOG.md"}:
            continue
        yield path


def build(output):
    output = output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise ValueError("Choose an output folder outside the source tree.")
    output.mkdir(parents=True, exist_ok=True)
    paths = list(included_files())
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text("".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(ROOT).as_posix() + "\n" for path in paths), encoding="utf-8")
    paths.append(manifest)
    source_zip = output / "OBDII_Lab.zip"
    with zipfile.ZipFile(source_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths):
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2026, 11, 13, 0, 0, 0))
            info.create_system = 3
            executable = path.suffix == ".sh" or relative in {"run.py", "launcher.py"}
            info.external_attr = (stat.S_IFREG | (0o755 if executable else 0o644)) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    archive_bytes = source_zip.read_bytes()
    archive_hash = hashlib.sha256(archive_bytes).hexdigest()
    launcher = output / "run.sh"
    launcher.write_bytes(BOOTSTRAP.replace("@@ARCHIVE_SHA256@@", archive_hash).encode("utf-8") + base64.encodebytes(archive_bytes) + b"OBDII_PAYLOAD\n")
    launcher.chmod(0o755)
    result = {"source_files": len(paths), "archive_layout": "flat: run.sh, launcher.py and run.py at top level", "downloads": []}
    for path in (launcher, source_zip):
        result["downloads"].append({"name": path.name, "path": str(path), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    (output / "SHA256SUMS.txt").write_text("".join(item["sha256"] + "  " + item["name"] + "\n" for item in result["downloads"]), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT.parent / "OBDII_Downloads")
    build(parser.parse_args().output)
