#!/usr/bin/env python3
"""Build the recovered workbench guide. Authoring only: requires ReportLab.
The simulator itself uses the Python standard library and does not run this script.
"""
from pathlib import Path
import html
import json
import re
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'OBDII_Visual_Workbench.pdf'
DOCS = ROOT / 'docs'
FONTDIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Lab','DejaVuSans.ttf'),('Lab-Bold','DejaVuSans-Bold.ttf'),('Lab-Italic','DejaVuSans-Oblique.ttf'),('Lab-Mono','DejaVuSansMono.ttf')]:
    if (FONTDIR/file).exists(): pdfmetrics.registerFont(TTFont(name,str(FONTDIR/file)))
    else:
        raise RuntimeError('Guide authoring needs DejaVu Sans fonts; the lab runtime does not.')
pdfmetrics.registerFontFamily('Lab',normal='Lab',bold='Lab-Bold',italic='Lab-Italic',boldItalic='Lab-Bold')
W,H=A4
INK=colors.HexColor('#1c2b49'); SUB=colors.HexColor('#63748b'); LINE=colors.HexColor('#dce4ed')
BLUE=colors.HexColor('#3856b8'); CYAN=colors.HexColor('#087d98'); TEAL=colors.HexColor('#227569')
SOFT=colors.HexColor('#f3f7fc'); AMBER=colors.HexColor('#ab7934'); WHITE=colors.white
SOURCES=[
 ('1','OBD application','ISO 15031-5:2015 - Emissions-related diagnostic services','https://www.iso.org/standard/66368.html'),
 ('2','CAN diagnostic path','ISO 15765-4:2021 - Requirements for emissions-related systems','https://www.iso.org/standard/78384.html'),
 ('3','ISO-TP transport','Linux kernel documentation - ISO 15765-2','https://docs.kernel.org/networking/iso15765-2.html'),
 ('4','UDS application','ISO 14229-1:2026 - Application layer','https://www.iso.org/standard/87962.html'),
 ('5','Connector and legacy interfaces','Elm Electronics - ELM327 data sheet, v2.3; figures 8 and 9','https://elmelectronics.com/wp-content/uploads/2020/05/ELM327DSL.pdf'),
 ('6','Legacy ISO diagnostics','ISO 9141-2:1994 - Digital information interchange','https://www.iso.org/standard/16738.html'),
 ('7','K-line physical layer','ISO 14230-1:2012 - Diagnostic communication over K-Line','https://www.iso.org/standard/55591.html'),
 ('8','J1850 network','SAE J1850_202212 - Class B Data Communications Network Interface','https://saemobilus.sae.org/standards/j1850_202212-class-b-data-communications-network-interface'),
 ('9','Diagnostics over IP','ISO 13400-2:2025 - Transport protocol and network layer services','https://www.iso.org/standard/13400-2'),
 ('10','LIN physical layer','ISO 17987-4:2025 - Electrical physical layer specification','https://www.iso.org/standard/85128.html'),
]

CHAPTERS=[
 ('start','Start with one question', '''The recovered visual workbench starts from the attached v0.3.2 source and reconstructs the visual features described in the earlier conversation. It preserves the learning book, instruments, original handbook, learning guide and EngDoc worksheet. It is a new recovery build, not a byte-for-byte copy of a missing release.

Download the standalone `run.sh`, keep it in any folder, then run `bash run.sh` from that folder. Python 3.10 or newer is required. No pip installation, Node.js, CDN or online model download is needed to use the lab. Open `http://127.0.0.1:8765` if the browser does not open. Keep the terminal running; Ctrl+C stops the server and normally removes its temporary working directory.

If port 8765 is busy, run `bash run.sh --port 8766`. Use `bash run.sh --no-browser` to open the browser yourself. The optional source ZIP has a flat layout: `run.sh`, `launcher.py`, `run.py`, `obdii_lab/`, `web/` and `docs/` are at its root.

The training panel, transparent vehicle, protocol desk and object view refer to the same simulation. The learning book supplies guided explanations; instruments expose more signals. Begin with the coolant sensor experiment, establish a healthy reading, disconnect one connector, then advance time. Reconnect the wire before deciding whether memory also needs clearing.

A connector switch changes the topology immediately. Sensor sampling, fault timers and controller decisions change on subsequent simulation steps. Always compare before and after at known simulation times.'''),
 ('layers','The socket, network and question', '''DLC means diagnostic link connector: the physical access point with cavities and contacts. It does not name the diagnostic question. CAN is a vehicle network that carries identified frames. ISO-TP assembles an application payload that may need several CAN frames. OBD emissions services and UDS diagnostic services define what that payload asks or reports. [1-4]

The runnable path here is DLC CAN branch -> Classical CAN lesson frames -> ISO-TP -> selected OBD or UDS services. The scan-tool trace is a synthetic sequence, not a model of arbitration, bit timing or analog bus voltage. Functional OBD requests use teaching ID 7DF; the single simulated engine ECU uses physical request ID 7E0 and response ID 7E8. UDS examples use 7E0.

OBD is focused on emissions-related reporting. It does not imply that a generic engine query reads every brake or battery module. UDS offers a broader diagnostic service vocabulary and is independent of one particular data link. This lab implements only a small part of either application. [1,4]

ISO 9141-2 and ISO 14230/KWP2000 are legacy diagnostic families associated with K-line. J1850 has different PWM and VPW physical-layer variants. DoIP is a diagnostic route over IP. LIN is a local network for simpler nodes; it is not a synonym for an OBD port. These families have reference cards here, not running protocol engines. [5-10]'''),
 ('connectors','Inspect a socket and every wire', '''Select a component, then its socket or wire. Inspect both endpoints, the associated signal, its unit, connection status and whether the value is currently available. A missing measurement must remain missing rather than becoming a displayed zero. A zero speed is a possible measurement; an unavailable speed is a different state.

The DLC diagram is viewed into the vehicle-side connector, with the wide edge at the top. In this CAN lesson, pin 6 is CAN-H and 14 is CAN-L. Pins 4 and 5 are grounds; pin 16 is the supply contact. Legacy reference roles include J1850 on 2/10 and K/L-line on 7/15. Actual use is protocol- and vehicle-dependent. [5]

The ECU, sensor and battery-monitor sockets are invented teaching connectors. Their pin assignments, wire dimensions, resistances and nominal values are model properties, not production vehicle service specifications. The drawn routes and vehicle coordinates are also illustrative.

The diagnostic disconnection experiment isolates the tester's CAN branch. It does not remove the DLC supply contacts or break the complete internal vehicle bus. A network animation can stop on that branch while the engine model continues.

Wire scopes display the bound model quantity. For a coolant wire, that can be the modeled sensor-node voltage. For a CAN wire, the display can be a logical payload or message-age value. It is not a measured CAN-H or CAN-L voltage waveform.'''),
 ('sensor','Follow an open coolant circuit', '''The sensor lesson keeps three temperatures separate: physical coolant temperature, the sensor's reported temperature, and the temperature the controller uses. A temperature-sensitive resistance and a pull-up form an illustrative voltage divider. The controller samples the node through an idealized ADC.

With a healthy circuit, the model computes resistance, voltage and a temperature report. Disconnect the sensor connector and the circuit opens. The physical coolant does not jump to minus forty degrees. The diagnostic teaching report uses -40 degrees Celsius as an invalid-input marker; the controller can use a separate fallback value.

Advance time to let detection run. Read pending warnings with 07, stored warnings with 03, and the warning-lamp state with 01 01. P0118 describes the observed high-input circuit condition in this model; it does not prove a unique defective part.

Reconnect the sensor and advance again. A plausible input can return before stored fault memory clears. Clear the teaching engine memory with 04, then run and recheck. If the physical problem remains, detection can recur. Clearing memory does not repair a circuit.

This is a simplified educational detection cycle. The lab does not implement full regulatory drive cycles, permanent DTCs, all readiness monitors or a manufacturer's fault-confirmation strategy.'''),
 ('faults','Separate three kinds of missing information', '''No scan-tool reply: first ask 01 0C with the diagnostic branch connected. Disconnect DLC CAN and ask the identical question. The tester receives no application reply while the plant may continue evolving. Reconnect the branch and repeat the same request. Do not equate tester isolation with a stopped engine.

A stale battery-monitor message: use the hybrid profile. Establish healthy updates, disconnect the BMU CAN connector, and advance time. Compare message age, supervisor mode and battery permission. Reconnection restores the communication route and subsequent messages, but the protective shutdown can remain latched. Cycle the simulated ignition off and on, or reset the experiment, to start again with a cleared latch.

A missing front-left wheel signal: use the braking profile with initial motion. Disconnect the sensor, advance time, and compare physical wheel speed with measured speed. The wheel can keep rotating while the measured speed is unavailable. Watch the brake controller's degraded state. Reconnection restores input sampling after the next model update.

The four connector switches are independent. Existing fault-injection controls can also hold a fault active. If reconnecting a connector does not restore a value, inspect both the selected experiment and active input overrides. Reset is the clean way to return to the experiment's initial conditions.'''),
 ('requests','Read the bytes without losing the meaning', '''Choose a named question in the protocol desk. The request field contains application bytes only. The lab adds the ISO-TP length information, CAN identifier and padding for its trace.

For example, 01 0C asks for engine speed. A response 41 0C 0F A0 contains the value (256 x 0x0F + 0xA0) / 4 = 1000 rpm. The two application bytes in the request fit a single CAN frame; a longer synthetic VIN answer shows first, flow-control and consecutive frames. [3,5]

Available OBD examples include current sensor values, engine warning-lamp state, stored and pending emissions DTCs, clearing the teaching memory and a synthetic VIN. Modes 02, 06, 08 and 0A, broad ECU discovery and manufacturer-specific scan coverage remain outside this build.

UDS examples use physical address 7E0: 10 01 and 10 03 select the supported sessions, 22 F1 90 and 22 F1 87 read invented identification data, and 3E 00 demonstrates tester present. The extended session expires after five seconds of simulation time without a physical diagnostic request; tester present refreshes its timer. These functions do not imply support for vehicle flashing, security access, actuator tests or complete UDS conformance.

No response and a negative response mean different things. A disconnected branch may yield silence. A supported UDS path can return a negative-response payload for an unsupported or invalid request. Read the result explanation and frame trace together.'''),
 ('objects','Keep the model separate from the picture', '''The object view describes explicit parts rather than a single picture. A Component owns sockets. A Socket contains Pins. A Wire connects endpoints and identifies a signal binding. A Signal has a quantity, unit, value and validity. A Protocol gives meaning to exchanged bytes. A View renders those objects and responds to selection.

Stable identifiers join the layers. For example, coolant_sensor is a component, coolant_socket is a socket, ect_signal is a wire, and ect is the connector switch. The backend catalog describes structure and properties. The live network state describes availability and values. The model snapshot remains the authority for simulation time and physics.

Changes should flow through the model API. Do not infer a sensor fault solely from a red line in the renderer, and do not repair it by recoloring that line. The view sends a connector action, then paints the state returned by the server. This keeps the training panel, scope, vehicle and diagnostic desk consistent.

The backend entry points are network_catalog(), observe_network(snapshot) and Sim.set_connection(id, connected). Current switch IDs are ect, dlc, bmu and wheel_fl. A topology change becomes visible immediately; sampled effects occur as time advances.

The original Python API, local HTTP API and JSON-lines bridge remain useful for experiments. These are external simulation interfaces, not an instruction-set emulator or a hardware-in-the-loop system.'''),
 ('vehicle','Use the vehicle as another instrument', '''The transparent vehicle uses an offline WebGL2 renderer, with a Canvas 2D fallback where WebGL2 is unavailable. Drag to rotate, zoom, adjust body transparency and select parts. Wheel rotation follows physical simulated wheel speed; signal pulses follow simulation activity and pause with simulation time. Animated dots explain logical activity, not electron motion or bus timing.

The included editable asset is web/models/training_vehicle.glb, with web/models/vehicle_bindings.json. The local Load GLB control supports uncompressed embedded triangle geometry, node transforms and base colors. Named wheel_fl, wheel_fr, wheel_rl and wheel_rr nodes bind to the four physical wheels. The Load bindings JSON control accepts the matching node map. Imports are session-local: retain your asset files and load them again after restarting.

The lightweight importer does not support textures, skins, animation clips, Draco compression or external buffers. A model that needs those features belongs in a fuller renderer. Imported geometry is a visual replacement; it does not change the simulation's equations or make a vehicle-specific model.

A separate web/three-adapter.js supplies integration hooks for an installed Three.js scene graph. It does not bundle Three.js or GLTFLoader. A future full renderer can load a scene, resolve nodes by stable IDs, apply snapshot values and use the same selection and connection actions. See docs/VEHICLE_MODELS.md for the actual adapter contract.

Maintain separate physical and measured channels when adding an animation. The disconnected wheel sensor is the key test: physical wheel rotation should continue, while its measured-signal animation becomes unavailable.'''),
 ('scope','Record what happened and know the boundary', '''The working features are the generic engine, hybrid and braking models; four connector experiments; the object and wire catalog; live signal inspection; selected OBD services; and the small UDS identification/session set. The CAN/ISO-TP view is a teaching transcript. Legacy protocols, DoIP and LIN are reference material.

Use the CSV and JSON exports to retain signal history, and the diagnostic trace export to retain requests and replies. Record the profile, initial settings, connection state, input overrides and simulation time with any comparison. A screenshot alone cannot establish which physical and measured values produced the picture.

To add a component, give it a stable ID and explicit sockets/pins. Add the physical behavior or input model, define its observed signal and unit, decide when the signal is invalid or stale, expose a wire binding, and add a view node. Verify healthy behavior, loss of information and repair through the model API before adding visual polish.

All vehicle outputs and identifiers are synthetic. Vehicle geometry, module pinouts, parameter values and timers are educational assumptions. The build does not execute original ECU firmware, connect to a real vehicle, simulate every electrical effect or certify protocol conformance. The EngDoc worksheet remains a separate static circuit worksheet; full editor import and live synchronization are not established by this recovery.

The source package includes the validation record for the recovered build. That record distinguishes automated behavior checks, packaging checks and browser inspection. Follow the supplied launch instructions on Linux Mint; the user's particular Mint installation is a separate environment.'''),
]


def para(c,text,x,y,w,size=10.5,color=INK,font='Lab',leading=None):
    style=ParagraphStyle('p',fontName=font,fontSize=size,leading=leading or size*1.55,textColor=color,spaceAfter=0,allowWidows=0,allowOrphans=0)
    p=Paragraph(text,style); _,h=p.wrap(w,1000); p.drawOn(c,x,y-h)
    return y-h

def line(c,x,y,w,color=LINE):
    c.setStrokeColor(color);c.setLineWidth(.6);c.line(x,y,x+w,y)
def label(c,text,x,y,color=CYAN):
    c.setFont('Lab-Bold',8);c.setFillColor(color);c.drawString(x,y,text.upper())
def rounded(c,x,y,w,h,fill=SOFT,stroke=None,r=9):
    c.setFillColor(fill);c.setStrokeColor(stroke or fill);c.roundRect(x,y,w,h,r,fill=1,stroke=bool(stroke))
def card(c,title,body,x,y,w,color=BLUE,size=10.2):
    # y is top coordinate; derive box height from wrapped text.
    ps=ParagraphStyle('card',fontName='Lab',fontSize=size,leading=size*1.5,textColor=SUB)
    p=Paragraph(body,ps);_,h=p.wrap(w-32,1000);height=h+60
    rounded(c,x,y-height,w,height,SOFT,LINE)
    label(c,title,x+16,y-22,color);p.drawOn(c,x+16,y-42-h)
    return y-height

def bullet(c,items,x,y,w,size=10):
    for t in items:
        c.setFillColor(CYAN);c.circle(x+3,y-6,2.2,fill=1,stroke=0)
        y=para(c,t,x+15,y,w-15,size)-10
    return y

def table(c,headers,rows,x,y,widths,size=9.2):
    sty=ParagraphStyle('cell',fontName='Lab',fontSize=size,leading=size*1.45,textColor=INK)
    hsty=ParagraphStyle('head',fontName='Lab-Bold',fontSize=size-0.3,leading=size*1.4,textColor=WHITE)
    data=[[Paragraph(html.escape(str(a)),hsty) for a in headers]]
    for row in rows: data.append([Paragraph(str(a),sty) for a in row])
    t=Table(data,colWidths=widths,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('ROWBACKGROUNDS',(0,1),(-1,-1),[WHITE,SOFT]),('LINEBELOW',(0,1),(-1,-1),.5,LINE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8)]))
    _,h=t.wrap(sum(widths),1000);t.drawOn(c,x,y-h);return y-h

c=canvas.Canvas(str(OUT),pagesize=A4,pageCompression=1)
c.setTitle('OBD-II Visual Workbench - Recovered build guide')
c.setAuthor('OBD II Lab')
c.setSubject('Offline visual learning lab: sockets, wires, signals, diagnostic layers and model bindings')
c.showOutline()
page=0

def begin(title,eyebrow,key,subtitle=None):
    global page
    page+=1
    c.setFillColor(WHITE);c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(INK);c.rect(0,H-32,W,32,fill=1,stroke=0)
    c.setFont('Lab-Bold',8);c.setFillColor(WHITE);c.drawString(42,H-20,'OBD-II  /  VISUAL WORKBENCH')
    c.setFont('Lab',7.5);c.drawRightString(W-42,H-20,'RECOVERED BUILD 0.4.0')
    c.bookmarkPage(key);c.addOutlineEntry(title,key,0,False)
    label(c,eyebrow,42,H-65)
    y=para(c,title,42,H-83,W-84,25,INK,'Lab-Bold',31)-10
    if subtitle:y=para(c,subtitle,42,y,W-84,10.5,SUB)-18
    else:y-=12
    return y

def finish(min_y=0):
    if min_y and min_y<61: raise RuntimeError(f'Page {page} overflow: {min_y:.1f}')
    line(c,42,47,W-84)
    c.setFont('Lab',7.2);c.setFillColor(SUB);c.drawString(42,31,'Synthetic learning model  •  Offline by design')
    c.drawRightString(W-42,31,f'{page:02d} / 10')
    c.showPage()

def badge(c,text,x,y,w=110,color=TEAL):
    rounded(c,x,y-22,w,22,colors.HexColor('#eaf5f2'))
    c.setFont('Lab-Bold',8);c.setFillColor(color);c.drawCentredString(x+w/2,y-14,text)

# 1 / cover and route through the book
page+=1
c.setFillColor(INK);c.rect(0,0,W,H,fill=1,stroke=0)
c.bookmarkPage('cover');c.addOutlineEntry('Inside the diagnostic loop','cover',0,False)
label(c,'OBD II LAB  /  RECOVERY EDITION',44,H-57,colors.HexColor('#7cd0e1'))
y=para(c,'Inside the<br/>diagnostic loop.',42,H-96,W-84,41,WHITE,'Lab-Bold',49)
y=para(c,'A visual workbench for sockets, wires, signals<br/>and the questions a scan tool asks.',44,y-18,W-90,14,colors.HexColor('#b7c8df'),leading=22)
# A compact vehicle plan with physical parts and a separate tester.
ox,oy=55,321
c.setStrokeColor(colors.HexColor('#607ba1'));c.setLineWidth(1.2);c.setFillColor(colors.HexColor('#253b5b'))
p=c.beginPath();p.moveTo(ox+55,oy);p.curveTo(ox+20,oy+10,ox+15,oy+150,ox+45,oy+175);p.lineTo(ox+290,oy+175);p.curveTo(ox+325,oy+150,ox+325,oy+25,ox+295,oy);p.close();c.drawPath(p,fill=1,stroke=1)
c.setFillColor(colors.HexColor('#314e70'));c.roundRect(ox+115,oy+20,125,135,18,fill=1,stroke=0)
for xx in [ox+65,ox+265]:
 for yy in [oy-9,oy+164]:rounded(c,xx,yy,38,20,colors.HexColor('#0f203a'),None,5)
c.setLineWidth(2);c.setStrokeColor(colors.HexColor('#6fbccf'));c.line(ox+89,oy+88,ox+260,oy+88)
for xx,yy,ww,hh,txt,col in [(ox+35,oy+65,54,45,'ECU',colors.HexColor('#68b8cf')),(ox+260,oy+55,43,65,'BMU',colors.HexColor('#79a8c7')),(ox+155,oy+70,54,25,'DLC',colors.HexColor('#e0b273'))]:
 rounded(c,xx,yy,ww,hh,col,None,6);c.setFont('Lab-Bold',9);c.setFillColor(INK);c.drawCentredString(xx+ww/2,yy+hh/2-3,txt)
c.setStrokeColor(colors.HexColor('#dfae65'));c.setLineWidth(2);c.line(ox+182,oy+70,ox+182,oy-44);c.line(ox+182,oy-44,ox+390,oy-44)
rounded(c,ox+365,oy-72,85,56,colors.HexColor('#324e75'),None,7)
c.setFont('Lab-Bold',9);c.setFillColor(WHITE);c.drawCentredString(ox+407.5,oy-46,'SCAN TOOL');c.setFont('Lab-Mono',8);c.drawCentredString(ox+407.5,oy-61,'01 0C')
c.setFont('Lab',8);c.setFillColor(colors.HexColor('#a0b7d5'));c.drawString(ox+43,oy+188,'ILLUSTRATIVE GEOMETRY / SELECTABLE MODEL OBJECTS')
y=238
for num,title in [('01','Run a healthy baseline'),('02','Disconnect a single path'),('03','Observe, repair and recheck')]:
 c.setFillColor(colors.HexColor('#7cd0e1'));c.setFont('Lab-Mono',12);c.drawString(44,y,num)
 c.setFillColor(WHITE);c.setFont('Lab',12);c.drawString(82,y,title);y-=31
c.setFillColor(colors.HexColor('#b7c8df'));c.setFont('Lab',9);c.drawString(44,79,'Reconstructed from the attached source. Generic teaching models.')
c.drawString(44,63,'Python 3.10+  •  No additional runtime packages  •  9 November 2026')
c.setFont('Lab-Mono',8);c.drawRightString(W-44,44,'01 / 10');c.showPage()

# 2 / quick start
y=begin('Start with one question','01 / OPEN THE LAB','start','Use the visual views and instruments to examine the same deterministic experiment.')
y=card(c,'ONE-FILE LAUNCH','Save <b>run.sh</b> in any folder. In that folder, run <font name="Lab-Mono">bash run.sh</font>. Open <font name="Lab-Mono">http://127.0.0.1:8765</font> if needed. Keep the terminal open; <b>Ctrl+C</b> stops the lab.',42,y,W-84)-16
y=para(c,'Python 3.10 or newer is required. The lab runs offline without pip, Node.js or a CDN. The standalone launcher extracts its verified bundle into a temporary directory and normally removes it on shutdown.',42,y,W-84,10)-17
y=table(c,['View','Use it to...'],[
 ['Training panel','Select a component, socket, pin or wire; compare its live properties.'],
 ['Transparent vehicle','Locate the same parts and see physical motion and logical activity.'],
 ['Protocols & scan tool','Ask a named OBD/UDS question and inspect the reply.'],
 ['Object layers','Follow stable identifiers from component to socket, wire and signal.'],
 ['Learning book / Instruments','Read explanations, compare more channels and retain exports.']],42,y,[140,W-224],9.4)-18
y=para(c,'<b>First pass:</b> start a healthy coolant lesson. Read the sensor value. Disconnect the sensor, then advance time. Compare physical temperature, measured input, controller fallback and fault memory. Reconnect and run again.',42,y,W-84,10.2)-14
y=para(c,'<b>Launch options:</b> <font name="Lab-Mono">--port 8766</font> selects another port; <font name="Lab-Mono">--no-browser</font> leaves browser opening to you. The optional source ZIP has <font name="Lab-Mono">run.sh</font>, <font name="Lab-Mono">launcher.py</font> and <font name="Lab-Mono">run.py</font> at the top level.',42,y,W-84,9.3,SUB)-12
y=para(c,'<b>Timing rule:</b> a connector action changes topology immediately. Sampling, fault detection and control change on subsequent simulation steps. Watch simulation time, not elapsed wall time.',42,y,W-84,9.3,CYAN)
finish(y)

# 3 / layers
y=begin('The socket, network and question','02 / KEEP THE LAYERS DISTINCT','layers','A shared connector can carry several kinds of communication. Name each layer before diagnosing it.')
layer_rows=[('APPLICATION','OBD / UDS','What does the message ask or report?'),('TRANSPORT','ISO-TP','How does a longer message fit into CAN frames?'),('NETWORK','Classical CAN','Which identified frames carry the bytes?'),('PHYSICAL ACCESS','DLC, pins and wires','Which route connects the tester to the vehicle?')]
for i,(a,b,detail) in enumerate(layer_rows):
 h=64;rounded(c,42,y-h,W-84,h,SOFT if i%2 else colors.HexColor('#eef2fc'),LINE)
 label(c,a,57,y-20);para(c,b,57,y-29,148,13,INK,'Lab-Bold')
 para(c,detail,225,y-18,W-282,10,SUB);y-=72
y-=8
y=para(c,'<b>OBD</b> centers on emissions-related reporting. <b>UDS</b> provides a broader diagnostic service vocabulary, independent of one data link. A generic engine OBD query does not read every brake or battery observation. [1,4]',42,y,W-84,10)-16
y=table(c,['Family','Role in this recovered lab'],[
 ['OBD over CAN / ISO-TP','Runnable selected requests; 11-bit teaching IDs; synthetic frames.'],
 ['UDS over CAN / ISO-TP','Runnable identification and session examples at 7E0.'],
 ['ISO 9141-2 / KWP2000','K-line reference cards; no initialization or message engine.'],
 ['J1850 PWM / VPW','Legacy network reference cards; neither is CAN.'],
 ['DoIP / LIN','IP diagnostic route / local network reference cards.']],42,y,[175,W-259],9)-13
y=para(c,'The simulated trace does not model CAN arbitration, bit timing or analog waveforms. The primary references define the real protocol families; the lab declares a much smaller executable subset. [2,3,5-10]',42,y,W-84,9,SUB)
finish(y)

# 4 / pins and wires
y=begin('Inspect a socket and every wire','03 / CONNECTIONS YOU CAN FOLLOW','connectors','Select an endpoint, then follow its wire to a measured quantity and its validity.')
# DLC front view, wide edge uppermost.
dx,dy=76,y-151;dw,dh=W-152,142
c.setStrokeColor(INK);c.setLineWidth(1.6);c.setFillColor(SOFT)
p=c.beginPath();p.moveTo(dx,dy+dh);p.lineTo(dx+dw,dy+dh);p.lineTo(dx+dw-23,dy);p.lineTo(dx+23,dy);p.close();c.drawPath(p,fill=1,stroke=1)
active={4:('GND',SUB),5:('GND',SUB),6:('CAN-H',CYAN),14:('CAN-L',CYAN),16:('SUPPLY',AMBER)}
for idx in range(16):
 row=idx//8;col=idx%8;num=idx+1
 px=dx+32+col*(dw-64)/7;py=dy+103-row*64
 c.setFillColor(active.get(num,('',colors.HexColor('#d3dce9')))[1]);c.roundRect(px-12,py-8,24,15,3,fill=1,stroke=0)
 c.setFont('Lab-Bold',8);c.setFillColor(INK);c.drawCentredString(px,py+16,str(num))
 if num in active:c.setFont('Lab-Bold',6.1);c.setFillColor(active[num][1]);c.drawCentredString(px,py-23,active[num][0])
y=dy-18
y=para(c,'Vehicle-side DLC, looking into the contacts; wide edge at top. Highlighted cavities are the CAN lesson route. Legacy roles and populated pins vary with protocol and vehicle. [5]',65,y,W-130,8.8,SUB)-20
y=table(c,['Object','What to inspect'],[
 ['Component','Stable ID, physical purpose, sockets and position.'],
 ['Socket / Pin','Owner, contact number, contact function and connection state.'],
 ['Wire','Source and destination contacts, model properties, signal binding and unit.'],
 ['Signal','Value, availability and any stale or invalid state. Zero is not the same as missing.']],42,y,[115,W-199],9.5)-18
y=card(c,'A WIRE CAN DISPLAY DIFFERENT QUANTITIES','The coolant wire can show its modeled node voltage. A CAN wire can show a logical payload value or message age. Moving dots and scopes are <b>not measured CAN-H/CAN-L electrical waveforms</b>.',42,y,W-84,CYAN,9.8)-16
y=para(c,'ECU, sensor and BMU socket assignments, dimensions and wire values are invented teaching properties. The diagnostic disconnect isolates the tester CAN branch; it leaves DLC supply contacts and the internal vehicle network in place.',42,y,W-84,9.5,SUB)
finish(y)

# 5 / coolant
y=begin('Follow an open coolant circuit','04 / PHYSICS, MEASUREMENT AND CONTROL','sensor','A changed measurement does not instantly change the physical condition it was meant to describe.')
# Circuit drawing.
ytop=y;diagram_h=184;rounded(c,42,y-diagram_h,W-84,diagram_h,SOFT,LINE)
xx=160;top=y-32;bot=y-147;node=y-89
c.setStrokeColor(CYAN);c.setLineWidth(1.8);c.line(xx,top,xx,top-15);c.rect(xx-8,top-45,16,30,fill=0,stroke=1);c.line(xx,top-45,xx,node)
c.setFillColor(CYAN);c.circle(xx,node,3,fill=1,stroke=0);c.line(xx,node,xx,node-12);c.rect(xx-8,node-42,16,30,fill=0,stroke=1);c.line(xx,node-42,xx,bot)
for width,off in [(24,0),(16,5),(7,10)]:c.line(xx-width/2,bot-off,xx+width/2,bot-off)
c.line(xx,node,303,node);rounded(c,303,node-19,135,40,colors.HexColor('#e4eafb'),None,6)
c.setFillColor(INK);c.setFont('Lab-Bold',9);c.drawCentredString(370,node+3,'ADC / ECU input');c.setFont('Lab',8);c.drawCentredString(370,node-10,'sample and validate')
para(c,'Reference supply',xx+20,top+4,120,9,SUB);para(c,'Pull-up',xx+20,top-22,100,9,SUB);para(c,'Temperature-sensitive<br/>resistance',xx+20,node-19,110,8.5,SUB)
para(c,'Illustrative divider. Values come from the model parameters.',57,y-165,W-114,8,SUB)
y-=diagram_h+20
y=table(c,['Physical truth','Sensor report','Control decision'],[
 ['Coolant continues evolving through the plant heat model.','An open input becomes invalid; this lesson reports -40 °C as its marker.','The ECU can substitute a separate fallback and record a detected fault.']],42,y,[(W-84)/3]*3,9.3)-17
y=bullet(c,[
 '<b>Baseline:</b> connect the sensor, advance, then ask <font name="Lab-Mono">01 05</font>.',
 '<b>Inject:</b> disconnect <font name="Lab-Mono">ect</font> and advance in small steps. Read <font name="Lab-Mono">07</font>, <font name="Lab-Mono">03</font> and <font name="Lab-Mono">01 01</font>.',
 '<b>Repair:</b> reconnect and advance. The signal can recover while P0118 remains stored.',
 '<b>Recheck:</b> use <font name="Lab-Mono">04</font> after repair, run again, and read the warning lists.'
],42,y,W-84,10)-7
y=para(c,'P0118 is the model\'s circuit observation, not proof of a uniquely defective component. Detection timers, readiness and clearing semantics are simplified. Full drive cycles and permanent DTCs are outside the model.',42,y,W-84,9.3,SUB)
finish(y)

# 6 / other faults
y=begin('Separate missing information','05 / THREE MORE DIAGNOSTIC ROUTES','faults','Use the profile that contains the affected control loop, then compare the same evidence before and after.')
for n,title,text,note in [
 ('A','No scan-tool reply','Start with <b>01 0C</b>. Disconnect the <b>DLC CAN branch</b>, then repeat it. Observe no application reply while engine and vehicle control can continue. Reconnect and ask again.','The test isolates the diagnostic CAN branch. DLC supply and the internal network remain present.'),
 ('B','A battery message goes stale','Use the <b>hybrid profile</b>. Disconnect <b>BMU CAN</b> and advance. Compare message age, supervisor mode and battery permission. Reconnect to restore communication.','Protective shutdown can remain latched. Cycle simulated ignition off/on, or reset, to clear that latch.'),
 ('C','A wheel turns without a reading','Use the <b>braking profile</b> with initial motion. Disconnect the <b>front-left wheel sensor</b>. Compare physical wheel speed with unavailable measured speed and controller degradation.','The wheel continues obeying the plant. Reconnection restores its measurement after the next sampling update.')]:
 y=card(c,n+' / '+title,text,42,y,W-84,CYAN,10)-8
 y=para(c,note,57,y,W-114,9,SUB)-23
y=para(c,'<b>One clean comparison:</b> record profile, inputs, connection states and simulation time. The connector switches are independent. A separate active fault override can still hold a fault after a connector is repaired; inspect overrides or reset the experiment.',42,y,W-84,10)
finish(y)

# 7 / requests
y=begin('Read the bytes and the meaning','06 / ASK, DECODE, COMPARE','requests','Named questions are the easiest entry point. Application bytes and transport frames are separate views of the exchange.')
y=table(c,['Request','Question / action','Address'],[
 ['01 05 / 01 0C / 01 0D','Coolant / engine rpm / vehicle speed','7DF'],
 ['01 01 / 01 00','Warning lamp & monitor / supported PIDs','7DF'],
 ['03 / 07 / 04','Stored / pending / clear teaching engine memory','7DF'],
 ['09 02','Read invented VIN; see a longer reply','7DF'],
 ['22 F1 90 / 22 F1 87','UDS synthetic VIN / lab part identifier','7E0'],
 ['10 01 / 10 03 / 3E 00','UDS default / extended session / tester present','7E0']],42,y,[142,280,W-506],8.9)-19
y=card(c,'EXAMPLE / A 1000 RPM ANSWER','Application request: <font name="Lab-Mono">01 0C</font><br/>Application response: <font name="Lab-Mono">41 0C 0F A0</font><br/>Decode: <font name="Lab-Mono">(256 x 15 + 160) / 4 = 1000 rpm</font>',42,y,W-84,BLUE,10)-16
y=table(c,['Direction','CAN ID','Single-frame data'],[
 ['Tester to ECU','7DF','02 01 0C 00 00 00 00 00'],
 ['ECU to tester','7E8','04 41 0C 0F A0 00 00 00']],42,y,[110,65,W-259],9.2)-15
y=para(c,'The first frame byte above is ISO-TP length information. It is <b>not</b> part of the OBD application request. Long replies use first (FF), flow-control (FC) and consecutive (CF) frames; short replies use a single frame (SF). [3,5]',42,y,W-84,9.7)-16
y=para(c,'<b>Silence is different from rejection.</b> No response can mean an isolated branch or an unsupported destination. A UDS negative response is an actual reply. Read the result explanation and frame trace together.',42,y,W-84,9.7)-13
y=para(c,'This build does not include full OBD/UDS coverage, programming, security access or actuator tests. The extended UDS session expires after 5 s of simulation time without a physical request. VIN and part identity are invented; one diagnostic ECU is modeled.',42,y,W-84,9.1,SUB)
finish(y)

# 8 / object + vehicle
y=begin('Connect objects to a 3D view','07 / A MODEL THAT CAN GROW','objects','Keep physical behavior, observed signals, protocol messages and rendering separate.')
y=table(c,['Layer','Stable identity / responsibility'],[
 ['Component','coolant_sensor: purpose, sockets, position and model connection.'],
 ['Socket and pin','coolant_socket: owner and numbered contacts.'],
 ['Wire and signal','ect_signal: two endpoints, quantity, unit and validity.'],
 ['Connection action','ect: the switch used by Sim.set_connection(id, connected).'],
 ['Live observation','network_catalog() describes structure; observe_network(snapshot) describes live availability and values.']],42,y,[135,W-219],9.3)-18
y=para(c,'The view sends an action, then paints the returned model state. Recoloring a wire does not repair a connection. Physical wheel speed and measured wheel speed must stay separate; that distinction should survive any future renderer.',42,y,W-84,10)-18
label(c,'TRANSPARENT VEHICLE / INCLUDED SUPPORT',42,y);y-=16
y=para(c,'The offline <b>WebGL2 renderer</b> has a Canvas 2D fallback. Rotate, zoom, change body opacity and select parts. Wheel motion and logical signal activity follow simulation state. The included asset is <font name="Lab-Mono">web/models/training_vehicle.glb</font> with a separate bindings JSON.',42,y,W-84,9.8)-15
y=card(c,'LOCAL MODEL IMPORT','The small importer supports <b>uncompressed embedded triangle geometry, node transforms and base colors</b>. It does not load textures, skins, animation clips, Draco data or external buffers. Use named <font name="Lab-Mono">wheel_fl/fr/rl/rr</font> nodes to bind the four physical wheels.',42,y,W-84,CYAN,9.5)-17
y=para(c,'<b>Three.js readiness:</b> <font name="Lab-Mono">web/three-adapter.js</font> supplies hooks for an installed Three.js scene graph. Three.js and GLTFLoader are not bundled. Imports are session-local; retain the GLB and bindings JSON for the next launch. The adapter preserves node IDs and simulation bindings. See <font name="Lab-Mono">docs/VEHICLE_MODELS.md</font>.',42,y,W-84,9.4,SUB)
finish(y)

# 9 / scope
y=begin('Record evidence and extend carefully','08 / WHAT THIS BUILD ESTABLISHES','scope','A visible animation is useful when you can trace it back to an explicit model state.')
y=table(c,['Runs in the lab','Explained or outside this build'],[
 ['Generic engine, hybrid and braking models','Production vehicle equations or original ECU firmware'],
 ['Four independent connector experiments','Complete harness, transceiver or analog network simulation'],
 ['Selected OBD services and small UDS subset','All services, multiple diagnostic ECUs or conformance testing'],
 ['Synthetic Classical CAN / ISO-TP transcript','CAN arbitration, bit timing, real waveform measurement'],
 ['Offline vehicle rendering and limited local GLB import','Full Three.js asset pipeline or vehicle-specific geometry'],
 ['Legacy protocol, DoIP and LIN reference cards','Running K-line, J1850, DoIP or LIN protocol engines']],42,y,[247,W-331],9.2)-20
label(c,'KEEP A REPEATABLE RECORD',42,y);y-=16
y=para(c,'Export signal <b>CSV</b>, full run <b>JSON</b> and the diagnostic <b>trace</b>. Keep profile, initial settings, input overrides, connection states and simulation time with the evidence. A screenshot alone cannot explain the state that generated it.',42,y,W-84,10)-20
label(c,'ADD THE BEHAVIOR BEFORE THE ANIMATION',42,y);y-=16
y=bullet(c,[
 'Define a stable component ID, sockets, pins and wire endpoints.',
 'Implement the physical or sensor behavior; expose a quantity, unit and validity.',
 'Verify healthy input, loss of input and repair through the model API.',
 'Bind the renderer to the returned state and preserve separate physical and measured channels.'
],42,y,W-84,9.7)-8
y=para(c,'The recovered source includes its validation record. Runtime checks, packaging checks and browser inspection are distinct from testing the user\'s particular Linux Mint installation. The preserved EngDoc file is a static circuit worksheet; full editor import and live synchronization remain unverified.',42,y,W-84,9.1,SUB)
finish(y)

# 10 / sources and definitions
y=begin('References and useful words','09 / GO DEEPER','references','Primary references checked 9 November 2026. They describe real standards; this lab implements its stated teaching subset.')
for number,role,title,url in SOURCES:
 y=para(c,f'<b>[{number}] {html.escape(role)}</b> - {html.escape(title)}',42,y,W-84,8.3)-3
 y=para(c,f'<link href="{html.escape(url,quote=True)}" color="#3856b8">{html.escape(url)}</link>',42,y,W-84,7.2,BLUE,leading=10)-11
y-=4
line(c,42,y,W-84);y-=19
label(c,'SMALL GLOSSARY',42,y);y-=14
y=table(c,['Term','Meaning'],[
 ['ECU / BMU','Electronic control unit / battery monitor unit.'],
 ['DLC / DTC','Diagnostic link connector / diagnostic trouble code.'],
 ['PID / DID','OBD parameter identifier / UDS data identifier.'],
 ['Invalid / stale / stored','Untrustworthy now / too old / retained as fault memory.']],42,y,[116,W-200],8.5)
finish(y)
c.save()

# Reusable complete text sources: Markdown for the learning-book importer and
# HTML with a persistent left-hand chapter outline for an ordinary browser.
md=['# OBD-II Visual Workbench','', 'Recovered build 0.4.0 | 9 November 2026','',
    'A practical guide to the offline training panel, transparent vehicle, connections, protocols and model bindings.','']
for key,title,body in CHAPTERS:md.extend(['## '+title,'',body,''])
md.extend(['## Primary references','', 'Checked 9 November 2026. These sources establish protocol roles; the lab implements only its documented teaching subset.',''])
for number,role,title,url in SOURCES:md.append(f'- [{number}] {role}: [{title}]({url}).')
(DOCS/'VISUAL_WORKBENCH.md').write_text('\n'.join(md)+'\n',encoding='utf-8')

def text_html(text):
    out=html.escape(text)
    return re.sub(r'`([^`]+)`',r'<code>\1</code>',out)
sections='\n'.join('<section id="'+key+'"><span class="chapter">CHAPTER '+str(i+1).zfill(2)+'</span><h2>'+html.escape(title)+'</h2>'+''.join('<p>'+text_html(p)+'</p>' for p in body.split('\n\n'))+'</section>' for i,(key,title,body) in enumerate(CHAPTERS))
source_html=''.join('<li id="ref-'+n+'"><strong>['+n+'] '+html.escape(role)+'</strong><br/><a href="'+html.escape(url,quote=True)+'" target="_blank" rel="noopener noreferrer">'+html.escape(title)+'</a><small>'+html.escape(url)+'</small></li>' for n,role,title,url in SOURCES)
nav=''.join('<a href="#'+key+'"><b>'+str(i+1).zfill(2)+'</b> '+html.escape(title)+'</a>' for i,(key,title,_) in enumerate(CHAPTERS))
css='''*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#f3f6fa;color:#1c2b49;font:15px/1.8 system-ui,-apple-system,"Segoe UI",sans-serif}header{background:#1c2b49;color:white;padding:18px 30px;font-size:12px;letter-spacing:1px}header a{color:#b9d9e8;text-decoration:none;margin-right:25px}.layout{max-width:1280px;margin:30px auto;padding:0 28px;display:grid;grid-template-columns:270px minmax(0,1fr);gap:26px;align-items:start}nav{position:sticky;top:24px;background:white;border:1px solid #dce4ed;border-radius:11px;padding:22px 14px;max-height:calc(100vh - 48px);overflow:auto}nav h2{margin:0 10px 15px;font-size:16px;line-height:1.3}nav p{font-size:11px;color:#8b98ac;margin:0 10px 16px}nav a{display:block;color:#60718a;text-decoration:none;font-size:12px;line-height:1.5;padding:10px;border-radius:6px}nav a:hover{background:#eef3fc;color:#3856b8}nav a b{color:#a3b5cf;font:11px ui-monospace,monospace;margin-right:6px}main{min-width:0;background:white;border:1px solid #dce4ed;border-radius:12px;padding:40px 48px}h1{font-size:39px;line-height:1.15;letter-spacing:-1.2px;margin:10px 0 18px}h2{font-size:26px;line-height:1.3;letter-spacing:-.6px;margin:8px 0 20px}.lede{font-size:17px;color:#74859b}.chapter{font-size:10px;letter-spacing:1.5px;font-weight:700;color:#087d98}section{scroll-margin-top:24px;margin-top:42px;padding-top:30px;border-top:1px solid #dce4ed}p{margin:14px 0;color:#566983}code{font:12px/1.6 ui-monospace,Consolas,monospace;background:#eef3fa;color:#3856b8;border-radius:4px;padding:2px 5px;overflow-wrap:anywhere}a{color:#3856b8}ul{padding-left:20px}li{margin:18px 0;color:#657790}small{display:block;font-size:10px;overflow-wrap:anywhere}.notice{border-left:3px solid #d5a153;background:#fff9ed;color:#9a7a47;padding:15px 20px;font-size:12px;margin-top:25px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin:24px 0}.actions a{border:1px solid #cbd9ed;border-radius:6px;padding:8px 12px;text-decoration:none;font-size:12px}.stack{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:25px 0}.stack div{background:#f1f5fb;border:1px solid #dce5f1;padding:15px;border-radius:7px}.stack span{display:block;font-size:9px;letter-spacing:1px;color:#6d83a4}.stack b{font-size:13px}.stack p{font-size:11px;line-height:1.6;margin:5px 0}.table{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:11px}th{background:#1c2b49;color:white;text-align:left}th,td{padding:9px;border-bottom:1px solid #dce4ed;vertical-align:top}@media(max-width:800px){.layout{grid-template-columns:1fr;padding:0 16px}nav{position:static;max-height:none}nav a{display:inline-block}main{padding:27px 23px}h1{font-size:31px}header{padding:17px}.stack{grid-template-columns:1fr}}@media print{nav,header,.actions{display:none}.layout{display:block;padding:0;margin:0}main{border:0;padding:0}body{background:white}section{break-inside:avoid}a{color:inherit}}'''
stack='<div class="stack"><div><span>PHYSICAL ACCESS</span><b>DLC, pins and wires</b><p>Contacts make an available route.</p></div><div><span>NETWORK</span><b>CAN frames</b><p>Identifiers and bytes travel through the route.</p></div><div><span>TRANSPORT</span><b>ISO-TP</b><p>A longer payload is split and reassembled.</p></div><div><span>APPLICATION</span><b>OBD or UDS</b><p>The payload asks a diagnostic question.</p></div></div>'
page_html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Visual Workbench - OBD II Lab</title><style>'+css+'</style></head><body><header><a href="/">OPEN THE LAB</a> OBD-II / VISUAL WORKBENCH GUIDE</header><div class="layout"><nav aria-label="Guide chapters"><h2>Follow the diagnostic loop.</h2><p>RECOVERED BUILD 0.4.0</p>'+nav+'<a href="#references"><b>10</b> Primary references</a></nav><main><span class="chapter">SOCKETS / WIRES / SIGNALS / DIAGNOSTICS</span><h1>Inside the diagnostic loop.</h1><p class="lede">Learn how a physical change becomes an input, a control decision and a diagnostic answer.</p><div class="actions"><a href="/">Open workbench</a><a href="/OBDII_Visual_Workbench.pdf">Download reading copy</a></div>'+stack+'<div class="notice">Reconstructed from the attached earlier source. Vehicle models, ordinary module connectors, geometry and identifiers are synthetic. This is an offline learning instrument.</div>'+sections+'<section id="references"><span class="chapter">PRIMARY REFERENCES</span><h2>Standards and implementation notes</h2><p>Checked 9 November 2026. These sources establish protocol roles; the lab implements only its documented teaching subset.</p><ol>'+source_html+'</ol></section></main></div></body></html>'
(DOCS/'VISUAL_WORKBENCH.html').write_text(page_html,encoding='utf-8')
(DOCS/'PROTOCOLS_REFERENCE.json').write_text(json.dumps({'checked':'2026-11-09','scope':'Teaching subset; no conformance claim','sources':[{'id':n,'role':role,'title':title,'url':url} for n,role,title,url in SOURCES]},indent=2)+'\n')
print(json.dumps({'pdf':str(OUT),'pages':page,'markdown':str(DOCS/'VISUAL_WORKBENCH.md'),'html':str(DOCS/'VISUAL_WORKBENCH.html')},indent=2))
